# Auditoría de compatibilidad RC6 → English graphics-a9

Fecha: 2026-08-26

## Alcance

Solo se valida la traducción inglesa `v0.10.7-graphics-a9`. La ROM japonesa y
la rama RC7 están expresamente fuera de alcance.

## Identidad de entradas

| Archivo | SHA-256 |
|---|---|
| RC6 histórica congelada | `07cc489d671b979dba31a72830591b11a5d460c90c4f84e08f74a1df9d344041` |
| Base inglesa graphics-a9 | `27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6` |
| IPS fuente graphics-a9 aportado | `9a1bf3430a4e213eb10d3a1f340532dc43f4a7554fad83821263c21bef9e9cb5` |

## Compatibilidad binaria

El constructor recupera la base inglesa histórica exacta desde RC6 y calcula
su delta sin incluir el checksum. Ese delta contiene 1.959 posiciones.

- Conflictos con graphics-a9: **0**.
- Hooks con instrucciones originales esperadas: **7/7**.
- Cueva `35C8A0h` disponible: **PASS**.
- Bloque de tiles RC6 `0C3h–0CCh` vacío antes del parche: **PASS**.
- Tiles RC6 sin referencias previas en ambos mapas del título: **PASS**.
- Diez celdas superiores de Screen2 libres: **PASS**.
- Bloque gráfico usado por RC7 `2FF040h–2FF13Fh` sin modificar: **PASS**.
- Traducción A9 preservada fuera del delta RC6: **PASS**.

El IPS final contiene 167 registros y 1.961 bytes efectivos, incluyendo los
dos bytes del checksum WonderSwan.

## Mesen 2.1.1 — título

Cuadros nativos auditados: 540, 570 y 600.

- Texto `CHIP CONTROL` visible en `(2,1)`: **PASS**.
- Tipografía 5×6 y sombra de RC6: **PASS**.
- Doble búfer Screen2 (`2800h`/`3000h`): **PASS**.
- Tilemap y gráficos idénticos en los tres cuadros: **PASS**.
- Sin bloques, repetición de glifos ni corrupción del logotipo: **PASS**.

Evidencia: `docs/evidence/mesen_v058_rc6_en_a9_title/`.

## Mesen 2.1.1 — batalla

La prueba parte de `NEW GAME`, navega con controles normales y llega a una
Free Battle sin modificar RAM.

- Batalla real y video packed `E0h`: **PASS**.
- Y1/Up2 llega a `CE46=0100h`: **PASS**.
- AP/SP y píxeles estables durante 120 cuadros: **PASS**.
- Celda superior derecha sin titileo: **PASS**.
- AP blanco con glifo negro visible: **PASS**.
- Navi nunca reemplazado: **PASS**.
- Liberar Y1 restaura los iconos: **PASS**.
- Paleta 14 y SRAM sin cambios: **PASS**.
- Pausa de revelado: 150 cuadros (~1,99 s): **PASS**.

Evidencia: `docs/evidence/mesen_v058_rc6_en_a9_battle/`.

Núcleo utilizado: Mesen 2.1.1 `MesenCore.so`, SHA-256
`36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9`.

## Resultado

La RC6 es compatible con la ROM inglesa graphics-a9 mediante el IPS dedicado
de esta entrega. No debe utilizarse el IPS histórico para v0.10.7 ni ningún
archivo RC7.
