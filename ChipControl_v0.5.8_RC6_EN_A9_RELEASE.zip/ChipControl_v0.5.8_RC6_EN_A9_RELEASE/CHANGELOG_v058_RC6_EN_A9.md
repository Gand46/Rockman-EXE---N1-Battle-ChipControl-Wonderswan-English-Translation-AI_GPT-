# v0.5.8 RC6 English-A9 compatibility build

- Se descartó por completo la rama RC7.
- Se tomó como única referencia funcional la ROM congelada v0.5.8 RC6,
  SHA-256 `07cc489d671b979dba31a72830591b11a5d460c90c4f84e08f74a1df9d344041`.
- Se auditó la nueva base inglesa graphics-a9, SHA-256
  `27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6`.
- Los 1.959 bytes funcionales RC6 tienen cero solapamientos con las
  modificaciones de graphics-a9.
- Se generó un IPS nuevo y exclusivo para graphics-a9.
- La tipografía, posición, paleta y tiles del rótulo son exactamente los de
  RC6 (`0C3h–0CCh`); no se usan los recursos gráficos RC7.
- Título y batalla pasaron validación nativa en Mesen 2.1.1.
- Salida final SHA-256:
  `18aa0fe6af0e49d37f135768d748941800480c2c385ddbd5ad08290d483a78e0`.
