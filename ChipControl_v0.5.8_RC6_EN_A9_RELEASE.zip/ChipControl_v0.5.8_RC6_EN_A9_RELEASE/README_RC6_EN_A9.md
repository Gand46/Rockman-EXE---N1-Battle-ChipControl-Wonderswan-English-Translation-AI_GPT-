# Chip Control v0.5.8 RC6 — English graphics-a9

Esta entrega conserva la implementación congelada de **v0.5.8 RC6** y la
porta a la traducción inglesa actualizada
`Rockman EXE N1 Battle English v0.10.7-graphics-a9`.

La rama RC7 fue descartada. Este proyecto no reutiliza su ROM, sus IPS, su
asignación alternativa de tiles ni sus gráficos.

## Archivos principales

- ROM final:
  `Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9_ChipControl_v0.5.8_RC6.wsc`
- IPS completo:
  `patches/ChipControl_v0.5.8_RC6_for_English_v0.10.7-graphics-a9.ips`
- Constructor:
  `tools/build_v058_rc6_en_a9.py`
- Prueba de compatibilidad:
  `tests/test_v058_rc6_en_a9.py`
- Auditoría:
  `docs/COMPATIBILITY_AUDIT_RC6_EN_A9.md`

## Base exacta admitida

El IPS de Chip Control se aplica únicamente a la ROM inglesa A9 con SHA-256:

`27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6`

El resultado correcto tiene SHA-256:

`18aa0fe6af0e49d37f135768d748941800480c2c385ddbd5ad08290d483a78e0`

No se debe aplicar sobre la antigua v0.10.7, sobre RC7 ni sobre la ROM
japonesa.

## Validación realizada

- Cero conflictos entre las 1.959 escrituras funcionales RC6 y graphics-a9.
- Siete hooks y payload de batalla idénticos a RC6.
- Rótulo `CHIP CONTROL` idéntico a RC6, estable en tres cuadros de título.
- Recorrido real en Mesen 2.1.1 desde `NEW GAME` hasta Free Battle.
- Y1/AP/SP estables durante 120 cuadros, sin titileo.
- Navi intacto e iconos restaurados al liberar Y1.
- Paleta y SRAM sin cambios.
- Pausa enemiga medida en 150 cuadros, aproximadamente 1,99 segundos.
- IPS reconstruye byte por byte la ROM final.
- Cero escrituras en el bloque gráfico introducido y luego descartado con RC7.

## Compilación

En Windows puede ejecutarse `43_BUILD_RC6_EN_A9.bat` después de colocar la ROM
base A9 exacta con el nombre documentado. El constructor valida los hashes de
entrada y salida; si la base no coincide, se detiene sin generar una ROM.

La base limpia aportada por el usuario se conserva solo en el workspace de
validación y se excluye del ZIP de desarrollo.
