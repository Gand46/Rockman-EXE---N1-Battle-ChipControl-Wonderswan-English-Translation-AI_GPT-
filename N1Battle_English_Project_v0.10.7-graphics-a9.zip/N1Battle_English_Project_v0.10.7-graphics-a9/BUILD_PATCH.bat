@echo off
setlocal

if "%~1"=="" goto :usage

set "PROJECT=%~dp0"
set "SOURCE_ROM=%~1"

if not exist "%PROJECT%build" mkdir "%PROJECT%build"

py -3 "%PROJECT%tools\n1tool.py" build "%SOURCE_ROM%" "%PROJECT%translation\en_v0_10_7_graphics_a9.json" "%PROJECT%build\Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.wsc" --table "%PROJECT%tables\n1battle_jp.tbl" --ips "%PROJECT%patches\Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.ips" --report "%PROJECT%build\build_v0_10_7_graphics_a9.json"
if errorlevel 1 exit /b %errorlevel%

echo.
echo Build terminado. La ROM de prueba esta en la carpeta build.
exit /b 0

:usage
echo Uso: BUILD_PATCH.bat "ROM japonesa Rev 1.wsc"
exit /b 2
