# Graphics Advance 7 — centrado de `1 MONTH LATER...`

## Resultado

El intertítulo auxiliar `1 MONTH LATER...` queda centrado en la pantalla nativa
de 224×144. La cadena ocupa 16 celdas de 8 píxeles, por lo que su tramo lógico
mide 128 píxeles y debe comenzar en `x=(224−128)/2=48`, columna 6. El tramo
final `[48,176)` tiene centro exacto `x=112`.

## Localización ejecutable

Una ruta determinista desde arranque limpio sitúa la primera escritura del
mapa en el fotograma 2537 y la primera imagen visible en el 2542. La traza
relaciona el registro auxiliar `0x10`, destino ROM `0x34AE1A`, con la llamada
del estado `0x0D`:

- PC físico: `0x2A6F7`.
- Offset ROM: `0x32A6F7`.
- Antes: `6A 0B` (`PUSH 11`).
- Después: `6A 06` (`PUSH 6`).
- El argumento vertical continúa siendo fila 8.

No se añaden espacios a la cadena ni se modifica el renderizador compartido.
El texto codificado, su puntero, la fuente, los tiles, las paletas, los mapas
persistentes y el fondo permanecen byte a byte idénticos al Avance 6.

## Validación

- Base A6: `9b135e34db6b20d8135c79476bd72a7118500e176ee8f5eee3c0c99fe3bb333b`.
- ROM A7 privada: `e049ce549ddbbe695995cc7c76863a201e22199e064daaa24f2e542dcedaf9fa`.
- IPS acumulativo: `26f612898f1bc8755324c5e6335c4581d3e8b19cd58fee46e9817eeff1d7ef86`.
- Checksum WonderSwan almacenado/calculado: `0xB4F6 / 0xB4F6`.
- Delta frente a A6: un byte del argumento `x` y un byte del checksum; cero
  bytes fuera de la lista blanca.
- La máscara conserva 269 píxeles y se traslada exactamente `(-40,0)`; su caja
  visible pasa de `[89,66,210,78]` a `[49,66,170,78]`.
- Los fotogramas no objetivo 2300, 2960 y 3200 coinciden byte a byte con A6.
- El IPS y el manifiesto reconstruyen exactamente la misma ROM que el
  generador directo basado en A6.

La prueba utiliza MesenCore a 224×144 desde un directorio nuevo, sin SAV,
savestate, filtros ni escalado. El cierre acumulativo aplica las 27 reglas y
queda registrado en `build/graphics_advance_rules_validation.json`.
