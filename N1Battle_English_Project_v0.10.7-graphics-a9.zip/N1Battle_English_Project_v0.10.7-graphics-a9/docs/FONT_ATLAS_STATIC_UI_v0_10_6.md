# Auditoría TTF y retoque de pixel art — v0.10.6

## Método aplicado

Esta revisión vuelve a construir 25 rótulos gráficos desde los dos TTF
suministrados y corrige manualmente sus máscaras problemáticas a resolución
nativa. FreeType fija familia, tamaño y proporción; después, 70 variantes de
glifo reciben máscaras deterministas de pixel art cuando el hinting pequeño
rompe trazos, cierra contraformas o deja diagonales irregulares. No se escala
un atlas PNG ni se comprimen líneas completas. El resultado se convierte a
tiles WonderSwan de 8×8 packed 4-bpp.

| Fuente maestra | Aplicación |
|---|---|
| `BN5DSEU Font Thin.ttf` | PET, SHOP, SAVE y banners largos |
| `SF3FontSmall.ttf` | Encabezados y controles del teclado, `BACK` y `STREAK` |

Los archivos TTF se verifican por SHA-256 durante la generación, pero no se
incluyen en el paquete público. Solo se distribuyen los gráficos nativos
rasterizados.

| Grupo | Rótulos |
|---|---:|
| Teclado `ENTRY NAME` | 7 |
| Banners del carrusel | 4 |
| Menú raíz PET, incluido `CLASS` | 6 |
| Pantalla SAVE | 4 |
| Interior de SHOP | 3 |
| Contador de racha Free Battle | 1 |
| **Total** | **25** |

## Composición y capacidad

Todos los rótulos conservan al menos una columna de separación tanto entre
caras como entre compuestos. Las sombras que avanzaban hacia la derecha se
sustituyeron por una sombra inferior de un píxel, por lo que ya no consumen el
separador. No se emplean antialiasing, filtros bilineales/bicúbicos, remuestreo
ni condensación posterior.

- PET utiliza exactamente sus 63 patrones seguros. `Program Deck`, `Chip
  Folder`, `Data Library`, `NetNavi`, `Save` y `CLASS` caben en sus campos sin
  invadir cursor, marco, rango `E` ni `3000Z`.
- SHOP utiliza 22 de sus 23 patrones disponibles para `1 Chip`, `10 Chips` e
  `Info`, sin tocar precios ni Zenny; queda un patrón seguro libre.
- SAVE utiliza 44 patrones auditados y mantiene intactos `6/108`, `71` y
  `3000z`.
- Las máscaras OBJ `LOW`, `CAP` y `ABC` se generan desde los mismos glifos del
  mapa. El validador usa los IDs vivos de cada página, incluidos los IDs
  específicos del nuevo mapa `ABC`.

## Elementos protegidos

- Cuadros de diálogo inferiores, sus cadenas y su fuente dinámica.
- `E`, `3000Z`, precios, contadores y otros datos generados en ejecución.
- Marcos, cursores, prioridades y bits de paleta.
- Contador numérico de Free Battle; solo cambia el rótulo estático `STREAK`.
- Efectos de seis caracteres de v0.10.5, incluido `NODATA`.
- Portada y logotipo de v0.10.4.

La generación produce 20 reemplazos gráficos completos guardados por hash. Un
vigésimo primer span corrige por separado `A CLASS`–`E CLASS` a `A CLS`–`E
CLS` dentro de sus slots existentes: no mueve punteros y libera las columnas
BG que ocultaban el icono verde en BATTLE CHIP GP. La composición no escribe
fuera de esos 21 rangos ni de los dos bytes del checksum WonderSwan.
