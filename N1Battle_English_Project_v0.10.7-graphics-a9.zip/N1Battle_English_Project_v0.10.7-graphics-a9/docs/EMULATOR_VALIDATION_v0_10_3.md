# Validación de emulador v0.10.3

Estado: **PASS**.

La ROM privada final tiene SHA-256
`eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc`
y checksum WonderSwan almacenado/calculado `0xAFC4 / 0xAFC4`.

Las tres rutas se ejecutaron mediante MesenCore desde arranques limpios, sin
SAV ni savestate, y produjeron capturas nativas de 224×144.

## Portada

| Comprobación | Resultado |
|---|---|
| Frames 450 y 550 del parpadeo de `PRESS START` | PASS |
| Transición real mediante START a `NEW GAME / CONTINUE`, frame 900 | PASS |
| Tiles, mapa, cinco paletas, fondo y aviso vivos iguales a sus activos | PASS |
| Núcleo opaco del logo estable entre ambos estados | PASS, 0 cambios en filas 0–101 |
| 384 píxeles retirados ya no forman una capa estática del logo | PASS |
| Separación entre logo y `PRESS START` | PASS, 0 píxeles superpuestos |
| Resolución de las tres capturas | PASS, 224×144 |

El maestro limpio contiene 10.680 píxeles opacos y termina en `y=102`.
Los 30 cambios observados sobre píxeles opacos de esa última fila corresponden
exclusivamente a la sombra intermitente de `PRESS START`; el frame oculto
coincide al 100 % con el maestro. El primer píxel blanco del aviso aparece en
`y=103`.

Capturas:

- `title_press_start_visible_450.png`, SHA-256
  `cc43a36f4334e701c17a285c7becdecfcb0e313439ad98619581fe742164bde8`.
- `title_press_start_hidden_550.png`, SHA-256
  `1c213c7d7e056c13f58836729e483d558a4fa59e35c807a951ad97ee43646e2a`.
- `title_new_game_continue_menu_900.png`, SHA-256
  `e3cf6c9316f208e374e329c97512aa56367ba1a1ae039dd49e1af655e7553a56`.

Informe: `docs/runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json`,
SHA-256
`fe7d85b843cf0ae565e963e4f5d5e4f42cfc58fad70bca803890728f3569fa81`.

## Teclado de nombre

| Página | Frame | Máscara OBJ viva | Resultado |
|---|---:|---|---|
| `LOW` | 10480 | Coincide con el recorte inglés y con la ROM | PASS |
| `CAP` | 11480 | Coincide con el recorte inglés y con la ROM | PASS |
| `ABC` | 11780 | Coincide con el recorte inglés y con la ROM | PASS |

El mapa BG0 y sus tiles ingleses permanecen idénticos en las tres páginas. La
composición usa seis sprites OBJ: el índice 7 dibuja el fondo cian seleccionado
y el índice 0 deja ver la tinta negra del rótulo inglés. No queda ninguna
máscara de selección japonesa activa y la página inicial es `LOW`.

Capturas:

- `name_keyboard_low_10480.png`, SHA-256
  `5e8b4ea83776b1702cf518e337d6ea7ea48362f670fa75ca9945e5c0eed0a2c3`.
- `name_keyboard_cap_11480.png`, SHA-256
  `7b2f7e7c569d981e1655046fedfced644eb6e931ac4f07d3105a92df2042a0f3`.
- `name_keyboard_abc_11780.png`, SHA-256
  `da7cde76039476ac0e5a7268eab865ff6602b489c4744b1ebef6d0b95823f9a9`.

Informe:
`docs/runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json`,
SHA-256
`5380cb6f21039cde10e2142955bf451c3d64a8fdd7832e0d797d9f9c2f23d8a2`.

## Program Deck

| Vista | Frame | Comprobación principal | Resultado |
|---|---:|---|---|
| `stats` | 17400 | Seis celdas `CAPACITY` usan paleta 2; violeta ausente | PASS |
| `order` | 21600 | Tres rótulos 5×7 coinciden píxel a píxel | PASS |
| `tool` | 23400 | `PRESS START / DECK INFO` coincide píxel a píxel | PASS |

Los tres mapas BG0 vivos coinciden exactamente con sus activos. Las
composiciones 5×7 tienen cero discrepancias respecto al render esperado. La
flecha de navegación y el pictograma de la tarjeta seleccionada conservan sus
tiles originales, con SHA-256
`fd46751854983722e969eb835d39ab3c78204c0ea9bf8c386ece98e9da582142` y
`33ec6cf730e810339945d86c61b913e5f591d6e2b5a34cd42cec87c802734605`.

Capturas:

- `program_deck_stats_17400.png`, SHA-256
  `03d14938cb0e3a7917f6021c03d39db838f72bf232625431ffb7e6b203eab9af`.
- `program_deck_order_21600.png`, SHA-256
  `c400a83828a956925cab627911f7836ca8729b90c09dd6ccc13de4245c28fa95`.
- `program_deck_tool_23400.png`, SHA-256
  `8d26f6fe89f32aa0f72fca6ea278d2dbd1331b04f25de7cf0d4b5987c23802ed`.

Informe:
`docs/runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json`,
SHA-256
`fa58af36c6bd32a54d01f75b08eb403f60d1a878dfa93d068f26deec87433a2d`.
