# PET root: tipografía de bloque v0.10.4

## Diagnóstico

Los rótulos `PROGRAM DECK`, `CHIP FOLDER`, `DATA LIBRARY`, `NETNAVI` y
`SAVE` no usan la fuente dinámica de los diálogos. Son gráficos precompuestos
del BG0:

| Recurso | Offset ROM | Longitud | Formato | SHA-256 fuente japonesa |
|---|---:|---:|---|---|
| Mapa PET | `0x042DBA` | `0x0400` | 32×16 palabras LE | `1e816281c017da01c3a882416a619f82af51e7ec5de45cd30a8c1880571f4d2b` |
| Tiles PET | `0x07C330` | `0x0980` | 76 tiles 8×8, 4-bpp empaquetado | `578f8463a08f42a0e1d175f01177db119c2418b2f859c575e1972480ae95710e` |

La `E` de clase y `3000z` se dibujan en una capa dinámica distinta. `CLASS`
es estático, pero usa los tiles `0x3C`–`0x41`, protegidos explícitamente.

## Diseño aplicado

- Mayúsculas de bloque y ancho variable, inspiradas en la referencia recibida.
- Glifos nativos de 7 píxeles de alto, sin el estiramiento vertical 2× de la
  fuente anterior.
- Contorno oscuro de un píxel; composición final de 9 píxeles de alto.
- Coordenadas enteras, sin antialias ni filtrado.
- Paleta BG original 2 sin modificaciones:
  - cara crema: índice `1`;
  - fondo gris: índice `9`;
  - contorno: índice `11`.
- Marco naranja, cuadrícula, cursor verde y panel derecho conservados.

| Rótulo | Rectángulo mapa | Cara | Con contorno | Capacidad horizontal |
|---|---|---:|---:|---:|
| `PROGRAM DECK` | `(2,2)`, 8×2 tiles | 57 px | 59 px | 64 px |
| `CHIP FOLDER` | `(2,5)`, 7×2 tiles | 50 px | 52 px | 56 px |
| `DATA LIBRARY` | `(2,8)`, 8×2 tiles | 57 px | 59 px | 64 px |
| `NETNAVI` | `(2,11)`, 5×2 tiles | 35 px | 37 px | 40 px |
| `SAVE` | `(2,14)`, 3×2 tiles | 20 px | 22 px | 24 px |

## Capacidad y allowlist

- 48 tiles de la fuente angosta v0.8 reutilizables.
- 9 tiles japoneses retirados y sin referencias en el mapa ni en la fila
  adicional que construye el juego durante la ejecución.
- Capacidad total: 57 tiles.
- Patrones únicos usados: 57.
- Reserva restante: 0 tiles; el atlas cabe exactamente.
- Celdas autorizadas: 62; celdas cuyo valor cambia: 56.
- Ninguna escritura fuera de los cinco rectángulos.
- El mapa desde `x=11` hasta `x=31` es idéntico byte a byte.
- Tiles `0x3C`–`0x41` (`CLASS`) y `0x45`/`0x46` (marco) idénticos byte a
  byte. El tile `0x45`, usado en runtime por la esquina inferior derecha del
  panel, queda protegido explícitamente.
- Cursor, rango y créditos dinámicos quedan fuera de ambos recursos parcheados.

## Salidas reproducibles

| Archivo | Tamaño/dimensiones | SHA-256 |
|---|---:|---|
| `pet_labels_bg0_map_v0_10_4.bin` | 1024 bytes | `926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c` |
| `pet_labels_tiles_v0_10_4.bin` | 2432 bytes | `f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2` |
| `pet_root_menu_font_preview_v0_10_4.png` | 224×144 | `751c0b0490e82a3785cc7aed22b631848b9e91da64fa9d3abf0cfa1c2f118f73` |

La previsualización conserva fuera de las áreas de los cinco rótulos cada píxel
del pantallazo nativo validado en v0.8, incluidos `CLASS`, `E`, `3000z` y el
cursor.

## Reproducción

```bash
python3 tools/pet_root_menu_font_assets_v0_10_4.py \
  --rom "/ruta/Rockman EXE - N1 Battle (Japan).wsc"
python3 -m unittest tests.test_pet_root_menu_font_v0_10_4 -v
```

El generador acepta además `--reference-menu` y `--observed-menu` para fijar
por SHA-256 las dos imágenes usadas en la auditoría de diseño.
