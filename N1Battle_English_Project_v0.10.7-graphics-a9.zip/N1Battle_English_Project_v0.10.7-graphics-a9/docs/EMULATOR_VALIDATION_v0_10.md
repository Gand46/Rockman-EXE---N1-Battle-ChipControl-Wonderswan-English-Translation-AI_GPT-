# Validación en emulador — versión 0.10

## Resultado

La ROM privada final SHA-256
`0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69`
pasó las rutas v0.10 ejecutadas con MesenCore. Se realizaron **10 arranques
limpios**, sin cargar SAV ni savestate, y se revisaron **46 capturas nativas
de 224×144**. Los mapas y tiles vivos comprobados coinciden con los activos de
la ROM final.

MesenCore usado en la prueba:
`36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9`.

| Familia | Boots | Capturas | Resultado principal |
|---|---:|---:|---|
| Shop, ROM final | 1 | 24 | menú, precios y `Low on Zenny.` correctos |
| Free/Host, ROM final | 4 | 12 | carrusel, racha y flujo Host en inglés |
| PET profundo, ROM final | 5 | 10 | toolbars, sort, `BACKPACK`, Data y NetNavi correctos |
| **Total ROM final** | **10** | **46** | **PASS** |

Todas las capturas conservan 224×144 píxeles; no se observó clipping,
solapamiento, suavizado, escalado ni japonés de juego en los estados
inspeccionados.

## Shop

La ruta de producción entra desde el carrusel PET, carga el mapa final de Shop
en `CPU:0x2000–0x247F` y muestra `1 CHIP`, `10 CHIPS`, `INFO`, los tres
precios, el cursor y la caja de Zenny. El mapa vivo SHA-256
`8898ff87ccd9d0cf50940155ec1975ed83c208dba114ccf51d075032a6563539`
coincide con el activo integrado.

El arranque limpio tiene 3000z y el paquete de diez chips cuesta 5000z; por
eso la ROM final alcanza correctamente `Low on Zenny.` antes de poder abrir la
confirmación. Para revisar el texto condicionado se ejecutó una sonda separada
derivada de la ROM final: sólo el precio lógico de prueba en `0x371BF2–3`
cambió de 5000 a 0 y se reparó el byte bajo del checksum en `0x3FFFFE`. Los
otros 4.194.301 bytes son idénticos y la sonda no se distribuye.

Con ese único gate temporal, el mismo motor y los mismos mapas, tiles, fuente
y diálogos de la compilación final muestran:

```text
Pack: 10 chips?
Yes
No
```

La pantalla del menú previa es pixel-idéntica a la ejecución de producción.
El diálogo cabe en el área original y conserva retrato, puntero y estilo.
Detalles y hashes: `runtime_v0_10/shop_runtime_validation_v0_10.json`.

## Free Battle y Host Tournament

Cuatro arranques limpios comprobaron:

- tarjetas `FREE BATTLE` y `HOST TOURNEY`;
- `STREAK: 0`, manteniendo el contador dinámico en BG1;
- `Navi Roster`, `Register`, `Delete` y teclado `ENTRY NAME`;
- selector `16/32/64/128 NAVIS`, fee, premio y `ENTRY NAME SELECT`;
- bloqueo legítimo `15 more needed` al faltar amigos registrados.

Las 12 capturas son 224×144, los activos ingleses vivos coinciden exactamente
con la ROM final y no aparece ningún patrón gráfico japonés heredado.

## PET profundo

Cinco arranques limpios y diez capturas recorrieron Program Deck normal y
alterno, Chip Folder, ordenación, mochila, Data Library y NetNavi. Quedaron
visibles y revisados `DECK FILE`, `NAVIGATION`, `NAVI CODE`, `PROGRAM DECK
Y4`, `NAME ATK`, `TYPE`, `CHIP FOLDER Y4`, `BACKPACK`, `MENU Y4`, `W/L` y
`NO CHIP / IS / SELECTED`.

La captura de `BACKPACK` usa el banco vivo SHA-256
`6df9cb1a34503c6996b31d29ac569b0c4827bf5c43deb7c65f789e4e8144f0ea`.
Las estadísticas dinámicas se dejaron completar hasta `Cls E NOVICE Tour`,
`In 0 Win 0` y `0W 0L 0%`. Los diez mapas/tiles cotejados son exactos y cero
patrones japoneses anteriores permanecen activos.

## Evidencia seleccionada

- `runtime_v0_10/shop_runtime_validation_v0_10.json` y capturas Shop.
- `runtime_v0_10/free_host_runtime_validation_v0_10.json` y montaje Free/Host.
- `runtime_v0_10/pet_deep_runtime_validation_v0_10.json` y montaje PET.
- `STRUCTURAL_VALIDATION_v0_10.json` para build, IPS, guards y checksum.
- `RESIDUAL_TEXT_SCAN_v0_10.json` para los 1.552 destinos textuales.

## Límites

No se afirma una partida orgánica para cada combinación de progreso ni un
enlace físico entre dos consolas. Un arranque limpio no dispone de quince
amigos adicionales para completar el torneo Host; los estados posteriores se
cierran mediante mapas, tiles, guards y renderizado estático exacto. Tampoco se
modifica el logotipo corporativo/legal japonés de Inti Creates del splash.
