# Graphics Advance 9 — restauración del chip junto a OK

## Hallazgo

En la pantalla principal de Program Deck, el cuadrante inferior izquierdo del
primer chip de MegaMan situado a la derecha de `OK` aparecía como un rectángulo
beige de 8×8 píxeles. La ROM japonesa y la captura original aportada muestran
que esa zona pertenece al dibujo del chip y no al fondo de la interfaz.

## Causa raíz

El mapa de Program Deck empieza en ROM `0x04323C` y su banco de tiles en
`0x07CD20`. Durante la ejecución, el banco se carga en CPU desde `0x8020`; por
ello, el ID de tile `N` consume el activo físico `N−1`. La celda `(14,7)`
contiene la palabra `0x2AE9`: usa el tile vivo `0x0E9`, pero el patrón real es
el activo `0x0E8`.

Una asignación gráfica anterior trató ambos números como equivalentes y
rellenó el activo `0x0E8` con el color beige. La auditoría completa del mapa
demuestra que la celda `(14,7)` es su único consumidor; no pertenece al rótulo
inglés de la barra de herramientas.

## Intervención aislada

- Base obligatoria: A8 SHA-256
  `aafa083e8781d58858c35cf729ed18c9269126cba70c789e1e631844071e3749`.
- Se restaura únicamente el activo `0x0E8` desde la ROM japonesa verificada.
- Cambian 29 bytes del banco y los dos bytes del checksum WonderSwan.
- No cambian mapas, atributos, paletas, código, punteros, textos ni otros
  patrones.
- El IPS entregado es acumulativo y se aplica directamente sobre la ROM
  japonesa admitida.

## Validación

| Comprobación | Resultado |
|---|---:|
| ROM A9 SHA-256 | `27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6` |
| IPS A9 SHA-256 | `9a1bf3430a4e213eb10d3a1f340532dc43f4a7554fad83821263c21bef9e9cb5` |
| Checksum almacenado/calculado | `0xB86D / 0xB86D` |
| Píxeles distintos A8→A9 en pantalla objetivo | 53 |
| Caja de diferencia | `[112,56,120,64]` |
| Píxeles distintos fuera del objetivo | 0 |
| Barra inglesa activada A8→A9 | 0 píxeles |
| Consumidores vivos del tile `0x0E9` | 1: `(14,7)` |
| Mapa y banco vivos frente a ROM | idénticos |
| Recorte restaurado frente a original aportado | idéntico |
| Arranques limpios | 2, sin SAV ni savestate |

El resultado cumple las 29 reglas acumulativas. La comparación ejecutada está
en `docs/runtime_graphics_advances/advance_9_gate_final/`.
