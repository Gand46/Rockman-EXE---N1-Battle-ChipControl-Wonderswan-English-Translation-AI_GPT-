# Avance gráfico 4: estadísticas de Program Deck

## Resultado

Los ocho campos de la pantalla superior fueron recompuestos sobre la ROM del
Avance 3, usando las palabras aceptadas sin sinónimos ni abreviaturas:

| Japonés | Traducción aceptada | Presentación final |
|---|---|---|
| ノーマル30 | Normal30 | `NORMAL30` |
| 攻撃こうか・攻撃力 | Attack Power | `ATTACK POWER` |
| たいきゅう力 | Chip Heal Points | `CHIP HEAL` / `POINTS` |
| しょりそくど | Speed Process | `SPEED` / `PROCESS` |
| 容量 | Capacity | `CAPACITY` |
| ノーマルナビ・ | Normal Navi | `NORMAL NAVI` |
| ノーマルバスター・ | Normal Buster | `NORMAL` / `BUSTER` |
| バトルチップ合計容量 / ナビチップ容量 | Battle Chip Capacity / Navi Chip Capacity | `BATTLE CHIP CAPACITY` / `NAVI CHIP CAPACITY` |

## Decisiones de pixel art

- Las palabras y su orden semántico son literales; las mayúsculas pertenecen
  a la convención visual de esta interfaz.
- La cara proporcional derivada de BN5 usa glifos de 1–5×7 píxeles en los
  campos principales. La cara compacta derivada del Avance 3 usa 3–5×5 en los
  dos descriptores derechos y la leyenda inferior.
- Cada glifo se dibuja directamente al tamaño final. No hay filtro,
  antialiasing, compresión de línea ni reescalado.
- Los textos largos se parten únicamente entre palabras y conservan al menos
  un píxel limpio entre glifos.

## Protección y depuración

El primer prototipo descubrió dos riesgos y fue descartado. El asignador podía
sobrescribir un patrón fuente necesario por un campo posterior; se corrigió
reservando patrones existentes antes de asignar los nuevos. Además, cinco IDs
sin referencias en el mapa BG0 resultaron ser consumidores de otra capa y
alteraban letras del diálogo inferior. La entrega final no utiliza ningún tile
externo o sin consumidor mapeado.

La allowlist final admite únicamente el mapa de estadísticas, su segmento
exacto de tiles y el checksum. Permanecen intactos `HP`, `SP`, `CS`, líneas
conectoras, `140/210 MB`, `START`, iconos, diálogo inferior y las demás páginas
del manual.

## Auditoría

- 114 celdas objetivo y 95 patrones finales.
- 59 IDs de tile modificados dentro del conjunto autorizado.
- 55 bytes de mapa y 1.033 bytes del segmento de estadísticas modificados.
- 0 tiles externos/no mapeados, 0 alias fuera del objetivo y 0 atributos de
  mapa alterados.
- 1.175 píxeles distintos frente al Avance 3, todos dentro de los ocho campos.
- Ocho máscaras internas exactas y 5.824 bytes de tiles activos iguales entre
  ROM y RAM.
- Regresiones A1, A2, A3 y A4 en `PASS` desde arranque limpio de MesenCore a
  224×144, sin SAV ni savestate.

Captura final: `docs/runtime_graphics_advances/advance_4_gate_final/program_deck_stats_17400.png`.
