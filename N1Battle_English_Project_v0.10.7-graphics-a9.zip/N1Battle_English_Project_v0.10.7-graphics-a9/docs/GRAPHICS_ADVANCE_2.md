# Avance gráfico 2 — tipografía de la vista general Program Deck

## Resultado

Estado final: **PASS**. La compilación acumulativa `0.10.7-graphics-a2`
reconstruye exclusivamente los carteles laterales `PROGRAM DECK`, `NAVICHIP`
y `BATTLECHIP`, preservando íntegramente el Avance 1.

## Decisión artística

- Fuente maestra de rol: `BN5DSEU Font Thin`; `SF3FontSmall` se verificó como
  alternativa disponible.
- Los glifos se redibujaron manualmente a 9 píxeles de alto, directamente en
  la cuadrícula nativa.
- Hay al menos un píxel entre caracteres, contraformas abiertas, barras
  continuas y línea base uniforme.
- No se usaron filtros, suavizado, antialiasing ni escalado.
- Los carteles conservan sus colores originales: blanco para `PROGRAM DECK`,
  amarillo para `NAVICHIP` y crema para `BATTLECHIP`.

## Corrección estructural

La primera sonda reveló que el mapa usa `tile N → slot N-1`, porque el banco
se carga desde `0x8020`. Además, la segunda fila de los carteles reutilizaba
tiles con otros consumidores. Escribir sobre ellos producía restos y podía
dañar bordes o textos vecinos.

La depuración contra la ROM japonesa ejecutándose corrigió una premisa de la
primera implementación: `BATTLECHIP` ocupa las filas de mapa 6–7
(`[176,48,216,64]`), no 7–8. Escribir en 7–8 había dejado visible la mitad
superior antigua y había pintado texto negro sobre la cuadrícula púrpura de la
fila 8. La solución reconstruye el cartel en sus diez celdas originales y
restaura `[176,64,216,72]` exactamente desde el Avance 1.

El banco mantiene 32 slots objetivo exclusivos. Solo cuatro palabras internas
de `PROGRAM DECK` se mueven a IDs libres; `NAVICHIP` y `BATTLECHIP` conservan
su geometría original. Cada slot modificado tiene exactamente los consumidores
previstos y no se modifica ningún tile compartido con elementos externos.

## Auditoría

| Compuerta | Resultado |
|---|---:|
| Base exacta Avance 1 | PASS |
| Tres rectángulos completos | PASS |
| Consumidores externos sin resolver | 0 |
| Tiles compartidos externos modificados | 0 |
| Píxeles diferentes dentro del objetivo | 832 |
| Píxeles diferentes fuera del objetivo | 0 |
| Máscaras internas fondo/glifo | 3/3 exactas |
| Paleta por cartel | 2 colores exactos |
| Franja antes invadida `[176,64,216,72]` | Exacta frente a A1 |
| Diálogo inferior exacto | PASS |
| Otras páginas del manual intactas | PASS |
| Mapa activo ROM/RAM | PASS |
| 32 tiles activos ROM/RAM | PASS |
| Cinco estados consecutivos a 224×144 | PASS |
| Regresión acumulativa del Avance 1 | PASS |

Rectángulos protegidos, en píxeles nativos:

- `PROGRAM DECK`: `[8,8,56,24]`
- `NAVICHIP`: `[8,56,48,72]`
- `BATTLECHIP`: `[176,48,216,64]`

## Identidades

- ROM privada candidata: `55616bc011c8439a693587c08dae9cf814801e61879ce280e253b0674e6004e5`
- IPS acumulativo: `2b54f43f19187feb59714d48be502d63b9bbdfbda1e1118de29619d13e55ba8c`
- Checksum WonderSwan: `0xF4E1`
- Captura primaria: `5cef0f15af583e1b8d83d96d573054320cf5cf3c3887b5ae8dd32e9855ba3dba`

La ROM no forma parte de la distribución pública.
