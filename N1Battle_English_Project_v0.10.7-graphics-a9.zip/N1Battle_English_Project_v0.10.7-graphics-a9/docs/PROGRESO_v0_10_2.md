# Progreso de traducción — versión 0.10.2

| Alcance | Estado |
|---|---:|
| Texto codificado referenciado | 1.552/1.552 (100,00 %) |
| Gráficos localizables | 129/129 (100,00 %) |
| Logotipo principal localizado al inglés | 1/1 |
| Efectos grandes compatibles con fuente 8×16 | 108/108 |
| Japonés residual conocido en destinos catalogados | 0 |
| Validación estructural final v0.10.2 | PASS |
| Barrido residual final v0.10.2 | PASS |
| Validación de emulador sobre la ROM v0.10.2 | PASS |
| Pruebas automatizadas | 24 OK, 1 omitida opcional |

La v0.10.2 reincorpora el logotipo principal al denominador gráfico y lo
resuelve como `MEGA MAN / BATTLE NETWORK / N1 BATTLE`. No se importa la
captura completa entregada como referencia: se reconstruye únicamente la capa
del logotipo, con maestro RGBA de 224×112, colores RGB444 y transparencia
binaria. El fondo animado, `PRESS START`, los textos legales y las cinco
paletas originales permanecen independientes.

El activo utiliza 194 de los 208 tiles disponibles y deja 14 libres. Las filas
14–17 del mapa y las columnas ocultas 28–31 son idénticas a la fuente. La
conversión y su round-trip están en `PASS` en
`translation/assets/title_logo_asset_report_v0_10_2.json`.

La reconstrucción final produce ROM SHA-256
`b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24`
y checksum WonderSwan válido `0x383A`. La validación estructural, el barrido
residual y el arranque limpio en MesenCore están en `PASS`. Los frames 450,
550 y 900 confirman el parpadeo de `PRESS START` y la transición real a
`NEW GAME / CONTINUE`.

Informes finales:

- `STRUCTURAL_VALIDATION_v0_10_2.json`, SHA-256
  `863abca9af78a801b2219a6c7072db1f92676448e574a82e5c193a72fcf2b561`.
- `RESIDUAL_TEXT_SCAN_v0_10_2.json`, SHA-256
  `f5a19dcc70633669298e69150e9040b0473dbc5da52a419c35b4ae9d3714ed27`.
- `runtime_v0_10_2/title/title_runtime_validation_v0_10_2.json`, SHA-256
  `63364d078c4d3e67e9c302ef2e5a3389399914ae761d06ab61ef7af7873bbb92`.
