# Rótulos de efecto de seis caracteres — v0.10.5

## Regla aplicada

1. Los rótulos de seis caracteres o menos se conservan.
2. `NO DATA` se convierte expresamente en `NODATA`.
3. En los demás casos se preservan el número completo y los modificadores
   `~`/`+`.
4. El espacio restante, hasta completar seis caracteres, se rellena con las
   primeras letras del efecto.

Ejemplos:

| Anterior | v0.10.5 |
|---|---|
| `NORMAL60` | `NORM60` |
| `RANDOM70` | `RAND70` |
| `NORMA120` | `NOR120` |
| `PIERC90+` | `PIE90+` |
| `~ADD50+` | `~AD50+` |
| `RNDM100+` | `RN100+` |
| `NO DATA` | `NODATA` |

La lista completa de 43 transformaciones, con sus punteros e índices de chip,
está en `translation/assets/chip_effect_label_asset_report_v0_10_5.json`.

## Protección

La implementación acorta cada cadena en su dirección original. No repaca el
banco ni cambia la tabla de 249 punteros. Los bytes posteriores al nuevo
terminador y la cola no referenciada se mantienen para minimizar el delta.
