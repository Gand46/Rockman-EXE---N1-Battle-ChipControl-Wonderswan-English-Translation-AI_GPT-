# Validación de emulador v0.10.1

MesenCore cargó la ROM final SHA-256
`5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b`
desde arranques limpios, sin SAV ni savestate.

- Portada: frames 450 y 550, 224×144; banco de 208 tiles, mapa y paletas
  coinciden exactamente con la ROM japonesa. `PRESS START` conserva el
  parpadeo nativo.
- Chip Folder: frame 27320, 224×144; `NORMAL60` se lee completo entre el código
  y el daño, sin mosaicos, recorte ni pérdida de información.
- Las capturas de ordenación y mochila confirman que las rutas adyacentes
  continúan estables.

Informes y PNG: `runtime_v0_10_1/title/` y `runtime_v0_10_1/chip/`.
