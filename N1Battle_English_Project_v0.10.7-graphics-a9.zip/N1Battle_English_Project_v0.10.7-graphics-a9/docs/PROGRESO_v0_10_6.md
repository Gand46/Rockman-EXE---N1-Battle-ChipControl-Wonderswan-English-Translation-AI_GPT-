# Progreso validado v0.10.6

La v0.10.6 final reconstruye 25 rótulos gráficos estáticos desde `BN5DSEU Font
Thin.ttf` y `SF3FontSmall.ttf`, y aplica retoque manual reproducible a 70
variantes de glifo en resolución nativa. Cada compuesto conserva una separación
mínima de un píxel; no se escala un atlas PNG ni se condensa la línea. Los
cuadros de diálogo inferiores quedan fuera del cambio.

La pantalla de clase de BATTLE CHIP GP también se corrige: `A CLASS`–`E CLASS`
pasan a `A CLS`–`E CLS` dentro de los mismos cinco slots y sin modificar ningún
puntero. Las dos celdas liberadas permiten que el icono verde vuelva a verse.

## Resultado

| Comprobación | Resultado |
|---|---:|
| Rótulos TTF reconstruidos | 25/25 |
| Rótulos con separación compuesta mínima de 1 px | 25/25 |
| Variantes de glifo retocadas a 1× | 70 |
| Etiquetas de clase corregidas sin repacado | 5/5 |
| Menú raíz PET, incluido `CLASS` | 6/6 |
| Patrones PET seguros | 63/63 |
| Patrones SHOP usados/seguros | 22/23 |
| Texto heredado | 1.552/1.552 |
| Gráficos localizables heredados | 129/129 |
| Efectos de chip de máximo 6 caracteres | 249/249 |
| Japonés referenciado inesperado | 0 |
| Spans guardados | 21/21 |
| Cambios fuera de allowlist | 0 |
| Diálogos modificados | 0 |

## Ejecución real

MesenCore verificó nueve arranques limpios y 45 capturas nativas de 224×144:
menú PET, teclado `LOW/CAP/ABC`, SAVE, SHOP, los cuatro banners y las rutas
Free/Host y selección de clase. Los mapas, tiles y máscaras vivos coinciden
con los activos revisados. La tabla del teclado usa los IDs vivos del nuevo
mapa `ABC`; las tres máscaras OBJ coinciden con sus páginas reales. En la
selección de clase se comprueban el mapa BG liberado y los sprites verde,
amarillo y rosa.

Se conservaron cursor, `E`, `3000Z`, precios, Zenny, contadores, marcos y
diálogos inferiores. En Free Battle el número dinámico continúa separado de
`STREAK`.

La compilación final tiene checksum WonderSwan `0x937D`. Frente a v0.10.5
cambian 4.918 bytes, todos dentro de los 21 spans permitidos y el
checksum. La composición IPS y la validación estructural concluyen en `PASS`;
el conteo final de pruebas se registra en `docs/progress_v0_10_6.json`.
