# Reglas acumulativas para los nueve avances gráficos

Estas reglas son obligatorias desde el Avance 1 corregido. Cada avance nuevo debe conservar las reglas anteriores, añadir sus propias zonas protegidas y detener la compilación ante cualquier incumplimiento.

## Flujo obligatorio

1. **Base exacta y trazable.** El avance parte de la última compilación aprobada y verifica su SHA-256 antes de escribir. La RC2 queda prohibida como base. Para el Avance 1, la base es v0.10.7 RC4 (`129ef89f...bbe1b8`).
2. **Contrato semántico previo.** Antes de editar se registran: elemento objetivo, función visual, coordenadas, tamaño, estado esperado y elementos vecinos que deben conservarse.
3. **Mapeo vivo de tiles.** La relación entre palabra de mapa, ID de tile, dirección de VRAM y slot del atlas se mide en RAM durante una ejecución limpia. Nunca se presume que `tile ID N` corresponde al `slot N`.
4. **Grafo de consumidores.** Todo slot de atlas modificado debe enumerar todas las celdas, textos, iconos y bordes que lo consumen. Si existe un consumidor fuera del objetivo, se restaura explícitamente o se rechaza el avance.
5. **Protección semántica de vecinos.** Textos, pictogramas, marcos, cursores y datos dinámicos aledaños se comparan píxel a píxel con la referencia aprobada.
6. **Allowlist binaria.** Solo pueden cambiar los rangos declarados de mapa, tiles y checksum. Código, paletas, diálogos inferiores, valores dinámicos, punteros y recursos ajenos quedan excluidos.
7. **Diferencia visual global.** A resolución nativa 224×144, todo píxel fuera de las regiones autorizadas debe ser idéntico a la base aprobada.
8. **Auditoría de los cuatro bordes.** Se revisan bandas completas izquierda, derecha, superior e inferior, aunque el objetivo esté lejos de ellas. Para el Avance 1, el borde izquierdo de 8×144 debe coincidir exactamente con la referencia limpia.
9. **Ejecución limpia.** Las capturas se obtienen sin partida, guardado o savestate y sin filtros, escalado ni antialiasing.
10. **Estados múltiples.** Se valida el estado principal y cualquier variante que pueda reutilizar el recurso. En el Avance 1 se capturan la pantalla raíz y la barra de herramientas activada.
11. **Coherencia ROM/RAM.** Los mapas y tiles activos en RAM deben coincidir con los activos de la ROM candidata.
12. **Revisión semántica final.** Una persona revisa legibilidad, continuidad de bordes, significado de iconos, jerarquía visual y ausencia de artefactos. Una imagen técnicamente válida pero semánticamente dañada se rechaza.
13. **Acumulación protegida.** Al aprobar un avance, sus zonas, capturas y hashes pasan a ser regresiones obligatorias de todos los avances siguientes.
14. **Reconstrucción exacta.** El manifiesto y el IPS se aplican de forma independiente sobre la ROM japonesa verificada y deben reconstruir byte a byte la misma ROM candidata.
15. **Paquete reproducible y seguro.** El ZIP se genera dos veces con igual SHA-256 e incluye IPS, manifiesto, BAT, reglas, scripts y evidencias. Nunca incluye ROM, BIOS, TTF, partidas, savestates ni emulador.
16. **Propiedad exclusiva de tiles.** Un tile editable no puede conservar consumidores ajenos al objetivo. Si el recurso existente está compartido, se reasigna la celda objetivo a un ID libre del mismo banco y se valida que el nuevo slot tenga exactamente un consumidor previsto.
17. **Escaneo del rectángulo completo.** La auditoría cubre todas las filas y columnas físicas del cartel, no solo la caja visible del glifo nuevo. Cualquier resto de la fuente anterior, píxel huérfano o franja repetida rechaza el avance.
18. **Legibilidad de pixel art nativo.** La fuente se compone directamente a píxel entero, sin filtros, reescalado ni antialiasing; debe conservar al menos un píxel entre glifos, contraformas abiertas, línea base uniforme y márgenes verificables a 224×144.
19. **Geometría original y máscara interna.** Las coordenadas del objetivo se obtienen de la ROM japonesa ejecutándose, no de una captura anotada ni de una estimación visual. Cada cartel debe coincidir exactamente con su máscara binaria de fondo/glifo, su paleta autorizada y su número esperado de componentes conectados. También se compara con la base cualquier fila que haya sido invadida por un intento descartado; un texto duplicado, residuo o derrame rechaza el avance aunque el delta permanezca dentro de un rectángulo declarado.
20. **Límite semántico y zona de contraste.** Cada texto se contrasta con la ROM japonesa y con su función antes de rasterizarlo. Las palabras compuestas conservan una separación visual medible; los indicadores cortos como `Y4` se reconstruyen una sola vez y con el color propio de su campo. Cualquier traducción de otro control, límite de palabra cerrado, glifo duplicado o máscara anterior conservada debajo rechaza el avance. Las coordenadas se validan tanto en mapa como en pantalla, porque el desplazamiento de scroll puede situar un cartel en otra fila visible.
21. **Prueba de función para gráficos adyacentes ambiguos.** Ningún bloque contiguo puede declararse icono, cursor o elemento funcional solo porque exista en el mapa original. Debe demostrarse su función mediante cambio de estado o dependencia ejecutable; si no forma parte del texto, no cambia con la interacción y el usuario lo identifica como residuo, se trata como contaminación visual. Antes de eliminarlo se auditan todos sus consumidores: un tile compartido se conserva y se corrige únicamente la celda de mapa objetivo. La zona eliminada debe quedar uniforme y los vecinos de ambos lados deben coincidir píxel a píxel con la base.
22. **Glosario literal y propiedad semántica del conector.** Una traducción aprobada es un contrato inmutable: no puede sustituirse por un término aproximado aunque quepa mejor. Antes de componer, cada rótulo se vincula a su texto japonés, campo, valor o línea conectora. Solo se permiten cambio de mayúsculas propio de la cara gráfica y salto en límites de palabra; una abreviatura, sinónimo o intercambio entre campos rechaza el avance.
23. **Reserva de patrones en dos pasadas.** Antes de asignar un patrón nuevo, el generador reserva todos los tiles cuyo patrón fuente aún será requerido por cualquier campo final. Un tile reservado no puede convertirse en candidato de otro patrón. Tras asignar, cada rectángulo se decodifica nuevamente desde el mapa y el banco resultantes y debe coincidir píxel a píxel con su máscara generada.
24. **Auditoría de consumidores entre capas y datos dinámicos.** Un tile no se considera libre porque carezca de referencias en el mapa BG objetivo. Deben revisarse BG0, BG1, OBJ, carga dinámica de glifos y estados posteriores. Cualquier slot que afecte diálogo, cursor, número, marco u otra capa queda prohibido. La prueba final compara la interfaz completa con la base ejecutada por la misma ruta, no con una captura histórica de otra revisión.
25. **Reutilización canónica de patrones equivalentes.** Si otra pantalla representa el mismo texto, función, paleta y geometría que un rótulo ya aprobado, primero debe reutilizar sus patrones mediante referencias de mapa. No se reservan ni redibujan tiles nuevos. El grafo declara cada consumidor previsto, los atributos de mapa se conservan y la validación dinámica demuestra que las pantallas no objetivo permanecen idénticas.
26. **Aislamiento de renderizadores numéricos dinámicos.** Un ajuste de tamaño no puede modificar la fuente numérica compartida. Debe interceptarse únicamente la llamada del campo objetivo, conservarse la lógica y la paleta originales y asignarse almacenamiento gráfico sin consumidores en mapas ROM, BG0, BG1 u OBJ. Se prueban todos los dígitos, valores límite, desplazamiento, estado vacío y pantallas hermanas.
27. **Centrado métrico y aislamiento de llamada de escena.** Un texto dinámico se centra con su ancho codificado completo y la geometría nativa: `x = (ancho de pantalla − ancho de celdas) / 2`, sin insertar espacios ni alterar glifos. Si el renderizador es compartido, solo puede cambiar el argumento de posición de la escena demostrada por traza; texto, puntero, eje no solicitado, fuente, paleta y motor quedan protegidos. La validación debe demostrar una traslación rígida de la máscara y coincidencia exacta de escenas hermanas.
28. **Limpieza de filas residuales en tarjetas compartidas.** Una traducción gráfica no se considera cerrada hasta auditar todas las filas físicas del activo, incluidas las situadas debajo de la última línea inglesa. Si una fila residual comparte el marco, se eliminan únicamente los píxeles del glifo anterior y se reconstruye el borde con su índice de paleta uniforme. Se comparan todos los consumidores, el texto inglés y los estados hermanos; mapas, paletas, código, punteros y datos dinámicos quedan protegidos.
29. **Fase viva tile/activo e integridad de iconos dinámicos exclusivos.** Antes de declarar libre o traducible un patrón se mide la fase real entre el ID escrito en el mapa, la dirección de carga en VRAM y el índice físico del banco. Un desfase como `tile N → activo N−1` debe aplicarse al grafo completo de consumidores. Si una celda dinámica posee un único consumidor y representa parte de un icono original, ese activo queda protegido: una traducción adyacente no puede convertirlo en fondo. La corrección restaura el patrón desde la ROM japonesa verificada y exige cero cambios en el mapa, la paleta, el código, los punteros, el texto y los estados hermanos.

## Contrato protegido del Avance 1

- Objetivo: eliminar únicamente el símbolo de las celdas `(18,0)` y `(18,1)` del encabezado Program Deck.
- Fondo esperado: palabra de mapa `0x240C`, color uniforme RGB `(85,102,102)`.
- Vecinos obligatorios: `PROGRAM DECK`, `Y2 CHIP FOLDER` y el pictograma Y2 coinciden con la referencia v0.10.6 aprobada.
- Borde izquierdo: los 8×144 píxeles coinciden con la referencia limpia; se protege el slot compartido `0x010` y sus 15 consumidores.
- Mapeo comprobado: `slot de atlas = ID de tile - 1`, carga en CPU desde `0x8020`.
- Fuera de las regiones `[88,0,224,16]` y `[0,0,8,144]`: cero cambios visuales frente a RC4.
- Resultado: `PASS`; ningún consumidor externo queda sin resolver.

## Contrato protegido del Avance 2

- Base acumulativa: Avance 1 exacto (`63ce8069...8575`); su regresión vuelve a pasar sobre la ROM del Avance 2.
- Objetivo semántico: reconstruir únicamente `PROGRAM DECK`, `NAVICHIP` y `BATTLECHIP` en los carteles laterales de la vista general del manual.
- Rectángulos completos: `[8,8,56,24]`, `[8,56,48,72]` y `[176,48,216,64]`. La ROM japonesa confirma que `BATTLECHIP` ocupa las filas 6–7; la fila 8 no pertenece al cartel.
- Fuente: máscaras de pixel art derivadas del rol de `BN5DSEU Font Thin`, retocadas manualmente a 9 píxeles de alto; `SF3FontSmall` queda verificada como alternativa del proyecto.
- Espaciado: mínimo de un píxel entre glifos; sin filtros, escalado ni antialiasing.
- Propiedad: 32 slots exclusivos y un único consumidor previsto por slot. Cuatro celdas internas de `PROGRAM DECK` se reasignan a IDs libres; `NAVICHIP` y `BATTLECHIP` conservan sus palabras de mapa originales.
- Mapeo comprobado: `slot de atlas = ID de tile - 1`, carga en CPU desde `0x8020`.
- Protección: diagrama central, encabezado superior, bordes, franja izquierda, diálogo inferior y demás páginas del manual permanecen intactos.
- Máscara interna: cada cartel contiene únicamente fondo y color de glifo; las máscaras binarias y sus componentes conectados coinciden exactamente con los patrones generados.
- Restauración: la antigua franja invadida `[176,64,216,72]` vuelve a coincidir píxel a píxel con el Avance 1.
- Diferencia visual: 832 píxeles dentro de los tres carteles y cero fuera de ellos en cinco estados consecutivos.
- Resultado: `PASS`; mapa y 32 tiles objetivo coinciden entre ROM y RAM.

## Contrato protegido del Avance 3

- Base acumulativa: Avance 2 exacto (`55616bc...e6004e5`); las regresiones de los avances 1 y 2 vuelven a pasar sobre la ROM del Avance 3.
- Semántica original: `プログラムデッキ Y4` → `PROGRAM DECK Y4` y `チップフォルダ` → `CHIP FOLDER`. La variante anterior `AUTO CONTROL` se rechaza por no corresponder al texto japonés.
- Rectángulos visibles: `PROGRAM DECK Y4` ocupa `[8,8,64,16]` y `CHIP FOLDER` ocupa `[80,0,128,16]`; las coordenadas incluyen el desplazamiento real del mapa en pantalla.
- Contraste: `PROGRAM DECK` usa el frente oscuro sobre el campo naranja; `Y4` usa naranja sobre el campo gris. No queda ningún segundo `Y4` oscuro debajo.
- Legibilidad: `CHIP FOLDER` conserva un píxel mínimo entre glifos, tres píxeles entre palabras, márgenes de 4/5 píxeles y cero solapamientos.
- Residuo adyacente: las celdas `(16,0)` y `(16,1)` situadas a la derecha de `CHIP FOLDER` se reasignan a `0x2404`; el rectángulo `[128,0,136,16]` queda completamente uniforme.
- Propiedad: los 19 tiles de texto tienen un único consumidor previsto. El tile inferior del residuo (`0x01C`) está compartido con otra pantalla y se conserva; solo cambian dos bytes del mapa objetivo.
- Protección: toda la interfaz bajo la fila 16 y los vecinos desde x=136 coinciden píxel a píxel con el Avance 2.
- Diferencia visual: 478 píxeles dentro de los tres rectángulos autorizados y cero fuera; mapa y tiles activos coinciden entre ROM y RAM.
- Resultado: `PASS` en arranque limpio de MesenCore a 224×144, sin SAV, savestate, filtros ni escalado.

## Contrato protegido del Avance 4

- Base acumulativa: Avance 3 exacto (`2080294b...cfe1c`); los recursos de A1–A3 permanecen byte a byte idénticos.
- Glosario literal: `Normal30`, `Attack Power`, `Chip Heal Points`, `Speed Process`, `Capacity`, `Normal Navi`, `Normal Buster` y `Battle Chip Capacity / Navi Chip Capacity` conservan exactamente las palabras aceptadas.
- Correspondencia: los rótulos centrales continúan unidos, respectivamente, a los campos HP, SP y CS; los descriptores derechos pertenecen al Navi y al Buster; la leyenda inferior describe `140/210 MB`.
- Composición: `Chip Heal Points`, `Speed Process`, `Normal Buster` y la leyenda se distribuyen en dos filas. No hay abreviaturas, filtros, reescalado ni antialiasing.
- Fuentes: la cara proporcional BN5 de 7 píxeles se mantiene en los campos principales; la cara compacta nativa de 5 píxeles, derivada del diseño aprobado en A3, se usa en ambos descriptores derechos y la leyenda para mantener uniformidad y no invadir datos.
- Asignación: 95 patrones finales caben exclusivamente en el conjunto mapeado autorizado. Cero tiles sin consumidor BG0 o pertenecientes a otras páginas/capas son modificados. El asignador reserva patrones existentes antes de crear patrones nuevos.
- Protección multicapas: el intento descartado que usaba cinco slots aparentemente libres alteraba la capa de diálogo y fue rechazado. La entrega final no escribe esos slots; texto, marco y fondo del diálogo coinciden píxel a píxel con A3 ejecutada por la misma ruta.
- Protección adicional: `HP/SP/CS`, conectores, `140/210 MB`, `START`, iconos, paletas y las demás páginas del manual permanecen intactos.
- Diferencia visual: 1.175 píxeles dentro de los ocho campos, caja `[94,16,198,78]` y cero cambios fuera de los rectángulos autorizados.
- Coherencia: mapa y 5.824 bytes de tiles mapeados coinciden entre ROM y RAM; las ocho máscaras decodificadas tienen cero discrepancias.
- Resultado: `PASS` en arranque limpio de MesenCore a 224×144, sin SAV, savestate, filtros ni escalado.

## Contrato protegido del Avance 5

- Base acumulativa: Avance 4 exacto (`e640da75...84d62c8`); todo el contenido de A1–A4 queda protegido por una diferencia binaria cerrada.
- Objetivo semántico: armonizar la segunda instancia principal de `チップフォルダ` → `CHIP FOLDER` con el patrón ya aprobado en A3.
- Geometría: doce celdas BG0 `(11,0)`–`(16,1)` y rectángulo visible `[88,0,136,16]`.
- Reutilización: se enlazan los IDs aprobados `0x02A`–`0x030` y `0x037`–`0x03B`; el banco compartido de 5.824 bytes permanece idéntico a A4.
- Consumidores: cada uno de los doce patrones tiene exactamente dos consumidores previstos, uno en la cabecera alterna de A3 y otro en la pantalla principal de Chip Folder.
- Allowlist: cambian doce bytes bajos de palabras de mapa y dos bytes de checksum. Atributos, tiles, paletas, código, punteros, textos, iconos, marcos y valores dinámicos no cambian.
- Diferencia visual: 524 píxeles dentro del objetivo y cero fuera. Las pantallas de ordenación y mochila coinciden píxel a píxel con A4.
- Coherencia: mapa y tiles activos en RAM coinciden con la ROM; la máscara ejecutada usa exclusivamente los índices de paleta `3`, `9` y `15` del patrón A3 aprobado.
- Resultado: `PASS` en dos arranques limpios de MesenCore a 224×144, sin SAV, savestate, filtros ni escalado.

## Contrato protegido del Avance 6

- Base acumulativa: Avance 5 exacto (`254bebac...706522`); los cinco avances anteriores permanecen protegidos.
- Objetivo: reducir únicamente la cantidad situada a la derecha de `MB` en las siete filas visibles de Backpack.
- Geometría: dígitos 3×5 en `(4,1)` dentro de cada celda 8×16, sin filtros, escala ni antialiasing.
- Aislamiento: se sustituye una sola llamada en `0x33835C`; el envoltorio reside en el tramo B1 vacío `[0x37D6D8,0x37D7F2)` y conserva el renderizador original para su caché.
- Propiedad: catorce tiles forman siete pares exclusivos. El grafo vivo contiene exactamente 14 consumidores objetivo, cero en la otra capa, cero en los mapas ROM relacionados y cero solapamiento con OBJ.
- Semántica: `0–9` usan su máscara exacta; los valores de más de una cifra muestran la última cifra, igual que el campo original de una columna. Los datos guardados no cambian.
- Protección: `Quake1`, `Meteor3`, capacidades, `MB`, nombres, iconos, tarjeta, estadísticas, encabezado, marcos y paletas coinciden píxel a píxel con A5.
- Diferencia visual: 195 píxeles en el caso aportado y 210 tras desplazamiento; cero fuera de `[128,24,136,136]` y de las siete celdas autorizadas.
- Estados adicionales: Backpack vacío y Chip Folder principal son idénticos a A5; se verifican `0–9`, `10`, `11`, `12` y `255`.
- Resultado: `PASS` a 224×144 en arranques limpios de MesenCore con partida determinista y checksum válido, sin savestate, filtros ni escalado.

## Contrato protegido del Avance 7

- Base acumulativa: Avance 6 exacto (`9b135e34...bb333b`); los seis avances anteriores permanecen protegidos.
- Objetivo: centrar únicamente `1 MONTH LATER...`, registro auxiliar `0x10`, sin cambiar su texto, puntero, glifos ni composición vertical.
- Geometría: 16 celdas de 8 píxeles ocupan 128 píxeles. En 224×144, el origen exacto es `(224−128)/2 = 48`, columna 6; el tramo `[48,176)` tiene centro `112`.
- Traza: la llamada exclusiva del estado `0x0D` está en PC físico `0x2A6F7`, ROM `0x32A6F7`. Solo cambia `PUSH 0x0B` por `PUSH 0x06`; el argumento `y=8` y el renderizador compartido permanecen intactos.
- Allowlist: cambia un byte de argumento y un byte del checksum. Texto, puntero, fuente, tiles, mapas persistentes, paletas, fondos y código compartido tienen cero cambios.
- Ejecución: la máscara conserva sus 269 píxeles y se traslada rígidamente 40 píxeles a la izquierda; la caja de glifo pasa de `[89,66,210,78]` a `[49,66,170,78]`.
- Regresiones: los fotogramas 2300, 2960 y 3200 coinciden byte a byte con A6; la ruta parte de un arranque limpio sin SAV ni savestate.
- Resultado: `PASS` a 224×144, con span de celdas centrado exactamente en `x=112` y cero cambios visuales fuera de las posiciones anterior/nueva del texto.

## Contrato protegido del Avance 8

- Base acumulativa: Avance 7 exacto (`e049ce54...af9fa`); los siete avances anteriores permanecen protegidos.
- Objetivo: eliminar exclusivamente los restos japoneses situados debajo de `NO CHIP / IS / SELECTED` en la tarjeta compartida de 64×32 píxeles.
- Geometría interna: las tres líneas inglesas ocupan `[0,0,64,24]`. La limpieza se limita a `[2,24,62,28]`; las columnas laterales del marco se conservan y la fila `y=27` se reconstruye con el índice uniforme `14` del propio borde.
- Allowlist: cambian 37 bytes dentro de los tiles `0x032`–`0x035` y dos bytes del checksum; cero escrituras fuera del banco `0x2B0A20–0x2B1120` y del checksum.
- Protección: `NO CHIP`, `IS`, `SELECTED`, `NO DATA SELECTED`, estadísticas, mapas, paletas, código, punteros, datos dinámicos y la parte inferior del marco permanecen intactos.
- Consumidores: el banco compartido tiene tres consumidores. Backpack y Data Library se ejecutan como pares A7/A8 y cargan en RAM, desde `0xA800`, exactamente el banco de su ROM; el tercer consumidor queda protegido por esa identidad compartida.
- Diferencia visual: 43 píxeles por consumidor ejecutado, todos dentro de sus franjas autorizadas. `chip_folder`, `chip_sort` y `data_library` coinciden píxel a píxel entre A7 y A8.
- Resultado: `PASS` en cuatro arranques limpios de MesenCore a 224×144, sin SAV, savestate, filtros ni escalado; no queda japonés residual visible.

## Contrato protegido del Avance 9

- Base acumulativa: Avance 8 exacto (`aafa083e...071e3749`); los ocho avances anteriores permanecen protegidos.
- Objetivo: eliminar exclusivamente el rectángulo beige que ocultaba el cuadrante inferior izquierdo del primer chip de MegaMan situado junto a `OK` en Program Deck.
- Causa raíz: la carga viva comienza en `0x8020`, de modo que el tile de mapa `0x0E9` consume el activo `0x0E8`. Una asignación anterior auditó ambos números como si fueran iguales y convirtió por error ese cuadrante en fondo.
- Propiedad: la palabra `0x2AE9` de la celda `(14,7)` es el único consumidor del tile vivo `0x0E9` en el mapa completo. El activo `0x0E8` se restaura byte a byte desde la ROM japonesa verificada.
- Geometría: el único rectángulo autorizado es `[112,56,120,64]`, exactamente 8×8 píxeles. En ejecución cambian 53 píxeles y cero fuera de esa zona.
- Allowlist: cambian 29 bytes del activo `0x0E8` en el banco `0x07CD20–0x07EC10` y dos bytes del checksum. Mapas, paletas, código, punteros, texto y todos los demás tiles tienen cero cambios.
- Protección: el estado con la barra `DECK FILE` activada coincide píxel a píxel con A8; los rótulos ingleses y los siete IDs del toolbar se conservan.
- Coherencia: el mapa y el banco vivos coinciden con la ROM A9, y el recorte 8×8 restaurado coincide exactamente con la captura original aportada.
- Resultado: `PASS` en dos arranques limpios de MesenCore a 224×144, sin SAV ni savestate; el icono vuelve a su estética original y el rectángulo beige desaparece.

Las reglas ejecutables están en `translation/graphics_advance_rules.json` y el cierre acumulativo se comprueba con `tools/validate_graphics_advance_rules_a9.py`.
