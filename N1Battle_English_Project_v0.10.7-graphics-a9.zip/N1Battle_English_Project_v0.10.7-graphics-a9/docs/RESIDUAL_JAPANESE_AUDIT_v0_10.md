# Auditoría completa de japonés residual — versión 0.10

## Resultado

| Dominio | Cobertura | Japonés restante | Resultado |
|---|---:|---:|---|
| Texto codificado referenciado | 1.552/1.552 | 0 destinos | `PASS` |
| Gráficos de juego catalogados | 129/129 | 0 ocurrencias | `PASS_CATALOGUED_SCOPE` |
| Build, IPS y checksum | exactos | 0 fallos | `PASS` |

La auditoría v0.10 no aceptó el 75/75 gráfico de v0.9 como denominador final.
Volvió a recorrer Shop, el carrusel PET, mapas desplazables de 26 filas,
botones alternos y los descriptores gráficos `D070000–D0704F0`. Esto recuperó
54 ocurrencias reales adicionales y elevó el inventario cerrado a 129.

## Texto codificado

`tools/audit_residual_japanese_v0_10.py` reconstruye la ROM desde la fuente y
el manifiesto, recorre las tablas/pools confirmados y vuelve a decodificar cada
destino. Resultado:

- 1.552/1.552 unidades en inglés;
- 0 destinos actuales con kana, kanji o puntuación japonesa;
- 0 punteros fuera de rango, destinos impares o registros sin terminador;
- 474 candidatos heurísticos en el barrido de los 2.097.152 offsets pares;
- 0 candidatos inesperados: 472 son bytes huérfanos dentro de pools acotados y
  dos son coincidencias binarias protegidas por bytes y SHA-256.

La presencia física de datos antiguos no implica que el juego los referencie.
Se preservan los huecos no usados para reducir cambios innecesarios.

## Ampliación gráfica v0.10

| Familia recuperada | Ocurrencias | Resultado inglés |
|---|---:|---|
| Shop interior | 3 | `1 CHIP`, `10 CHIPS`, `INFO` |
| Carrusel PET | 2 | `FREE BATTLE`, `HOST TOURNEY` |
| Host/Free profundo | 31 | roster, registro, bracket, participantes, entradas, resultados y racha |
| PET profundo | 18 | toolbars, sort, backpack, estadísticas y tarjeta compartida |
| **Total nuevo** | **54** | **integrado** |

El total gráfico es 75 ocurrencias heredadas verificadas + 54 nuevas =
**129/129**.

### Shop

El mapa `0x04604C+0x480` y el atlas `0x0818A0+0x600` fueron reconstruidos con
guards de la ROM japonesa. Las tres áreas de precio (`500z`, `5000z`, `0z`)
permanecen byte por byte; también se preservan el cursor, la caja de Zenny, el
marco y la lógica de compra. Una ruta limpia entra realmente a Shop y carga el
mapa final exacto en `CPU:0x2000`.

### Free Battle

El texto fijo `ただ今 … 連勝中` del mapa `0x049AE8` se sustituyó por
`STREAK:`. Las celdas BG1 `x5–6` que dibujan el contador se dejaron intactas,
por lo que la traducción no convierte el valor dinámico en una imagen fija.
Los maps consumidores alternos tampoco referencian los tiles modificados.

### Host Tournament

Se auditaron diez pantallas/variantes entre `D070160` y `D070210`: configuración,
roster, NaviCode, tres brackets, cuatro tamaños, selección, diálogo/tabla de
resultado y borrado. Los tres mapas de bracket y los mapas cuyas posiciones ya
eran adecuadas permanecen byte-idénticos; sólo se redibujan pools exclusivos.
Los outputs se cotejan con 34 regiones de origen y 24 archivos de salida.

### PET profundo

Los mapas Program/Chip de 26 filas explican la omisión de v0.9: la barra START
está en la fila 24, fuera del viewport inicial. v0.10 verifica el mapa completo
y traduce `DECK FILE`, `NAVIGATION`, `NAVI CODE`, `PROGRAM DECK Y4`,
`NAME ATK`, `TYPE`, `CHIP FOLDER Y4`, `BACKPACK`, `MENU Y4`, `W` y `L`.

La tarjeta compartida `チップが / えらばれて / いません` usa los tiles
globales `0x158–0x16F` del atlas `0x2B0A20`. Un único parche muestra
`NO CHIP / IS / SELECTED` en Program Deck, Chip Folder y Data Library sin
modificar sus dos plantillas ni su paleta.

## Restricción nativa

Todos los activos se renderizan en el espacio real de WonderSwan Color:

- pantalla 224×144 y viewport 28×18 tiles;
- tile 8×8 packed 4-bpp, 32 bytes;
- mapas 32×18 o 32×26;
- paletas BGR444 originales;
- coordenadas enteras, sin antialias ni interpolación;
- marcos, fondos, cursores, flips, bank y palette flags preservados.

## Barrido visual fuera de las familias nuevas

Una ruta orgánica desde arranque recorrió título, `NEW GAME / CONTINUE`,
apertura, recepción BattleChipGP, selección de clase, fee/prize, confirmaciones,
Round 1, Program Deck, combate, resultado y regreso. No mostró japonés de
juego. Data Library primario y Save también estaban limpios; sólo compartían la
tarjeta PET ya corregida.

Después de `D070230`, el barrido hasta `D0704F0` no encontró otro recurso de
texto japonés pendiente: hay escenarios/arte, `CONGRATULATIONS`, recursos ya
traducidos o pantallas sin lenguaje.

## Preservación intencional

El splash de arranque conserva `インティ・クリエイツ`. Es el logotipo
corporativo/legal de Inti Creates, no una instrucción, diálogo, opción o menú.
Se excluye del denominador de texto de juego y no se redibuja.

## Evidencia

- `STRUCTURAL_VALIDATION_v0_10.json` — 345 spans, guards, assets, build e IPS.
- `RESIDUAL_TEXT_SCAN_v0_10.json` — inventario textual y barrido heurístico.
- `../translation/assets/shop_purchase_asset_report_v0_10.json`.
- `../translation/assets/pet_carousel_remaining_asset_report_v0_10.json`.
- `../translation/assets/host_free_menu_asset_report_v0_10.json`.
- `../translation/assets/pet_runtime_remaining_asset_report_v0_10.json`.
- `runtime_v0_10/` — capturas runtime y montajes nativos seleccionados.

## Límite de la afirmación

El resultado prueba ausencia de japonés en todos los destinos textuales
referenciados y en todas las ocurrencias gráficas de juego catalogadas. No
afirma una partida orgánica para cada combinación posible, enlace entre dos
consolas, hardware físico, corrupción de estado o datos de depuración. Las
pantallas Host dependientes de listas de amigos se respaldan por estructura,
hashes, exclusividad de tiles y renderizado exacto cuando la ruta limpia no
puede producir todos los datos requeridos.
