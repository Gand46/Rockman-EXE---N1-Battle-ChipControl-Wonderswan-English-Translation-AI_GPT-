# Validación de emulador v0.10.2

Estado: **PASS**.

La ROM privada final disponible tiene SHA-256
`b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24`
y checksum WonderSwan almacenado/calculado `0x383A / 0x383A`.

## Validación estructural previa disponible

- Maestro del logo: 224×112 dentro de la pantalla nativa 224×144.
- Formato: tiles 8×8 packed 4-bpp, sin dithering, índice 0 transparente.
- Uso: 194/208 tiles, con 14 tiles libres.
- Paletas: bloque original SHA-256
  `5bbabe397d4dec9fda37d9f6a2e0e5b871118eace3fb1790d8718ce9f7359602`,
  byte a byte intacto.
- Mapa: solo cambian filas 0–13; fila 14, créditos de filas 15–17 y columnas
  ocultas 28–31 permanecen intactos.
- El fondo animado y `PRESS START` no forman parte de los activos emitidos.

## Validación dinámica en MesenCore

| Comprobación | Resultado |
|---|---|
| Arranque limpio, sin SAV ni savestate | PASS |
| Capturas nativas 224×144 en los dos estados de parpadeo | PASS, frames 450 y 550 |
| Tiles y mapa vivos iguales a los activos v0.10.2 | PASS |
| Fondo animado sin congelación ni rectángulos opacos | PASS |
| `PRESS START` completo y con parpadeo nativo | PASS, 408 → 0 píxeles neutros |
| `LICENSED BY BANDAI` y copyright sin cambios visuales | PASS, filas protegidas |
| Paso a `NEW GAME / CONTINUE` sin recortes | PASS, frame 900 |
| Ausencia de mosaicos, halos, tiles residuales o duplicación | PASS |
| Regresión de Chip Folder con `NORMAL60` | PASS estructural; banco y evidencia v0.10.1 heredados |

Capturas verificadas:

- Frame 450, `PRESS START` visible:
  `title_press_start_visible_450.png`, SHA-256
  `cf680a3d368c8df1543bd53e2038ceb9544d0c3ad35de1ca04f0663fef6ffd31`.
- Frame 550, `PRESS START` oculto:
  `title_press_start_hidden_550.png`, SHA-256
  `961022b981c7b623401b178c93fb21464ad5a66ab0d9f86918acadbf3b513990`.
- Frame 900, menú `NEW GAME / CONTINUE`:
  `title_new_game_continue_menu_900.png`, SHA-256
  `aef79534267f02ae7118754604a32dad07d57b6bf4bdefa6e726732749fbce91`.

Los recursos vivos de logo, mapa, cinco paletas, mapa de fondo, paleta 7 y
tiles de `PRESS START` coincidieron con sus hashes esperados. El pulso real de
START se realizó en los frames 650–659 y cargó correctamente `NEW GAME`
seleccionado y `CONTINUE` sin seleccionar.

Informe final:
`docs/runtime_v0_10_2/title/title_runtime_validation_v0_10_2.json`, SHA-256
`63364d078c4d3e67e9c302ef2e5a3389399914ae761d06ab61ef7af7873bbb92`.
