# Progreso de traducción — versión 0.10.4

Estado de la candidata: **PASS estructural y runtime**.

| Alcance | Estado |
|---|---:|
| Texto codificado referenciado | 1.552/1.552 (100,00 %), heredado sin cambios de v0.10.3 |
| Gráficos localizables | 129/129 (100,00 %) |
| Japonés residual conocido en destinos catalogados | 0 |
| Logotipo reconstruido desde el PNG exacto suministrado | PASS de activo |
| Resolución de referencia y de vista previa | 224×144 |
| Tiles únicos del logotipo | 194/208; 14 libres |
| Opciones del menú PET con tipografía de bloque | 5/5 |
| Patrones asignados a la nueva fuente | 57/57; 0 libres |
| Allowlist de cambios frente a v0.10.3 | 4 spans gráficos + checksum; 0 bytes fuera |
| Checksum WonderSwan | PASS, `0x7684` |
| Composición del IPS desde la base v0.10.3 | PASS |
| Validación de emulador sobre la ROM final v0.10.4 | **PASS** |

## Cambios gráficos

### Portada

`translation/assets/title_logo_reference_v0_10_4.png` es la única referencia
artística del logotipo. Su SHA-256 es
`f1394a24454413e44933fb5981825dd97daa93647b05ece03ecb0fbf91b9973e`.
Es un PNG indexado de 224×144, con paleta de 256 entradas y chunk `tRNS` de
un byte (`00`): el índice de paleta 0 es transparente y no se sustituye por un
lienzo negro opaco.

No se redibujó el contenido. El proceso permitido recorta exclusivamente el
borde alfa del PNG, aplica escala uniforme nearest-neighbour y centra el
resultado. La capa final ocupa 196×99 píxeles desde `(14,4)` hasta `(210,103)`
en coordenadas exclusivas. El maestro conserva alfa real, termina en `y=102`,
usa 194 de los 208 tiles disponibles y deja una separación estructural de un
píxel antes de `PRESS START`.

No se emiten ni modifican el fondo animado, `PRESS START`, los créditos, las
cinco paletas, las filas 14–17 del mapa ni sus columnas ocultas 28–31.

### Menú raíz del PET

Las cinco opciones `PROGRAM DECK`, `CHIP FOLDER`, `DATA LIBRARY`, `NETNAVI` y
`SAVE` se reconstruyen con letras de bloque de píxel entero inspiradas en la
referencia visual suministrada. No se usa antialiasing ni reescalado
fraccional. Tras proteger el tile funcional `0x45`, el banco dispone de 57 IDs
reemplazables y los 57 patrones únicos están asignados; no quedan IDs libres.

La intervención protege el panel derecho, `CLASS`, el cursor, el sufijo estático
`Z`, los dígitos dinámicos de rango/créditos y los tiles de marco `0x45` y
`0x46`. En particular, `0x45` sigue reservado para la esquina runtime de la
fila 16.

## Allowlist exacta frente a v0.10.3

| Recurso | Offset | Longitud | Bytes realmente distintos |
|---|---:|---:|---:|
| Mapa BG0 del logo | `0x0409A6` | 1.152 | 293 |
| Mapa BG0 de etiquetas PET | `0x042DBA` | 1.024 | 56 |
| Tiles del logo | `0x071BC0` | 6.656 | 5.563 |
| Tiles de etiquetas PET | `0x07C330` | 2.432 | 1.553 |
| Checksum WonderSwan | `0x3FFFFE` | 2 | 2 |

Total: 7.467 bytes distintos respecto de v0.10.3 y cero cambios fuera de los
cuatro spans gráficos autorizados más los dos bytes del checksum.

## Artefactos finales conocidos

- ROM privada v0.10.4, 4.194.304 bytes, SHA-256
  `ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2`.
- IPS v0.10.4, 241.997 bytes, SHA-256
  `025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b`.
- Checksum almacenado/calculado: `0x7684 / 0x7684`.
- El IPS normalizado conserva la base pública sobre la ROM japonesa Rev 1 y su
  prueba de composición contra v0.10.3 es `PASS`.

## Validación runtime final

La ROM final identificada por SHA-256
`ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2`
se ejecutó mediante MesenCore desde entornos limpios, sin SAV ni savestate.
Las cuatro capturas son nativas de 224×144.

En la portada, los frames 450 y 550 comprobaron las fases visible y oculta de
`PRESS START`. El núcleo opaco del logo en `y=0–101` tuvo cero diferencias
entre ambas fases; 3.845 de 12.179 píxeles transparentes cambiaron con el fondo
animado, las 40 celdas mixtas examinadas mostraron animación y no apareció
ningún relleno rectangular estático. Una pulsación real de START en los frames
650–659 abrió `NEW GAME / CONTINUE` en el frame 900. Tiles, mapa, paletas,
fondo y aviso vivos coincidieron con sus activos.

El menú raíz del PET se capturó en el frame 27000 mediante una ruta limpia y
sin inyección de memoria. La imagen 224×144 RGB444 coincide píxel a píxel con
la vista previa esperada; los tiles y el mapa BG0 vivos coinciden exactamente
con los activos. No existen referencias de tiles cambiados ni cambios de mapa
fuera de las etiquetas. El tile `0x45`, la palabra de esquina `0x2445` en
`(11,16)`, el cursor, `CLASS`, rango, créditos y marcos permanecen protegidos;
el recuento de píxeles protegidos distintos es cero.

Informes:

- `docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json`, SHA-256
  `89701fa441175db8291654c40ef48754bb92bffdd3771b49187279a8bcb9897a`.
- `docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json`,
  SHA-256
  `47de9aabd6ea15d07c84477bed366c25557ac380cedd7340014dfe26a75cae90`.
- Resumen consolidado: `docs/EMULATOR_VALIDATION_v0_10_4.md`.
