# Progreso v0.10.7 RC4

La traducción base continúa en 1.552/1.552 registros textuales y 129/129
gráficos localizables. RC4 no amplía ese inventario: corrige la composición de
los cuadros inferiores y preserva todos los ajustes gráficos aprobados en RC3.

## Diálogo normal con retrato

- Líneas RC3 de 20 columnas detectadas: 71.
- Páginas afectadas: 67.
- Entradas afectadas: 52.
- Redistribuciones con texto exacto: 56.
- Condensaciones mínimas revisadas: 11.
- Líneas restantes por encima de 19 columnas: 0.
- Páginas restantes por encima de tres filas: 0.
- Entradas que exceden su span original: 0.

## Batalla, resultados y pausa

- Bancos B1/B2: generador RC4 independiente cerrado y determinista.
- Cuadros con retrato: límite de 19 columnas y tres filas.
- Resultados sin retrato: límite de 26 columnas.
- Menú de pausa: límite de ocho columnas por opción.
- Punteros nulos y flags de terminación: idénticos a la base.
- `VIEW DECK` → `DECK`: incluido para liberar el slot de `RETRY`.
- Destinos modificados: 23 en B1 y uno en B2.
- Saltos nativos `0x0800`: 13, únicamente en el último registro del grupo.
- Capacidad libre final: 284 bytes en B1 y 84 bytes en B2.

## Estado de cierre

| Compuerta | Estado |
|---|---:|
| Generación determinista del manifiesto intermedio | PASS |
| Auditoría de 271 entradas normales | PASS |
| Generación final B1/B2 | PASS |
| Manifiesto acumulativo RC4 | PASS |
| Validación estructural de ROM/IPS | PASS |
| Mecanismo de tercera fila en MesenCore | PASS |
| Cinco rutas limpias de diálogo/pausa/batalla | PASS |
| Tres soportes exactos y grupo posterior limpio | PASS |
| Suite pública autocontenida | 44 PASS / 1 opcional omitida |
| Empaquetado determinista y libre de ROM | PASS |

El delta frente a RC3 es de 3.355 bytes, con cero cambios fuera de 56 spans
guardados y cero recursos gráficos estáticos alterados.
