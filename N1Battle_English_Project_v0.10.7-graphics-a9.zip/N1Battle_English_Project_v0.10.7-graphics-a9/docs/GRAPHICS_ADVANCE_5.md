# Avance gráfico 5: segunda cabecera CHIP FOLDER

## Resultado

La cabecera de la pantalla principal de Chip Folder reutiliza ahora el mismo
patrón `CHIP FOLDER` aprobado en el Avance 3. La semántica se mantiene literal:
`チップフォルダ` corresponde a `CHIP FOLDER`. No se crea una fuente nueva ni
se altera el banco gráfico compartido.

## Método

La pantalla principal usa el mapa BG0 de `0x043F40`, mientras que la instancia
aprobada de A3 está en `0x0438BE`. Ambas usan el mismo banco de 5.824 bytes en
`0x07EC10` y los mismos atributos `0x2400`. A5 sustituye únicamente los IDs de
las doce celdas `(11,0)`–`(16,1)` por `0x02A`–`0x030` y `0x037`–`0x03B`,
conservando todos los bits de atributo.

El grafo final asigna a cada patrón exactamente dos consumidores previstos:
la cabecera alterna de A3 y la cabecera principal de A5. No se escriben tiles,
paletas, código, diálogo, punteros, iconos, lista de chips ni datos dinámicos.

## Auditoría

- Base A4 SHA-256: `e640da75a810a3cc7699c93333d164dfbf444baef006c5d26bbec176d84d62c8`.
- ROM A5 SHA-256: `254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522`.
- IPS A5 SHA-256: `2beb302099fc4b6c661c1db39722978cf83f6705b8edf7856d21e812e0627faf`.
- Delta A4→A5: 12 bytes bajos de mapa y 2 bytes de checksum; cero bytes de tile o paleta.
- Checksum WonderSwan almacenado/calculado: `0x5286 / 0x5286`.
- Captura principal: 524 píxeles distintos, caja `[88,0,132,16]`, cero fuera de `[88,0,136,16]`.
- Ordenación y mochila: cero píxeles distintos frente a A4.
- ROM/RAM: mapas y tiles activos coinciden byte a byte.
- Máscara: coincidencia exacta con el patrón A3 aprobado y sus tres índices de paleta.

Evidencia: `docs/runtime_graphics_advances/advance_5_gate_final/graphics_advance_5_runtime_validation.json`.
