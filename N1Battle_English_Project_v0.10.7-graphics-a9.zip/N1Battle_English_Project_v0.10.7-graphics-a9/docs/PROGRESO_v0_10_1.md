# Progreso de traducción — versión 0.10.1

| Alcance | Estado |
|---|---:|
| Texto codificado referenciado | 1.552/1.552 (100,00 %) |
| Gráficos localizables | 128/128 (100,00 %) |
| Logotipo de marca WSC preservado | 1 |
| Efectos grandes compatibles con fuente 8×16 | 108/108 |
| Japonés residual en destinos catalogados | 0 |

La portada usa nuevamente el logotipo original de WonderSwan a 224×144. La
decisión se registra fuera del denominador traducible. Los efectos de chips
conservan toda su información y se muestran en mayúsculas, que es el juego de
glifos compatible con el renderer grande de la consola.
