# Progreso de traducción — versión 0.10.3

| Alcance | Estado |
|---|---:|
| Texto codificado referenciado | 1.552/1.552 (100,00 %) |
| Gráficos localizables | 129/129 (100,00 %) |
| Logotipo principal localizado al inglés | 1/1 |
| Pantallazos aportados a la auditoría visual | 7/7 resueltos o clasificados |
| Máscaras dinámicas del teclado inglés | 3/3 |
| Celdas erróneas de paleta `CAPACITY` | 6/6 corregidas |
| Efectos grandes compatibles con fuente 8×16 | 108/108 |
| Japonés residual conocido en destinos catalogados | 0 |
| Validación estructural final v0.10.3 | PASS |
| Barrido residual final v0.10.3 | PASS |
| Validación de emulador sobre la ROM v0.10.3 | PASS |
| Pruebas automatizadas | 32 OK, 1 omitida opcional |

La v0.10.3 corrige los defectos de composición encontrados en la auditoría
visual posterior a v0.10.2. El logo conserva la composición inglesa, pero su
alfa ya no inmoviliza 340 píxeles del fondo animado ni invade la zona de
`PRESS START`. La limpieza elimina 384 píxeles en total; el maestro final usa
191/208 tiles y deja 17 libres.

El teclado tenía un mapa inglés correcto bajo seis sprites de selección cuyas
transparencias todavía correspondían a kana. Las tres máscaras `LOW`, `CAP` y
`ABC` se regeneraron contra los glifos ingleses. En Program Deck se corrigió
la paleta de seis celdas de `CAPACITY` y se reemplazaron cuatro rótulos
comprimidos por texto 5×7 de píxel entero. La flecha de dirección y el
pictograma de tipo/ranura se verificaron como arte funcional original y no se
alteraron.

La reconstrucción final produce ROM SHA-256
`eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc`,
IPS SHA-256
`db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7`
y checksum WonderSwan válido `0xAFC4`. El build directo y la ROM reconstruida
mediante el IPS son idénticos.

Informes finales:

- `STRUCTURAL_VALIDATION_v0_10_3.json`, estado `PASS`, SHA-256
  `f8d64503aab0f9381ab0fbbf8bec18d2445fc650e12a4395aea2ad7beb3d57a6`.
- `RESIDUAL_TEXT_SCAN_v0_10_3.json`, SHA-256
  `e0f7756f2d2815e9a12cce2dc6faa68426ec679725a25c393a2c502a47ea819a`.
- `runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json`, SHA-256
  `fe7d85b843cf0ae565e963e4f5d5e4f42cfc58fad70bca803890728f3569fa81`.
- `runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json`,
  SHA-256
  `5380cb6f21039cde10e2142955bf451c3d64a8fdd7832e0d797d9f9c2f23d8a2`.
- `runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json`,
  SHA-256
  `fa58af36c6bd32a54d01f75b08eb403f60d1a878dfa93d068f26deec87433a2d`.
