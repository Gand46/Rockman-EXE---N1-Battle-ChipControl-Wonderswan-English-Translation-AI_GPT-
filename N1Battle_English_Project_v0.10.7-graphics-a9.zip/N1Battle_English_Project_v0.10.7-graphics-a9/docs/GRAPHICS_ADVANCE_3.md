# Avance gráfico 3 — cabecera Program Deck alterna

## Resultado

El Avance 3 reconstruye `PROGRAM DECK Y4` y `CHIP FOLDER` y elimina el
residuo de 8×16 situado inmediatamente a la derecha de este último rótulo
sobre la base aprobada del Avance 2. La corrección conserva la presentación de
pixel art seleccionada, elimina los solapamientos y mantiene intacta toda la
interfaz ajena a los dos carteles.

## Revisión semántica

La pantalla japonesa ejecutándose contiene `プログラムデッキ Y4` y
`チップフォルダ`. Por tanto, las traducciones válidas son `PROGRAM DECK Y4`
y `CHIP FOLDER`. El rótulo anterior `AUTO CONTROL` pertenecía a otra función y
se descarta.

## Corrección de pixel art

- `PROGRAM DECK` usa frente oscuro sobre la flecha naranja.
- `Y4` se dibuja una sola vez, en naranja sobre el campo gris.
- Se elimina la máscara oscura duplicada que cubría el indicador naranja.
- `CHIP FOLDER` usa las máscaras nativas derivadas de la fuente BN5 aprobada.
- El campo de 48×16 conserva 4 píxeles de margen izquierdo, 5 de margen
  derecho, un píxel mínimo entre glifos y tres píxeles entre palabras.
- No se aplican filtros, escalado ni antialiasing.

## Alcance binario

- Base Avance 2: `55616bc011c8439a693587c08dae9cf814801e61879ce280e253b0674e6004e5`.
- ROM candidata: `2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c`.
- IPS acumulativo: `0d7d2ca8d516489b8452f55438dda497fc39ecff363ed5fd6b299facf274b316`.
- Checksum WonderSwan: `0x33C6`.
- Banco modificado: `0x07EC10–0x0802CF`.
- 284 bytes de tiles cambian dentro de 19 slots exclusivos.
- El mapa `0x0438BE–0x043F3D` cambia únicamente en los bytes bajos de las
  celdas `(16,0)` y `(16,1)`: `0x240B/0x241C` → `0x2404/0x2404`.
- El tile `0x01C`, compartido con otra pantalla, permanece intacto.
- La diferencia completa contra A2 contiene 288 bytes: 284 del banco de
  texto, dos del mapa y dos del checksum.

## Auditoría en ejecución

La ruta `program_alt` parte de un arranque limpio y captura la pantalla en
MesenCore 2.1.1 a 224×144. La RAM activa coincide con los mapas y tiles de la
ROM candidata.

| Compuerta | Resultado |
|---|---:|
| Píxeles cambiados frente a A2 | 478 |
| Píxeles fuera de los tres rectángulos autorizados | 0 |
| Solapamientos de glifos | 0 |
| Píxeles oscuros duplicados en `Y4` | 0 |
| Residuo `[128,0,136,16]` | 0 píxeles; fondo uniforme |
| Vecinos desde x=136 | Exactos frente a A2 |
| Interfaz desde la fila 16 | Exacta frente a A2 |
| Mapa activo ROM/RAM | Exacto |
| Tiles activos ROM/RAM | Exactos |

La captura primaria es
`docs/runtime_graphics_advances/advance_3_gate_final/program_alt_button_27440.png`
con SHA-256
`7ad998a2a27e225568f492aa011476a20675ec613512d51132704e4fd115080b`.

## Regla nueva

Se incorpora R20: toda corrección debe validar el significado contra la ROM
original, preservar límites medibles entre palabras, usar el contraste propio
de cada campo y comprobar las coordenadas visibles después del scroll. Un
texto de otra función, un glifo duplicado o un residuo oculto rechaza el avance.

Se incorpora además R21: un gráfico contiguo ambiguo no puede protegerse como
“funcional” sin demostrar un cambio de estado o una dependencia real. Si debe
eliminarse y usa un tile compartido, se reasigna únicamente su celda de mapa y
se exige fondo uniforme con ambos vecinos intactos.
