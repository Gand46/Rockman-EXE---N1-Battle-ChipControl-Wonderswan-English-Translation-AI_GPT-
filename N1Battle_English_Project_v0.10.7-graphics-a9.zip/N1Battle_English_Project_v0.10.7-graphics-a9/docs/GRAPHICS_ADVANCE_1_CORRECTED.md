# Avance gráfico 1 corregido — v0.10.7

## Resultado

Se retiró únicamente el símbolo marcado entre `PROGRAM DECK` y `Y2 CHIP FOLDER`. La franja corrupta del borde izquierdo del intento anterior fue eliminada y los textos e iconos vecinos fueron restaurados.

## Causa raíz

El atlas de Program Deck se carga en RAM desde `0x8020`: el ID de tile `N` del mapa consume el slot `N-1` del activo. La auditoría anterior supuso una relación directa y sobrescribió el slot `0x010`, compartido por 15 celdas del borde izquierdo.

## Corrección

- Celdas objetivo `(18,0)` y `(18,1)` limpiadas con `0x240C`.
- `PROGRAM DECK`, `Y2 CHIP FOLDER` y pictograma Y2 restaurados desde la referencia aprobada.
- Slot compartido `0x010` restaurado para sus 15 consumidores del borde izquierdo.
- Ningún consumidor externo sin resolver.
- Cero cambios binarios fuera de la allowlist.
- Cero píxeles modificados fuera de las dos regiones autorizadas.
- ROM candidata reconstruida exactamente desde el manifiesto y desde el IPS acumulativo.

## Identidades

- ROM de validación: `63ce8069d89106fdc96167a14d139641db202d23e0a2cd539347e19f8fcd8575`.
- IPS acumulativo: `874bb8a02d3f21e45883d1c051159c6721b1c9472f04458594b646c31f2f1fb0`.
- Captura nativa final: `b079d82d662f06c4dae943eb893d3abb8684fa4135fdc00ed713e55a61f35921`.

La ROM se usa únicamente para validación y no forma parte del paquete público.
