# Validación en MesenCore — v0.10.7 RC3

La compilación final se validó con el núcleo extraído del Mesen 2.1.1 adjunto,
SHA-256 `36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9`.
Cada ruta parte de un directorio vacío, no carga SAV ni savestate y elimina la
persistencia creada por el propio emulador al terminar.

| Ruta | Capturas | Verificación |
|---|---:|---|
| Program raíz | 2 | `PROGRAM DECK`, `Y2 CHIP FOLDER`, barra Start |
| Program alternativa | 1 | `AUTO CONTROL` e icono funcional |
| Chip | 3 | `CHIP FOLDER`, ordenación y `BACKPACK` |
| Data | 2 | `DATA LIBRARY` con y sin datos |
| NetNavi | 2 | raíz y estadísticas |
| Manual Program Deck | 3 | estadísticas, orden y herramienta |

Resultado: seis arranques limpios y 13 capturas a 224×144. En las diez
capturas PET, los mapas y tiles cargados en RAM coinciden exactamente con la
ROM RC3. En el manual, la franja superior de estadísticas de 224×80 coincide
píxel por píxel con el activo renderizado mediante su paleta real. La región
inferior de diálogo coincide píxel por píxel con la referencia aprobada.

Evidencia reproducible:

- `runtime_v0_10_7_rc3/pet_deep/redbox_pet_runtime_validation_v0_10_7_rc3.json`
- `runtime_v0_10_7_rc3/pet_deep/redbox_pet_runtime_montage_v0_10_7_rc3.png`
- `runtime_v0_10_7_rc3/program_deck/program_deck_runtime_validation_v0_10_7_rc3.json`
- `runtime_v0_10_7_rc3/program_deck/program_deck_stats_17400.png`

