# N1Battle English Project v0.10.7 RC4

RC4 es una revisión correctiva acumulativa construida sobre la RC3 aprobada.
Su único alcance funcional es impedir que el texto de los cuadros inferiores
invada el retrato, el marco, otra opción o una cuarta fila inexistente.

## Identidad

| Elemento | Valor |
|---|---|
| Base preservada | v0.10.7 RC3 |
| ROM final privada | `129ef89f09e2fef3a6c7f1acce11f62ff0c615ca583317e5e5b106f029bbe1b8` |
| IPS | `1f4270eab41a0401381c8ba53087faa337436337933932dc3623d1cf4321d2e9` |
| Checksum WonderSwan | `0xCB1C` |
| Manifiesto final | `translation/en_v0_10_7_rc4.json` |

El IPS reconstruye de forma exacta la ROM candidata desde la ROM japonesa Rev
1 verificada. La ROM se usa únicamente para validación y no forma parte del
paquete público.

## Geometría auditada

- Fuente dinámica: celdas fijas de 8×16 píxeles.
- Cuadro inferior con retrato: 152 píxeles útiles, equivalentes a 19 columnas.
- Capacidad vertical: tres filas.
- Cuadro sin retrato: 208 píxeles útiles, equivalentes a 26 columnas.
- Opciones del menú de pausa: slots independientes de ocho columnas.

## Corrección acumulativa

- 71 líneas de 20 columnas del diálogo normal de RC3 se redistribuyen en 67
  páginas y 52 entradas.
- 56 páginas conservan exactamente sus palabras y cambian solo los saltos de
  línea.
- 11 páginas reciben una condensación mínima, enumerada y reproducible, porque
  el texto original requería cuatro filas a 19 columnas.
- Los bancos B1/B2 de batalla y resultados se regeneran por separado,
  conservando la topología de punteros nulos, los flags de terminación y la
  capacidad fija de cada banco.
- Trece grupos B1 usan el control nativo `0x0800` en el último registro del
  grupo. La sonda MesenCore demostró que este control crea la fila adicional y
  que reutilizar el separador nulo, en cambio, mezcla el mensaje siguiente.
- La opción `VIEW DECK` del menú de pausa se reduce a `DECK` dentro de su slot,
  evitando que tape `RETRY`.
- Los casos mostrados en los soportes (`Navi and chip match type!`, `MegaMan
  was paralyzed` y `is numb and cannot move!`) quedan cubiertos por la
  auditoría específica de batalla.

## Compuertas de cierre

- [x] ROM final e IPS fijados con SHA-256.
- [x] Checksum WonderSwan válido.
- [x] Cero líneas literales por encima de la anchura asignada.
- [x] Cero páginas por encima de tres filas.
- [x] Cero cambios fuera de la allowlist RC4.
- [x] Topología B1/B2 y punteros nulos preservados.
- [x] Sonda del mecanismo de tercera fila desde arranque limpio, sin SAV ni
  savestate.
- [x] Cinco rutas MesenCore limpias: diálogo normal, pausa y los tres soportes
  exactos de batalla.
- [x] Grupo siguiente limpio después de cada mensaje de tres filas.
- [x] Suite pública autocontenida sin fallos: 44 correctas y una opcional
  omitida por ausencia de una partida privada.
- [x] ZIP público generado dos veces con la misma huella y sin contenido
  privado.

La RC3 se conserva como entrega independiente; RC4 no reescribe su parche ni
sus evidencias.
