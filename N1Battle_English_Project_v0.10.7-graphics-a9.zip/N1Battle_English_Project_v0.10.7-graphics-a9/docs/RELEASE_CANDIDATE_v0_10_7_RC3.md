# N1Battle English Project v0.10.7 RC3

RC3 es una revisión correctiva construida directamente sobre la v0.10.6
aprobada. No contiene ni reutiliza activos, composición o decisiones de RC2.

## Identidad

| Elemento | Valor |
|---|---|
| Base aprobada | v0.10.6 pixel-polished |
| ROM final privada | `6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c` |
| IPS | `165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980` |
| Checksum WonderSwan | `0xE8FF` |
| Manifiesto | 271 entradas textuales y 80 binarias |

## Cierre de auditoría

- 17 incidencias rojas corregidas y un duplicado NetNavi armonizado.
- 19 segmentos rasterizados manualmente a 1:1.
- Un símbolo ajeno eliminado de forma puntual.
- Iconos funcionales, arte mixto, cursores, datos dinámicos y diálogos
  inferiores protegidos.
- 12 rangos autorizados, 4.016 bytes distintos y cero bytes externos.
- 67 pruebas correctas y una opcional omitida.
- Seis arranques limpios y 13 capturas nativas.

El paquete público incluye IPS, manifiesto, activos, herramientas, pruebas y
evidencia. No incluye ROM, BIOS, TTF, partidas, savestates ni emulador.

