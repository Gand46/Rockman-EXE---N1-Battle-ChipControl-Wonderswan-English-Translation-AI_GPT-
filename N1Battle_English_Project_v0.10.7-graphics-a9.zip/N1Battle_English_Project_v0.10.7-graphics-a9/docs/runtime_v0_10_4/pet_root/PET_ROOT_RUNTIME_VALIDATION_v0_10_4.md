# PET root runtime validation v0.10.4

- Result: **PASS**
- ROM SHA-256: `ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2`
- Clean boot: yes; SAV/savestate/memory injection: no
- START: frames 650–659
- Capture: frame 27000, 224×144
- Live tiles match asset: `True`
- Live BG0 map matches asset: `True`
- Changed-tile references outside labels: `0`
- Protected screen-pixel differences: `0`

## Protected elements

- CLASS tiles: `True`
- Static Z tiles: `True`
- Frame/separator tiles: `True`
- Cursor pixels: `True`
- CLASS/rank/credits panel pixels: `True`

Red pixels in `pet_root_runtime_vs_expected_diff.png` are changes outside the five allowed label rectangles; yellow pixels would be differences inside them.
