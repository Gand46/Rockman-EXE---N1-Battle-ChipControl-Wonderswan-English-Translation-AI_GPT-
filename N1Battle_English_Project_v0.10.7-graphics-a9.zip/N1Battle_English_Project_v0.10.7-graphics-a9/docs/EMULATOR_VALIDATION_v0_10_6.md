# Validación de emulador v0.10.6

- Emulador: MesenCore.
- Resolución: 224×144 nativa.
- Arranques: 9, todos limpios.
- SAV, savestate o inyección de memoria: no.
- Capturas revisadas: 45.
- Resultado: `PASS`.
- Separación mínima entre compuestos de glifo: 1 píxel nativo.
- Rasterización: ambos TTF más retoque manual nativo, sin remuestreo ni antialiasing.

## Rutas comprobadas

- Menú raíz PET: cinco opciones, `CLASS`, `E` y `3000Z`.
- Teclado: páginas `LOW`, `CAP` y `ABC`, máscaras OBJ e IDs vivos de mapa
  incluidos.
- Carrusel: `SHOP`, `BATTLE CHIP GP`, `FREE BATTLE` y `HOST TOURNEY`.
- SHOP interior: `1 Chip`, `10 Chips`, `Info`, precios y Zenny.
- SAVE: `SAVE`, `Data Library`, `Battle Chips`, `Credits` y valores dinámicos.
- Free Battle: `STREAK 0` con las cuatro celdas del contador BG1 intactas.
- Rutas profundas Host/Free heredadas para descartar colisiones de tiles.
- Selección BATTLE CHIP GP: `A CLS`–`E CLS`, columnas BG 8/9 liberadas,
  cursor e iconos verde/amarillo/rosa visibles.

En PET, la captura del frame 27000 coincide píxel a píxel con la
previsualización reconstruida; fuera de los seis campos permitidos hay cero
diferencias. En SHOP y SAVE, los mapas y tiles vivos coinciden exactamente con
los activos finales y los cuadros de diálogo inferiores permanecen visibles
sin cambios. La inspección confirma que los rótulos PET y `1 Chip`, `10 Chips`
e `Info` no comparten columnas de cara ni se solapan. En el teclado, la página
`ABC` usa una distribución de IDs distinta de la implementación PNG anterior;
el validador comprueba ahora la relación cargada por el mapa TTF final.

La captura de clase demuestra que el texto `E CLS` termina antes de `x=64`.
El primer icono de torneo, que seguía presente como OBJ pero quedaba detrás de
las dos `S` finales de `E CLASS`, vuelve a verse completo sin alterar los otros
sprites ni los datos Fee/Prize.

Evidencia: `docs/runtime_v0_10_6/`.
