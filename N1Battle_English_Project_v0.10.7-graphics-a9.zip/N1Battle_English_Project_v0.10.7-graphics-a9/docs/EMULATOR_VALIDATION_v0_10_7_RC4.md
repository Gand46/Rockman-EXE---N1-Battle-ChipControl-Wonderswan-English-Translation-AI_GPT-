# Validación MesenCore — v0.10.7 RC4

## Objetivo

Comprobar en el motor real que los cuadros inferiores admiten tres filas sin
invadir el retrato, el marco o el siguiente grupo de mensajes, y que el menú
de pausa conserva tres opciones visualmente separadas.

## Condiciones obligatorias

- ROM reconstruida desde la revisión japonesa verificada.
- Arranque limpio para cada ruta.
- Resolución nativa de 224×144.
- Sin SAV, savestate, inyección de partida ni archivos del emulador en el
  paquete público.
- Comparación de mapa, tiles y punteros activos cuando el caso lo permita.

## Casos de prueba

| Caso | Resultado |
|---|---:|
| Sonda controlada de tercera fila | PASS |
| Grupo siguiente limpio después de la tercera fila | PASS |
| `Navi and chip match / type! Chip Attack / increased!` | PASS |
| `MegaMan was / paralyzed` | PASS |
| `MegaMan / is numb and cannot / move!` | PASS |
| Pausa `DECK / RETRY / GIVE UP` | PASS |
| Regresión del diálogo normal con retrato | PASS |

## Resultado final

- Cinco rutas independientes desde arranque limpio.
- Diálogo normal comprobado en `f8550`: `I'm here to / register for /
  BattleChipGP.`, sin píxeles fuera del área segura.
- Pausa comprobada orgánicamente en `f32592`: 38 píxeles entre `DECK` y
  `RETRY`, 25 entre `RETRY` y `GIVE UP`, y 12 hasta el borde derecho.
- Los tres casos aportados se comprobaron con redirecciones temporales hacia
  sus registros finales exactos; esas ROM de sonda se destruyeron al terminar
  cada proceso y la ROM final nunca se modificó.
- El grupo posterior se capturó limpio en `f33300` en las tres sondas.
- Cero SAV, savestates, dumps de CPU, directorios de Mesen o ROM de sonda
  conservados.

El informe reproducible está en
`docs/runtime_v0_10_7_rc4/battle_dialogue/`
`battle_dialogue_runtime_validation_v0_10_7_rc4.json` y el montaje final en
`battle_dialogue_runtime_montage_v0_10_7_rc4.png`.

La imagen `battle_engine_null_separator_bleed_f32820.png` es una **prueba
negativa intencional**: documenta que consumir un puntero nulo fusiona el
grupo siguiente y crea una cuarta fila recortada. Ese mecanismo fue rechazado.
La solución final usa el control nativo `0x0800`, cuya tercera fila y limpieza
del grupo siguiente se muestran en los otros paneles de
`battle_engine_line_mechanism_comparison_v0_10_7_rc4.png`.
