# Graphics Advance 8 — limpieza de la tarjeta `NO CHIP SELECTED`

## Resultado

La tarjeta compartida de estado vacío ya no conserva la última fila del texto
japonés original debajo de `NO CHIP / IS / SELECTED`. La composición inglesa,
la franja amarilla `NO DATA SELECTED`, las estadísticas y el marco mantienen
su posición, color y geometría original.

## Localización y corrección

El banco gráfico compartido ocupa `0x2B0A20–0x2B1120`. La traducción v0.10
había reconstruido los tres primeros renglones de la tarjeta, tiles
`0x018–0x02F`, pero la cuarta fila física conservaba el remate japonés en los
tiles `0x032–0x035`.

La corrección limpia solamente el interior `[2,24,62,28]` de la tarjeta
64×32. En las filas 24–26 se restablece el fondo de índice 1; en la fila 27 se
restablece el índice 14 para conservar una línea de marco continua. Las dos
columnas laterales y las filas 28–31 del borde permanecen idénticas a A7.

## Validación

- Base A7: `e049ce549ddbbe695995cc7c76863a201e22199e064daaa24f2e542dcedaf9fa`.
- ROM A8 privada: `aafa083e8781d58858c35cf729ed18c9269126cba70c789e1e631844071e3749`.
- IPS acumulativo: `d4f05841889955bd0818994f05637203bbea376b31ef90edf08cd2ba8e1c3165`.
- Manifiesto A8: `aef62af89624e73f8b9bc5cab7521477fdae683c4202c6c3188419268843ad59`.
- Checksum WonderSwan almacenado/calculado: `0xB6E7 / 0xB6E7`.
- Delta frente a A7: 37 bytes del banco y dos bytes del checksum; cero fuera
  de la lista blanca.
- `NO CHIP / IS / SELECTED` y las cinco filas inferiores del marco conservan
  su máscara autorizada; mapas, paletas, código y punteros no cambian.
- Cuatro arranques limpios ejecutan los pares A7/A8 de Backpack y Data Library.
  Cada consumidor cambia 43 píxeles y cero fuera de su franja residual.
- El banco vivo cargado en RAM desde `0xA800` coincide byte a byte con la ROM.
- `chip_folder`, `chip_sort` y `data_library` permanecen píxel a píxel idénticos.
- El IPS y el manifiesto reconstruyen exactamente la misma ROM candidata.

El cierre acumulativo aplica las 28 reglas y se registra en
`build/graphics_advance_rules_validation.json`.
