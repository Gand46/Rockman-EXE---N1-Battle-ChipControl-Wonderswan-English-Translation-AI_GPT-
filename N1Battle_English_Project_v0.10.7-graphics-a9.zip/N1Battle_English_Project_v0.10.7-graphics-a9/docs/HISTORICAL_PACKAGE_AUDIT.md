# Auditoría histórica y método de parcheado hasta Graphics Advance 5

## Fuentes recibidas

| Entrega | SHA-256 del ZIP recibido | Estado |
|---|---|---|
| v0.10.7 RC4 | `7e64247ab15d73863c574c1f6c5987e90311f3b2bfc4b2c4f33232c5f548f4fd` | ZIP válido, 416 entradas |
| Graphics A1 | `30a60093b078ed645b46e0bf1abfa8378a07004290768b69986aca8cfd0a9124` | ZIP válido, 434 entradas |
| Graphics A2 | `c31a4179fb3c8444a3fe4c4257d712ca3a21818a1384bab80d28c5a866cfc69d` | ZIP válido, 448 entradas |
| Graphics A3 | `7136c8c1b1e7bbffb3415d8c7c93d748f5446d49a6cae91a207bc6260a94fed3` | ZIP válido, 465 entradas; coincide con la entrega publicada |
| Graphics A4 | `b42c9cb64cb66fad5eabe114b9a87a8f037b59317ef0f850addbad346e47e1cb` | Carga truncada: 3.511.364 bytes, sin directorio central; 254 entradas locales recuperables |

La huella publicada del ZIP A4 completo era
`abe3cf62b35a158f19b14ce5fc300d41bbc693c76363848ece4cdb833eeb9a28`
con 471 archivos. La copia recibida no puede considerarse ese archivo completo.
No obstante, su IPS separado sí coincide con la entrega publicada:
`8c5dc76eb9a5841453f613d4babb3d1eb83e7fa114729b66c6f233b96e3302f9`.

## Reconstrucción de la línea acumulativa

La ROM japonesa Rev 1 se identifica por SHA-256
`4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed`.
El manifiesto A3 reconstruyó de forma exacta la ROM A3
`2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c`.
Aplicar el IPS A4 verificado sobre la misma ROM japonesa produjo exactamente
`e640da75a810a3cc7699c93333d164dfbf444baef006c5d26bbec176d84d62c8`,
con checksum WonderSwan `0x50F4`. Los dos activos A4 que faltaban en el ZIP
truncado se extrajeron de esa ROM verificada y coinciden con las huellas
publicadas:

- mapa de estadísticas: `ed8ae281f04b285ce93c5ad92411ce2643fd1ece8600a0042f7a10ec1b2d1cad`;
- tiles internos del manual: `f465f7ecb14960d06156a34970dc4d98db1f19b101bd68b16ddacd4358a88218`.

## Evolución de los métodos

| Avance | Método principal | Protección añadida |
|---|---|---|
| A1 | Corrección de dos celdas y restauración de un tile compartido | Mapeo vivo, grafo de consumidores y bordes completos |
| A2 | Pixel art nativo en carteles de dos filas y IDs exclusivos | Geometría japonesa, máscara interna y restauración de derrames |
| A3 | Reconstrucción de dos cabeceras y limpieza por mapa | Fidelidad semántica, contraste por campo y prueba de función |
| A4 | Composición de ocho campos con asignación de patrones en dos pasadas | Glosario literal y auditoría BG/OBJ/datos dinámicos |
| A5 | Reutilización de doce patrones A3 mediante referencias de mapa | Patrón canónico, dos consumidores previstos y cero tiles nuevos |

El proyecto usa parches *in-place*: cada entrada declara offset, longitud y
huella del fragmento japonés esperado. `n1tool.py` rechaza otra revisión,
escribe solo dentro de los spans declarados, repara el checksum y genera un
IPS acumulativo. La ROM del manifiesto y la reconstruida desde el IPS deben
ser idénticas byte a byte.

Las correcciones gráficas separan mapa, banco de tiles y atributos. Antes de
escribir se inspeccionan los consumidores; después se compara la ROM candidata
con la base mediante una allowlist binaria. MesenCore arranca sin SAV ni
savestate, captura a 224×144 y comprueba que mapa y tiles vivos en RAM son los
mismos que contiene la ROM.

## Cierre A5

A5 modifica solo las doce referencias BG0 `(11,0)`–`(16,1)` de la pantalla
principal de Chip Folder y los dos bytes del checksum. Reutiliza los IDs A3
`0x02A`–`0x030` y `0x037`–`0x03B`; cada patrón queda con exactamente dos
consumidores previstos. El banco de tiles y las paletas no cambian.

La ROM candidata es
`254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522`,
el IPS es
`2beb302099fc4b6c661c1db39722978cf83f6705b8edf7856d21e812e0627faf`
y el checksum es `0x5286`. En ejecución cambian 524 píxeles, todos dentro de
`[88,0,136,16]`; ordenación y mochila son idénticas a A4. Las 25 reglas
acumulativas cierran en `PASS`.
