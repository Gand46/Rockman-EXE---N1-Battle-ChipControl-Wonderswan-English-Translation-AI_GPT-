# Progreso de traducción — versión 0.10

## Resultado

La cobertura se informa por dominios separados para que cada denominador sea
reproducible:

| Métrica | Resultado | Porcentaje |
|---|---:|---:|
| Texto codificado y referenciado | 1.552/1.552 | **100,00 %** |
| Ocurrencias gráficas catalogadas | 129/129 | **100,00 %** |
| Destinos de juego catalogados con japonés | 0 | **0,00 % restante** |

Las rutas de emulador se expresan como casos aprobados, no como porcentaje de
todo el juego: no existe un denominador finito para cada combinación de
partida, enlace y estado dinámico.

La ROM final pasó 10 arranques limpios y 46 capturas nativas: Shop (1/24),
Free/Host (4/12) y PET profundo (5/10). Una sonda controlada adicional abrió
el diálogo de 10 chips que el saldo inicial no permite alcanzar; no se cuenta
como ejecución de la ROM final y queda identificada por sus tres bytes de
diferencia.

## Texto

El inventario textual de v0.9 permanece cerrado y se volvió a auditar contra
la ROM v0.10:

```text
274 diálogos
+ 88 destinos auxiliares
+ 1 confirmación directa
+ 882 filas de bases estáticas
+ 49 ataques Navi
+ 73 participantes
+ 185 mensajes de batalla/resultado
= 1.552 unidades
```

Los 1.552 destinos terminan correctamente y contienen cero glifos japoneses.
El barrido completo conserva sólo fragmentos huérfanos no referenciados y dos
coincidencias binarias documentadas.

## Gráficos

La validación de v0.10 corrigió el alcance anterior: v0.9 había cerrado 75
ocurrencias, pero su ruta de Shop sólo seleccionaba la tarjeta exterior y la
captura PET sólo inspeccionaba el viewport inicial de mapas de 26 filas.

| Punto de control | Ocurrencias | Porcentaje del inventario v0.10 |
|---|---:|---:|
| Base v0.9 | 75/129 | 58,14 % |
| + interior de Shop | 78/129 | 60,47 % |
| + carrusel Free/Host | 80/129 | 62,02 % |
| + menús Host/Free | 111/129 | 86,05 % |
| + estados profundos PET | 129/129 | **100,00 %** |

Las 54 ocurrencias añadidas se distribuyen así:

- Shop: 3 (`1 CHIP`, `10 CHIPS`, `INFO`).
- Carrusel: 2 (`FREE BATTLE`, `HOST TOURNEY`).
- Host/Free: 31 en diez pantallas o variantes.
- PET profundo: 18, incluidas barras desplazadas, controles alternos y la
  tarjeta compartida `NO CHIP / IS / SELECTED` en tres consumidores.

## Restricción estética

Cada activo se genera para 224×144 píxeles, 28×18 tiles visibles, tiles 8×8
packed 4-bpp y paletas BGR444. Se conservan dimensiones, marcos, flags, bancos,
cursores y paletas. La tipografía nueva usa píxel entero sin antialias.

## Criterio de cierre

Una ocurrencia cuenta sólo si está integrada en el manifiesto, protegida por
hash de origen, cabe en su pool, conserva los consumidores compartidos y pasa
la reconstrucción/IPS/checksum. Los límites de rutas y el logotipo corporativo
japonés preservado se documentan en `RESIDUAL_JAPANESE_AUDIT_v0_10.md`.
