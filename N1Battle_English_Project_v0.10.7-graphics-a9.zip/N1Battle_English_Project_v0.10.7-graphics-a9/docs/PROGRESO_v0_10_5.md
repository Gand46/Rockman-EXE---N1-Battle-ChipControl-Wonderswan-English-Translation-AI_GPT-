# Progreso validado v0.10.5

La revisión v0.10.5 limita los rótulos de efecto de las fichas grandes a un
máximo de seis caracteres. Se conservan completos los valores numéricos y los
modificadores `~`/`+`; el rótulo compartido `NO DATA` pasa a `NODATA`.

## Resultado

| Comprobación | Resultado |
|---|---:|
| Punteros auditados | 249/249 |
| Destinos únicos | 70/70 |
| Destinos únicos abreviados | 43 |
| Apariciones actualizadas | 194 |
| Longitud máxima final | 6 |
| Reservas `NODATA` | 136 |
| Colisiones de abreviaturas | 0 |
| Punteros modificados | 0 |
| Texto heredado | 1.552/1.552 |
| Gráficos heredados | 129/129 |
| Japonés referenciado inesperado | 0 |

Los cinco chips especiales cuyo campo de efecto está vacío permanecen vacíos.
No se modifican nombres, daño, código, descripciones, mapas, tiles, paletas,
logotipo ni tipografía del menú.

## Aislamiento binario

Frente a v0.10.4 cambian 187 bytes: 185 dentro del banco
`0x369550–0x36A4DF` y los dos bytes del checksum WonderSwan. No hay cambios
fuera de esa lista permitida y la cola no referenciada del banco se conserva.

## Ejecución real

MesenCore recorrió desde un arranque limpio la transición START, el PET y
`CHIP FOLDER`, sin SAV ni savestate. Se comprobaron `NORM60` en Cannon y
`NODATA` en una ficha vacía, ambos a 224×144. Los mapas y tiles vivos de las
tres pantallas capturadas coinciden con la ROM final.

La validación estructural y la composición del IPS concluyen en `PASS`.
