# Validación de emulador v0.10.5

- Emulador: MesenCore.
- Resolución: 224×144 nativa.
- Arranque: limpio, sin SAV ni savestate.
- Ruta: START real → PET → CHIP FOLDER → ordenación → mochila.
- Resultado: `PASS`.

## Rótulos comprobados

- Cannon: `NORMAL60` → `NORM60`.
- Ficha vacía: `NO DATA` → `NODATA` en el campo de efecto.

El `NO DATA` amarillo de la tarjeta de aviso se conserva porque es otra capa
funcional y no forma parte del rótulo de efecto solicitado.

Las diferencias frente a las capturas anteriores quedan confinadas al campo
de efecto: `(56,82)–(88,95)` para Cannon y `(184,82)–(224,95)` para la ficha
vacía. No se observan artefactos, recortes ni pérdida de información.

Evidencia: `docs/runtime_v0_10_5/chip_effect/`.
