# Auditoría residual japonesa v0.10.2

Resultado: **PASS**.

## Evidencia final

- La base heredada v0.10.1 cerró en `PASS` los 1.552 destinos textuales
  codificados y referenciados.
- El manifiesto v0.10.2 mantiene 1.552/1.552 unidades textuales y amplía el
  inventario gráfico a 129/129 al contar el logotipo principal localizado.
- El nuevo maestro muestra `MEGA MAN / BATTLE NETWORK / N1 BATTLE`; no contiene
  texto japonés y su conversión estructural está en `PASS`.
- Las filas 14–17 del mapa, que protegen la zona inferior y los textos legales,
  permanecen byte a byte iguales a la fuente.
- Los 108 efectos no vacíos de chips se heredan sin cambios de v0.10.1: ASCII
  en mayúsculas, estilo `0x0600` y máximo de ocho glifos.
- El logotipo corporativo/legal de Inti Creates del arranque se conserva
  intencionalmente como marca, no como diálogo o menú.
- El inventario autoritativo enumeró 1.552/1.552 registros, con cero destinos y
  cero glifos japoneses referenciados.
- El barrido heurístico de ROM completa encontró 474 candidatos crudos. Dos
  estaban fuera de los pools y ambos coincidieron exactamente con la allowlist;
  quedaron cero candidatos inesperados.
- La reconstrucción canónica y el manifiesto de 271 entradas textuales y 75
  binarias producen byte a byte la ROM final esperada.
- MesenCore validó la portada inglesa en arranque limpio y la transición real
  al menú, sin restos visibles del logotipo japonés.

La evidencia máquina-legible está en:

- `RESIDUAL_TEXT_SCAN_v0_10_2.json`, SHA-256
  `f5a19dcc70633669298e69150e9040b0473dbc5da52a419c35b4ae9d3714ed27`.
- `STRUCTURAL_VALIDATION_v0_10_2.json`, SHA-256
  `863abca9af78a801b2219a6c7072db1f92676448e574a82e5c193a72fcf2b561`.
