# Progreso v0.10.7 RC3

La traducción continúa en 1.552/1.552 registros textuales y 129/129 gráficos
localizables. RC3 no amplía ese inventario: corrige la presentación de las
fuentes estáticas marcadas sobre la v0.10.6 aprobada.

- Incidencias tipográficas señaladas: 17/17.
- Duplicados compartidos armonizados: 1/1.
- Símbolos ajenos señalados: 1/1.
- Rangos gráficos guardados: 12/12.
- Bytes fuera de allowlist: 0.
- Capturas nativas nuevas: 13/13.
- Pruebas automatizadas: 67 PASS, 0 FAIL, 1 SKIP opcional.

Estado de RC3: **PASS**.

