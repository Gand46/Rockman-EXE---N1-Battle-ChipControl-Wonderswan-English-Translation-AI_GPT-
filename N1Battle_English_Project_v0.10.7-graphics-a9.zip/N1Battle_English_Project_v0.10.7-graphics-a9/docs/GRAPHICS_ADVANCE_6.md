# Avance gráfico 6: cantidades compactas en Backpack

## Resultado

La cantidad situada a la derecha de `MB` usa ahora dígitos de pixel art de
3×5, alineados como un superíndice dentro de la celda original de 8×16. Solo
cambia el contador de existencias de Backpack. Los números grandes de
capacidad y los dígitos incluidos en nombres como `Quake1` y `Meteor3`
permanecen idénticos al Avance 5.

## Método

La llamada de cinco bytes en ROM `0x33835C` se redirige a un envoltorio de
282 bytes alojado en el tramo vacío y no referenciado
`[0x37D6D8,0x37D7F2)`. El envoltorio ejecuta primero el renderizador numérico
original para conservar su caché y después reasigna únicamente las siete
celdas visibles de cantidad a pares propios. Finalmente limpia esos pares y
dibuja el dígito compacto con la paleta que recibió la llamada original.

El campo continúa siendo de una sola columna. Por eso `0–9` se representan
directamente y los valores superiores muestran su última cifra: `10→0`,
`11→1`, `12→2` y `255→5`. No se cambia el valor almacenado ni la lógica del
inventario.

Los pares `0x0BC/0x0BD`, `0x0BE/0x0BF`, `0x0C0/0x0C1`, `0x0C6/0x0C7`,
`0x0D6/0x0D7`, `0x0E0/0x0E1` y `0x0E2/0x0E3` se eligieron después de revisar
los mapas ROM relacionados, las dos capas completas de 32×32 en ejecución y
el rango OBJ observado. Cada uno tiene un solo consumidor final: su celda de
cantidad correspondiente.

## Auditoría

- Base A5 SHA-256: `254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522`.
- ROM A6 SHA-256: `9b135e34db6b20d8135c79476bd72a7118500e176ee8f5eee3c0c99fe3bb333b`.
- IPS A6 SHA-256: `05e449483f5ee665688e60548b1d06d458c689e572e5e5801bd259cc8925cb0a`.
- Checksum WonderSwan almacenado/calculado: `0xB4FB / 0xB4FB`.
- Delta A5→A6: 268 bytes efectivos, todos dentro de llamada, host y checksum.
- Mochila poblada: 195 píxeles distintos, caja `[128,25,135,134]`, cero fuera
  de las siete celdas de cantidad.
- Mochila desplazada: 210 píxeles distintos y cero fuera de las cantidades.
- Pruebas exactas de los diez dígitos y de `10`, `11`, `12` y `255`.
- Backpack vacío y pantalla principal Chip Folder: coincidencia exacta con A5.
- Cero consumidores en la otra capa, mapas ROM relacionados u OBJ.

La evidencia está en
`docs/runtime_graphics_advances/advance_6_gate_final/graphics_advance_6_runtime_validation.json`.
