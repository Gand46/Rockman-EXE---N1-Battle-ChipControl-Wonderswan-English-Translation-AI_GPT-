# Auditoría residual japonesa v0.10.3

Resultado: **PASS**.

## Evidencia final

- El manifiesto v0.10.3 conserva 1.552/1.552 unidades textuales y 129/129
  ocurrencias gráficas localizables, con cero destinos referenciados que
  contengan japonés.
- La portada muestra `MEGA MAN / BATTLE NETWORK / N1 BATTLE`. La máscara de
  limpieza retira exactamente 384 píxeles ajenos al logo sin incorporar texto
  japonés ni modificar los textos legales inferiores.
- Las páginas `LOW`, `CAP` y `ABC` del registro de nombre usan máscaras OBJ
  derivadas de los rótulos ingleses. La página inicial `LOW` ya no combina una
  cuadrícula latina con recortes de kana.
- Los rótulos revisados de Program Deck son ASCII y se renderizan con una
  fuente 5×7 de píxel entero. La flecha y el pictograma señalados en la
  auditoría son elementos funcionales sin texto y se conservan iguales a la
  fuente japonesa.
- Los 108 efectos no vacíos de chips continúan en ASCII mayúsculo, con estilo
  `0x0600` y un máximo de ocho glifos.
- El logotipo corporativo/legal de Inti Creates del arranque se conserva
  intencionalmente como marca, no como diálogo o menú.
- El inventario autoritativo enumeró 1.552/1.552 registros, con cero destinos
  y cero glifos japoneses referenciados.
- El barrido heurístico de ROM completa encontró 474 candidatos crudos. Dos
  estaban fuera de los pools y ambos coincidieron exactamente con la
  allowlist; quedaron cero candidatos inesperados.
- La reconstrucción canónica y el manifiesto de 271 entradas textuales y 77
  binarias producen byte a byte la ROM final esperada.
- MesenCore validó en arranque limpio la portada y las tres páginas del
  teclado. La validación final de Program Deck coteja sus recursos vivos y la
  composición nativa documentada en el informe de emulador.

La evidencia máquina-legible está en:

- `RESIDUAL_TEXT_SCAN_v0_10_3.json`, SHA-256
  `e0f7756f2d2815e9a12cce2dc6faa68426ec679725a25c393a2c502a47ea819a`.
- `STRUCTURAL_VALIDATION_v0_10_3.json`, con estado `PASS`, SHA-256
  `f8d64503aab0f9381ab0fbbf8bec18d2445fc650e12a4395aea2ad7beb3d57a6`.
- `runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json`, SHA-256
  `fe7d85b843cf0ae565e963e4f5d5e4f42cfc58fad70bca803890728f3569fa81`.
- `runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json`,
  SHA-256
  `5380cb6f21039cde10e2142955bf451c3d64a8fdd7832e0d797d9f9c2f23d8a2`.
- `runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json`,
  SHA-256
  `fa58af36c6bd32a54d01f75b08eb403f60d1a878dfa93d068f26deec87433a2d`.
