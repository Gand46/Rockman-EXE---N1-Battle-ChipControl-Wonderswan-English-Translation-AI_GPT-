# Lower-dialogue layout — v0.10.7 RC4

## Scope

This RC4 step corrects the normal lower dialogue stored in `entries` without
modifying the immutable RC3 manifest.

The active dynamic font uses fixed 8×16-pixel cells. A box that reserves the
64-pixel portrait area has 152 visible pixels, so its safe layout is:

- 19 characters per line;
- 3 lines per page.

RC3 contained 71 lines of 20 characters across 67 pages and 52 entries.

## Reproducible generation

Run from the project root:

```bash
python tools/lower_dialogue_layout_v0_10_7_rc4.py
```

The tool accepts only the pinned RC3 manifest SHA-256
`2a0d1096a2a898c7fa4191b733da3abaab89aff284de5592fc1e8b19b81e07f1`
and writes:

- `translation/en_v0_10_7_rc4_dialogue.json` (intermediate manifest);
- `translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json`.

## Result

- 56 pages retain their exact wording and only redistribute `[LINE]` breaks.
- 11 pages use explicit minimal condensations because exact wording needs four
  rows at 19 columns.
- 0 literal lines exceed 19 characters.
- 0 pages exceed 3 rows.
- All 52 changed entries remain inside their original byte spans.
- All offsets, lengths, portraits, waits, dynamic fields, binary entries and
  unrelated RC3 data remain unchanged.

The separate B1/B2 battle-message banks are not modified by this transformer;
their per-record layout requires its own RC4 asset generation and validation.
The cumulative `translation/en_v0_10_7_rc4.json` integrates this intermediate
manifest with the separately audited B1/B2 assets; this transformer remains
independently reproducible.

## Tests

```bash
python -m unittest tests.test_lower_dialogue_layout_v0_10_7_rc4 -v
```

The dedicated suite checks deterministic generation, exact-wording reflow,
the eleven reviewed condensations, all 271 entry layouts, encoded byte
capacity, immutability of unrelated fields and rejection of an altered RC3
source manifest.
