# Validación de emulador v0.10.4

Estado: **PASS**.

La ROM final validada tiene SHA-256
`ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2`
y checksum WonderSwan `0x7684`. Las rutas se ejecutaron con MesenCore desde
entornos limpios, sin SAV ni savestate; todas las capturas tienen resolución
nativa 224×144.

## Portada

Informe:
`docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json`, SHA-256
`89701fa441175db8291654c40ef48754bb92bffdd3771b49187279a8bcb9897a`.

| Comprobación | Resultado |
|---|---|
| Arranque limpio; sin SAV ni savestate | PASS |
| `PRESS START` visible, frame 450 | PASS, 408 píxeles blancos neutros |
| `PRESS START` oculto, frame 550 | PASS, 0 píxeles blancos neutros |
| Pulsación real de START, frames 650–659 | PASS |
| Transición a `NEW GAME / CONTINUE`, frame 900 | PASS |
| Tiles, mapa, cinco paletas, fondo y aviso vivos | PASS, coinciden con sus activos |
| Núcleo opaco del logo en `y=0–101` entre las dos fases | PASS, 0 diferencias |
| Transparencia sobre el fondo animado | PASS, 3.845/12.179 píxeles cambiaron |
| Celdas mixtas de borde con fondo dinámico | PASS, 40/40 |
| Rellenos rectangulares estáticos sospechosos | PASS, ninguno |
| Separación logo/`PRESS START` | PASS, 0 píxeles superpuestos |

El frame oculto coincide exactamente con el maestro en sus 10.680 píxeles
opacos. En el frame visible solo cambian cinco píxeles de sombra en la fila
`y=102`, donde comienza la interacción visual del aviso; el núcleo `y=0–101`
permanece idéntico. La zona transparente cambia en un 31,57 % entre las dos
fases y todas las celdas que mezclan logo y transparencia dejan ver animación,
lo que descarta el lienzo negro opaco observado en la revisión anterior.

Capturas:

- `docs/runtime_v0_10_4/title/title_press_start_visible_450.png`, SHA-256
  `48ff9970d70312ab01f54ded37d3c8f8333f9486afc7e232ea5c2365ca29fac1`.
- `docs/runtime_v0_10_4/title/title_press_start_hidden_550.png`, SHA-256
  `03debd3937bd32648883e0ddddbc0e951cf2a21826467db79fcd786c311a6d36`.
- `docs/runtime_v0_10_4/title/title_new_game_continue_menu_900.png`, SHA-256
  `a4e565aeb82ea78498e7b01d6cd274b0282d791aaef75325578da4ab3f109fec`.

## Menú raíz del PET

Informe:
`docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json`,
SHA-256
`47de9aabd6ea15d07c84477bed366c25557ac380cedd7340014dfe26a75cae90`.

La ruta alcanzó el menú en el frame 27000 tras un arranque limpio, sin SAV,
savestate ni inyección de memoria. El núcleo usado fue `MesenCore.so`, SHA-256
`36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9`.

| Comprobación | Resultado |
|---|---|
| Captura nativa 224×144 RGB444 | PASS |
| Imagen runtime frente a la vista previa esperada | PASS, 0 píxeles distintos |
| Tiles vivos frente al activo | PASS, coincidencia SHA-256 exacta |
| Mapa BG0 vivo frente al activo | PASS, coincidencia SHA-256 exacta |
| Referencias de tiles cambiados fuera de las etiquetas | PASS, 0 |
| Cambios serializados del mapa fuera de las etiquetas | PASS, 0 |
| Píxeles protegidos frente a la base | PASS, 0 distintos |
| Tiles `CLASS` `0x3C–0x41` | PASS, idénticos a la base |
| Tiles estáticos `Z` `0x2B/0x30` | PASS, idénticos a la base |
| Tiles de marco `0x45/0x46` | PASS, idénticos a la base |
| Esquina inferior runtime `(11,16)` | PASS, palabra `0x2445` |
| Cursor y panel `CLASS`/rango/créditos | PASS, píxeles idénticos |

Hashes vivos:

- Tiles en `CPU:0x8020`, 2.432 bytes:
  `f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2`.
- Mapa BG0 en `CPU:0x2000`, 1.024 bytes:
  `926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c`.
- Tile protegido `0x45`, vivo y base:
  `c597c10469398d7c2169e97d548f3dbf7a99fa0e3c5326a7872230e9064f01d7`.

Captura:

- `docs/runtime_v0_10_4/pet_root/pet_root_runtime_27000.png`, SHA-256
  `1a978431df1eff538b96bf081a8c44110328add3f121237f6b47270e2f4bb786`.

La prueba runtime cubre la composición completa visible del menú raíz y sus
recursos vivos. No atribuye pruebas de entrada y retorno a cada submenú, ya
que ese recorrido no forma parte de este informe.
