# Corrección tipográfica de pixel art — v0.10.7 RC3

Esta revisión descarta íntegramente la RC2 y parte de la ROM v0.10.6 aprobada,
SHA-256 `fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc`.
El alcance se limita a las áreas delimitadas en rojo por los siete soportes
aportados; los cuadros de diálogo inferiores no forman parte del trabajo.

## Criterio artístico

- `BN5DSEU Font Thin` se conserva como familia maestra por paridad con la
  interfaz v0.10.6; `SF3FontSmall` se verifica por huella como alternativa,
  pero no se mezcla en estos rótulos.
- Cada glifo visible se reemplaza por una máscara manual proporcional de
  1–5×7 píxeles a resolución final.
- No se aplica antialiasing, filtro, remuestreo, condensación posterior ni
  escalado de línea.
- Se conserva al menos una columna nativa entre caras de glifo.
- `M` abre sus valles internos; `N` extiende la diagonal durante toda la
  altura; `W` aligera la base; `G` abre el arco superior.
- Las dos apariciones de `PROGRAM DECK` comparten exactamente la misma máscara
  de 46×7, con un píxel real de margen por lado en la placa de 48 píxeles.
- Las dos apariciones de `NETNAVI` comparten la misma máscara.

## Alcance efectivo

| Grupo | Rótulos corregidos |
|---|---|
| Program Deck vivo | `PROGRAM DECK`, `Y2 CHIP FOLDER` |
| Encabezados compartidos | `AUTO CONTROL`, `DATA LIBRARY`, `BACKPACK` |
| NetNavi | `NETNAVI` marcado y duplicado raíz armonizado |
| Manual, vista general | `PROGRAM DECK`, `NAVICHIP`, `BATTLECHIP` |
| Manual, estadísticas | `NORMAL30`, `ATTACK POWER`, `RETREAT`, `VICTORY`, `CAPACITY`, `NAVI CHIP`, `BATTLE CHIP`, `BATTLE CHIP / NAVI CHIP` |

Son 17 incidencias marcadas, un duplicado armonizado, 18 instancias semánticas
y 19 segmentos rasterizados; `NAVICHIP` se divide en dos segmentos para no
invadir una celda mixta de ilustración.

El símbolo blanco ajeno situado en la celda `(17,0)` del mapa vivo se elimina
con el patrón limpio del fondo. `Y2 CHIP FOLDER` se dibuja sobre el índice 4
nativo en vez de repetir un tile que contenía píxeles índice 8, evitando que el
fondo contamine su cara naranja.

## Protecciones comprobadas

- Flecha/pictograma Y2 en `(27,0)` y `(27,1)`.
- Icono funcional de `AUTO CONTROL` en `(16,0)` y `(16,1)`.
- Celda diminuta no marcada `(18,1)`.
- Mapa y apariencia completa de la pantalla no marcada `CHIP FOLDER`.
- Celdas mixtas del manual `(1,2)`, `(6,2)`, `(3,7)`, `(6,7)` y `(27,7)`.
- Dos píxeles de acento no textual del encabezado NetNavi de estadísticas.
- Cursores, marcos, pictogramas, valores dinámicos, cadenas y cuadros de
  diálogo inferiores.

Los cinco tiles huérfanos del banco Program y diez del banco compartido están
enumerados explícitamente y se comprueban sin consumidor en todos sus mapas.
NetNavi y el manual no reutilizan tiles huérfanos. No existe ningún alias de
tile modificado fuera de los rectángulos autorizados.

## Resultado

- 12 rangos gráficos guardados.
- 4.014 bytes gráficos distintos y dos bytes de checksum.
- Cero bytes fuera de la allowlist.
- 67 pruebas correctas, cero fallos y una prueba opcional omitida.
- Seis arranques limpios y 13 capturas nativas a 224×144.
- ROM final: `6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c`.
- IPS final: `165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980`.

