@echo off
setlocal

if "%~1"=="" goto :usage

set "PROJECT=%~dp0"
set "SOURCE_ROM=%~1"
set "OUTPUT_ROM=%~2"
if not defined OUTPUT_ROM set "OUTPUT_ROM=%PROJECT%build\Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.wsc"

if not exist "%PROJECT%build" mkdir "%PROJECT%build"

py -3 "%PROJECT%tools\n1tool.py" apply "%SOURCE_ROM%" "%PROJECT%patches\Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.ips" "%OUTPUT_ROM%"
if errorlevel 1 exit /b %errorlevel%

echo.
echo ROM parcheada: "%OUTPUT_ROM%"
exit /b 0

:usage
echo Uso: APPLY_PATCH.bat "ROM japonesa Rev 1.wsc" ["salida.wsc"]
exit /b 2
