# Rockman EXE N1 Battle — traducción completa al inglés

Versión del proyecto: **0.10.7 — Graphics Advance 9**

Este paquete contiene el parche IPS, el manifiesto editable, los activos de
interfaz, las herramientas de reconstrucción y la evidencia de validación. No
incluye la ROM japonesa ni modificada, BIOS, firmware, partidas, savestates o
ejecutables de emulador.

## Estado validado

| Alcance | Resultado |
|---|---:|
| Texto codificado y referenciado | **1.552/1.552 = 100,00 %** |
| Gráficos localizables catalogados | **129/129 = 100,00 %** |
| Logotipo principal localizado al inglés | **1/1** |
| Japonés restante en destinos de juego catalogados | **0** |
| Pantalla nativa / maestro de logo | **224×144 / 224×112** |
| Hallazgos visuales v0.10.3 aportados y auditados | **7/7** |
| Ajustes gráficos solicitados para v0.10.4 | **2/2** |
| Rótulos de efecto con máximo de 6 caracteres | **249/249** |
| Rótulos estáticos reconstruidos desde los TTF adjuntos | **25/25** |
| Incidencias tipográficas marcadas en rojo corregidas | **17/17** |
| Duplicados compartidos armonizados | **1/1** |
| Símbolos ajenos eliminados | **1/1** |
| Capturas nativas RC3 desde arranque limpio | **13/13** |
| Líneas normales RC3 desbordadas corregidas en RC4 | **71/71** |
| Páginas normales RC4 dentro de 19×3 | **67/67** |
| Destinos B1/B2 corregidos en RC4 | **24/24** |
| Rótulos de estadísticas recompuestos en el Avance 4 | **8/8** |
| Segunda cabecera `CHIP FOLDER` armonizada | **1/1** |
| Contador compacto de Backpack aislado | **1/1** |
| Intertítulo `1 MONTH LATER...` centrado | **1/1** |
| Tarjeta `NO CHIP SELECTED` sin residuos japoneses | **3/3 consumidores** |
| Primer chip de MegaMan junto a `OK` restaurado | **1/1** |
| Reglas acumulativas de avances gráficos | **29/29** |
| Avances gráficos protegidos por regresión | **9/9** |
| Consumidores externos sin resolver | **0** |

El Avance gráfico 1 corregido elimina exclusivamente el símbolo de 8×16
píxeles situado entre `PROGRAM DECK` y `Y2 CHIP FOLDER`. También revierte el
daño colateral del intento anterior: restaura ambos rótulos, el pictograma Y2
y la banda izquierda completa. La relación viva comprobada es
`slot de atlas = ID de tile - 1`; el slot compartido `0x010` vuelve a servir a
sus 15 celdas del borde sin artefactos.

El Avance gráfico 2 reconstruye `PROGRAM DECK`, `NAVICHIP` y `BATTLECHIP`
en la vista general del manual. Los glifos tienen 9 píxeles de alto, un píxel
mínimo de separación y ocupan sus carteles completos de dos filas. La
geometría fue contrastada con la ROM japonesa: `BATTLECHIP` pertenece a las
filas 6–7, y la fila 8 púrpura queda excluida y restaurada. Cuatro celdas de
`PROGRAM DECK` usan IDs libres para mantener los 32 tiles objetivo sin dañar
gráficos compartidos. Cinco capturas limpias confirman cero píxeles alterados
fuera de los carteles, máscaras internas exactas y diálogo inferior idéntico.

El Avance gráfico 3 reconstruye `PROGRAM DECK Y4` y `CHIP FOLDER` en la
cabecera alterna. Conserva la fuente de pixel art seleccionada, separa `Y4`
en su campo gris con frente naranja y elimina el duplicado oscuro que causaba
el solapamiento. La traducción se verificó contra el japonés original:
`チップフォルダ` significa `CHIP FOLDER`, por lo que `AUTO CONTROL` queda
descartado. Una captura limpia confirma cero cambios fuera de ambos carteles.
También elimina el bloque residual de 8×16 a la derecha de `CHIP FOLDER` sin
alterar su tile compartido: solo se reasignan dos celdas del mapa al fondo gris.

El Avance gráfico 4 recompone los ocho rótulos de estadísticas de Program Deck
con el glosario aprobado. Los textos largos se distribuyen únicamente entre
palabras y se dibujan directamente a píxel nativo con las caras BN5 y compacta
ya disponibles en el proyecto. No se usan abreviaturas, filtros ni escalado;
`HP/SP/CS`, conectores, `140/210 MB`, iconos y diálogo inferior permanecen
intactos.

El Avance gráfico 5 armoniza la cabecera de la pantalla principal de Chip
Folder con el patrón `CHIP FOLDER` aprobado en A3. Solo reasigna doce
referencias BG0 y conserva los atributos originales; el banco de tiles, las
paletas y los demás recursos permanecen idénticos. Dos arranques limpios
confirman 524 píxeles distintos dentro de `[88,0,136,16]`, cero fuera y
coincidencia exacta de mapa y tiles entre ROM y RAM.

El Avance gráfico 6 sustituye únicamente el contador de existencias de
Backpack por dígitos 3×5 alineados como superíndice. La fuente numérica grande
compartida no se modifica: `Quake1`, `Meteor3`, capacidades y `MB` permanecen
idénticos. Siete pares de tiles sin consumidores externos aíslan las filas
visibles; se probaron los diez dígitos, `10/11/12/255`, desplazamiento,
Backpack vacío y Chip Folder principal.

El Avance gráfico 7 centra únicamente `1 MONTH LATER...`. La cadena de 16
celdas pasa de la columna 11 a la 6, por lo que su tramo `[48,176)` queda
centrado exactamente en `x=112`. La intervención cambia solo el argumento
horizontal de la llamada exclusiva del estado `0x0D`; texto, puntero, eje
vertical, renderizador, fuente, paletas y fondos permanecen intactos.

El Avance gráfico 8 limpia la cuarta fila física de la tarjeta compartida
`NO CHIP / IS / SELECTED`, donde permanecían los últimos píxeles del japonés
original. Las tres líneas inglesas y los laterales no cambian; la fila que
comparte el marco se reconstruye con su color uniforme para no adelgazarlo.
Backpack y Data Library cambian exactamente 43 píxeles dentro de la franja
autorizada y cargan desde RAM el mismo banco verificado de la ROM.

El Avance gráfico 9 restaura el cuadrante inferior izquierdo de 8×8 píxeles
del primer chip de MegaMan situado junto a `OK` en Program Deck. La causa era
un desfase de índice: el tile vivo `0x0E9` consume el activo `0x0E8`, no el
activo con su mismo número. Solo se recuperan desde la ROM japonesa los 29
bytes distintos de ese patrón; el mapa, las paletas, el código, los punteros,
el texto y la barra inglesa `DECK FILE` permanecen intactos.

Desde este avance, cada corrección gráfica debe superar las 29 reglas de
`docs/GRAPHICS_ADVANCE_RULES.md`, incluidas protección semántica de vecinos,
grafo completo de consumidores, auditoría de los cuatro bordes, diferencia
visual global, propiedad exclusiva de tiles, escaneo del rectángulo completo
y reconstrucción independiente del IPS. La regla 19 obliga a obtener la
geometría desde la ROM original y a verificar máscara interna, paleta,
componentes conectados y cualquier franja invadida por un intento anterior.
La regla 20 exige fidelidad semántica, separación medible entre palabras,
contraste correcto por campo y validación de coordenadas visibles con scroll.
La regla 21 prohíbe proteger como funcional cualquier gráfico ambiguo sin una
prueba de estado y obliga a aislar por mapa los residuos que usen tiles compartidos.
Las reglas 22–24 fijan el glosario y la propiedad semántica de cada conector,
reservan los patrones necesarios antes de reasignar tiles y extienden la
auditoría a BG0, BG1, OBJ y consumidores dinámicos como el diálogo inferior.
La regla 25 obliga a reutilizar los patrones canónicos cuando otra pantalla
presenta el mismo texto, función, geometría y paleta, cerrando explícitamente
su grafo de consumidores antes de crear gráficos nuevos.
La regla 26 obliga a aislar cualquier ajuste de un número dinámico mediante
una llamada específica y tiles sin consumidores en mapas ROM, BG0, BG1 u OBJ.
La regla 27 exige calcular el centrado con el ancho codificado completo y
aislar la coordenada de la escena, sin espacios artificiales ni cambios en el
renderizador compartido.
La regla 28 obliga a auditar las filas situadas debajo de la última línea
traducida y, cuando comparten un borde, a reconstruir su color uniforme sin
alterar los consumidores ni el texto inglés.
La regla 29 obliga a medir el desfase real entre tile de mapa y activo cargado,
a cerrar el grafo de consumidores con esa fase y a proteger cualquier parte
exclusiva de un icono dinámico frente a traducciones gráficas adyacentes.

La v0.10 reabrió la auditoría visual de v0.9 y añadió 54 ocurrencias que no
estaban en su denominador: tres opciones del interior de Shop, dos tarjetas del
carrusel (`FREE BATTLE` y `HOST TOURNEY`), 31 rótulos de Host/Free y 18
ocurrencias profundas de PET. Entre ellas están las barras de Program Deck,
ordenación y mochila de chips, estadísticas NetNavi y la tarjeta compartida
`NO CHIP / IS / SELECTED`. La mochila usa el rótulo contextual `BACKPACK`.

El contador de Free Battle conserva sus dos celdas dinámicas y ahora aparece
como `STREAK [n]`. Shop conserva precios, Zenny, cursor, marco y diálogo. Los
menús Host conservan las paletas, mapas y pools compartidos originales.

La revisión contextual final ajustó la confirmación de tienda a `Pack: 10
chips?`, la derrota de Free Battle a `Fix the Chip Folder`, la descripción de
Host a `Host your own tournament.` y la cabecera de mochila a `BACKPACK`, sin
romper punteros internos ni superar el ancho de 20 caracteres por línea.

La v0.10.1 restaura el logotipo original de WonderSwan en la portada. La
adaptación anterior (`MEGA MAN / 1 BATTLE`) no respetaba la composición ni la
marca del juego; el banco, mapa y cinco paletas nativos vuelven a quedar
intactos. `PRESS START`, `NEW GAME` y `CONTINUE` conservan sus versiones
inglesas.

También corrige el supuesto artefacto de las fichas grandes. Esa franja era el
campo legítimo de efecto y potencia (`Normal60`, por ejemplo), pero la fuente
8×16 de WonderSwan no admite minúsculas en el estilo usado. Los 108 efectos no
vacíos se codifican ahora en mayúsculas (`NORMAL60`), sin cambiar punteros,
daño, código, mapas ni ilustraciones.

La v0.10.2 sustituye el logotipo japonés por una composición inglesa
`MEGA MAN / BATTLE NETWORK / N1 BATTLE`, reconstruida específicamente para la
cuadrícula y las paletas de WonderSwan Color. La captura de referencia no se
inserta como una pantalla plana: el parche emite únicamente una capa RGBA de
224×112 y conserva por separado el fondo animado, `PRESS START`, los textos
legales, `NEW GAME` y `CONTINUE`.

El logo usa 194 de los 208 tiles disponibles, mantiene las cinco paletas
originales y deja byte a byte intactas la fila 14, las filas legales 15–17 y
las columnas ocultas del mapa. El activo y la reconstrucción están cerrados;
la ejecución final de MesenCore, el barrido residual y la validación
estructural v0.10.2 concluyeron en `PASS`.

La v0.10.3 cierra la auditoría puntual de siete pantallazos. En la portada se
eliminaron 384 píxeles que la composición plana de v0.10.2 había confundido
con el logo: 340 restos del fondo animado y 44 píxeles de separación respecto
a `PRESS START`. El logo limpio usa 191/208 tiles, deja 17 libres y termina en
la coordenada vertical 102; el primer píxel blanco del aviso aparece en la
fila 103, sin solapamiento.

En `ENTRY NAME`, la causa no estaba en el mapa inglés sino en las máscaras OBJ
dinámicas heredadas del selector japonés. Se reconstruyeron las tres máscaras
`LOW`, `CAP` y `ABC` a partir de los rótulos ingleses y se mantuvo `LOW` como
página inicial coherente. En Program Deck se corrigieron seis celdas de
paleta que producían el rectángulo violeta de `CAPACITY` y se rediseñaron, con
fuente nativa 5×7, los rótulos `LIKELY / CHIPS`, `2 CHIPS / LEFT`,
`MIDDLE / 1 CHIP` y `PRESS START / DECK INFO`. La flecha superior y el
pictograma de tipo/ranura señalados en las capturas son información funcional
original y permanecen byte a byte iguales a la ROM japonesa.

La v0.10.4 reemplaza la portada anterior usando como única referencia
artística el PNG indexado de 224×144 suministrado. La conversión respeta su
transparencia `tRNS`, distingue el negro transparente del negro opaco del
contorno y adapta el logo mediante recorte alfa y escala nearest-neighbour a
196×99 píxeles. El resultado usa 194/208 tiles, termina en `y=102` y mantiene
intactos el fondo animado, las cinco paletas, `PRESS START` y los créditos.

También sustituye los cinco rótulos del menú raíz PET por letras de bloque
nativas de 7 píxeles con contorno de un píxel, sin antialiasing. Los 57
patrones disponibles se usan exactamente. El tile funcional `0x45`, que el
juego emplea en runtime para la esquina inferior derecha del panel, queda
protegido junto con `CLASS`, el marco, el cursor, `Z`, rango y créditos. La
captura real coincide píxel a píxel con la previsualización revisada.

La v0.10.5 reduce a seis caracteres los rótulos de efecto de las fichas
grandes. La regla conserva el número completo y los modificadores `~`/`+`, y
usa el espacio restante para las primeras letras del efecto: `NORMAL60` pasa
a `NORM60`, `NORMA120` a `NOR120` y `PIERC90+` a `PIE90+`. El rótulo
compartido `NO DATA` de este campo pasa a `NODATA`; otras capas informativas
con ese texto permanecen intactas.

Se actualizaron 43 destinos únicos y 194 apariciones sin colisiones. Los 249
punteros, cinco efectos especiales vacíos, nombres, daño, código,
descripciones, mapas, tiles y paletas no cambian. Frente a v0.10.4 solo son
distintos 185 bytes del banco de efectos y los dos bytes del checksum.

La v0.10.6 final reconstruye 25 rótulos gráficos estáticos desde `BN5DSEU Font
Thin.ttf` y `SF3FontSmall.ttf`. FreeType fija familia, tamaño y proporción, y
70 variantes de glifo se retocan después píxel a píxel para reparar trazos
rotos, contraformas cerradas y diagonales irregulares. No se escala un atlas
PNG, no se comprime la línea completa y no se usan filtros ni antialiasing. Se
mantiene al menos un píxel limpio entre compuestos. El alcance incluye teclado,
cuatro banners, menú PET, SAVE, interior de SHOP y el rótulo de racha; los
cuadros de diálogo inferiores quedan expresamente excluidos.

`BN5DSEU Font Thin` se usa para PET, SHOP, SAVE y los banners largos;
`SF3FontSmall` para los encabezados y controles del teclado y para `STREAK`.
En PET, `Program Deck`, `Chip Folder`, `Data Library`, `NetNavi`,
`Save` y `CLASS` comparten la misma familia y consumen exactamente los 63
patrones seguros. Cursor, marco, `E`, `3000Z`, precios, contadores y diálogos
permanecen intactos.

La selección de clase de BATTLE CHIP GP también queda corregida. `A CLASS`–`E
CLASS` pasan a `A CLS`–`E CLS` dentro de los mismos slots de 16 bytes, sin
mover punteros. Esto libera las dos celdas BG que tapaban el icono verde; cursor
y los tres iconos vuelven a comprobarse como sprites vivos.

MesenCore confirmó los activos en nueve arranques limpios y 45 capturas de
224×144. La página `ABC` se valida con los IDs de tiles vivos de su nuevo mapa,
y sus máscaras OBJ coinciden con las tres páginas reales. Frente a v0.10.5
cambian 4.918 bytes dentro de 21 spans guardados y el checksum; no hay
escrituras fuera de la allowlist ni cambios en los rótulos de efecto de seis
caracteres.

La v0.10.7 RC3 descarta íntegramente la RC2 y parte de la v0.10.6 aprobada.
Corrige de forma autónoma las 17 incidencias tipográficas delimitadas en rojo
y armoniza la segunda instancia compartida de `NETNAVI`. `PROGRAM DECK`,
`Y2 CHIP FOLDER`, `AUTO CONTROL`, `DATA LIBRARY`, `BACKPACK`, los encabezados
de NetNavi y los rótulos internos del manual se redibujan a resolución final
con máscaras proporcionales de 1–5×7, sin filtros, antialiasing ni escalado de
línea. Las formas de `M`, `N`, `W` y `G` se retocan manualmente para abrir
contraformas, equilibrar diagonales y conservar una columna entre glifos.

El campo de `Y2 CHIP FOLDER` se limpia sobre su fondo nativo antes de dibujar,
evitando que el patrón anterior contamine las letras. Se elimina únicamente el
símbolo blanco ajeno situado bajo el encabezado de Program Deck. La flecha Y2,
el icono de `AUTO CONTROL`, la pantalla no marcada de `CHIP FOLDER`, los
pictogramas del manual, cursores, marcos, valores dinámicos y cuadros de diálogo
inferiores permanecen intactos. La RC3 cambia 4.016 bytes frente a v0.10.6,
incluidos los dos bytes del checksum, dentro de 12 rangos guardados y con cero
escrituras externas.

La comprobación final incluye 68 pruebas automatizadas —67 correctas y una
opcional omitida—, seis arranques limpios de MesenCore y 13 capturas nativas.
Los mapas y tiles vivos coinciden con la ROM final; la página de estadísticas
coincide píxel por píxel con su render de paleta activa y el cuadro inferior es
idéntico a la referencia aprobada.

La v0.10.7 RC4 preserva íntegramente RC3 y abre por primera vez una auditoría
específica de los cuadros inferiores. La fuente dinámica usa celdas fijas de
8×16 píxeles: al reservar el retrato quedan 152 píxeles, es decir, 19
caracteres por fila y tres filas visibles. En el diálogo normal se corrigen 71
líneas de 20 caracteres repartidas entre 67 páginas y 52 entradas. Cincuenta y
seis páginas conservan exactamente sus palabras mediante nuevos saltos de
línea; once requieren condensaciones mínimas documentadas para no necesitar
una cuarta fila.

Los bancos B1/B2 de batalla y resultados se auditan por separado porque cada
puntero no nulo representa una línea física y los punteros nulos separan
grupos de despacho. La reconstrucción RC4 conserva esa topología y los flags
de terminación, limita las líneas con retrato a 19 columnas y los resultados
sin retrato a 26. También cambia `VIEW DECK` por `DECK` dentro del slot de ocho
columnas del menú de pausa, para que no cubra `RETRY`. Los casos aportados de
parálisis, entumecimiento y bonificación por coincidencia Navi/chip forman
parte de las compuertas de ejecución final. MesenCore confirmó que `0x0800`
crea la tercera fila sin alterar el grupo siguiente; consumir un separador
nulo fue rechazado porque genera una cuarta fila recortada.

La ejecución final cubre cinco arranques limpios a 224×144: diálogo normal de
tres filas, pausa y los tres casos aportados (`paralyzed`, `numb` y
coincidencia Navi/chip). `DECK`, `RETRY` y `GIVE UP` permanecen separados; el
grupo posterior a cada sonda aparece limpio. No se usaron SAV ni savestates y
no se conserva ninguna ROM temporal de prueba.

## Criterio visual de WonderSwan Color

Todos los ajustes respetan la pantalla nativa de **224×144 píxeles**
(28×18 tiles visibles), tiles de 8×8 packed 4-bpp y paletas BGR444. Los rótulos
nuevos usan una fuente compacta de píxel entero, sin suavizado ni escalado
bilineal. No se ensancharon ventanas, no se estiraron fondos y se mantuvieron
cursores, bordes, flags de mapa, bancos y paletas del juego.

El japonés visible que se conserva intencionalmente se limita a
`インティ・クリエイツ` en el splash de arranque: forma parte del logotipo
corporativo/legal de Inti Creates, no de un diálogo o menú del juego.

## Qué significa el 100 %

La cifra se aplica a los 1.552 registros textuales referenciados y a las 129
ocurrencias gráficas localizables identificadas mediante estructura de ROM,
renderizado exacto y rutas de emulador. Los bytes japoneses huérfanos que ya no
son referenciados se conservan para evitar alterar datos innecesarios.
El logotipo principal inglés se cuenta ahora como una ocurrencia gráfica
localizada.

No significa que se haya recorrido orgánicamente cada combinación de partida,
enlace entre consolas o estado corrupto. Los menús Host que requieren datos de
amigos se verifican también mediante sus mapas, tiles, exclusividad de pools y
renderizado nativo. Los límites exactos figuran en
`docs/RESIDUAL_JAPANESE_AUDIT_v0_10_3.md`; v0.10.7 RC4 conserva esa cobertura
y modifica únicamente las entradas y bancos incluidos en su allowlist de
cuadros inferiores.

## ROM compatible

Solo se admite esta revisión japonesa:

| Dato | Valor |
|---|---|
| Tamaño | `4.194.304` bytes |
| CRC-32 | `1F10CA75` |
| MD5 | `d902afdadf17b452621c50a1ffda2fa9` |
| SHA-1 | `9b4786adca7b83fe66a9d4b9fd4ffaf32abe7656` |
| SHA-256 | `4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed` |

La herramienta rechaza automáticamente cualquier otra ROM.

## Aplicar el parche

En Windows, con Python 3 instalado:

```bat
APPLY_PATCH.bat "C:\ruta\Rockman EXE - N1 Battle (Japan).wsc" "C:\ruta\N1Battle_English_v0.10.7-graphics-a7.wsc"
```

En Linux o macOS:

```bash
python3 tools/n1tool.py apply \
  "Rockman EXE - N1 Battle (Japan).wsc" \
  patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7.ips \
  N1Battle_English_v0.10.7-graphics-a7.wsc
```

## Reconstrucción reproducible

```bat
BUILD_PATCH.bat "C:\ruta\Rockman EXE - N1 Battle (Japan).wsc"
```

O directamente:

```bash
python3 tools/n1tool.py build \
  "Rockman EXE - N1 Battle (Japan).wsc" \
  translation/en_v0_10_7_graphics_a7.json \
  build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7.wsc \
  --table tables/n1battle_jp.tbl \
  --ips patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7.ips
```

Cada entrada declara offset, longitud y huella del fragmento japonés esperado.
El proceso se detiene si la ROM o cualquiera de esos fragmentos no coincide.
Las huellas de la ROM privada final, el IPS y el checksum WonderSwan se fijan
en `RELEASE_SHA256.txt` después del cierre estructural y dinámico. Se
identifican para reproducibilidad, pero la ROM no se distribuye. La
reconstrucción canónica y el IPS aplicado deben ser idénticos a esa ROM.

## Evidencia principal

- `translation/assets/graphics_advance_7_month_later_centering_report.json`:
  llamada de escena, geometría 16×8 y lista blanca binaria; `PASS`.
- `docs/runtime_graphics_advances/advance_7_gate_final/`: comparación A6/A7,
  traslación rígida y fotogramas hermanos; `PASS`.
- `build/graphics_advance_rules_validation.json`: 27 reglas acumulativas,
  reconstrucciones IPS/manifiesto y regresiones A1–A7; `PASS`.

- `docs/GRAPHICS_ADVANCE_4.md` y `build/build_v0_10_7_graphics_a4.json`:
  glosario literal, composición nativa, identidad exacta de la ROM A4 y
  checksum válido; `PASS`.
- `docs/runtime_graphics_advances/advance_4_gate_final/`: captura real a
  224×144, ocho máscaras exactas, ROM/RAM y protección del diálogo inferior.
- `translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json`: 71
  líneas, 67 páginas, 52 entradas, 56 redistribuciones exactas, 11
  condensaciones revisadas y cero desbordes restantes; `PASS`.
- `translation/assets/battle_message_asset_report_v0_10_7_rc4.json`: bancos
  B1/B2, anchos máximos, topología nula, flags y capacidad; debe cerrar en
  `PASS` antes de empaquetar.
- `docs/runtime_v0_10_7_rc4/battle_dialogue/`: evidencia a 224×144 del tercer
  renglón, limpieza del grupo siguiente y menú de pausa.
- `build/validation_v0_10_7_rc4.json`: identidad de ROM/IPS, checksum,
  allowlist y regresión acumulativa RC3.
- `translation/assets/redbox_font_asset_report_v0_10_7_rc3.json`: 17
  incidencias, un duplicado armonizado, 19 segmentos rasterizados, listas
  explícitas de tiles libres y protecciones visuales; `PASS`.
- `docs/runtime_v0_10_7_rc3/`: seis rutas limpias y 13 capturas nativas con
  mapas/tiles vivos exactos; `PASS`.
- `build/validation_v0_10_7_rc3.json`: ROM, IPS, checksum, 12 rangos,
  uniformidad de máscaras, símbolos e iconos protegidos; `PASS`.

- `translation/assets/ttf_static_ui_asset_report_v0_10_6.json`: fuentes TTF
  verificadas, 25 rótulos, 70 variantes retocadas, capacidades, mapas, tiles
  y protecciones; `PASS`.
- `translation/assets/class_selection_labels_report_v0_10_6.json`: cinco
  abreviaturas in-place, punteros intactos y allowlist; `PASS`.
- `docs/runtime_v0_10_6/`: PET, teclado, SAVE, SHOP, banners, Free/Host y
  selección de clase en
  224×144 con activos vivos exactos; `PASS`.
- `docs/STRUCTURAL_VALIDATION_v0_10_6.json`: ROM, IPS, checksum, manifiesto,
  allowlist, diálogos protegidos y herencia v0.10.5; `PASS`.
- `translation/assets/chip_effect_label_asset_report_v0_10_5.json`: regla,
  inventario, 43 transformaciones, punteros y allowlist; `PASS`.
- `docs/runtime_v0_10_5/chip_effect/`: capturas nativas de `NORM60` y
  `NODATA`, comparaciones y validación de recursos vivos; `PASS`.
- `docs/STRUCTURAL_VALIDATION_v0_10_5.json`: ROM, IPS, checksum, manifiesto,
  banco de efectos y herencia v0.10.4; `PASS`.
- `translation/assets/title_logo_asset_report_v0_10_4.json`: PNG exacto,
  transparencia, transformación, maestro, tiles, mapa y separación de
  `PRESS START`; `PASS`.
- `translation/assets/pet_root_menu_font_asset_report_v0_10_4.json`: fuente,
  capacidad, allowlists y protecciones del menú raíz; `PASS`.
- `translation/assets/quality_graphics_asset_report_v0_10_3.json`: máscaras
  del teclado, paleta y tipografía de Program Deck, y arte funcional protegido;
  `PASS`.
- `docs/STRUCTURAL_VALIDATION_v0_10_4.json`: validación heredada de portada y
  menú PET; `PASS`.
- `docs/RESIDUAL_TEXT_SCAN_v0_10_3.json`: 1.552 registros y cero candidatos
  inesperados; `PASS`, SHA-256
  `e0f7756f2d2815e9a12cce2dc6faa68426ec679725a25c393a2c502a47ea819a`.
- `docs/RESIDUAL_JAPANESE_AUDIT_v0_10_3.md`: alcance residual final.
- `docs/EMULATOR_VALIDATION_v0_10_4.md`: portada y menú raíz PET.
- `docs/runtime_v0_10_4/`: capturas e informes nativos de ambas rutas.
- `docs/runtime_v0_10_3/`: evidencia heredada de teclado y Program Deck.
- `docs/runtime_v0_10/`: 10 boots limpios, 46 capturas finales y la sonda
  documentada del diálogo de compra condicionado por 5000z.
- `docs/PROGRESO_v0_10_6.md` y `docs/progress_v0_10_6.json`: métricas y
  compuertas separadas.

La suite pública autocontenida ejecuta 45 pruebas: 44 correctas y una opcional
omitida por ausencia de una partida privada. Las 16 pruebas específicas de
RC4 pasan completas; la distribución queda bloqueada ante cualquier fallo.

Distribuye el parche, nunca una ROM modificada. Rockman, Mega Man y sus
recursos pertenecen a sus respectivos titulares.
