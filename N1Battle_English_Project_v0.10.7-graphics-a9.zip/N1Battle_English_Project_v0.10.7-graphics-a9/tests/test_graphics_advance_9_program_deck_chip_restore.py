from __future__ import annotations

import sys
import unittest
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_9_program_deck_chip_restore as a9  # noqa: E402


class GraphicsAdvance9Tests(unittest.TestCase):
    @classmethod
    def setUpClass(cls) -> None:
        cls.source = (ROOT.parents[1] / "upload/Rockman EXE - N1 Battle (Japan).wsc").read_bytes()
        cls.a8 = (ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a8.wsc").read_bytes()
        cls.output = a9.restore_tile(cls.source, cls.a8)

    def test_complete_bank_and_single_tile_allowlist(self) -> None:
        self.assertEqual(len(self.output), a9.BANK_LENGTH)
        before = self.a8[a9.BANK_OFFSET:a9.BANK_OFFSET + a9.BANK_LENGTH]
        changed = [i for i, pair in enumerate(zip(before, self.output, strict=True)) if pair[0] != pair[1]]
        self.assertEqual(len(changed), 29)
        self.assertTrue(all(a9.ASSET_INDEX * 32 <= i < (a9.ASSET_INDEX + 1) * 32 for i in changed))

    def test_restored_pattern_is_exact_original(self) -> None:
        start = a9.ASSET_INDEX * 32
        source_bank = self.source[a9.BANK_OFFSET:a9.BANK_OFFSET + a9.BANK_LENGTH]
        self.assertEqual(self.output[start:start + 32], source_bank[start:start + 32])
        self.assertEqual(a9.sha256(self.output[start:start + 32]), a9.SOURCE_TILE_SHA256)

    def test_runtime_consumer_is_exclusive(self) -> None:
        tilemap = self.a8[a9.MAP_OFFSET:a9.MAP_OFFSET + a9.MAP_LENGTH]
        self.assertEqual(a9.consumers(tilemap, a9.RUNTIME_TILE_ID), [list(a9.TARGET_CELL)])

    def test_toolbar_pool_does_not_include_runtime_tile_e9(self) -> None:
        self.assertNotIn(a9.RUNTIME_TILE_ID, set(range(0x0E2, 0x0E9)))


if __name__ == "__main__":
    unittest.main()
