#!/usr/bin/env python3
"""Validate the deep PET states in the final English v0.10 ROM.

The validator uses five independent, empty Mesen homes.  It never loads SRAM
or a savestate, captures every requested 224x144 state, dumps CPU memory, and
checks the live BG0 map and relevant tile bytes against the final ROM.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import ctypes
import hashlib
import json
import multiprocessing
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
NATIVE_DISPLAY = (224, 144)
EXPECTED_ROM_SHA256 = "0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69"

# Manual review is tied to these exact deterministic screenshots.  A fresh
# capture with different pixels remains structurally validated but must not
# inherit the visual PASS without inspection.
REVIEWED_SCREENSHOT_SHA256 = {
    "program_root": "31d6d1d2b847bb974264cbeced0d49e86273fa0c0320cfb9caf7cc14aba63aee",
    "program_start_toolbar": "ea8d14d537a3be97a33308d5b46d2b3fcefec7ea598502ffba1a54e0afff0453",
    "program_alt_button": "3ad03db59f8dae2b621f6170167d229613d15249c0b5c28d8b208687feb32aa5",
    "chip_folder": "e727ffa09d64b5dd9b113d17b37ba1360375f0ac9a1269e95c764096b900d870",
    "chip_sort": "d2185d732f3a7c00a6c833d06ea1d67316d74838cc92236b04dbcadabf895a65",
    "chip_backpack": "a70f238b5e089a40b8caea2d24321fee61124b66c4a15838e5d1fcf93f2b55ac",
    "data_library": "db9768c503de571156aef670dea217e4847e5f9bdd5c943d8f01bf75c86bcb6d",
    "data_no_data": "c9870353a4e73b0492ce7171f1c73cf2962aa3cafc5e0cfafbffb1da5132498e",
    "netnavi_root": "b56290b421ed5331d069d2793de4cf4422a4e919c2b7307e9d488c1fa0edff41",
    "netnavi_stats": "3b55da9bdd6192024db4ebf52a67695d631e12d3d14416031def3eb487746ba9",
}

VISIBLE_TEXT_BY_STATE = {
    "program_root": ["PROGRAM DECK", "Y2 CHIP FOLDER", "MegaMan", "ChgShot"],
    "program_start_toolbar": ["DECK FILE", "NAVIGATION", "NAVI CODE"],
    "program_alt_button": ["PROGRAM DECK Y4", "CHIP FOLDER"],
    "chip_folder": ["CHIP FOLDER", "Y2 PACK"],
    "chip_sort": ["NAME ATK", "HP", "SP", "CS", "TYPE"],
    "chip_backpack": [
        "CHIP FOLDER Y4", "BACKPACK", "NO DATA", "NO DATA SELECTED",
        "NO CHIP", "IS", "SELECTED",
    ],
    "data_library": ["DATA LIBRARY", "6/108"],
    "data_no_data": [
        "DATA LIBRARY", "NO DATA", "NO DATA SELECTED", "NO CHIP", "IS",
        "SELECTED", "6/108",
    ],
    "netnavi_root": [
        "NETNAVI", "Y2 MEGAMAN", "OPERATOR", "TOTAL CHIPS", "NETNAVI CODE",
    ],
    "netnavi_stats": [
        "MENU Y4", "NETNAVI", "BATTLE CHIP GP", "FREE BATTLES",
        "TOTAL RECORDS", "W", "L", "Cls E NOVICE Tour", "In 0 Win 0",
        "0W 0L 0%",
    ],
}


@dataclass(frozen=True)
class Region:
    offset: int
    length: int
    sha256: str


MAPS = {
    "program": Region(0x04323C, 0x0680, "8db80ab67444ed4190f703c2171efb8658eee86ffb0eeca29f06439396b3cd52"),
    "program_alt": Region(0x0438BE, 0x0680, "d9e6f17908ad2da229bdf53a339e20a4e78a2641e447dd700d852d14485ef2cf"),
    "chip": Region(0x043F40, 0x0680, "41e54fd79cc046fa9b5cadfd1c47d2a884f4db2a7dda7ad763185cc40c79f80c"),
    "backpack": Region(0x0445C2, 0x0680, "782e352204c6e53684b8579668a3f1a8d6cdf9487247387bc5cb5334adec4c59"),
    "data": Region(0x044C44, 0x0680, "0cea35569bcfe6b0302a51dd777653ca3089bcd23f87211d5b60d96aa0327f32"),
    "netnavi": Region(0x0452C6, 0x0480, "3966864b141ae128b02cf1020f199879b1aebe636da60e21d7776d7565aa329c"),
    "netnavi_stats": Region(0x045748, 0x0480, "51d99c5d476ad281e3e454a81c24723bdd0ac4863ef36e7c0b5038d3f1b1940f"),
}

TILE_BANKS = {
    "program": Region(0x07CD20, 0x1EF0, "fafec0b9d72bf2c1a6222e8bf074f2e41aeb3d3f94b8b8c4db45572deb73cf37"),
    "chip": Region(0x07EC10, 0x16C0, "6df9cb1a34503c6996b31d29ac569b0c4827bf5c43deb7c65f789e4e8144f0ea"),
    "netnavi": Region(0x080300, 0x0D40, "9630d2731ff5ed25b818f1164d2163846df521a0ee4ed7fcb9c1ba6a800fdf91"),
    "no_data": Region(0x2B0A20, 0x0700, "74c01244813b89716255ac44afb13b8370dc254264a1bc73404303ee2882a26f"),
}

# Program Deck has a 0x20-byte VRAM prefix and runtime-generated portrait
# tiles, so only the v0.10 label IDs are required to match.  The other PET
# banks are stable and are compared in full.
PROGRAM_V10_TILE_IDS = (
    0x0CE, 0x0CF, 0x0D4, 0x0D5, 0x0D6, 0x0D7, 0x0D8,
    0x0E2, 0x0E3, 0x0E4, 0x0E5, 0x0E6, 0x0E7, 0x0E8,
    0x0EB, 0x0EC, 0x0ED, 0x0EE, 0x0EF, 0x0F0, 0x0F1,
)


@dataclass(frozen=True)
class Capture:
    name: str
    frame: int
    map_name: str
    tile_bank: str
    expected_labels: tuple[str, ...]


@dataclass(frozen=True)
class Route:
    name: str
    actions: tuple[tuple[str, int], ...]
    captures: tuple[Capture, ...]
    stop_frame: int


ROUTES = (
    Route(
        "program",
        (("A", 27020), ("A", 27400), ("Start", 27600)),
        (
            Capture("program_root", 27200, "program", "program", ("PROGRAM DECK", "Y2 CHIP FOLDER")),
            Capture("program_start_toolbar", 27680, "program", "program", ("DECK FILE", "NAVIGATION", "NAVI CODE")),
        ),
        27720,
    ),
    Route(
        "program_alt",
        (("A", 27020), ("R", 27400)),
        (Capture("program_alt_button", 27440, "program_alt", "chip", ("PROGRAM DECK Y4",)),),
        27520,
    ),
    Route(
        "chip",
        (
            ("Down", 27040), ("A", 27100), ("A", 27400),
            ("Start", 27600), ("Down", 27800), ("Right", 28000),
            ("A", 28200), ("Start", 28400), ("Down", 28600),
            ("Right", 28800),
        ),
        (
            Capture("chip_folder", 27320, "chip", "chip", ("CHIP FOLDER", "Y2 PACK")),
            Capture("chip_sort", 27680, "chip", "chip", ("NAME ATK", "TYPE")),
            Capture("chip_backpack", 28880, "backpack", "chip", ("CHIP FOLDER Y4", "BACKPACK", "NO CHIP", "IS", "SELECTED")),
        ),
        28920,
    ),
    Route(
        "data",
        (
            ("Down", 27040), ("Down", 27100), ("A", 27160),
            ("A", 27400), ("Start", 27600), ("Down", 27800),
            ("Right", 28000), ("A", 28200), ("Start", 28400),
            ("Down", 28600), ("Right", 28800),
        ),
        (
            Capture("data_library", 27320, "data", "chip", ("DATA LIBRARY",)),
            Capture("data_no_data", 28880, "data", "chip", ("DATA LIBRARY", "NO CHIP", "IS", "SELECTED")),
        ),
        28920,
    ),
    Route(
        "netnavi",
        (
            ("Down", 27040), ("Down", 27100), ("Down", 27160),
            ("A", 27220), ("A", 27400), ("Start", 27600),
            ("Down", 27800), ("Right", 28000),
        ),
        (
            Capture("netnavi_root", 27360, "netnavi", "netnavi", ("NETNAVI", "Y2 MEGAMAN")),
            Capture("netnavi_stats", 28300, "netnavi_stats", "netnavi", ("MENU Y4", "FREE BATTLES", "TOTAL RECORDS", "W", "L", "Cls E NOVICE Tour")),
        ),
        28340,
    ),
)


@dataclass(frozen=True)
class LegacyPattern:
    name: str
    bank: str
    tile_ids: tuple[int, ...]
    sha256: str


LEGACY_PATTERNS = (
    LegacyPattern("program_deck_file_japanese", "program", tuple(range(0x0E2, 0x0E9)), "0a692550f7a7c3bd195213073117fc4a94dcc75bf6248e4a333042778ca78e19"),
    LegacyPattern("program_navigation_japanese", "program", (0x0CE, 0x0CF, 0x0D4, 0x0D5, 0x0D6, 0x0D7, 0x0D8), "2cc8c5bf1a5c5288988ba798d92484770482506a181b0af16ea1e0a13aecc344"),
    LegacyPattern("program_navi_code_japanese", "program", tuple(range(0x0EB, 0x0F3)), "cd31d40d0170a476f80f100232a6930151a1260682b1ab00e56658b08fed2074"),
    LegacyPattern("program_alt_japanese", "chip", tuple(range(0x010, 0x017)), "01d78c2ff628ed426aa72ee3e94cd209fa08040e30297877b7c79924020c009b"),
    LegacyPattern("chip_sort_name_attack_japanese", "chip", tuple(range(0x097, 0x0A0)), "52e3df3eb840f7e888e1f4bfa0f2c2c65354adc0aac87ef6023606fb185fcaf7"),
    LegacyPattern("chip_sort_type_japanese", "chip", tuple(range(0x0B1, 0x0B5)), "a10a64108969fc6416ede34309e7146693c509e27471c07aaf9afba3bdecfa15"),
    LegacyPattern("backpack_button_japanese", "chip", (0x069, 0x047, 0x048, 0x049, 0x04A, 0x06A, 0x06B), "916ca91fad92f766f1e3078318202f52155fda635a84a79a9edab8c9ec1c7d6f"),
    LegacyPattern("backpack_header_japanese", "chip", tuple(range(0x02A, 0x031)) + tuple(range(0x037, 0x03E)), "db030721a1b9ef69530937dc197c8b73bbd751d44a095a8a8ef9378718dae8a3"),
    LegacyPattern("netnavi_menu_japanese", "netnavi", tuple(range(0x00F, 0x014)), "c0ad9d49e68cc3fb5d044f6b6c4b43c186d1463a595099c6347be651113b6505"),
    LegacyPattern("netnavi_wins_japanese", "netnavi", (0x065, 0x067), "81b9de0cbef002471a07ce9e459f88a080d38f4e41c313a6052e2e83a2850960"),
    LegacyPattern("netnavi_losses_japanese", "netnavi", (0x066, 0x068), "142f0803c16306b5c55f88895acd85954ba95b27d6cc0f06904afc8d24b4f0c2"),
)

NO_DATA_LEGACY_SHA256 = "62393ecf009d82970cd0f681ee57458a970d812f0e365fb908d6386675a50dc2"


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def portable_path(path: Path, project_root: Path) -> str:
    try:
        return str(path.resolve().relative_to(project_root.resolve()))
    except ValueError:
        return path.name


def pulse(frame: int, first: int, duration: int = 8) -> bool:
    return first <= frame < first + duration


def route_by_name(name: str) -> Route:
    return next(route for route in ROUTES if route.name == name)


def input_for_frame(route: Route, frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = pulse(frame, 650, 10)
    state.A = (
        pulse(frame, 950)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or pulse(frame, 26920)
    )
    for button, first in route.actions:
        setattr(state, button, getattr(state, button) or pulse(frame, first))
    return state


def configure_core(lib: ctypes.CDLL) -> None:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
        "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib._pet_deep_callback_type = callback_type
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]


def bank_payload(rom: bytes, bank_name: str) -> bytes:
    region = TILE_BANKS[bank_name]
    payload = rom[region.offset:region.offset + region.length]
    if len(payload) != region.length or sha256(payload) != region.sha256:
        raise ValueError(f"{bank_name}: final-ROM tile bank hash guard failed")
    return payload


def selected_tiles(payload: bytes, tile_ids: tuple[int, ...]) -> bytes:
    return b"".join(payload[tile_id * 32:(tile_id + 1) * 32] for tile_id in tile_ids)


def runtime_bank_bytes(cpu: bytes, bank_name: str) -> tuple[bytes, int, str]:
    region = TILE_BANKS[bank_name]
    if bank_name == "program":
        base = 0x8020
        tile_ids = PROGRAM_V10_TILE_IDS
        payload = b"".join(
            cpu[base + tile_id * 32:base + (tile_id + 1) * 32]
            for tile_id in tile_ids
        )
        return payload, base, "v0.10_label_tiles"
    base = 0x8000
    return cpu[base:base + region.length], base, "full_bank"


def expected_runtime_bank_bytes(rom: bytes, bank_name: str) -> bytes:
    payload = bank_payload(rom, bank_name)
    if bank_name == "program":
        return selected_tiles(payload, PROGRAM_V10_TILE_IDS)
    return payload


def legacy_checks(rom: bytes, cpu: bytes, bank_name: str) -> list[dict]:
    bank = bank_payload(rom, bank_name)
    cpu_base = 0x8020 if bank_name == "program" else 0x8000
    rows = []
    for pattern in LEGACY_PATTERNS:
        if pattern.bank != bank_name:
            continue
        final_rom_payload = selected_tiles(bank, pattern.tile_ids)
        live_payload = b"".join(
            cpu[cpu_base + tile_id * 32:cpu_base + (tile_id + 1) * 32]
            for tile_id in pattern.tile_ids
        )
        rows.append({
            "pattern": pattern.name,
            "legacy_sha256": pattern.sha256,
            "final_rom_sha256": sha256(final_rom_payload),
            "final_rom_matches_legacy": sha256(final_rom_payload) == pattern.sha256,
            "live_sha256": sha256(live_payload),
            "live_matches_legacy": sha256(live_payload) == pattern.sha256,
        })
    return rows


def run_route(payload: dict) -> dict:
    route = route_by_name(payload["route"])
    rom_path = Path(payload["rom"])
    core_path = Path(payload["core"])
    output_dir = Path(payload["output"])
    timeout = float(payload["timeout"])
    rom = rom_path.read_bytes()

    if output_dir.exists():
        shutil.rmtree(output_dir)
    home = output_dir / "mesen_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(core_path.resolve()))
    configure_core(lib)
    completed = 0
    captures_by_frame = {capture.frame: capture for capture in route.captures}
    memory_captures: dict[int, bytes] = {}
    captured_frames: list[int] = []
    route_done = threading.Event()
    callback_type = lib._pet_deep_callback_type

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(route, completed + 1))
        if completed in captures_by_frame:
            lib.TakeScreenshot()
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
            memory_captures[completed] = bytes(buffer)
            captured_frames.append(completed)
        if completed >= route.stop_frame:
            route_done.set()

    listener = None
    started = time.monotonic()
    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    try:
        if not lib.LoadRom(str(rom_path.resolve()).encode(), b""):
            raise RuntimeError(f"{route.name}: MesenCore could not load ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(route, 0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError(f"{route.name}: could not register callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not route_done.wait(timeout):
            raise TimeoutError(f"{route.name}: timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.25)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 8
    while len(list(screenshot_dir.glob("*.png"))) < len(route.captures) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != len(route.captures):
        raise RuntimeError(
            f"{route.name}: expected {len(route.captures)} screenshots, found {len(screenshots)}"
        )
    if captured_frames != [capture.frame for capture in route.captures]:
        raise RuntimeError(f"{route.name}: missing CPU capture: {captured_frames}")

    capture_results = []
    for capture, source in zip(route.captures, screenshots, strict=True):
        screenshot = output_dir / f"{capture.name}_{capture.frame}.png"
        shutil.copy2(source, screenshot)
        cpu = memory_captures[capture.frame]
        cpu_path = output_dir / f"{capture.name}_cpu_{capture.frame}.bin"
        cpu_path.write_bytes(cpu)

        with Image.open(screenshot) as image:
            dimensions = list(image.size)

        map_region = MAPS[capture.map_name]
        expected_map = rom[map_region.offset:map_region.offset + map_region.length]
        if sha256(expected_map) != map_region.sha256:
            raise ValueError(f"{capture.name}: final-ROM map hash guard failed")
        live_map = cpu[0x2000:0x2000 + map_region.length]

        expected_tiles = expected_runtime_bank_bytes(rom, capture.tile_bank)
        live_tiles, tile_cpu_base, compare_mode = runtime_bank_bytes(cpu, capture.tile_bank)
        map_match = live_map == expected_map
        tiles_match = live_tiles == expected_tiles
        if not map_match or not tiles_match:
            raise RuntimeError(
                f"{capture.name}: runtime mismatch map={map_match}, tiles={tiles_match}"
            )

        capture_results.append({
            "state": capture.name,
            "frame": capture.frame,
            "expected_visible_labels": list(capture.expected_labels),
            "screenshot": {
                "file": screenshot.name,
                "sha256": sha256(screenshot.read_bytes()),
                "dimensions": dimensions,
                "native_224x144": dimensions == list(NATIVE_DISPLAY),
            },
            "cpu_dump": {"file": cpu_path.name, "sha256": sha256(cpu)},
            "runtime_map": {
                "rom_offset": f"0x{map_region.offset:06X}",
                "cpu_address": "0x2000",
                "length": map_region.length,
                "final_rom_sha256": sha256(expected_map),
                "live_sha256": sha256(live_map),
                "exact_match": map_match,
            },
            "runtime_tiles": {
                "bank": capture.tile_bank,
                "rom_offset": f"0x{TILE_BANKS[capture.tile_bank].offset:06X}",
                "cpu_base": f"0x{tile_cpu_base:04X}",
                "comparison": compare_mode,
                "checked_bytes": len(expected_tiles),
                "final_rom_sha256": sha256(expected_tiles),
                "live_sha256": sha256(live_tiles),
                "exact_match": tiles_match,
            },
            "legacy_japanese_tile_checks": legacy_checks(rom, cpu, capture.tile_bank),
        })

    persistence_files = sorted(
        str(path.relative_to(home))
        for path in home.rglob("*")
        if path.is_file() and ("Saves" in path.parts or "SaveStates" in path.parts)
    )
    shutil.rmtree(home)
    route_result = {
        "route": route.name,
        "last_callback_frame": completed,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "clean_boot": True,
        "uses_sav": False,
        "uses_savestate": False,
        "preexisting_persistence_files": 0,
        "runtime_generated_persistence_files_removed": persistence_files,
        "mesen_home_removed_after_capture": True,
        "route_input_pulses": [
            {"button": button, "frame": frame, "duration_frames": 8}
            for button, frame in route.actions
        ],
        "captures": capture_results,
    }
    (output_dir / "route_report.json").write_text(
        json.dumps(route_result, indent=2) + "\n", encoding="utf-8"
    )
    return route_result


def build_montage(results: list[dict], output_dir: Path) -> dict:
    cards = []
    for route in results:
        for capture in route["captures"]:
            path = output_dir / route["route"] / capture["screenshot"]["file"]
            with Image.open(path) as source:
                image = source.convert("RGB")
            image = image.resize((672, 432), Image.Resampling.NEAREST)
            card = Image.new("RGB", (672, 462), (24, 24, 24))
            card.paste(image, (0, 30))
            ImageDraw.Draw(card).text(
                (8, 9), capture["state"].replace("_", " ").upper(), fill="white"
            )
            cards.append(card)

    columns = 2
    rows = (len(cards) + columns - 1) // columns
    gap = 8
    montage = Image.new(
        "RGB",
        (columns * cards[0].width + (columns - 1) * gap,
         rows * cards[0].height + (rows - 1) * gap),
        (10, 10, 10),
    )
    for index, card in enumerate(cards):
        montage.paste(
            card,
            ((index % columns) * (card.width + gap),
             (index // columns) * (card.height + gap)),
        )
    path = output_dir / "pet_deep_runtime_montage_v0_10_final.png"
    montage.save(path)
    return {
        "file": path.name,
        "sha256": sha256(path.read_bytes()),
        "dimensions": list(montage.size),
        "scale": "3x nearest-neighbor",
    }


def cleanup_post_worker_homes(output_dir: Path, routes: list[Route]) -> list[dict]:
    """Remove persistence Mesen can recreate while its worker is exiting."""
    removed = []
    for route in routes:
        home = output_dir / route.name / "mesen_home"
        if not home.exists():
            continue
        files = sorted(
            str(path.relative_to(home)) for path in home.rglob("*") if path.is_file()
        )
        shutil.rmtree(home)
        removed.append({"route": route.name, "files_removed": files})
    return removed


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--rom", type=Path,
        default=project_root / "build/Rockman_EXE_N1_Battle_English_v0.10.wsc",
    )
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument(
        "--output-dir", type=Path,
        default=project_root / "build/runtime_v0_10_final_pet_deep",
    )
    parser.add_argument(
        "--jobs", type=int, choices=(1,), default=1,
        help="MesenCore is process-global; deep routes are intentionally serialized",
    )
    parser.add_argument(
        "--route", action="append", choices=tuple(route.name for route in ROUTES),
        help="capture only this route; may be repeated and preserves other route outputs",
    )
    parser.add_argument(
        "--assemble-existing", action="store_true",
        help="skip emulation and assemble the final report from all route_report.json files",
    )
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    rom_before = args.rom.read_bytes()
    if sha256(rom_before) != EXPECTED_ROM_SHA256:
        raise ValueError(
            f"final SHA-256 {sha256(rom_before)}; expected {EXPECTED_ROM_SHA256}"
        )
    for name in MAPS:
        region = MAPS[name]
        if sha256(rom_before[region.offset:region.offset + region.length]) != region.sha256:
            raise ValueError(f"{name}: final-ROM map hash guard failed")
    for name in TILE_BANKS:
        bank_payload(rom_before, name)

    if not args.route and not args.assemble_existing and args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True, exist_ok=True)
    selected_routes = (
        [route_by_name(name) for name in args.route] if args.route else list(ROUTES)
    )
    payloads = [
        {
            "route": route.name,
            "rom": str(args.rom),
            "core": str(args.mesen_core),
            "output": str(args.output_dir / route.name),
            "timeout": args.timeout,
        }
        for route in selected_routes
    ]
    # MesenCore cannot be initialized twice safely in one Python process and
    # also crashes when two cores run concurrently.  A one-worker pool with a
    # one-task lifetime gives every clean route a fresh process while retaining
    # deterministic serial execution.
    order = [route.name for route in ROUTES]
    if args.assemble_existing:
        results = [
            json.loads((args.output_dir / route.name / "route_report.json").read_text())
            for route in ROUTES
        ]
        post_worker_cleanup = cleanup_post_worker_homes(
            args.output_dir, list(ROUTES)
        )
    else:
        context = multiprocessing.get_context("spawn")
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=1, mp_context=context, max_tasks_per_child=1
        ) as executor:
            results = list(executor.map(run_route, payloads))
        post_worker_cleanup = cleanup_post_worker_homes(
            args.output_dir, selected_routes
        )
        if args.route:
            results.sort(key=lambda item: order.index(item["route"]))
            print(json.dumps({
                "validation": "pet_deep_v0_10_route_capture",
                "routes_completed": [result["route"] for result in results],
                "output_dir": str(args.output_dir.resolve()),
                "post_worker_persistence_cleanup": post_worker_cleanup,
            }, indent=2))
            return 0
    results.sort(key=lambda item: order.index(item["route"]))

    montage = build_montage(results, args.output_dir)
    captures = [capture for route in results for capture in route["captures"]]
    legacy_checks_all = [
        check
        for capture in captures
        for check in capture["legacy_japanese_tile_checks"]
    ]
    no_data = bank_payload(rom_before, "no_data")
    no_data_legacy = no_data[0x300:0x600]
    rom_after = args.rom.read_bytes()
    structural_pass = (
        all(capture["screenshot"]["native_224x144"] for capture in captures)
        and all(capture["runtime_map"]["exact_match"] for capture in captures)
        and all(capture["runtime_tiles"]["exact_match"] for capture in captures)
        and not any(check["final_rom_matches_legacy"] or check["live_matches_legacy"] for check in legacy_checks_all)
        and sha256(no_data_legacy) != NO_DATA_LEGACY_SHA256
        and rom_after == rom_before
    )
    captured_screenshot_sha256 = {
        capture["state"]: capture["screenshot"]["sha256"]
        for capture in captures
    }
    reviewed_visual_hashes_match = (
        captured_screenshot_sha256 == REVIEWED_SCREENSHOT_SHA256
    )
    overall_pass = structural_pass and reviewed_visual_hashes_match
    report = {
        "validation": "pet_deep_v0_10_final_clean_boot_mesen_core",
        "status": (
            "PASS" if overall_pass else
            "STRUCTURAL_PASS_VISUAL_REVIEW_REQUIRED" if structural_pass else "FAIL"
        ),
        "rom": {
            "path": portable_path(args.rom, project_root),
            "sha256_before": sha256(rom_before),
            "sha256_after": sha256(rom_after),
            "unchanged_by_validation": rom_after == rom_before,
        },
        "mesen_core": {
            "path": args.mesen_core.name,
            "sha256": sha256(args.mesen_core.read_bytes()),
        },
        "native_display": {"width": 224, "height": 144},
        "clean_boots": len(results),
        "uses_any_sav_or_savestate": False,
        "post_worker_persistence_cleanup": post_worker_cleanup,
        "all_captures_224x144": all(capture["screenshot"]["native_224x144"] for capture in captures),
        "all_runtime_maps_match_final_rom": all(capture["runtime_map"]["exact_match"] for capture in captures),
        "all_runtime_tile_checks_match_final_rom": all(capture["runtime_tiles"]["exact_match"] for capture in captures),
        "legacy_japanese_tile_patterns_detected": any(
            check["final_rom_matches_legacy"] or check["live_matches_legacy"]
            for check in legacy_checks_all
        ) or sha256(no_data_legacy) == NO_DATA_LEGACY_SHA256,
        "no_data_card_rom_check": {
            "bank_offset": "0x2B0A20",
            "bank_sha256": sha256(no_data),
            "key_text_span_offset": "0x2B0D20",
            "key_text_span_sha256": sha256(no_data_legacy),
            "matches_legacy_japanese": sha256(no_data_legacy) == NO_DATA_LEGACY_SHA256,
            "runtime_confirmation": "manual inspection of chip_backpack and data_no_data captures",
        },
        "routes": results,
        "montage": montage,
        "visual_review": {
            "status": "PASS" if reviewed_visual_hashes_match else "REVIEW_REQUIRED",
            "reviewed_rom_sha256": EXPECTED_ROM_SHA256,
            "method": "manual inspection of ten native 224x144 captures and the 3x nearest-neighbor montage",
            "reviewed_screenshot_sha256": REVIEWED_SCREENSHOT_SHA256,
            "all_reviewed_screenshot_hashes_match": reviewed_visual_hashes_match,
            "visible_text_by_state": (
                VISIBLE_TEXT_BY_STATE if reviewed_visual_hashes_match else {}
            ),
            "residual_japanese_visible": [],
            "clipping_or_layout_defects": [],
            "notes": [
                "All new labels are legible at native WonderSwan resolution and stay inside their original fields.",
                "The yellow NO DATA SELECTED layer and white NO CHIP / IS / SELECTED layer are semantically redundant but distinct, do not overlap, and are not clipped.",
                "The compact 3x5 and 3x7 glyphs, palette, spacing, and unchanged maps preserve the existing WonderSwan UI style.",
                "NetNavi stats is captured at frame 28300 so the dynamic line is complete: Cls E NOVICE Tour.",
            ] if reviewed_visual_hashes_match else [],
            "blockers": [] if reviewed_visual_hashes_match else [
                "capture pixels differ from the manually reviewed evidence set"
            ],
        },
    }
    report_path = args.output_dir / "pet_deep_runtime_validation_v0_10_final.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if overall_pass else 1


if __name__ == "__main__":
    raise SystemExit(main())
