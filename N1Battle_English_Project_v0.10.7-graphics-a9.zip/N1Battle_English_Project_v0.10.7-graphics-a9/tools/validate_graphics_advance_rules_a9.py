#!/usr/bin/env python3
"""Enforce all cumulative graphics gates through Advance 9."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_9_program_deck_chip_restore as a9  # noqa: E402
import n1tool  # noqa: E402


SOURCE_SHA256 = a9.SOURCE_SHA256
A8_SHA256 = a9.BASE_A8_SHA256
A9_SHA256 = "27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6"
IPS_SHA256 = "9a1bf3430a4e213eb10d3a1f340532dc43f4a7554fad83821263c21bef9e9cb5"
MANIFEST_SHA256 = "6c56afcdc9507ecfb08b228472bf7f60a558b031ca23887be01201853e17bb50"
ASSET_SHA256 = "cfd0ce2af1ae99363c224d6b13e6fcd612a2e472751d0d2fce50d879e49768ef"
RUNTIME = Path("docs/runtime_graphics_advances/advance_9_gate_final")
TARGET_RECT = (112, 56, 120, 64)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def image_delta(before_path: Path, after_path: Path) -> tuple[int, tuple[int, int, int, int] | None]:
    before = Image.open(before_path).convert("RGB")
    after = Image.open(after_path).convert("RGB")
    require(before.size == after.size == (224, 144), "runtime captures must be native 224x144")
    difference = ImageChops.difference(before, after)
    bbox = difference.getbbox()
    payload = difference.tobytes()
    changed = sum(any(payload[index:index + 3]) for index in range(0, len(payload), 3))
    return changed, bbox


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--a8-rom", required=True, type=Path)
    parser.add_argument("--candidate-rom", type=Path)
    parser.add_argument("--direct-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    candidate_path = args.candidate_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.wsc"
    direct_path = args.direct_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9-direct.wsc"
    ips_path = args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a9.ips"
    source = args.source_rom.read_bytes()
    base = args.a8_rom.read_bytes()
    candidate = candidate_path.read_bytes()
    direct = direct_path.read_bytes()
    ips = ips_path.read_bytes()

    require(sha256(source) == SOURCE_SHA256, "Japanese source ROM identity differs")
    require(sha256(base) == A8_SHA256, "approved Advance 8 identity differs")
    require(sha256(candidate) == A9_SHA256, "Advance 9 candidate identity differs")
    require(candidate == direct, "direct manifest build differs from IPS reconstruction")
    require(sha256(ips) == IPS_SHA256, "Advance 9 IPS identity differs")
    require(n1tool.apply_ips(source, ips) == candidate, "IPS does not reconstruct candidate")
    stored, calculated = n1tool.checksum(candidate)
    require(stored == calculated == 0xB86D, "WonderSwan checksum differs")

    asset_path = root / "translation/assets" / a9.ASSET_NAME
    asset = asset_path.read_bytes()
    base_bank = base[a9.BANK_OFFSET:a9.BANK_OFFSET + a9.BANK_LENGTH]
    candidate_bank = candidate[a9.BANK_OFFSET:a9.BANK_OFFSET + a9.BANK_LENGTH]
    require(len(asset) == a9.BANK_LENGTH and sha256(asset) == ASSET_SHA256,
            "A9 Program Deck asset differs")
    require(a9.restore_tile(source, base) == asset == candidate_bank,
            "candidate bank does not equal the isolated restoration")

    tile_start = a9.ASSET_INDEX * a9.TILE_BYTES
    source_bank = source[a9.BANK_OFFSET:a9.BANK_OFFSET + a9.BANK_LENGTH]
    require(asset[tile_start:tile_start + a9.TILE_BYTES]
            == source_bank[tile_start:tile_start + a9.TILE_BYTES],
            "restored chip quadrant differs from the Japanese original")

    changed = {index for index, pair in enumerate(zip(base, candidate, strict=True)) if pair[0] != pair[1]}
    bank_changed = {a9.BANK_OFFSET + index for index, pair in enumerate(
        zip(base_bank, candidate_bank, strict=True)) if pair[0] != pair[1]}
    tile_range = set(range(a9.BANK_OFFSET + tile_start,
                           a9.BANK_OFFSET + tile_start + a9.TILE_BYTES))
    checksum_changed = {len(candidate) - 2, len(candidate) - 1}
    require(len(bank_changed) == 29 and bank_changed <= tile_range,
            "A9 changed bytes outside the exclusive tile")
    require(changed == bank_changed | checksum_changed and len(changed) == 31,
            "A9 binary delta escaped its tile/checksum allowlist")

    tilemap = candidate[a9.MAP_OFFSET:a9.MAP_OFFSET + a9.MAP_LENGTH]
    position = (a9.TARGET_CELL[1] * 32 + a9.TARGET_CELL[0]) * 2
    require(int.from_bytes(tilemap[position:position + 2], "little") == a9.TARGET_MAP_WORD,
            "target map word differs")
    require(a9.consumers(tilemap, a9.RUNTIME_TILE_ID) == [list(a9.TARGET_CELL)],
            "restored runtime tile is not exclusively owned")

    manifest_path = root / "translation/en_v0_10_7_graphics_a9.json"
    manifest = load_json(manifest_path)
    build = load_json(root / "build/build_v0_10_7_graphics_a9.json")
    generator = load_json(root / "translation/assets" / a9.REPORT_NAME)
    rules = load_json(root / "translation/graphics_advance_rules.json")
    runtime = load_json(root / RUNTIME / "graphics_advance_9_runtime_validation.json")
    require(sha256(manifest_path.read_bytes()) == MANIFEST_SHA256, "A9 manifest identity differs")
    require(manifest.get("project_version") == "0.10.7-graphics-a9", "A9 manifest version differs")
    entries = [row for row in manifest.get("binary_entries", [])
               if row.get("id") == "program_deck_live_ui_tiles"]
    require(len(entries) == 1 and entries[0].get("asset") == f"assets/{a9.ASSET_NAME}"
            and entries[0].get("asset_sha256") == ASSET_SHA256,
            "A9 manifest does not select the restored bank")
    require(build.get("output_sha256") == A9_SHA256, "manifest build identity differs")
    require(build.get("checksum", {}).get("checksum_valid") is True, "manifest checksum invalid")
    require(generator.get("status") == "PASS"
            and generator.get("changed_bytes_vs_advance_8") == 29
            and generator.get("runtime_consumers") == [[14, 7]],
            "A9 generator report is not final")

    require(rules.get("status") == "PASS" and rules.get("project_version") == "0.10.7-graphics-a9",
            "cumulative rule identity differs")
    require(len(rules.get("rules", [])) == 29, "expected 29 cumulative rules")
    require(all(row.get("mandatory") is True for row in rules["rules"]), "a cumulative rule is optional")
    for advance in range(1, 10):
        require(rules.get(f"advance_{advance}", {}).get("status") == "PASS",
                f"Advance {advance} checkpoint missing")

    require(runtime.get("status") == "PASS"
            and runtime.get("candidate_advance_9_sha256") == A9_SHA256,
            "A9 runtime validation is not final")
    require(runtime.get("clean_boots") == 2 and runtime.get("uses_save_or_savestate") is False,
            "A9 runtime routes were not clean")
    require(runtime.get("target_state", {}).get("changed_pixels") == 53
            and runtime.get("target_state", {}).get("changed_pixel_bbox") == list(TARGET_RECT)
            and runtime.get("target_state", {}).get("pixels_outside_target_rectangle") == 0,
            "A9 target-state runtime metrics differ")
    require(runtime.get("protected_toolbar_state", {}).get("changed_pixels") == 0
            and runtime.get("beige_rectangle_visible") is False
            and runtime.get("english_toolbar_labels_preserved") is True,
            "A9 protected toolbar or semantic review differs")
    require(runtime.get("live_map_matches_rom") is True
            and runtime.get("live_program_bank_matches_rom") is True
            and runtime.get("restored_tile_pattern_matches_original_rom") is True,
            "A9 live ROM/RAM identity differs")

    root_changed, root_bbox = image_delta(
        root / RUNTIME / "a8/program_root_27200.png",
        root / RUNTIME / "a9/program_root_27200.png",
    )
    toolbar_changed, toolbar_bbox = image_delta(
        root / RUNTIME / "a8/program_start_toolbar_27680.png",
        root / RUNTIME / "a9/program_start_toolbar_27680.png",
    )
    require((root_changed, root_bbox) == (53, TARGET_RECT), "A9 root screenshot delta differs")
    require((toolbar_changed, toolbar_bbox) == (0, None), "A9 toolbar screenshot is not pixel-exact")

    report = {
        "status": "PASS", "project_version": "0.10.7-graphics-a9", "rules_enforced": 29,
        "source_rom_sha256": SOURCE_SHA256, "base_advance_8_sha256": A8_SHA256,
        "candidate_rom_sha256": A9_SHA256, "cumulative_ips_sha256": IPS_SHA256,
        "wonder_swan_checksum": "0xB86D", "ips_reconstructs_candidate": True,
        "manifest_reconstructs_candidate": True, "direct_build_matches_manifest": True,
        "binary_write_allowlist": "PASS", "changed_bytes_vs_advance_8": 31,
        "tile_bank_changed_bytes": 29, "restored_asset_index": "0x0E8",
        "runtime_tile_id": "0x0E9", "runtime_consumers": [[14, 7]],
        "maps_palettes_code_pointers_text_changed_bytes": 0,
        "changed_pixels": 53, "changed_pixel_bbox": list(TARGET_RECT),
        "pixels_outside_target_rectangle": 0, "protected_toolbar_changed_pixels": 0,
        "advance_1_through_8_checkpoints": "PASS", "advance_9_checkpoint": "PASS",
        "beige_rectangle_visible": False, "manual_semantic_review": "PASS",
    }
    output = root / "build/graphics_advance_rules_validation.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
