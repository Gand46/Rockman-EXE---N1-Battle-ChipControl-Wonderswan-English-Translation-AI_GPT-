#!/usr/bin/env python3
"""Assemble the cumulative v0.10.7 RC4 manifest.

RC4 has two independently audited inputs: the narrow lower-dialogue reflow
manifest and the repacked B1/B2 battle-message assets.  This script combines
them without regenerating or changing any static RC3 graphical resource.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any


VERSION = "0.10.7-rc4"
SOURCE_DIALOGUE_SHA256 = (
    "f82f494a2328f2d6e59bf3bdd031ff051089059092dd622c12a46a7b11537080"
)
EXPECTED_TEXT_ENTRIES = 271
EXPECTED_BINARY_ENTRIES = 80

BATTLE_ENTRY_FILES = {
    "battle_messages_b1_data": "battle_messages_b1_data_v0_10_7_rc4.bin",
    "battle_messages_b1_pointers": "battle_messages_b1_pointers_v0_10_7_rc4.bin",
    "battle_messages_b2_data": "battle_messages_b2_data_v0_10_7_rc4.bin",
    "battle_messages_b2_pointers": "battle_messages_b2_pointers_v0_10_7_rc4.bin",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def write_json(path: Path, value: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(
        json.dumps(value, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--dialogue-manifest",
        type=Path,
        default=root / "translation/en_v0_10_7_rc4_dialogue.json",
    )
    parser.add_argument(
        "--battle-report",
        type=Path,
        default=root / "translation/assets/battle_message_asset_report_v0_10_7_rc4.json",
    )
    parser.add_argument(
        "--assets",
        type=Path,
        default=root / "translation/assets",
    )
    parser.add_argument(
        "--output",
        type=Path,
        default=root / "translation/en_v0_10_7_rc4.json",
    )
    parser.add_argument(
        "--report",
        type=Path,
        default=root / "translation/assets/manifest_report_v0_10_7_rc4.json",
    )
    args = parser.parse_args()

    source_payload = args.dialogue_manifest.read_bytes()
    if sha256(source_payload) != SOURCE_DIALOGUE_SHA256:
        raise ValueError("intermediate RC4 dialogue manifest is not the reviewed build")
    manifest = json.loads(source_payload)
    if manifest.get("project_version") != VERSION:
        raise ValueError("intermediate manifest version differs")
    if (
        len(manifest.get("entries", [])) != EXPECTED_TEXT_ENTRIES
        or len(manifest.get("binary_entries", [])) != EXPECTED_BINARY_ENTRIES
    ):
        raise ValueError("manifest coverage differs from RC3")

    battle_report = json.loads(args.battle_report.read_text(encoding="utf-8"))
    if (
        battle_report.get("status") != "PASS"
        or battle_report.get("project_version") != VERSION
    ):
        raise ValueError("battle-message report is not a final RC4 report")

    report_rows: dict[str, dict[str, Any]] = {}
    for bank in battle_report.get("banks", []):
        bank_id = str(bank["id"])
        report_rows[f"battle_messages_{bank_id}_data"] = bank["data"]
        report_rows[f"battle_messages_{bank_id}_pointers"] = bank["pointers"]
    if set(report_rows) != set(BATTLE_ENTRY_FILES):
        raise ValueError("battle report does not describe the four guarded spans")

    by_id = {str(row["id"]): row for row in manifest["binary_entries"]}
    if len(by_id) != EXPECTED_BINARY_ENTRIES:
        raise ValueError("binary entry IDs are not unique")
    updated: list[dict[str, Any]] = []
    for entry_id, filename in BATTLE_ENTRY_FILES.items():
        entry = by_id.get(entry_id)
        report_row = report_rows[entry_id]
        if entry is None:
            raise ValueError(f"missing binary entry {entry_id}")
        asset = args.assets / filename
        payload = asset.read_bytes()
        expected_length = int(entry["length"])
        expected_offset = int(str(entry["offset"]), 0)
        if (
            len(payload) != expected_length
            or int(str(report_row["offset"]), 0) != expected_offset
            or int(report_row.get("length", expected_length)) != expected_length
            or str(report_row["asset"]) != filename
            or str(report_row["sha256"]) != sha256(payload)
        ):
            raise ValueError(f"{entry_id}: asset/report/manifest geometry mismatch")
        previous_asset = str(entry["asset"])
        previous_hash = str(entry["asset_sha256"])
        entry["asset"] = f"assets/{filename}"
        entry["asset_sha256"] = sha256(payload)
        updated.append({
            "id": entry_id,
            "offset": entry["offset"],
            "length": expected_length,
            "previous_asset": previous_asset,
            "previous_asset_sha256": previous_hash,
            "asset": entry["asset"],
            "asset_sha256": entry["asset_sha256"],
        })

    manifest["scope"] = (
        "v0.10.7 RC4 corrects every audited lower-dialogue overflow while "
        "preserving the approved RC3 graphics and behavior. Portrait-backed "
        "dialogue pages are reflowed to at most three 8x16 rows of nineteen "
        "cells. Battle-log B1 records use the engine's runtime-verified LINE "
        "control only within the existing pointer groups, or concise wording "
        "where a three-row group was already full; B2 retains its 26-cell "
        "layout and changes only the eight-cell PAUSE option from VIEW DECK "
        "to DECK. Null-pointer topology, offsets, spans, portraits, dynamic "
        "values, static TTF/pixel-art assets and all unrelated RC3 data remain "
        "unchanged."
    )

    output_payload = (
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    ).encode("utf-8")
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output_payload)
    report = {
        "status": "PASS",
        "project_version": VERSION,
        "source_dialogue_manifest": {
            "file": args.dialogue_manifest.name,
            "sha256": sha256(source_payload),
        },
        "battle_report": {
            "file": args.battle_report.name,
            "sha256": sha256(args.battle_report.read_bytes()),
        },
        "output_manifest": {
            "file": args.output.name,
            "sha256": sha256(output_payload),
            "bytes": len(output_payload),
        },
        "text_entries": EXPECTED_TEXT_ENTRIES,
        "binary_entries": EXPECTED_BINARY_ENTRIES,
        "updated_battle_entries": updated,
        "static_rc3_binary_entries_changed": 0,
    }
    write_json(args.report, report)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
