#!/usr/bin/env python3
"""Create the deterministic, ROM-free public N1 Battle v0.10 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


PACKAGE_ROOT = "N1Battle_English_Project_v0.10.0"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
FINAL_ROM_SHA256 = "0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69"
FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".deb", ".so", ".dll",
    ".exe", ".tar", ".gz", ".7z",
}
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict[str, object]:
    return json.loads(require(root, relative).read_text(encoding="utf-8"))


def validate_release_evidence(root: Path) -> None:
    structural = load_json(root, "docs/STRUCTURAL_VALIDATION_v0_10.json")
    residual = load_json(root, "docs/RESIDUAL_TEXT_SCAN_v0_10.json")
    shop = load_json(root, "docs/runtime_v0_10/shop_runtime_validation_v0_10.json")
    free_host = load_json(root, "docs/runtime_v0_10/free_host_runtime_validation_v0_10.json")
    pet = load_json(root, "docs/runtime_v0_10/pet_deep_runtime_validation_v0_10.json")

    checks = {
        "structural PASS": structural.get("overall_result") == "PASS",
        "structural final ROM": (
            structural.get("checks", {}).get("canonical_rebuild", {}).get("built_sha256")
            == FINAL_ROM_SHA256
        ),
        "residual PASS": residual.get("overall_result") == "PASS",
        "residual final ROM": (
            residual.get("checks", {}).get("build_size_and_optional_hash", {}).get("sha256")
            == FINAL_ROM_SHA256
        ),
        "Shop runtime PASS": shop.get("status") == "PASS",
        "Shop runtime final ROM": shop.get("final_rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "Free/Host runtime PASS": free_host.get("status") == "PASS",
        "Free/Host runtime final ROM": free_host.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "PET runtime PASS": pet.get("status") == "PASS",
        "PET runtime final ROM": pet.get("rom", {}).get("sha256_before") == FINAL_ROM_SHA256,
        "PET runtime left ROM unchanged": pet.get("rom", {}).get("unchanged_by_validation") is True,
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError("release evidence is not final: " + ", ".join(failed))


def collect(root: Path) -> list[Path]:
    manifest_path = require(root, "translation/en_v0_10.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files: set[Path] = {manifest_path}

    for relative in (
        "APPLY_PATCH.bat",
        "BUILD_PATCH.bat",
        "CHANGELOG.md",
        "LICENSE.txt",
        "README_ES.md",
        "RELEASE_SHA256.txt",
        "patches/Rockman_EXE_N1_Battle_English_v0.10.ips",
        "references/bcc_en.tbl",
        "tables/n1battle_jp.tbl",
    ):
        files.add(require(root, relative))

    for entry in manifest.get("binary_entries", []):
        asset = PurePosixPath("translation") / str(entry["asset"])
        if asset.is_absolute() or ".." in asset.parts:
            raise ValueError(f"manifest asset escapes translation/: {asset}")
        files.add(require(root, asset.as_posix()))

    # Generators and validators make the release reproducible.  Historical
    # v0.9 tools remain useful because v0.10 layers its four new banks on them.
    for directory, pattern in (
        ("tools", "*.py"),
        ("tests", "*.py"),
    ):
        files.update(
            path for path in (root / directory).glob(pattern) if path.is_file()
        )

    # Include current durable reports/previews, but never transient build or
    # emulator homes. Runtime evidence selected for release lives under
    # docs/runtime_v0_10/. Keep only two inherited audit inventories whose
    # scope is still cited by the v0.10 closure.
    files.update(
        path for path in (root / "docs").rglob("*")
        if path.is_file()
        and path.suffix.lower() in {".md", ".json", ".png", ".tsv"}
        and (
            "v0_10" in path.relative_to(root / "docs").as_posix()
            or path.name in {
                "CREDITS_ENDING_AUDIT_v0_9.json",
                "deep_text_inventory_v0_9.json",
            }
        )
    )
    files.update(
        path for path in (root / "translation/assets").glob("*")
        if path.is_file()
        and "v0_10" in path.name
        and path.suffix.lower() in {".json", ".png", ".tsv", ".md"}
    )

    required_v010 = {
        "docs/STRUCTURAL_VALIDATION_v0_10.json",
        "docs/RESIDUAL_TEXT_SCAN_v0_10.json",
        "docs/RESIDUAL_JAPANESE_AUDIT_v0_10.md",
        "docs/EMULATOR_VALIDATION_v0_10.md",
        "docs/PROGRESO_v0_10.md",
        "docs/progress_v0_10.json",
        "docs/runtime_v0_10/shop_runtime_validation_v0_10.json",
        "docs/runtime_v0_10/free_host_runtime_validation_v0_10.json",
        "docs/runtime_v0_10/pet_deep_runtime_validation_v0_10.json",
        "tools/validate_release_v0_10.py",
        "tools/audit_residual_japanese_v0_10.py",
        "tools/package_release_v0_10.py",
        "tools/shop_purchase_assets_v0_10.py",
        "tools/pet_carousel_remaining_assets_v0_10.py",
        "tools/host_free_menu_assets_v0_10.py",
        "tools/pet_runtime_remaining_assets_v0_10.py",
    }
    for relative in required_v010:
        files.add(require(root, relative))

    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if "candidate" in relative.lower():
        raise ValueError(f"candidate artifact in public package: {relative}")
    if path.is_symlink():
        raise ValueError(f"symlink not allowed in public package: {relative}")
    suffix = path.suffix.lower()
    size = path.stat().st_size
    lowered_parts = {part.lower() for part in path.relative_to(root).parts}
    if lowered_parts & {"mesen_home", "savestates", "saves", "memory"}:
        raise ValueError(f"runtime-private directory in public package: {relative}")
    if relative.startswith("docs/") and suffix not in {".md", ".json", ".png", ".tsv"}:
        raise ValueError(f"unexpected document evidence type: {relative}")
    if suffix in FORBIDDEN_SUFFIXES:
        raise ValueError(f"forbidden extension in public package: {relative}")
    if size in FORBIDDEN_SIZES:
        raise ValueError(f"forbidden ROM/save-sized file: {relative} ({size})")
    payload = path.read_bytes()
    if relative.startswith("docs/") and "v0_10" in relative and suffix in {".md", ".json", ".tsv"}:
        text = payload.decode("utf-8")
        forbidden_markers = (
            "/workspace/", "/root/", "/tmp/",
            "bddeef28419bb9f7a0dabde5b46c3283e2f913f78af895601816e500e885f76d",
            "85545d5615",
        )
        found = [marker for marker in forbidden_markers if marker in text]
        if found:
            raise ValueError(f"stale/private marker in {relative}: {found}")
    if relative.endswith(".ips"):
        if not payload.startswith(b"PATCH") or b"EOF" not in payload[-11:]:
            raise ValueError(f"malformed IPS: {relative}")
    if relative.endswith(".json"):
        json.loads(payload.decode("utf-8"))
    return {"path": relative, "size": size, "sha256": sha256(payload)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project-root", type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    validate_release_evidence(root)
    output = (
        args.output or root / "dist/N1Battle_English_Project_v0.10.0.zip"
    ).resolve()
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(
        output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(
                info, path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED, compresslevel=9,
            )

    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": "0.10.0",
        "archive": output.name,
        "archive_size": len(payload),
        "archive_sha256": sha256(payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": 0,
        "files": inventory,
    }
    report_path = output.with_suffix(".release.json")
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_save_emulator_files",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
