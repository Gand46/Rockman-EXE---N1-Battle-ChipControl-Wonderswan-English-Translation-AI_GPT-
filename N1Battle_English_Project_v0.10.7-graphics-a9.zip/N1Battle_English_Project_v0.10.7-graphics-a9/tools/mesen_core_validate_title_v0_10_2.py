#!/usr/bin/env python3
"""Clean-boot runtime validation of the v0.10.2 English title screen."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
ROM_SHA256 = "b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24"
NATIVE_DISPLAY = (224, 144)
VISIBLE_FRAME = 450
HIDDEN_FRAME = 550
START_FIRST_FRAME = 650
START_LAST_FRAME = 659
MENU_FRAME = 900
STOP_FRAME = 925


@dataclass(frozen=True)
class Region:
    offset: int
    length: int
    sha256: str


REGIONS = {
    "title_tiles": Region(
        0x071BC0, 0x1A00,
        "70e121351d3077b8c4e89c6085ed85b0d0e4fc321c4dbbfc632657721e085d2b",
    ),
    "title_map": Region(
        0x0409A6, 0x0480,
        "d16eaa95a1829c462f2e036fa4cde8c8c5416579cb8f0a00c128132358535036",
    ),
    "title_palettes": Region(
        0x074C68, 0x00A0,
        "5bbabe397d4dec9fda37d9f6a2e0e5b871118eace3fb1790d8718ce9f7359602",
    ),
    "background_map": Region(
        0x040E28, 0x0480,
        "1130b1db429bf68dbbed0cc8eadf773bbde73645428c087baa81f697df8ae0a9",
    ),
    "background_palette_7": Region(
        0x074D08, 0x0020,
        "610e6eac5c5a21fd17087be11284e2719166b68f06aa35cf131b980a4ae09f07",
    ),
    "press_start_tiles": Region(
        0x194C0E, 0x0300,
        "ca7d4d49c62b3a03d194499db47b661b26cc07b314dfe0ee1f377a6bb4aae606",
    ),
    "new_game_selected": Region(
        0x19430E, 0x0240,
        "008f6a5d4b541c99c82ab6c649b4a0ab26cb72731b25a913ca48d80e4d2ac926",
    ),
    "new_game_unselected": Region(
        0x19454E, 0x0240,
        "e5598945b5c8370359e6a7101f187179937a2e0a638b578486c3c816decfaef3",
    ),
    "continue_selected": Region(
        0x19478E, 0x0240,
        "69e38f577a05a30058e7c40849fbe4ea8ece1449fde1afaa9716c0e0584ae339",
    ),
    "continue_unselected": Region(
        0x1949CE, 0x0240,
        "538b60339a6a430a1b1a07e4e5a31c34419d991cee92b5718d3f8309f4e8965f",
    ),
}


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame <= last


def input_for_frame(frame: int) -> Controller:
    # X=True is the established neutral clean-boot override used by the other
    # WonderSwan validators in this project.  Start is pulsed independently.
    state = Controller(X=True)
    state.Start = pulse(frame, START_FIRST_FRAME, START_LAST_FRAME)
    return state


def configure(lib: ctypes.CDLL) -> None:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
        "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib._title_v0102_callback = callback
    lib.RegisterNotificationCallback.argtypes = [callback]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]


def read_cpu(lib: ctypes.CDLL) -> bytes:
    buffer = (ctypes.c_uint8 * 0x10000)()
    lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
    return bytes(buffer)


def region_payload(rom: bytes, name: str) -> bytes:
    region = REGIONS[name]
    return rom[region.offset:region.offset + region.length]


def resource_check(
    cpu: bytes,
    rom: bytes,
    name: str,
    cpu_start: int,
) -> dict:
    expected = region_payload(rom, name)
    live = cpu[cpu_start:cpu_start + len(expected)]
    return {
        "rom_offset": f"0x{REGIONS[name].offset:06X}",
        "cpu_span": [f"0x{cpu_start:04X}", f"0x{cpu_start + len(expected) - 1:04X}"],
        "length": len(expected),
        "expected_sha256": digest(expected),
        "live_sha256": digest(live),
        "match": live == expected,
    }


def map_resource_check(cpu: bytes, rom: bytes) -> dict:
    expected = region_payload(rom, "title_map")
    buffers = []
    for cpu_start in (0x2800, 0x3000):
        live = cpu[cpu_start:cpu_start + len(expected)]
        buffers.append({
            "cpu_span": [
                f"0x{cpu_start:04X}",
                f"0x{cpu_start + len(expected) - 1:04X}",
            ],
            "live_sha256": digest(live),
            "match": live == expected,
        })
    return {
        "rom_offset": f"0x{REGIONS['title_map'].offset:06X}",
        "length": len(expected),
        "expected_sha256": digest(expected),
        "candidate_live_buffers": buffers,
        "match": any(item["match"] for item in buffers),
    }


def find_all(payload: bytes, pattern: bytes) -> list[str]:
    addresses: list[str] = []
    start = 0
    while True:
        offset = payload.find(pattern, start)
        if offset < 0:
            return addresses
        addresses.append(f"0x{offset:04X}")
        start = offset + 1


def prompt_metrics(path: Path) -> dict:
    # PRESS START occupies x=69..150, y=103..113 in the native 224x144 frame.
    # Neutral-white pixels distinguish it from the animated green/pink BG.
    with Image.open(path) as source:
        image = source.convert("RGB")
        pixels: list[tuple[int, int]] = []
        for y in range(102, 116):
            for x in range(55, 170):
                red, green, blue = image.getpixel((x, y))
                if min(red, green, blue) >= 145 and max(red, green, blue) - min(red, green, blue) <= 55:
                    pixels.append((x, y))
    bbox = None
    if pixels:
        bbox = [
            min(x for x, _y in pixels),
            min(y for _x, y in pixels),
            max(x for x, _y in pixels),
            max(y for _x, y in pixels),
        ]
    return {
        "measurement_crop": [55, 102, 170, 116],
        "neutral_white_pixels": len(pixels),
        "neutral_white_bbox": bbox,
    }


def title_live_resources(cpu: bytes, rom: bytes) -> dict:
    resources = {
        "title_tiles": resource_check(cpu, rom, "title_tiles", 0x8020),
        "title_map": map_resource_check(cpu, rom),
        "title_palettes": resource_check(cpu, rom, "title_palettes", 0xFE40),
        "background_map": resource_check(cpu, rom, "background_map", 0x2000),
        "background_palette_7": resource_check(cpu, rom, "background_palette_7", 0xFEE0),
        "press_start_tiles": resource_check(cpu, rom, "press_start_tiles", 0x4900),
    }
    resources["all_match"] = all(item["match"] for item in resources.values())
    return resources


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=60.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    rom_sha256 = digest(rom)
    if rom_sha256 != ROM_SHA256:
        raise ValueError(
            f"unexpected v0.10.2 ROM: expected {ROM_SHA256}, got {rom_sha256}"
        )
    rom_guards = {
        name: digest(region_payload(rom, name)) == region.sha256
        for name, region in REGIONS.items()
    }
    if not all(rom_guards.values()):
        raise ValueError(f"v0.10.2 title ROM guards failed: {rom_guards}")

    output_dir = args.output_dir.resolve()
    if output_dir == Path(output_dir.anchor) or output_dir == Path.cwd().resolve():
        raise ValueError(f"unsafe output directory: {output_dir}")
    if output_dir.exists():
        shutil.rmtree(output_dir)
    home = output_dir / "mesen_home"
    shots_dir = home / "Screenshots"
    shots_dir.mkdir(parents=True)
    fresh_home = not any(home.glob("*.sav")) and not any(home.glob("*.state"))

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    configure(lib)
    frame = 0
    capture_frames = (VISIBLE_FRAME, HIDDEN_FRAME, MENU_FRAME)
    dumps: dict[int, bytes] = {}
    captured_frames: list[int] = []
    done = threading.Event()
    callback_type = lib._title_v0102_callback

    @callback_type
    def notification(kind: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal frame
        if kind != PPU_FRAME_DONE:
            return
        frame += 1
        lib.SetInputOverrides(0, input_for_frame(frame + 1))
        if frame in capture_frames:
            lib.TakeScreenshot()
            dumps[frame] = read_cpu(lib)
            captured_frames.append(frame)
        if frame >= STOP_FRAME:
            done.set()

    listener = None
    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the v0.10.2 ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("MesenCore could not register the title callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not done.wait(args.timeout):
            raise TimeoutError(f"title/menu route timed out at frame {frame}")
        lib.Pause()
        time.sleep(0.25)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 8.0
    while len(list(shots_dir.glob("*.png"))) < len(capture_frames) and time.monotonic() < deadline:
        time.sleep(0.05)
    source_shots = sorted(shots_dir.glob("*.png"))
    if len(source_shots) != len(capture_frames):
        raise RuntimeError(
            f"expected {len(capture_frames)} screenshots, found {len(source_shots)}"
        )
    if captured_frames != list(capture_frames) or set(dumps) != set(capture_frames):
        raise RuntimeError(f"incomplete title CPU captures: {captured_frames}")

    capture_specs = (
        (VISIBLE_FRAME, "press_start_visible", "title"),
        (HIDDEN_FRAME, "press_start_hidden", "title"),
        (MENU_FRAME, "new_game_continue_menu", "menu"),
    )
    captures = []
    output_paths: dict[int, Path] = {}
    for (capture_frame, name, phase), source in zip(capture_specs, source_shots, strict=True):
        screenshot = output_dir / f"title_{name}_{capture_frame}.png"
        cpu_path = output_dir / f"title_{name}_cpu_{capture_frame}.bin"
        shutil.copy2(source, screenshot)
        cpu_path.write_bytes(dumps[capture_frame])
        output_paths[capture_frame] = screenshot
        with Image.open(screenshot) as image:
            dimensions = list(image.size)
        capture = {
            "name": name,
            "phase": phase,
            "frame": capture_frame,
            "screenshot": screenshot.name,
            "screenshot_sha256": digest(screenshot.read_bytes()),
            "cpu_dump": cpu_path.name,
            "cpu_dump_sha256": digest(dumps[capture_frame]),
            "dimensions": dimensions,
            "native_224x144": dimensions == list(NATIVE_DISPLAY),
        }
        if phase == "title":
            capture["live_resources"] = title_live_resources(dumps[capture_frame], rom)
            capture["prompt_metrics"] = prompt_metrics(screenshot)
        captures.append(capture)

    visible_metrics = captures[0]["prompt_metrics"]
    hidden_metrics = captures[1]["prompt_metrics"]
    visible_pixels = visible_metrics["neutral_white_pixels"]
    hidden_pixels = hidden_metrics["neutral_white_pixels"]
    prompt_blink = {
        "visible_frame": VISIBLE_FRAME,
        "hidden_frame": HIDDEN_FRAME,
        "visible_neutral_pixels": visible_pixels,
        "hidden_neutral_pixels": hidden_pixels,
        "delta_neutral_pixels": visible_pixels - hidden_pixels,
        "visible_verified": visible_pixels >= 250,
        "hidden_verified": hidden_pixels <= 75,
    }
    prompt_blink["verified"] = (
        prompt_blink["visible_verified"]
        and prompt_blink["hidden_verified"]
        and prompt_blink["delta_neutral_pixels"] >= 250
    )

    menu_cpu = dumps[MENU_FRAME]
    new_game_selected_addresses = find_all(
        menu_cpu, region_payload(rom, "new_game_selected")
    )
    continue_unselected_addresses = find_all(
        menu_cpu, region_payload(rom, "continue_unselected")
    )
    new_game_selected_match = bool(new_game_selected_addresses)
    continue_unselected_match = bool(continue_unselected_addresses)
    start_transition = {
        "start_button_pulse_frames": [START_FIRST_FRAME, START_LAST_FRAME],
        "pre_start_frame": HIDDEN_FRAME,
        "post_start_frame": MENU_FRAME,
        "menu_screenshot": output_paths[MENU_FRAME].name,
        "new_game_selected_live_addresses": new_game_selected_addresses,
        "continue_unselected_live_addresses": continue_unselected_addresses,
        "new_game_selected_live_match": new_game_selected_match,
        "continue_unselected_live_match": continue_unselected_match,
        "screenshot_changed_from_pre_start": (
            digest(output_paths[MENU_FRAME].read_bytes())
            != digest(output_paths[HIDDEN_FRAME].read_bytes())
        ),
    }
    start_transition["verified"] = (
        new_game_selected_match
        and continue_unselected_match
        and start_transition["screenshot_changed_from_pre_start"]
        and captures[2]["native_224x144"]
    )
    captures[2]["live_menu_assets"] = {
        "new_game_selected": {
            "expected_sha256": REGIONS["new_game_selected"].sha256,
            "live_addresses": new_game_selected_addresses,
            "match": new_game_selected_match,
        },
        "continue_unselected": {
            "expected_sha256": REGIONS["continue_unselected"].sha256,
            "live_addresses": continue_unselected_addresses,
            "match": continue_unselected_match,
        },
    }

    title_resources_ok = all(
        capture["live_resources"]["all_match"]
        for capture in captures[:2]
    )
    native_display_ok = all(capture["native_224x144"] for capture in captures)
    passed = (
        all(rom_guards.values())
        and fresh_home
        and title_resources_ok
        and native_display_ok
        and prompt_blink["verified"]
        and start_transition["verified"]
    )
    report = {
        "validation": "title_screen_v0_10_2_clean_boot_and_start_transition",
        "status": "PASS" if passed else "FAIL",
        "rom_sha256": rom_sha256,
        "expected_rom_sha256": ROM_SHA256,
        "native_display": list(NATIVE_DISPLAY),
        "clean_boot": {
            "fresh_mesen_home": fresh_home,
            "uses_sav_or_savestate": False,
        },
        "rom_guards": rom_guards,
        "input_route": {
            "held_override": "X",
            "start_button_pulse_frames": [START_FIRST_FRAME, START_LAST_FRAME],
            "other_menu_buttons_pressed": False,
        },
        "captures": captures,
        "press_start_blink": prompt_blink,
        "start_transition": start_transition,
        "summary_checks": {
            "native_224x144_all_captures": native_display_ok,
            "active_title_tiles_maps_palettes_live": title_resources_ok,
            "press_start_visible_and_hidden": prompt_blink["verified"],
            "real_start_transition_to_new_game_continue": start_transition["verified"],
        },
    }
    report_path = output_dir / "title_runtime_validation_v0_10_2.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    shutil.rmtree(home)
    print(json.dumps(report, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
