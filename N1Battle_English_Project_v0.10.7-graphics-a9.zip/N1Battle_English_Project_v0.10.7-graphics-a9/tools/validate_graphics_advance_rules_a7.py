#!/usr/bin/env python3
"""Enforce all cumulative graphics gates through Advance 7."""

from __future__ import annotations

import argparse
import hashlib
import json
import struct
import sys
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_7_month_later_centering as a7  # noqa: E402
import n1tool  # noqa: E402


SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
A6_SHA256 = a7.BASE_A6_SHA256
A7_SHA256 = "e049ce549ddbbe695995cc7c76863a201e22199e064daaa24f2e542dcedaf9fa"
IPS_SHA256 = "26f612898f1bc8755324c5e6335c4581d3e8b19cd58fee46e9817eeff1d7ef86"
MANIFEST_SHA256 = "cc3e39705bfa5280567f1fc68fde7a732dbf3a55123ca72aa40704e436b4f045"
MESEN_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
RUNTIME = Path("docs/runtime_graphics_advances/advance_7_gate_final")


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def load_image(path: Path) -> Image.Image:
    image = Image.open(path).convert("RGB")
    require(image.size == (224, 144), f"not a native 224x144 capture: {path}")
    return image


def nonblack(image: Image.Image) -> dict[tuple[int, int], tuple[int, int, int]]:
    return {
        (x, y): image.getpixel((x, y))
        for y in range(144)
        for x in range(224)
        if image.getpixel((x, y)) != (0, 0, 0)
    }


def bbox(points: set[tuple[int, int]]) -> list[int]:
    return [
        min(x for x, _ in points), min(y for _, y in points),
        max(x for x, _ in points) + 1, max(y for _, y in points) + 1,
    ]


def map_words(memory: bytes, base: int, y: int) -> list[int]:
    return [struct.unpack_from("<H", memory, base + (y * 32 + x) * 2)[0] for x in range(32)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--a6-rom", required=True, type=Path)
    parser.add_argument("--candidate-rom", type=Path)
    parser.add_argument("--direct-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    candidate_path = args.candidate_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7.wsc"
    direct_path = args.direct_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7-direct.wsc"
    ips_path = args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a7.ips"

    source = args.source_rom.read_bytes()
    base = args.a6_rom.read_bytes()
    candidate = candidate_path.read_bytes()
    direct = direct_path.read_bytes()
    ips = ips_path.read_bytes()
    require(sha256(source) == SOURCE_SHA256, "Japanese source ROM identity differs")
    require(sha256(base) == A6_SHA256, "approved Advance 6 identity differs")
    require(sha256(candidate) == A7_SHA256, "Advance 7 candidate identity differs")
    require(candidate == direct, "direct A6-based build differs from manifest reconstruction")
    require(sha256(ips) == IPS_SHA256, "Advance 7 IPS identity differs")
    require(n1tool.apply_ips(source, ips) == candidate, "IPS does not reconstruct candidate")
    stored, calculated = n1tool.checksum(candidate)
    require(stored == calculated == 0xB4F6, "WonderSwan checksum differs")

    call_asset = (root / "translation/assets" / a7.CALL_ASSET).read_bytes()
    require(call_asset == a7.PATCHED_CALL and sha256(call_asset) == a7.CALL_ASSET_SHA256,
            "A7 call-site asset differs")
    require(base[a7.CALL_OFFSET:a7.CALL_OFFSET + 2] == a7.ORIGINAL_CALL,
            "A6 call-site source differs")
    require(candidate[a7.CALL_OFFSET:a7.CALL_OFFSET + 2] == a7.PATCHED_CALL,
            "A7 call-site output differs")
    allowed = set(range(a7.CALL_OFFSET, a7.CALL_OFFSET + 2)) | set(range(len(candidate) - 2, len(candidate)))
    changed = {i for i, pair in enumerate(zip(base, candidate, strict=True)) if pair[0] != pair[1]}
    require(changed == {0x32A6F8, 0x3FFFFE}, "A7 binary delta escaped its exact two-byte contract")
    require(changed <= allowed, "A7 binary delta escaped its closed allowlist")

    pointer_span = slice(0x34AB10, 0x34ACB0)
    pool_span = slice(0x34ACB0, 0x34B75E)
    require(base[pointer_span] == candidate[pointer_span], "auxiliary pointer table changed")
    require(base[pool_span] == candidate[pool_span], "auxiliary text pool changed")
    require(base[0x32A700:0x32A718] == candidate[0x32A700:0x32A718],
            "auxiliary pointer resolution instructions changed")

    manifest_path = root / "translation/en_v0_10_7_graphics_a7.json"
    manifest = load_json(manifest_path)
    build = load_json(root / "build/build_v0_10_7_graphics_a7.json")
    generator = load_json(root / "translation/assets/graphics_advance_7_month_later_centering_report.json")
    rules = load_json(root / "translation/graphics_advance_rules.json")
    require(sha256(manifest_path.read_bytes()) == MANIFEST_SHA256, "A7 manifest identity differs")
    require(manifest.get("project_version") == "0.10.7-graphics-a7", "A7 manifest version differs")
    require(build.get("output_sha256") == A7_SHA256, "manifest reconstruction identity differs")
    require(build.get("checksum", {}).get("checksum_valid") is True, "manifest checksum invalid")
    require(generator.get("status") == "PASS" and generator.get("candidate_rom_sha256") == A7_SHA256,
            "A7 generator report is not final")
    require(generator.get("bytes_outside_allowlist") == 0, "generator allowlist failed")
    require(rules.get("status") == "PASS" and rules.get("project_version") == "0.10.7-graphics-a7",
            "cumulative rule identity differs")
    require(len(rules.get("rules", [])) == 27, "expected 27 cumulative rules")
    require(all(row.get("mandatory") is True for row in rules["rules"]), "a cumulative rule is optional")
    for advance in range(1, 8):
        require(rules.get(f"advance_{advance}", {}).get("status") == "PASS",
                f"Advance {advance} checkpoint missing")

    evidence = root / RUNTIME
    a6_title_path = evidence / "a6/story_02600.png"
    a7_title_path = evidence / "a7/story_02600.png"
    a6_title = load_image(a6_title_path)
    a7_title = load_image(a7_title_path)
    before = nonblack(a6_title)
    after = nonblack(a7_title)
    require(len(before) == len(after) == 269, "title foreground pixel count differs")
    require(bbox(set(before)) == [89, 66, 210, 78], "A6 title glyph box differs")
    require(bbox(set(after)) == [49, 66, 170, 78], "A7 title glyph box differs")
    translated = {(x - 40, y): colour for (x, y), colour in before.items()}
    require(translated == after, "A7 title is not an exact 40-pixel rigid translation")
    require((a7.CENTERED_X_CELL * a7.CELL_WIDTH,
             (a7.CENTERED_X_CELL + a7.TEXT_CELLS) * a7.CELL_WIDTH) == (48, 176),
            "centered text span differs")
    require((48 + 176) // 2 == 112, "text cell span is not centered on screen")

    unaffected = {}
    for frame in (2300, 2960, 3200):
        before_path = evidence / "a6" / f"story_{frame:05d}.png"
        after_path = evidence / "a7" / f"story_{frame:05d}.png"
        require(before_path.read_bytes() == after_path.read_bytes(), f"unrelated frame {frame} changed")
        unaffected[str(frame)] = sha256(before_path.read_bytes())

    memory_a6 = (evidence / "a6/story_02600_cpu.bin").read_bytes()
    memory_a7 = (evidence / "a7/story_02600_cpu.bin").read_bytes()
    require(len(memory_a6) == len(memory_a7) == 0x10000, "runtime CPU dump length differs")
    map_rows = {}
    blank = 0x21C3
    for y in (8, 9):
        row_a6 = map_words(memory_a6, 0x3000, y)
        row_a7 = map_words(memory_a7, 0x3000, y)
        require(row_a7[6:22] == row_a6[11:27], f"BG map row {y} did not shift five cells")
        require(all(word == blank for word in row_a6[6:11]), f"A6 leading cells on row {y} were not blank")
        require(all(word == blank for word in row_a7[22:27]), f"A7 trailing cells on row {y} were not cleared")
        require(row_a6[:6] == row_a7[:6] and row_a6[27:] == row_a7[27:],
                f"BG map row {y} changed outside the union span")
        map_rows[str(y)] = {"before_cells": [11, 26], "after_cells": [6, 21],
                            "shift_cells": -5, "outside_union_exact": True}

    for variant in ("a6", "a7"):
        probe = load_json(evidence / variant / "story_probe_report.json")
        require(probe.get("status") == "PASS" and probe.get("clean_boot") is True,
                f"{variant} runtime probe did not use a clean boot")
        require(probe.get("uses_save_or_savestate") is False, f"{variant} runtime probe used saved state")
        require(probe.get("mesen_core_sha256") == MESEN_CORE_SHA256, f"{variant} emulator identity differs")

    runtime_report = {
        "status": "PASS", "project_version": "0.10.7-graphics-a7",
        "native_resolution": [224, 144], "mesen_core_sha256": MESEN_CORE_SHA256,
        "clean_boot": True, "uses_save_or_savestate": False,
        "target": "1 MONTH LATER...", "auxiliary_pointer_index": "0x10",
        "cell_geometry": {"text_cells": 16, "cell_width": 8, "before_span": [88, 216],
                          "after_span": [48, 176], "screen_center_x": 112,
                          "after_span_center_x": 112},
        "foreground": {"pixels_before": 269, "pixels_after": 269,
                       "bbox_before": [89, 66, 210, 78], "bbox_after": [49, 66, 170, 78],
                       "exact_rigid_translation": [-40, 0]},
        "runtime_bg_map": map_rows,
        "unrelated_story_frames_pixel_exact": unaffected,
        "text_pointer_renderer_font_palette_vertical_position_unchanged": True,
        "manual_semantic_review": "PASS",
        "a6_title_sha256": sha256(a6_title_path.read_bytes()),
        "a7_title_sha256": sha256(a7_title_path.read_bytes()),
    }
    runtime_path = evidence / "graphics_advance_7_runtime_validation.json"
    runtime_path.write_text(json.dumps(runtime_report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")

    report = {
        "status": "PASS", "project_version": "0.10.7-graphics-a7", "rules_enforced": 27,
        "source_rom_sha256": SOURCE_SHA256, "base_advance_6_sha256": A6_SHA256,
        "candidate_rom_sha256": A7_SHA256, "cumulative_ips_sha256": IPS_SHA256,
        "wonder_swan_checksum": "0xB4F6", "ips_reconstructs_candidate": True,
        "manifest_reconstructs_candidate": True, "direct_build_matches_manifest": True,
        "binary_write_allowlist": "PASS", "metric_centering": "PASS",
        "scene_specific_call_isolation": "PASS", "exact_rigid_mask_translation": "PASS",
        "text_pointer_renderer_font_palette_y_protection": "PASS",
        "unrelated_story_frame_regression": "PASS",
        "advance_1_through_6_checkpoints": "PASS", "advance_7_checkpoint": "PASS",
        "manual_semantic_review": "PASS",
    }
    output = root / "build/graphics_advance_rules_validation.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
