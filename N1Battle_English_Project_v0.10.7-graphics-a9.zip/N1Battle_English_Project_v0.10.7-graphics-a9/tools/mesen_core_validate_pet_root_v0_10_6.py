#!/usr/bin/env python3
"""Validate the pixel-polished v0.10.6 PET root menu from a clean boot.

The route and MesenCore bridge are inherited from the independently proven
v0.10.4 PET validator.  This revision audits six static lettering fields: the
five left menu labels and CLASS.  Rank E, 3000Z, cursor, frames and every
pixel outside those fields must remain identical to the v0.10.5 screen.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

from PIL import Image

import mesen_core_validate_pet_root_v0_10_4 as runtime


ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
MAP_SHA256 = "c7576cfa9c3592da4854aff9fb38eeed3faa0cd38c8c8feb6f567380c519d58b"
TILES_SHA256 = "d091e6648a55b4113b9e7d80dcc987e84e4f2175ee6f7434b4a141ab7666a3f6"

LABEL_RECTS = (
    ("Program Deck", 2, 2, 8, 2),
    ("Chip Folder", 2, 5, 7, 2),
    ("Data Library", 2, 8, 8, 2),
    ("NetNavi", 2, 11, 5, 2),
    ("Save", 2, 14, 3, 2),
    ("CLASS", 16, 2, 6, 2),
)
STATIC_Z_TILE_IDS = (0x2B, 0x30)
FRAME_TILE_IDS = (0x0F, 0x10, 0x31, 0x45, 0x46)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def target_cells() -> set[tuple[int, int]]:
    return {
        (x + dx, y + dy)
        for _label, x, y, width, height in LABEL_RECTS
        for dy in range(height)
        for dx in range(width)
    }


def target_pixels() -> set[tuple[int, int]]:
    return {
        (x * 8 + dx, y * 8 + dy)
        for _label, x, y, width, height in LABEL_RECTS
        for dy in range(height * 8)
        for dx in range(width * 8)
    }


def map_word(payload: bytes, x: int, y: int) -> int:
    offset = (y * runtime.MAP_WIDTH + x) * 2
    return int.from_bytes(payload[offset:offset + 2], "little")


def tile_bytes(payload: bytes, tile_id: int) -> bytes:
    offset = (tile_id - runtime.FIRST_TILE_ID) * runtime.TILE_BYTES
    return payload[offset:offset + runtime.TILE_BYTES]


def compare_pixels(reference_path: Path, actual_path: Path) -> dict[str, object]:
    with Image.open(reference_path) as source:
        reference = source.convert("RGB")
    with Image.open(actual_path) as source:
        actual = source.convert("RGB")
    if reference.size != (224, 144):
        raise ValueError("invalid reference dimensions")
    if actual.size != (224, 144):
        raise ValueError("invalid runtime dimensions")
    allowed = target_pixels()
    changed = []
    protected = []
    for y in range(144):
        for x in range(224):
            if reference.getpixel((x, y)) == actual.getpixel((x, y)):
                continue
            changed.append((x, y))
            if (x, y) not in allowed:
                protected.append((x, y))
    return {
        "changed_pixels": len(changed),
        "protected_changed_pixels": len(protected),
        "protected_pixels_identical": not protected,
        "protected_difference_sample": [list(point) for point in protected[:64]],
    }


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc")
    parser.add_argument("--mesen-core", type=Path, default=Path("/tmp/MesenCore.so"))
    parser.add_argument("--tiles", type=Path, default=root / "translation/assets/pet_labels_tiles_v0_10_6.bin")
    parser.add_argument("--tilemap", type=Path, default=root / "translation/assets/pet_labels_bg0_map_v0_10_6.bin")
    parser.add_argument("--base-tiles", type=Path, default=root / "translation/assets/pet_labels_tiles_v0_10_4.bin")
    parser.add_argument("--base-tilemap", type=Path, default=root / "translation/assets/pet_labels_bg0_map_v0_10_4.bin")
    parser.add_argument("--base-screenshot", type=Path, default=root / "docs/runtime_v0_10_4/pet_root/pet_root_runtime_27000.png")
    parser.add_argument("--expected-preview", type=Path, default=root / "translation/assets/pet_root_menu_font_preview_v0_10_6.png")
    parser.add_argument("--output-dir", type=Path, default=root / "docs/runtime_v0_10_6/pet_root")
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    expected_map = args.tilemap.read_bytes()
    expected_tiles = args.tiles.read_bytes()
    base_map = args.base_tilemap.read_bytes()
    base_tiles = args.base_tiles.read_bytes()
    if len(rom) != runtime.EXPECTED_ROM_SIZE or sha256(rom) != ROM_SHA256:
        raise ValueError("expected the canonical v0.10.6 ROM")
    if len(expected_map) != runtime.EXPECTED_MAP_LENGTH or sha256(expected_map) != MAP_SHA256:
        raise ValueError("unexpected v0.10.6 PET map")
    if len(expected_tiles) != runtime.EXPECTED_TILES_LENGTH or sha256(expected_tiles) != TILES_SHA256:
        raise ValueError("unexpected v0.10.6 PET tiles")
    if len(base_map) != len(expected_map) or len(base_tiles) != len(expected_tiles):
        raise ValueError("PET baseline size mismatch")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    capture = runtime.run_clean_boot(args.rom, args.mesen_core, args.output_dir, args.timeout)
    live_map = capture.cpu[runtime.MAP_CPU_BASE:runtime.MAP_CPU_BASE + len(expected_map)]
    live_tiles = capture.cpu[runtime.TILES_CPU_BASE:runtime.TILES_CPU_BASE + len(expected_tiles)]
    visible_map = capture.cpu[
        runtime.MAP_CPU_BASE:
        runtime.MAP_CPU_BASE + runtime.MAP_WIDTH * runtime.VISIBLE_ROWS * 2
    ]

    cells = target_cells()
    map_changes_outside = []
    for offset in range(0, len(expected_map), 2):
        if expected_map[offset:offset + 2] == base_map[offset:offset + 2]:
            continue
        cell = ((offset // 2) % runtime.MAP_WIDTH, (offset // 2) // runtime.MAP_WIDTH)
        if cell not in cells:
            map_changes_outside.append(list(cell))

    changed_tiles = {
        tile_id
        for tile_id in range(runtime.FIRST_TILE_ID, len(expected_tiles) // runtime.TILE_BYTES + 1)
        if tile_bytes(expected_tiles, tile_id) != tile_bytes(base_tiles, tile_id)
    }
    collisions = []
    for y in range(runtime.VISIBLE_ROWS):
        for x in range(runtime.VISIBLE_COLUMNS):
            word = map_word(visible_map, x, y)
            tile_id = word & 0x01FF
            if tile_id in changed_tiles and (x, y) not in cells:
                collisions.append({"x": x, "y": y, "tile_id": f"0x{tile_id:02X}"})

    protected_tiles = {}
    for tile_id in (*STATIC_Z_TILE_IDS, *FRAME_TILE_IDS):
        preserved = tile_bytes(live_tiles, tile_id) == tile_bytes(base_tiles, tile_id)
        protected_tiles[f"0x{tile_id:02X}"] = preserved

    base_comparison = compare_pixels(args.base_screenshot, capture.screenshot)
    with Image.open(args.expected_preview) as source:
        expected_rgb = source.convert("RGB").tobytes()
    with Image.open(capture.screenshot) as source:
        screenshot_rgb = source.convert("RGB").tobytes()

    checks = {
        "live_map_matches_asset": live_map == expected_map,
        "live_tiles_match_asset": live_tiles == expected_tiles,
        "map_changes_only_in_six_fields": not map_changes_outside,
        "changed_tiles_confined_at_runtime": not collisions,
        "static_z_and_frames_preserved": all(protected_tiles.values()),
        "cursor_rank_and_credits_preserved": bool(base_comparison["protected_pixels_identical"]),
        "runtime_matches_reviewed_preview": screenshot_rgb == expected_rgb,
        "bottom_frame_corner_preserved": map_word(visible_map, 11, 16) == 0x2445,
        "clean_boot_without_savestate": True,
    }
    failures = [name for name, passed in checks.items() if not passed]
    report = {
        "validation": "pet_root_v0_10_6_clean_boot_mesen_core",
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "rom": {"file": args.rom.name, "sha256": sha256(rom)},
        "assets": {
            "map": {"file": args.tilemap.name, "sha256": sha256(expected_map)},
            "tiles": {"file": args.tiles.name, "sha256": sha256(expected_tiles)},
        },
        "labels": [label for label, *_rest in LABEL_RECTS],
        "route": {
            "clean_boot": True,
            "uses_sav_or_savestate": False,
            "target_frame": runtime.TARGET_FRAME,
            "last_callback_frame": capture.completed_frames,
            "elapsed_seconds": round(capture.elapsed_seconds, 3),
        },
        "runtime": {
            "map_sha256": sha256(live_map),
            "tiles_sha256": sha256(live_tiles),
            "changed_tile_ids": [f"0x{tile_id:02X}" for tile_id in sorted(changed_tiles)],
            "changed_tile_references_outside_fields": collisions,
            "serialized_map_changes_outside_fields": map_changes_outside,
            "protected_tiles": protected_tiles,
        },
        "visual": {
            "screenshot": capture.screenshot.name,
            "screenshot_sha256": runtime.file_sha256(capture.screenshot),
            "dimensions": [224, 144],
            "base_protected_comparison": base_comparison,
        },
        "checks": checks,
    }
    report_path = args.output_dir / "pet_root_runtime_validation_v0_10_6.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
