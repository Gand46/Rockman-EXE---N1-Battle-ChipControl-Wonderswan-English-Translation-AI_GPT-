#!/usr/bin/env python3
"""Validate the cumulative Advance 1 checkpoint on the Advance 3 ROM."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from dataclasses import replace
from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_pet_deep_v0_10 as legacy  # noqa: E402


EXPECTED_ROM_SHA256 = "2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c"
EXPECTED_REFERENCE_SHA256 = "63ce8069d89106fdc96167a14d139641db202d23e0a2cd539347e19f8fcd8575"
EXPECTED_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
EXPECTED_PROGRAM_MAP_SHA256 = "5a95ddcd69954f615b15f6aa9ae2ebefe07ba3e616141657b22ac46b57291643"
RC4_SCREENSHOT_SHA256 = "86fe84efd06a4e2098b05c63b7010ee62d6fba8621f1fc559876fb74fe5ce6d5"
REFERENCE_SCREENSHOT_SHA256 = "b079d82d662f06c4dae943eb893d3abb8684fa4135fdc00ed713e55a61f35921"
HEADER_RECT = (88, 0, 224, 16)
LEFT_EDGE_RECT = (0, 0, 8, 144)
PROGRAM_DECK_RECT = (88, 0, 144, 16)
SYMBOL_RECT = (144, 0, 152, 16)
RIGHT_HEADER_RECT = (152, 0, 224, 16)
EXPECTED_RC4_CHANGED_PIXELS = 1410
EXPECTED_RC4_CHANGED_BBOX = (0, 0, 224, 128)
EXPECTED_SCREENSHOT_SHA256 = "b079d82d662f06c4dae943eb893d3abb8684fa4135fdc00ed713e55a61f35921"
EXPECTED_REFERENCE_SYMBOL_PIXELS = 0
EXPECTED_CLEAN_RGB = (85, 102, 102)
PROGRAM_MAP_OFFSET = 0x04323C
PROGRAM_TILE_OFFSET = 0x07CD20
TILE_MASK = 0x01FF
TILE_BYTES = 32
PROGRAM_DECK_CELLS = tuple((x, y) for y in (0, 1) for x in range(11, 18))
Y2_CHIP_FOLDER_CELLS = tuple((x, y) for y in (0, 1) for x in range(20, 27))
Y2_PICTOGRAM_CELLS = ((27, 0), (27, 1))
RESTORED_HEADER_CELLS = PROGRAM_DECK_CELLS + Y2_CHIP_FOLDER_CELLS + Y2_PICTOGRAM_CELLS
SYMBOL_CELLS = ((18, 0), (18, 1))
LEFT_BORDER_CELLS = tuple((0, y) for y in range(1, 16))


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def bind_rom(rom: bytes) -> None:
    if sha256(rom) != EXPECTED_ROM_SHA256:
        raise ValueError("Advance 1 runtime validator requires the exact candidate ROM")
    for name, region in list(legacy.MAPS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.MAPS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    for name, region in list(legacy.TILE_BANKS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.TILE_BANKS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    legacy.PROGRAM_V10_TILE_IDS = (
        0x004, 0x005, 0x006, 0x007, 0x008, 0x009, 0x00A,
        0x00E, 0x00F, 0x010, 0x014, 0x015, 0x016, 0x017,
        0x018, 0x01A, 0x01C, 0x01D, 0x01E,
    )
    legacy.ROUTES = tuple(
        replace(
            route,
            captures=tuple(
                replace(
                    capture,
                    expected_labels=(
                        ("PROGRAM DECK", "Y2 CHIP FOLDER")
                        if capture.name == "program_root"
                        else capture.expected_labels
                    ),
                )
                for capture in route.captures
            ),
        )
        for route in legacy.ROUTES
    )


def disable_gui_release() -> None:
    original = legacy.configure_core

    def configure(lib) -> None:
        original(lib)
        lib.Release = lambda: None

    legacy.configure_core = configure


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, required=True)
    parser.add_argument("--mesen-core", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--baseline-rc4", type=Path, required=True)
    parser.add_argument("--reference-screenshot", type=Path, required=True)
    parser.add_argument("--reference-rom", type=Path, required=True)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    reference = args.reference_rom.read_bytes()
    if sha256(reference) != EXPECTED_REFERENCE_SHA256:
        raise ValueError("The supplied reference ROM is not the approved Advance 1")
    if sha256(args.mesen_core.read_bytes()) != EXPECTED_CORE_SHA256:
        raise ValueError("MesenCore differs from the validated 2.1.1 build")
    if sha256(args.baseline_rc4.read_bytes()) != RC4_SCREENSHOT_SHA256:
        raise ValueError("The supplied baseline is not the approved RC4 Program Deck capture")
    if sha256(args.reference_screenshot.read_bytes()) != REFERENCE_SCREENSHOT_SHA256:
        raise ValueError("The supplied reference is not the approved Advance 1 capture")
    bind_rom(rom)
    program = legacy.MAPS["program"]
    if program.sha256 != EXPECTED_PROGRAM_MAP_SHA256:
        raise AssertionError("Advance 1 Program Deck map identity differs")
    disable_gui_release()
    result = legacy.run_route({
        "route": "program",
        "rom": str(args.rom),
        "core": str(args.mesen_core),
        "output": str(args.output_dir),
        "timeout": args.timeout,
    })

    screenshot = args.output_dir / "program_root_27200.png"
    with (
        Image.open(args.baseline_rc4) as rc4_source,
        Image.open(args.reference_screenshot) as reference_source,
        Image.open(screenshot) as after_source,
    ):
        before = rc4_source.convert("RGB")
        reference_image = reference_source.convert("RGB")
        after = after_source.convert("RGB")
    if before.size != (224, 144) or reference_image.size != (224, 144) or after.size != (224, 144):
        raise AssertionError("The comparison is not at native 224x144 resolution")
    difference = ImageChops.difference(before, after)
    bbox = difference.getbbox()
    changed_pixels = sum(
        before.getpixel((x, y)) != after.getpixel((x, y))
        for y in range(144) for x in range(224)
    )
    if changed_pixels != EXPECTED_RC4_CHANGED_PIXELS:
        raise AssertionError(
            f"Unexpected RC4 pixel delta: {changed_pixels} != {EXPECTED_RC4_CHANGED_PIXELS}"
        )
    if bbox != EXPECTED_RC4_CHANGED_BBOX:
        raise AssertionError(
            f"Unexpected RC4 pixel bbox: {bbox} != {EXPECTED_RC4_CHANGED_BBOX}"
        )
    screenshot_sha256 = sha256(screenshot.read_bytes())
    if screenshot_sha256 != EXPECTED_SCREENSHOT_SHA256:
        raise AssertionError(
            f"Unexpected screenshot identity: {screenshot_sha256} != {EXPECTED_SCREENSHOT_SHA256}"
        )
    outside_allowed_changes = sum(
        before.getpixel((x, y)) != after.getpixel((x, y))
        for y in range(144) for x in range(224)
        if not (
            (HEADER_RECT[0] <= x < HEADER_RECT[2] and HEADER_RECT[1] <= y < HEADER_RECT[3])
            or (LEFT_EDGE_RECT[0] <= x < LEFT_EDGE_RECT[2] and LEFT_EDGE_RECT[1] <= y < LEFT_EDGE_RECT[3])
        )
    )
    if outside_allowed_changes:
        raise AssertionError(f"{outside_allowed_changes} pixels changed outside the allowed regions")
    for name, rect in (("PROGRAM DECK", PROGRAM_DECK_RECT), ("Y2 CHIP FOLDER/pictogram", RIGHT_HEADER_RECT)):
        if after.crop(rect).tobytes() != reference_image.crop(rect).tobytes():
            raise AssertionError(f"{name} does not match the approved intact reference")
    clean_crop = after.crop(SYMBOL_RECT)
    if set(clean_crop.getdata()) != {EXPECTED_CLEAN_RGB}:
        raise AssertionError("The removed symbol area is not uniformly clean")
    reference_symbol_pixels = sum(
        left != right
        for left, right in zip(clean_crop.getdata(), reference_image.crop(SYMBOL_RECT).getdata())
    )
    if reference_symbol_pixels != EXPECTED_REFERENCE_SYMBOL_PIXELS:
        raise AssertionError(
            f"Unexpected symbol-only delta: {reference_symbol_pixels} != {EXPECTED_REFERENCE_SYMBOL_PIXELS}"
        )
    if after.crop(LEFT_EDGE_RECT).tobytes() != reference_image.crop(LEFT_EDGE_RECT).tobytes():
        raise AssertionError("The complete left edge does not match the clean approved reference")

    diff_image = Image.new("RGB", before.size, (0, 0, 0))
    for y in range(144):
        for x in range(224):
            if before.getpixel((x, y)) != after.getpixel((x, y)):
                diff_image.putpixel((x, y), (255, 0, 255))
    diff_path = args.output_dir / "program_root_advance_1_changed_pixels.png"
    diff_image.save(diff_path, optimize=False)

    captures = result["captures"]
    if not all(item["runtime_map"]["exact_match"] for item in captures):
        raise AssertionError("A live Program Deck map differs from the candidate ROM")
    if not all(item["runtime_tiles"]["exact_match"] for item in captures):
        raise AssertionError("Live Program Deck tiles differ from the candidate ROM")

    cpu = (args.output_dir / "program_root_cpu_27200.bin").read_bytes()
    if len(cpu) != 0x10000:
        raise AssertionError("Program Deck CPU dump is incomplete")
    for x, y in RESTORED_HEADER_CELLS:
        position = PROGRAM_MAP_OFFSET + (y * 32 + x) * 2
        candidate_word = int.from_bytes(rom[position:position + 2], "little")
        reference_word = int.from_bytes(reference[position:position + 2], "little")
        if candidate_word != reference_word:
            raise AssertionError(f"header map word differs from approved Advance 1 at {(x, y)}")
        tile_id = candidate_word & TILE_MASK
        asset_index = tile_id - 1
        expected_tile = reference[
            PROGRAM_TILE_OFFSET + asset_index * TILE_BYTES:
            PROGRAM_TILE_OFFSET + (asset_index + 1) * TILE_BYTES
        ]
        live_tile = cpu[0x8000 + tile_id * TILE_BYTES:0x8000 + (tile_id + 1) * TILE_BYTES]
        if live_tile != expected_tile:
            raise AssertionError(f"live header tile differs from v0.10.6 at {(x, y)}")
    for x, y in SYMBOL_CELLS:
        position = PROGRAM_MAP_OFFSET + (y * 32 + x) * 2
        word = int.from_bytes(rom[position:position + 2], "little")
        if word != 0x240C:
            raise AssertionError(f"symbol map cell was not cleared at {(x, y)}")
        tile_id = word & TILE_MASK
        live_tile = cpu[0x8000 + tile_id * TILE_BYTES:0x8000 + (tile_id + 1) * TILE_BYTES]
        if live_tile != bytes([0x44]) * TILE_BYTES:
            raise AssertionError(f"symbol cell is not a clean background tile at {(x, y)}")
    for x, y in LEFT_BORDER_CELLS:
        position = PROGRAM_MAP_OFFSET + (y * 32 + x) * 2
        candidate_word = int.from_bytes(rom[position:position + 2], "little")
        reference_word = int.from_bytes(reference[position:position + 2], "little")
        if candidate_word != reference_word:
            raise AssertionError(f"left border map word differs at {(x, y)}")
        tile_id = candidate_word & TILE_MASK
        asset_index = tile_id - 1
        expected_tile = reference[
            PROGRAM_TILE_OFFSET + asset_index * TILE_BYTES:
            PROGRAM_TILE_OFFSET + (asset_index + 1) * TILE_BYTES
        ]
        live_tile = cpu[0x8000 + tile_id * TILE_BYTES:0x8000 + (tile_id + 1) * TILE_BYTES]
        if live_tile != expected_tile:
            raise AssertionError(f"live left border tile differs at {(x, y)}")
    report = {
        "status": "PASS",
        "advance": "1 of 6",
        "checkpoint_after_advance": 3,
        "rom_sha256": sha256(rom),
        "mesen_core_sha256": EXPECTED_CORE_SHA256,
        "clean_boot": result["clean_boot"],
        "uses_sav_or_savestate": result["uses_sav"] or result["uses_savestate"],
        "native_resolution": [224, 144],
        "runtime_map_matches_rom": True,
        "runtime_tiles_match_rom": True,
        "runtime_map_tile_to_asset_offset": -1,
        "adjacent_program_deck_matches_v0_10_6": True,
        "adjacent_y2_chip_folder_matches_v0_10_6": True,
        "adjacent_y2_pictogram_matches_v0_10_6": True,
        "left_edge_matches_v0_10_6": True,
        "rc4_baseline_sha256": sha256(args.baseline_rc4.read_bytes()),
        "intact_heading_reference_sha256": sha256(args.reference_screenshot.read_bytes()),
        "screenshot": screenshot.name,
        "screenshot_sha256": screenshot_sha256,
        "changed_pixel_count": changed_pixels,
        "changed_pixel_bbox_vs_rc4": list(bbox),
        "allowed_visual_rectangles": {
            "corrected_header": list(HEADER_RECT),
            "restored_left_edge": list(LEFT_EDGE_RECT),
        },
        "pixels_outside_allowed_regions_unchanged_vs_rc4": True,
        "program_deck_pixel_exact_vs_v0_10_6": True,
        "y2_chip_folder_and_pictogram_pixel_exact_vs_v0_10_6": True,
        "symbol_only_changed_pixels_vs_v0_10_6": reference_symbol_pixels,
        "target_area_uniform_rgb": list(EXPECTED_CLEAN_RGB),
        "symbol_fully_removed": True,
        "difference_mask": diff_path.name,
        "captures": captures,
    }
    report_path = args.output_dir / "graphics_advance_1_runtime_validation.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    home = args.output_dir / "mesen_home"
    if home.exists():
        shutil.rmtree(home)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
