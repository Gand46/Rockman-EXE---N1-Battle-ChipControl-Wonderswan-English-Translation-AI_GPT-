#!/usr/bin/env python3
"""Fail-closed audit of residual encoded Japanese in the v0.10.1 WSC build.

This audit deliberately covers encoded, pointer-referenced text only.  It does
not inspect tile graphics and must not be used as evidence about graphical
translation coverage.

The authoritative inventory has 1,552 logical units:

    274 + 88 + 1 + 882 + 49 + 73 + 185 = 1,552

The source ROM defines which aliased source targets count as logical Japanese
units.  The built ROM defines their current destinations.  Every current
destination is decoded again after validating its pointer, bounds and
terminator.  Finally, a conservative whole-ROM heuristic scans every even byte
offset for Japanese-looking dynamic/static records.  Candidates outside the
verified text pools are rejected unless their exact span and bytes match the
two documented binary coincidences.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import struct
import sys
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Iterable


ROM_SIZE = 0x400000
SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
TEXT_DENOMINATOR = 1552
REPORT_DATE = "2026-08-22"

# These are data regions in which the verified readers obtain encoded text.
# Pointer tables and graphical assets are intentionally not included.
TEXT_POOLS: tuple[tuple[int, int, str], ...] = (
    (0x34ACB0, 0x34B75E, "auxiliary_group_5"),
    (0x34B8A0, 0x34CFDA, "dialogue_group_0"),
    (0x34D0C0, 0x3540B8, "dialogue_group_1"),
    (0x354160, 0x3574CE, "dialogue_group_2"),
    (0x357510, 0x357D38, "dialogue_group_3"),
    (0x357D80, 0x358732, "dialogue_group_4"),
    (0x367170, 0x367592, "navi_attack_names"),
    (0x367660, 0x367AEA, "participant_names"),
    (0x368010, 0x369160, "chip_names"),
    (0x369550, 0x36A4E0, "effect_labels"),
    (0x36A8D0, 0x36B8DE, "description_text_0"),
    (0x36BB90, 0x36C7BC, "description_text_1"),
    (0x36CA30, 0x36D3FC, "description_text_2"),
    (0x36D650, 0x36DFAC, "description_text_3"),
    (0x36E1D0, 0x36EA8C, "operator_names"),
    (0x37CC30, 0x37D7F4, "battle_messages_b1"),
    (0x37DAE0, 0x37E0CC, "battle_messages_b2"),
)

DESCRIPTION_LIST_POOLS: tuple[tuple[int, int], ...] = (
    (0x36B8DE, 0x36BB8A),
    (0x36C7BC, 0x36CA28),
    (0x36D3FC, 0x36D648),
    (0x36DFAC, 0x36E1C8),
)

ALLOWLIST: tuple[dict[str, Any], ...] = (
    {
        "id": "binary_false_positive_29284E",
        "start": 0x29284E,
        "end": 0x292854,
        "bytes_hex": "d50622000280",
        "sha256": "9d8554984169369a0c730954b10003d65c8827dc6c44acb71dd244f3e2f25411",
        "classification": "binary coincidence",
    },
    {
        "id": "binary_false_positive_367160",
        "start": 0x367160,
        "end": 0x36716A,
        "bytes_hex": "00004800ac006f000480",
        "sha256": "ea918fdcf755b302fae8a77ffea2c9c952dc375368bd97133101dd018bba2391",
        "classification": "graphics-adjacent binary coincidence",
    },
)

EXPECTED_COUNTS = {
    "dialogue_groups_0_4": 274,
    "auxiliary_group_5": 88,
    "direct_overwrite_prompt": 1,
    "static_databases": 882,
    "navi_attack_names": 49,
    "participant_names": 73,
    "battle_and_result_messages": 185,
}

JP_PUNCTUATION = frozenset("。、「」『』【】")
RAW_STATIC_CONTROLS = frozenset({0x0200, 0x0201, 0x0202, 0x0203})


class AuditError(RuntimeError):
    """A structural invariant failed."""


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise AuditError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def number(value: int | str) -> int:
    return value if isinstance(value, int) else int(value, 0)


def fmt(value: int) -> str:
    return f"0x{value:06X}"


def path_label(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        try:
            return "../" + path.relative_to(root.parent).as_posix()
        except ValueError:
            return path.name


def is_japanese_character(character: str) -> bool:
    return (
        "\u3040" <= character <= "\u30ff"
        or "\u3400" <= character <= "\u4dbf"
        or "\u4e00" <= character <= "\u9fff"
        or character in JP_PUNCTUATION
    )


def japanese_characters(text: str) -> list[str]:
    return [character for character in text if is_japanese_character(character)]


def heuristic_japanese_characters(text: str) -> list[str]:
    """Return script/CJK glyphs used by the documented whole-ROM heuristic.

    Canonical records use the stricter :func:`japanese_characters`, which also
    rejects Japanese quote/full-stop punctuation.  Binary graphics frequently
    contain two coincidental 0x0090 words (corner patterns that decode as 「),
    so punctuation alone is not sufficient to promote a whole-ROM candidate.
    """

    return [
        character for character in text
        if "\u3040" <= character <= "\u30ff"
        or "\u3400" <= character <= "\u4dbf"
        or "\u4e00" <= character <= "\u9fff"
    ]


def in_span(value: int, spans: Iterable[tuple[int, int]]) -> bool:
    return any(start <= value < end for start, end in spans)


def containing_span(value: int, spans: Iterable[tuple[int, int]]) -> tuple[int, int] | None:
    for start, end in spans:
        if start <= value < end:
            return start, end
    return None


def overlaps_text_pool(start: int, end: int) -> list[str]:
    return [name for pool_start, pool_end, name in TEXT_POOLS if max(start, pool_start) < min(end, pool_end)]


def decode_dynamic_word(word: int, decode: dict[int, str], n1tool: Any) -> str:
    return n1tool.token_for(word, decode)


def decode_static_word(word: int, decode: dict[int, str]) -> str:
    if word in RAW_STATIC_CONTROLS:
        return f"[RAW:{word:04X}]"
    base = word & 0x01FF
    token = decode.get(base, "")
    return token if token else f"[RAW:{word:04X}]"


@dataclass(frozen=True)
class ParsedRecord:
    start: int
    end: int
    words: tuple[int, ...]
    terminator: int
    text: str
    japanese: tuple[str, ...]
    raw_words: tuple[int, ...]

    def summary(self) -> dict[str, Any]:
        return {
            "start": fmt(self.start),
            "end": fmt(self.end),
            "bytes": self.end - self.start,
            "payload_words": len(self.words) - 1,
            "terminator": f"0x{self.terminator:04X}",
            "japanese_glyphs": len(self.japanese),
            "raw_words": [f"0x{word:04X}" for word in self.raw_words],
            "text": self.text,
        }


def read_dynamic_record(
    data: bytes,
    start: int,
    limit: int,
    label: str,
    decode: dict[int, str],
    n1tool: Any,
) -> ParsedRecord:
    if start % 2:
        raise AuditError(f"{label}: odd target {fmt(start)}")
    if not 0 <= start < limit <= len(data):
        raise AuditError(f"{label}: target/limit outside ROM ({fmt(start)}..{fmt(limit)})")
    words: list[int] = []
    raw: list[int] = []
    text_parts: list[str] = []
    cursor = start
    while cursor + 2 <= limit:
        word = struct.unpack_from("<H", data, cursor)[0]
        words.append(word)
        token = decode_dynamic_word(word, decode, n1tool)
        text_parts.append(token)
        if token.startswith("[RAW:"):
            raw.append(word)
        cursor += 2
        if word == 0x8000:
            text = "".join(text_parts)
            return ParsedRecord(
                start, cursor, tuple(words), word, text,
                tuple(japanese_characters(text)), tuple(raw),
            )
    raise AuditError(f"{label}: no exact 0x8000 terminator before {fmt(limit)}")


def read_static_record(
    data: bytes,
    start: int,
    limit: int,
    label: str,
    decode: dict[int, str],
) -> ParsedRecord:
    if start % 2:
        raise AuditError(f"{label}: odd target {fmt(start)}")
    if not 0 <= start < limit <= len(data):
        raise AuditError(f"{label}: target/limit outside ROM ({fmt(start)}..{fmt(limit)})")
    words: list[int] = []
    raw: list[int] = []
    text_parts: list[str] = []
    cursor = start
    for payload_count in range(256):
        if cursor + 2 > limit:
            raise AuditError(f"{label}: record crosses verified region ending {fmt(limit)}")
        word = struct.unpack_from("<H", data, cursor)[0]
        words.append(word)
        cursor += 2
        high_byte = word & 0xFF00
        if high_byte in (0x8000, 0xC000):
            if (word & 0xFF) != payload_count:
                raise AuditError(
                    f"{label}: terminator length {word & 0xFF} != payload {payload_count}"
                )
            text = "".join(text_parts)
            return ParsedRecord(
                start, cursor, tuple(words), word, text,
                tuple(japanese_characters(text)), tuple(raw),
            )
        if word & 0x8000:
            raise AuditError(f"{label}: invalid terminator word 0x{word:04X}")
        token = decode_static_word(word, decode)
        text_parts.append(token)
        if token.startswith("[RAW:"):
            raw.append(word)
    raise AuditError(f"{label}: no valid terminator within 256 words")


def far_target(data: bytes, table: int, index: int, label: str) -> int | None:
    entry = table + index * 4
    if entry < 0 or entry + 4 > len(data):
        raise AuditError(f"{label}[{index}]: pointer entry outside ROM")
    offset, segment = struct.unpack_from("<HH", data, entry)
    if offset == segment == 0:
        return None
    target = 0x300000 + segment * 16 + offset
    if not 0 <= target < len(data):
        raise AuditError(
            f"{label}[{index}]: far pointer {segment:04X}:{offset:04X} -> {fmt(target)} outside ROM"
        )
    if target % 2:
        raise AuditError(f"{label}[{index}]: odd far target {fmt(target)}")
    return target


def relative_target(data: bytes, group: Any, index: int, label: str) -> int | None:
    entry = group.pointer_table + index * 2
    if entry < 0 or entry + 2 > len(data):
        raise AuditError(f"{label}[{index}]: pointer entry outside ROM")
    relative = struct.unpack_from("<H", data, entry)[0]
    target = group.base + relative * 2
    if not group.base <= target < group.end:
        return None
    if target % 2:
        raise AuditError(f"{label}[{index}]: odd relative target {fmt(target)}")
    return target


def record_item(
    record_id: str,
    corpus: str,
    source_targets: Iterable[int],
    built_records: Iterable[ParsedRecord],
    pointer_ids: Iterable[str],
    logical_row: int | None = None,
) -> dict[str, Any]:
    records = list(built_records)
    jp = sum(len(record.japanese) for record in records)
    result: dict[str, Any] = {
        "id": record_id,
        "corpus": corpus,
        "source_targets": [fmt(target) for target in sorted(set(source_targets))],
        "pointer_ids": sorted(set(pointer_ids)),
        "built_targets": [fmt(record.start) for record in records],
        "built_records": [record.summary() for record in records],
        "remaining_japanese_glyphs": jp,
        "result": "PASS" if jp == 0 else "FAIL",
    }
    if logical_row is not None:
        result["logical_row"] = logical_row
    return result


def grouped_relative_targets(data: bytes, group: Any, label: str) -> tuple[dict[int, list[int]], list[bool]]:
    grouped: dict[int, list[int]] = {}
    validity: list[bool] = []
    for index in range(group.pointer_count):
        target = relative_target(data, group, index, label)
        validity.append(target is not None)
        if target is not None:
            grouped.setdefault(target, []).append(index)
    return grouped, validity


def audit_relative_corpora(
    source: bytes,
    built: bytes,
    decode: dict[int, str],
    n1tool: Any,
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
    pointer_stats: dict[str, int],
) -> None:
    dialogue_count = 0
    auxiliary_count = 0
    for group in n1tool.TEXT_GROUPS:
        source_targets, source_valid = grouped_relative_targets(source, group, f"source_group_{group.index}")
        built_targets, built_valid = grouped_relative_targets(built, group, f"built_group_{group.index}")
        if source_valid != built_valid:
            raise AuditError(f"group {group.index}: valid/invalid pointer-slot pattern changed")
        pointer_stats["relative_slots"] += group.pointer_count
        pointer_stats["relative_valid_slots"] += sum(built_valid)

        # Validate every live output target, including the 82 auxiliary targets
        # that are not Japanese logical units in the source-derived metric.
        parsed_by_target: dict[int, ParsedRecord] = {}
        for target in built_targets:
            parsed = read_dynamic_record(
                built, target, group.end, f"group_{group.index}@{fmt(target)}", decode, n1tool
            )
            parsed_by_target[target] = parsed
            canonical_targets.add(target)
            canonical_spans.add((parsed.start, parsed.end))

        if group.index <= 4:
            for source_target, slots in sorted(source_targets.items()):
                source_record = read_dynamic_record(
                    source, source_target, group.end,
                    f"source_group_{group.index}@{fmt(source_target)}", decode, n1tool,
                )
                if not source_record.japanese:
                    raise AuditError(
                        f"dialogue source target {fmt(source_target)} unexpectedly has no Japanese"
                    )
                output_targets = sorted({
                    relative_target(built, group, slot, f"built_group_{group.index}")
                    for slot in slots
                })
                if any(target is None for target in output_targets):
                    raise AuditError(f"group {group.index}: source-live slot became invalid")
                built_records = [parsed_by_target[int(target)] for target in output_targets]
                records.append(record_item(
                    f"dialogue:{group.index}:{source_target:06X}",
                    "dialogue_groups_0_4", [source_target], built_records,
                    [f"{group.index:02X}:{slot:02X}" for slot in slots],
                ))
                dialogue_count += 1
        else:
            for source_target, slots in sorted(source_targets.items()):
                source_record = read_dynamic_record(
                    source, source_target, group.end,
                    f"source_group_5@{fmt(source_target)}", decode, n1tool,
                )
                if not source_record.japanese:
                    continue
                output_targets = sorted({
                    relative_target(built, group, slot, "built_group_5") for slot in slots
                })
                if any(target is None for target in output_targets):
                    raise AuditError("group 5: Japanese source-live slot became invalid")
                built_records = [parsed_by_target[int(target)] for target in output_targets]
                records.append(record_item(
                    f"auxiliary:{source_target:06X}", "auxiliary_group_5",
                    [source_target], built_records,
                    [f"05:{slot:02X}" for slot in slots],
                ))
                auxiliary_count += 1

    if dialogue_count != EXPECTED_COUNTS["dialogue_groups_0_4"]:
        raise AuditError(f"dialogue logical count {dialogue_count} != 274")
    if auxiliary_count != EXPECTED_COUNTS["auxiliary_group_5"]:
        raise AuditError(f"auxiliary Japanese logical count {auxiliary_count} != 88")


def audit_direct_prompt(
    built: bytes,
    decode: dict[int, str],
    n1tool: Any,
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
) -> None:
    start, limit = 0x3578AE, 0x3578E8
    parsed = read_dynamic_record(built, start, limit, "direct_overwrite_prompt", decode, n1tool)
    canonical_targets.add(start)
    canonical_spans.add((parsed.start, parsed.end))
    records.append(record_item(
        "direct:overwrite_prompt", "direct_overwrite_prompt", [start], [parsed], [], 0
    ))


def audit_far_table(
    built: bytes,
    layout: Any,
    corpus: str,
    decode: dict[int, str],
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
    pointer_stats: dict[str, int],
) -> None:
    for index in range(layout.count):
        target = far_target(built, layout.pointer_start, index, layout.name)
        pointer_stats["far_slots"] += 1
        if target is None:
            raise AuditError(f"{layout.name}[{index}]: unexpected null pointer")
        if not layout.data_start <= target < layout.data_end:
            raise AuditError(
                f"{layout.name}[{index}]: {fmt(target)} outside {fmt(layout.data_start)}..{fmt(layout.data_end)}"
            )
        parsed = read_static_record(
            built, target, layout.data_end, f"{layout.name}[{index}]", decode
        )
        canonical_targets.add(target)
        canonical_spans.add((parsed.start, parsed.end))
        records.append(record_item(
            f"{layout.name}:{index:03d}", corpus, [target], [parsed],
            [f"{fmt(layout.pointer_start + index * 4)}"], index,
        ))


def audit_descriptions(
    built: bytes,
    bcc: Any,
    decode: dict[int, str],
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
    pointer_stats: dict[str, int],
) -> None:
    text_spans = tuple(bcc.DESCRIPTION_TEXT_POOLS)
    list_spans = tuple(bcc.DESCRIPTION_LIST_POOLS)
    for row in range(bcc.DESCRIPTION_COUNT):
        list_target = far_target(
            built, bcc.DESCRIPTION_OUTER_POINTERS, row, "chip_descriptions_outer"
        )
        pointer_stats["far_slots"] += 1
        if list_target is None:
            raise AuditError(f"chip_descriptions[{row}]: null outer pointer")
        list_span = containing_span(list_target, list_spans)
        if list_span is None:
            raise AuditError(
                f"chip_descriptions[{row}]: list {fmt(list_target)} outside verified list pools"
            )
        parsed_lines: list[ParsedRecord] = []
        pointer_ids: list[str] = [fmt(bcc.DESCRIPTION_OUTER_POINTERS + row * 4)]
        for line in range(16):
            entry = list_target + line * 4
            if entry + 4 > list_span[1]:
                raise AuditError(f"chip_descriptions[{row}]: list crosses pool")
            offset, segment = struct.unpack_from("<HH", built, entry)
            pointer_stats["description_line_slots"] += 1
            if offset == segment == 0:
                if not parsed_lines:
                    raise AuditError(f"chip_descriptions[{row}]: empty row")
                break
            target = 0x300000 + segment * 16 + offset
            if target % 2:
                raise AuditError(f"chip_descriptions[{row}][{line}]: odd target")
            text_span = containing_span(target, text_spans)
            if text_span is None:
                raise AuditError(
                    f"chip_descriptions[{row}][{line}]: {fmt(target)} outside text pools"
                )
            parsed = read_static_record(
                built, target, text_span[1], f"chip_descriptions[{row}][{line}]", decode
            )
            parsed_lines.append(parsed)
            pointer_ids.append(fmt(entry))
            canonical_targets.add(target)
            canonical_spans.add((parsed.start, parsed.end))
        else:
            raise AuditError(f"chip_descriptions[{row}]: no null sentinel in 16 slots")
        records.append(record_item(
            f"chip_descriptions:{row:03d}", "static_databases",
            [line.start for line in parsed_lines], parsed_lines, pointer_ids, row,
        ))


def audit_participants(
    source: bytes,
    built: bytes,
    decode: dict[int, str],
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
    pointer_stats: dict[str, int],
) -> None:
    pointer_start, count = 0x367AEA, 73
    data_start, data_end = 0x367660, 0x367AEA
    for index in range(count):
        source_target = far_target(source, pointer_start, index, "participant_source")
        built_target = far_target(built, pointer_start, index, "participant_built")
        pointer_stats["far_slots"] += 1
        if source_target is None or built_target is None:
            raise AuditError(f"participant[{index}]: unexpected null pointer")
        if not data_start <= source_target < data_end or not data_start <= built_target < data_end:
            raise AuditError(f"participant[{index}]: pointer outside verified data span")
        source_record = read_static_record(
            source, source_target, data_end, f"participant_source[{index}]", decode
        )
        if not source_record.japanese:
            raise AuditError(f"participant_source[{index}] unexpectedly has no Japanese")
        parsed = read_static_record(
            built, built_target, data_end, f"participant_built[{index}]", decode
        )
        canonical_targets.add(built_target)
        canonical_spans.add((parsed.start, parsed.end))
        records.append(record_item(
            f"participant:{index:03d}", "participant_names", [source_target], [parsed],
            [fmt(pointer_start + index * 4)], index,
        ))


def audit_battle_messages(
    source: bytes,
    built: bytes,
    decode: dict[int, str],
    records: list[dict[str, Any]],
    canonical_targets: set[int],
    canonical_spans: set[tuple[int, int]],
    pointer_stats: dict[str, int],
) -> None:
    layouts = (
        ("B1", 0x37CC30, 0x37D7F4, 0x37D7F4, 187),
        ("B2", 0x37DAE0, 0x37E0CC, 0x37E0CC, 92),
    )
    logical = 0
    for bank, data_start, data_end, pointer_start, count in layouts:
        source_groups: dict[int, list[int]] = {}
        built_by_slot: dict[int, ParsedRecord] = {}
        for index in range(count):
            source_target = far_target(source, pointer_start, index, f"{bank}_source")
            built_target = far_target(built, pointer_start, index, f"{bank}_built")
            pointer_stats["far_slots"] += 1
            if (source_target is None) != (built_target is None):
                raise AuditError(f"{bank}[{index}]: null/non-null pattern changed")
            if source_target is None:
                continue
            if not data_start <= source_target < data_end:
                raise AuditError(f"{bank}_source[{index}]: target outside bank")
            if built_target is None or not data_start <= built_target < data_end:
                raise AuditError(f"{bank}_built[{index}]: target outside bank")
            source_groups.setdefault(source_target, []).append(index)
            parsed = read_static_record(
                built, built_target, data_end, f"{bank}_built[{index}]", decode
            )
            built_by_slot[index] = parsed
            canonical_targets.add(built_target)
            canonical_spans.add((parsed.start, parsed.end))

        for source_target, slots in sorted(source_groups.items()):
            source_record = read_static_record(
                source, source_target, data_end, f"{bank}_source@{fmt(source_target)}", decode
            )
            if not source_record.japanese:
                continue
            output_records_by_target = {
                built_by_slot[slot].start: built_by_slot[slot] for slot in slots
            }
            records.append(record_item(
                f"battle:{bank}:{source_target:06X}", "battle_and_result_messages",
                [source_target], output_records_by_target.values(),
                [f"{bank}:{slot:03d}" for slot in slots],
            ))
            logical += 1
    if logical != EXPECTED_COUNTS["battle_and_result_messages"]:
        raise AuditError(f"battle Japanese logical count {logical} != 185")


def is_dynamic_scan_word(word: int, decode: dict[int, str]) -> bool:
    return (
        word in (0x0800, 0x4000)
        or 0x0900 <= word <= 0x09FF
        or bool(decode.get(word, ""))
    )


def scan_dynamic_candidates(data: bytes, decode: dict[int, str]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for start in range(0, len(data) - 4, 2):
        japanese = 0
        for count in range(256):
            cursor = start + count * 2
            if cursor + 2 > len(data):
                break
            word = struct.unpack_from("<H", data, cursor)[0]
            if word == 0x8000:
                if japanese >= 2:
                    end = cursor + 2
                    payload = data[start:end]
                    candidates.append({
                        "kind": "dynamic_8000",
                        "start": start,
                        "end": end,
                        "payload_words": count,
                        "japanese_glyphs": japanese,
                        "bytes_hex": payload.hex(),
                        "sha256": sha256(payload),
                    })
                break
            if not is_dynamic_scan_word(word, decode):
                break
            japanese += len(heuristic_japanese_characters(decode.get(word, "")))
    return candidates


def scan_static_candidates(data: bytes, decode: dict[int, str]) -> list[dict[str, Any]]:
    candidates: list[dict[str, Any]] = []
    for start in range(0, len(data) - 4, 2):
        japanese = 0
        for count in range(256):
            cursor = start + count * 2
            if cursor + 2 > len(data):
                break
            word = struct.unpack_from("<H", data, cursor)[0]
            high_byte = word & 0xFF00
            if high_byte in (0x8000, 0xC000):
                if (word & 0xFF) == count and japanese >= 2:
                    end = cursor + 2
                    payload = data[start:end]
                    candidates.append({
                        "kind": "static_80LL" if high_byte == 0x8000 else "static_C0LL",
                        "start": start,
                        "end": end,
                        "payload_words": count,
                        "japanese_glyphs": japanese,
                        "bytes_hex": payload.hex(),
                        "sha256": sha256(payload),
                    })
                break
            # Verified Japanese static strings use the normal (0x00) or
            # emphasized (0x06) style byte.  0x01 is part of glyph code 0x100,
            # but that code is Latin 'v' and cannot increase the JP count.
            if (word >> 8) not in (0x00, 0x06):
                break
            base = word & 0x01FF
            token = decode.get(base, "")
            if not token:
                break
            japanese += len(heuristic_japanese_characters(token))
    return candidates


def candidate_public(candidate: dict[str, Any]) -> dict[str, Any]:
    return {
        **{key: value for key, value in candidate.items() if key not in ("start", "end")},
        "start": fmt(candidate["start"]),
        "end": fmt(candidate["end"]),
        "length": candidate["end"] - candidate["start"],
    }


def audit_heuristic_scan(
    built: bytes,
    decode: dict[int, str],
    canonical_targets: set[int],
) -> dict[str, Any]:
    dynamic = scan_dynamic_candidates(built, decode)
    static = scan_static_candidates(built, decode)
    candidates = sorted(
        [*dynamic, *static], key=lambda item: (item["start"], item["end"], item["kind"])
    )
    inside: list[dict[str, Any]] = []
    outside: list[dict[str, Any]] = []
    referenced_hits: list[dict[str, Any]] = []
    for candidate in candidates:
        pools = overlaps_text_pool(candidate["start"], candidate["end"])
        item = {**candidate, "overlapping_verified_text_pools": pools}
        if candidate["start"] in canonical_targets:
            referenced_hits.append(item)
        if pools:
            inside.append(item)
        else:
            outside.append(item)

    allowlist_matches: list[dict[str, Any]] = []
    unexpected = list(outside)
    missing_allowlist: list[dict[str, Any]] = []
    for allowed in ALLOWLIST:
        matches = [
            candidate for candidate in unexpected
            if candidate["start"] == allowed["start"]
            and candidate["end"] == allowed["end"]
            and candidate["bytes_hex"] == allowed["bytes_hex"]
            and candidate["sha256"] == allowed["sha256"]
        ]
        span = built[allowed["start"]:allowed["end"]]
        exact_span = (
            span.hex() == allowed["bytes_hex"] and sha256(span) == allowed["sha256"]
        )
        if len(matches) == 1 and exact_span:
            match = matches[0]
            allowlist_matches.append({
                "id": allowed["id"],
                "classification": allowed["classification"],
                **candidate_public(match),
                "exact_span_match": True,
            })
            unexpected.remove(match)
        else:
            missing_allowlist.append({
                "id": allowed["id"],
                "detected_matches": len(matches),
                "exact_span_match": exact_span,
            })

    digest_payload = json.dumps(
        [
            {
                "kind": item["kind"], "start": item["start"], "end": item["end"],
                "japanese_glyphs": item["japanese_glyphs"], "sha256": item["sha256"],
            }
            for item in candidates
        ],
        sort_keys=True, separators=(",", ":"),
    ).encode("utf-8")
    result = not referenced_hits and not unexpected and not missing_allowlist
    return {
        "result": "PASS" if result else "FAIL",
        "scope": "all even ROM offsets; encoded-text heuristic only; graphical text excluded",
        "algorithm": {
            "dynamic": "exact known 16-bit glyph/control words through exact 0x8000; at least two decoded Japanese glyphs",
            "static": "style byte 0x00/0x06 through exact 0x80LL/0xC0LL with LL equal to payload length; at least two decoded Japanese glyphs",
            "classification": "candidates overlapping verified text pools are checked for canonical target reachability; every outside-pool candidate requires an exact fixed allowlist match",
        },
        "even_offsets_scanned": ROM_SIZE // 2,
        "raw_candidates": len(candidates),
        "dynamic_candidates": len(dynamic),
        "static_candidates": len(static),
        "candidate_inventory_sha256": sha256(digest_payload),
        "inside_verified_text_pools": len(inside),
        "inside_pool_canonical_target_hits": len(referenced_hits),
        "inside_pool_canonical_target_hit_examples": [candidate_public(x) for x in referenced_hits[:20]],
        "outside_verified_text_pools": len(outside),
        "allowlist_policy": "exact start, end, bytes and SHA-256; relocation or mutation fails",
        "allowlist_matches": allowlist_matches,
        "missing_or_mutated_allowlist": missing_allowlist,
        "unexpected_outside_pool_candidates": [candidate_public(x) for x in unexpected],
        "note": "Japanese-looking bytes left in unused portions of verified pools are not live targets; every canonical current pointer target is independently enumerated above.",
    }


def check_result(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def build_manifest_identity(
    source: bytes,
    built: bytes,
    manifest_path: Path,
    manifest: dict[str, Any],
    encode: dict[str, int],
    n1tool: Any,
) -> dict[str, Any]:
    manifest_bytes = manifest_path.read_bytes()
    header_ok = (
        manifest.get("format") == "n1battle-inplace-translation-v1"
        and manifest.get("project_version") == "0.10.1"
        and manifest.get("source_sha256") == SOURCE_SHA256
        and manifest.get("expanded_inventory", {}).get("text_units", {}).get("denominator") == TEXT_DENOMINATOR
    )
    asset_checks: list[dict[str, Any]] = []
    for entry in manifest.get("binary_entries", []):
        start = number(entry["offset"])
        length = number(entry["length"])
        asset_path = (manifest_path.parent / str(entry.get("asset", ""))).resolve()
        try:
            asset_path.relative_to(manifest_path.parent.resolve())
        except ValueError as exc:
            raise AuditError(f"{entry.get('id')}: asset path escapes manifest directory") from exc
        asset = asset_path.read_bytes()
        expected = str(entry.get("asset_sha256", "")).lower()
        item = {
            "id": str(entry.get("id", "")),
            "length_ok": len(asset) == length,
            "hash_declared": bool(expected),
            "hash_ok": bool(expected) and sha256(asset) == expected,
            "build_span_match": built[start:start + length] == asset,
        }
        asset_checks.append(item)
    assets_ok = bool(asset_checks) and all(
        item["length_ok"] and item["hash_declared"] and item["hash_ok"]
        and item["build_span_match"] for item in asset_checks
    )
    rebuilt, entries = n1tool.patch_entries(source, manifest, encode, manifest_path.parent)
    identical = rebuilt == built
    return check_result(
        header_ok and assets_ok and identical,
        manifest_header_valid=header_ok,
        manifest_sha256=sha256(manifest_bytes),
        manifest_text_entries=len(manifest.get("entries", [])),
        manifest_binary_entries=len(manifest.get("binary_entries", [])),
        rebuild_report_entries=len(entries),
        binary_assets_checked=len(asset_checks),
        binary_asset_failures=[
            item for item in asset_checks
            if not (
                item["length_ok"] and item["hash_declared"] and item["hash_ok"]
                and item["build_span_match"]
            )
        ],
        canonical_rebuild_byte_identical=identical,
        built_sha256=sha256(built),
        canonical_rebuild_sha256=sha256(rebuilt),
    )


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project-root", type=Path,
        default=Path(__file__).resolve().parent.parent,
        help="project root (default: parent of tools/)",
    )
    parser.add_argument("--source-rom", type=Path, help="verified Japanese Rev 1 ROM")
    parser.add_argument("--built-rom", type=Path, help="v0.10.1 translated ROM")
    parser.add_argument("--manifest", type=Path, help="v0.10.1 translation manifest")
    parser.add_argument("--report", type=Path, help="JSON report destination")
    parser.add_argument(
        "--expected-build-sha256",
        help="optional additional build-hash pin; canonical manifest rebuild is always required",
    )
    args = parser.parse_args()

    root = args.project_root.resolve()
    source_path = (args.source_rom or root.parent / "rom/Rockman EXE - N1 Battle (Japan).wsc").resolve()
    built_path = (args.built_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.1.wsc").resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_10_1.json").resolve()
    report_path = (args.report or root / "docs/RESIDUAL_TEXT_SCAN_v0_10_1.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-residual-encoded-text-scan-v1",
        "project_version": "0.10.1",
        "report_date": REPORT_DATE,
        "overall_result": "FAIL",
        "scope": {
            "included": "encoded user-facing text reachable through the verified pointer/direct-record layouts",
            "excluded": "tile/tilemap graphics and gameplay-route execution",
            "publication_rule": "A PASS supports 1552/1552 encoded-text units only; it is not a claim about graphical text.",
        },
        "checks": {},
        "inventory": {},
        "pointer_safety": {},
        "heuristic_scan": {},
        "records": [],
        "failures": [],
    }

    try:
        source = source_path.read_bytes()
        built = built_path.read_bytes()
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        n1tool = load_module("n1tool_residual_audit_v09", root / "tools/n1tool.py")
        bcc = load_module("bcc_residual_audit_v09", root / "tools/bcc_reference.py")
        decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")

        source_ok = len(source) == ROM_SIZE and sha256(source) == SOURCE_SHA256
        report["checks"]["source_identity"] = check_result(
            source_ok, path=path_label(source_path, root), size=len(source), sha256=sha256(source),
            expected_size=ROM_SIZE, expected_sha256=SOURCE_SHA256,
        )
        if not source_ok:
            raise AuditError("source ROM identity failed")

        build_size_ok = len(built) == ROM_SIZE
        actual_build_hash = sha256(built)
        expected_hash_ok = (
            args.expected_build_sha256 is None
            or actual_build_hash == args.expected_build_sha256.lower()
        )
        report["checks"]["build_size_and_optional_hash"] = check_result(
            build_size_ok and expected_hash_ok,
            path=path_label(built_path, root), size=len(built), expected_size=ROM_SIZE,
            sha256=actual_build_hash,
            expected_sha256=args.expected_build_sha256,
        )
        if not build_size_ok:
            raise AuditError("build size failed")

        manifest_identity = build_manifest_identity(
            source, built, manifest_path, manifest, encode, n1tool
        )
        report["checks"]["canonical_manifest_build_identity"] = manifest_identity
        if manifest_identity["result"] != "PASS":
            raise AuditError("built ROM is not the canonical source+manifest rebuild")

        stored = int.from_bytes(built[-2:], "little")
        calculated = sum(built[:-2]) & 0xFFFF
        footer_identity = built[-10:-2] == source[-10:-2]
        report["checks"]["wonderswan_identity_and_checksum"] = check_result(
            stored == calculated and footer_identity,
            footer_identity_bytes_match_source=footer_identity,
            footer_identity_hex=built[-10:-2].hex().upper(),
            stored_checksum=f"0x{stored:04X}", calculated_checksum=f"0x{calculated:04X}",
        )

        records: list[dict[str, Any]] = []
        canonical_targets: set[int] = set()
        canonical_spans: set[tuple[int, int]] = set()
        pointer_stats = {
            "relative_slots": 0,
            "relative_valid_slots": 0,
            "far_slots": 0,
            "description_line_slots": 0,
            "out_of_bounds": 0,
            "odd_targets": 0,
            "unterminated": 0,
            "length_mismatches": 0,
        }

        audit_relative_corpora(
            source, built, decode, n1tool, records, canonical_targets,
            canonical_spans, pointer_stats,
        )
        audit_direct_prompt(
            built, decode, n1tool, records, canonical_targets, canonical_spans
        )
        audit_far_table(
            built, bcc.CHIP_NAMES, "static_databases", decode, records,
            canonical_targets, canonical_spans, pointer_stats,
        )
        audit_far_table(
            built, bcc.EFFECT_LABELS, "static_databases", decode, records,
            canonical_targets, canonical_spans, pointer_stats,
        )
        audit_descriptions(
            built, bcc, decode, records, canonical_targets, canonical_spans, pointer_stats
        )
        audit_far_table(
            built, bcc.OPERATOR_NAMES, "static_databases", decode, records,
            canonical_targets, canonical_spans, pointer_stats,
        )
        audit_far_table(
            built, bcc.NAVI_ATTACK_NAMES, "navi_attack_names", decode, records,
            canonical_targets, canonical_spans, pointer_stats,
        )
        audit_participants(
            source, built, decode, records, canonical_targets, canonical_spans, pointer_stats
        )
        audit_battle_messages(
            source, built, decode, records, canonical_targets, canonical_spans, pointer_stats
        )

        by_corpus: dict[str, int] = {}
        residual_records: list[dict[str, Any]] = []
        for item in records:
            by_corpus[item["corpus"]] = by_corpus.get(item["corpus"], 0) + 1
            if item["result"] != "PASS":
                residual_records.append(item)
        count_ok = len(records) == TEXT_DENOMINATOR and by_corpus == EXPECTED_COUNTS
        residual_glyphs = sum(item["remaining_japanese_glyphs"] for item in records)
        residual_ok = not residual_records and residual_glyphs == 0
        report["checks"]["authoritative_inventory"] = check_result(
            count_ok,
            enumerated_records=len(records), denominator=TEXT_DENOMINATOR,
            formula_components=by_corpus,
            expected_formula_components=EXPECTED_COUNTS,
        )
        report["checks"]["authoritative_referenced_japanese"] = check_result(
            residual_ok,
            referenced_japanese_targets=len(residual_records),
            referenced_japanese_glyphs=residual_glyphs,
            examples=[{
                "id": item["id"],
                "built_targets": item["built_targets"],
                "remaining_japanese_glyphs": item["remaining_japanese_glyphs"],
            } for item in residual_records[:20]],
        )
        report["pointer_safety"] = {
            "result": "PASS",
            **pointer_stats,
            "canonical_current_targets": len(canonical_targets),
            "canonical_terminated_spans": len(canonical_spans),
            "invariant": "Every enumerated slot/target passed its verified region, alignment, terminator and LL checks; an exception would fail the report.",
        }

        heuristic = audit_heuristic_scan(built, decode, canonical_targets)
        report["heuristic_scan"] = heuristic
        report["checks"]["whole_rom_heuristic"] = check_result(
            heuristic["result"] == "PASS",
            raw_candidates=heuristic["raw_candidates"],
            inside_pool_canonical_target_hits=heuristic["inside_pool_canonical_target_hits"],
            outside_pool_candidates=heuristic["outside_verified_text_pools"],
            exact_allowlist_matches=len(heuristic["allowlist_matches"]),
            unexpected_candidates=len(heuristic["unexpected_outside_pool_candidates"]),
            missing_or_mutated_allowlist=len(heuristic["missing_or_mutated_allowlist"]),
        )

        report["inventory"] = {
            "metric": "encoded_user_facing_text_coverage",
            "translated": len(records) - len(residual_records),
            "denominator": TEXT_DENOMINATOR,
            "remaining_japanese_targets": len(residual_records),
            "percent": round((len(records) - len(residual_records)) / TEXT_DENOMINATOR * 100, 2),
            "formula": "274 + 88 + 1 + 882 + 49 + 73 + 185 = 1552",
            "components": by_corpus,
        }
        report["records"] = records

    except BaseException as exc:
        report["failures"].append(f"{type(exc).__name__}: {exc}")

    failed_checks = [
        name for name, check in report["checks"].items()
        if isinstance(check, dict) and check.get("result") == "FAIL"
    ]
    if report.get("pointer_safety", {}).get("result") == "FAIL":
        failed_checks.append("pointer_safety")
    if report.get("heuristic_scan", {}).get("result") == "FAIL" and "whole_rom_heuristic" not in failed_checks:
        failed_checks.append("whole_rom_heuristic")
    report["failed_checks"] = failed_checks
    report["overall_result"] = (
        "PASS" if not failed_checks and not report["failures"]
        and len(report["records"]) == TEXT_DENOMINATOR else "FAIL"
    )

    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    summary = {
        "overall_result": report["overall_result"],
        "failed_checks": failed_checks,
        "failures": report["failures"],
        "inventory": report.get("inventory"),
        "heuristic": report.get("checks", {}).get("whole_rom_heuristic"),
        "build_sha256": report.get("checks", {}).get("build_size_and_optional_hash", {}).get("sha256"),
        "report": str(report_path),
        "report_sha256": sha256(rendered.encode("utf-8")),
    }
    print(json.dumps(summary, ensure_ascii=False, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
