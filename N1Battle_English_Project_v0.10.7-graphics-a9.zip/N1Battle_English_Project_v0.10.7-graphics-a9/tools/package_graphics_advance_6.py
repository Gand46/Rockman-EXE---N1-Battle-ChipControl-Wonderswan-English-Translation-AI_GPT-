#!/usr/bin/env python3
"""Create the deterministic ROM-free cumulative Graphics Advance 6 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
import zipfile
from pathlib import Path, PurePosixPath


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import package_graphics_advance_5 as a5  # noqa: E402
import package_release_v0_10_7_rc4 as rc4  # noqa: E402


VERSION = "0.10.7-graphics-a6"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.7-graphics-a6"
# Preserve the established project epoch used by RC4 and every prior advance.
FIXED_TIME = (2026, 8, 24, 0, 0, 0)
ROM_SHA256 = "9b135e34db6b20d8135c79476bd72a7118500e176ee8f5eee3c0c99fe3bb333b"
IPS_SHA256 = "05e449483f5ee665688e60548b1d06d458c689e572e5e5801bd259cc8925cb0a"


ADVANCE_FILES = {
    "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a6.ips",
    "translation/en_v0_10_7_graphics_a6.json",
    "translation/graphics_advance_rules.json",
    "translation/assets/backpack_quantity_callsite_graphics_a6.bin",
    "translation/assets/backpack_quantity_superscript_graphics_a6.bin",
    "translation/assets/battle_messages_b1_data_graphics_a6.bin",
    "translation/assets/graphics_advance_6_backpack_quantity_report.json",
    "translation/assets/graphics_advance_6_quantity_preview.png",
    "build/build_v0_10_7_graphics_a6.json",
    "build/graphics_advance_rules_validation.json",
    "docs/GRAPHICS_ADVANCE_6.md",
    "docs/GRAPHICS_ADVANCE_RULES.md",
    "docs/runtime_graphics_advances/advance_6_gate_final/graphics_advance_6_runtime_validation.json",
    "docs/runtime_graphics_advances/advance_6_gate_final/a5/backpack_populated_3660.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a5/backpack_scrolled_3900.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a5/backpack_empty_3660.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a5/chip_folder_3500.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/backpack_populated_3660.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/backpack_scrolled_3900.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/backpack_empty_3660.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/chip_folder_3500.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/backpack_digits_0_6_3660.png",
    "docs/runtime_graphics_advances/advance_6_gate_final/a6/backpack_digits_7_255_3660.png",
    "tools/backpack_quantity_callsite.s",
    "tools/backpack_quantity_superscript.s",
    "tools/graphics_advance_6_backpack_quantity.py",
    "tools/compose_graphics_advance_6_manifest.py",
    "tools/make_graphics_advance_6_backpack_save.py",
    "tools/make_graphics_advance_6_probe_save.py",
    "tools/mesen_core_probe_graphics_advance_6.py",
    "tools/validate_graphics_advance_rules_a6.py",
    "tools/package_graphics_advance_6.py",
    "tests/test_graphics_advance_6_backpack_quantity.py",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def required(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def collect(root: Path) -> list[Path]:
    files = set(a5.collect(root))
    files.update(required(root, relative) for relative in ADVANCE_FILES)
    manifest = json.loads(required(root, "translation/en_v0_10_7_graphics_a6.json").read_text(encoding="utf-8"))
    if manifest.get("project_version") != VERSION:
        raise ValueError("unexpected Graphics Advance 6 manifest")
    for entry in manifest.get("binary_entries", []):
        relative = PurePosixPath("translation") / str(entry["asset"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"unsafe manifest asset: {relative}")
        path = required(root, relative.as_posix())
        payload = path.read_bytes()
        if len(payload) != int(entry["length"]) or sha256(payload) != entry["asset_sha256"]:
            raise ValueError(f"manifest asset mismatch: {relative}")
        files.add(path)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def validate_file(root: Path, path: Path) -> dict[str, object]:
    info = rc4.validate_file(root, path)
    relative = path.relative_to(root).as_posix()
    if relative.endswith("v0.10.7-graphics-a6.ips") and sha256(path.read_bytes()) != IPS_SHA256:
        raise ValueError("unexpected cumulative Graphics Advance 6 IPS")
    return info


def validate_archive(path: Path) -> None:
    rc4.validate_archive(path)
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        expected = {f"{PACKAGE_ROOT}/{relative}" for relative in ADVANCE_FILES}
        missing = sorted(expected - names)
        if missing:
            raise ValueError(f"missing Graphics Advance 6 files: {missing}")
        forbidden = (".wsc", ".ws", ".ttf", ".sav", ".state", ".mss", ".ieeprom")
        if any(name.lower().endswith(forbidden) for name in names):
            raise ValueError("archive contains private runtime content")
        if any(name.lower().endswith((".so", ".dll", ".exe", ".appimage")) for name in names):
            raise ValueError("archive contains emulator binaries")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=ROOT)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    rules = json.loads(required(root, "build/graphics_advance_rules_validation.json").read_text(encoding="utf-8"))
    if rules.get("status") != "PASS" or rules.get("candidate_rom_sha256") != ROM_SHA256 or rules.get("rules_enforced") != 26:
        raise ValueError("cumulative A6 rules validation is not final")
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output = (args.output or root / "dist/N1Battle_English_Project_v0.10.7-graphics-a6.zip").resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside project root")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    validate_archive(output)
    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1", "project_version": VERSION,
        "status": "PASS", "archive": output.name, "archive_size": len(payload),
        "archive_sha256": sha256(payload), "file_count": len(inventory),
        "cumulative_ips_sha256": IPS_SHA256, "validation_rom_sha256": ROM_SHA256,
        "rom_bios_ttf_save_savestate_emulator_files": 0, "rules_enforced": 26,
        "files": inventory,
    }
    output.with_suffix(".release.json").write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    output.with_suffix(output.suffix + ".sha256").write_text(f"{report['archive_sha256']}  {output.name}\n", encoding="ascii")
    print(json.dumps({key: report[key] for key in (
        "status", "archive", "archive_size", "archive_sha256", "file_count",
        "cumulative_ips_sha256", "rom_bios_ttf_save_savestate_emulator_files", "rules_enforced",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
