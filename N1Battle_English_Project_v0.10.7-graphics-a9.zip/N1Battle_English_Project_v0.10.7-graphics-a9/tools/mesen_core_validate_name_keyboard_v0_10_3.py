#!/usr/bin/env python3
"""Validate the corrected v0.10.3 ENTRY NAME keyboard from a clean boot.

The route enters the keyboard without a save or savestate, captures the
initial LOW page, selects CAP, then selects ABC.  Besides native screenshots,
it records complete CPU-memory snapshots and proves that:

* LOW is the coherent initial page (constructor byte 0x00);
* the three English OBJ selector masks reach live tile RAM;
* their transparent letter cut-outs agree with the reviewed BG0 labels;
* the expected six-sprite rectangle is used for each selected page; and
* the v0.9 English keyboard BG0 map and tiles remain byte-identical.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
NATIVE_DISPLAY = (224, 144)

ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
ROM_SIZE = 0x400000

BG_MAP_ROM = 0x0412AA
BG_MAP_RAM = 0x2000
BG_MAP_LENGTH = 0x0480
BG_MAP_SHA256 = "85c718873c336c1d66739f97ce37408b98c0ee85b483145c1f27294df4fe8e3b"

BG_TILES_ROM = 0x074E10
BG_TILES_RAM = 0x8020
BG_TILES_LENGTH = 0x0760
BG_TILES_SHA256 = "516f83ee3eba54416785d81d836e697bfb8036646f06377217ae6994c72a631e"

INITIAL_PAGE_ROM = 0x32B147
INITIAL_PAGE_VALUE = 0x00


@dataclass(frozen=True)
class Page:
    name: str
    capture_frame: int
    mask_rom: int
    mask_ram: int
    mask_sha256: str
    bg_grid: tuple[tuple[int, int, int], tuple[int, int, int]]
    obj_table: bytes
    keyboard_crop_sha256: str


PAGES = (
    Page(
        "low",
        10480,
        0x19A47E,
        0x4180,
        "2d4b9752c5f396dadfd2f05e5ce4182ce7a750c7909d40e841452f1b09a477eb",
        ((0x23, 0x24, 0x25), (0x26, 0x27, 0x28)),
        bytes.fromhex(
            "0c2238c8 0d2240c8 0e2238b8 0f2238c0 102240b8 112240c0"
        ),
        "aafe0c7ca24fb3267087be02082094ddd48ce1947282417c66d04c5c84901141",
    ),
    Page(
        "cap",
        11480,
        0x19A55C,
        0x4240,
        "b1388a7b66111d0f810a1d2b2611a764e4aa5f7178858cb9dc272c3c2f60d078",
        ((0x10, 0x11, 0x12), (0x13, 0x14, 0x15)),
        bytes.fromhex(
            "122248c8 132250c8 142248b8 152248c0 162250b8 172250c0"
        ),
        "3053f49e5f9225d45c8625a5f119abdfc25208e91b2d37d2175b9b783bbb02f7",
    ),
    Page(
        "abc",
        0x2E04,  # 11780, written in hex to make accidental timing edits obvious.
        0x19A63A,
        0x4180,
        "57ee607495b834236e0212f0bd22aa132c57a8550f4dba85f4b8cb0ad649ded9",
        ((0x2B, 0x2C, 0x1D), (0x2D, 0x2E, 0x1D)),
        bytes.fromhex(
            "0c2258c8 0d2260c8 0e2258b8 0f2258c0 102260b8 112260c0"
        ),
        "dd29af83ed0a66a5e0e825d78394473afcc4a546b87f0c1f854de39038fbc61b",
    ),
)

STOP_FRAME = 11820
MASK_LENGTH = 0x00C0
OBJ_TABLES = (0x1C00, 0x1E00)


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pulse(frame: int, first: int, duration: int = 8) -> bool:
    return first <= frame < first + duration


def input_for_frame(frame: int) -> Controller:
    state = Controller()
    state.Start = pulse(frame, 650, 10)

    intro = 1200 <= frame <= 9000 and frame % 300 < 8
    open_keyboard = pulse(frame, 10320)
    select_cap = pulse(frame, 11400)
    select_abc = pulse(frame, 11700)
    state.A = pulse(frame, 950) or intro or open_keyboard or select_cap or select_abc

    # Twelve pulses are intentionally used.  The first ten cross the ten-cell
    # row; the final pulses harmlessly settle the cursor at the right selector.
    state.Right = any(pulse(frame, first) for first in range(10500, 11161, 60))
    state.Down = pulse(frame, 11300) or pulse(frame, 11600)
    return state


def configure_core(lib: ctypes.CDLL) -> type[ctypes._CFuncPtr]:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p,
        ctypes.c_void_p,
        ctypes.c_void_p,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
        ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int,
        ctypes.c_uint32,
        ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll",
        "InitializeDebugger",
        "ReleaseDebugger",
        "Pause",
        "Resume",
        "TakeScreenshot",
        "Stop",
        "Release",
    ):
        getattr(lib, name).argtypes = []

    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]
    return callback_type


def bg_tile(tiles: bytes, tile_id: int) -> bytes:
    if not 1 <= tile_id <= BG_TILES_LENGTH // 32:
        raise AssertionError(f"BG tile 0x{tile_id:02X} is outside the reviewed span")
    start = (tile_id - 1) * 32
    return tiles[start:start + 32]


def selector_mask_from_bg(
    tiles: bytes,
    grid: tuple[tuple[int, int, int], tuple[int, int, int]],
) -> bytes:
    """Recreate the six OBJ tiles from the corresponding English BG label."""

    def mask_tile(tile_id: int) -> bytes:
        pixels: list[int] = []
        for value in bg_tile(tiles, tile_id):
            pixels.extend((value >> 4, value & 0x0F))
        # Index 1 is the reviewed black BG ink.  OBJ zero is transparent and
        # exposes that ink; index 7 provides the cyan selected background.
        masked = [0 if pixel == 1 else 7 for pixel in pixels]
        return bytes(
            (masked[index] << 4) | masked[index + 1]
            for index in range(0, len(masked), 2)
        )

    # The ROM DMA layout is not screen order: right top, right bottom,
    # left top, middle top, left bottom, middle bottom.
    order = (
        grid[0][2], grid[1][2], grid[0][0],
        grid[0][1], grid[1][0], grid[1][1],
    )
    return b"".join(mask_tile(tile_id) for tile_id in order)


def screenshot_crop_hash(path: Path) -> str:
    """Hash the visible keyboard rows and selectors, excluding the header."""
    with Image.open(path) as image:
        crop = image.convert("RGB").crop((0, 48, 224, 144))
        return sha256(crop.tobytes())


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=90.0, type=float)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    if len(rom) != ROM_SIZE or sha256(rom) != ROM_SHA256:
        raise ValueError(
            f"unsupported final ROM {sha256(rom)}; expected v0.10.3 {ROM_SHA256}"
        )
    if rom[INITIAL_PAGE_ROM] != INITIAL_PAGE_VALUE:
        raise AssertionError(
            f"initial keyboard page byte is 0x{rom[INITIAL_PAGE_ROM]:02X}, expected LOW 0x00"
        )

    expected_bg_map = rom[BG_MAP_ROM:BG_MAP_ROM + BG_MAP_LENGTH]
    expected_bg_tiles = rom[BG_TILES_ROM:BG_TILES_ROM + BG_TILES_LENGTH]
    if sha256(expected_bg_map) != BG_MAP_SHA256:
        raise AssertionError("reviewed keyboard BG0 map changed in final ROM")
    if sha256(expected_bg_tiles) != BG_TILES_SHA256:
        raise AssertionError("reviewed keyboard BG0 tiles changed in final ROM")
    for page in PAGES:
        payload = rom[page.mask_rom:page.mask_rom + MASK_LENGTH]
        if sha256(payload) != page.mask_sha256:
            raise AssertionError(f"{page.name.upper()} selector mask changed in final ROM")
        if payload != selector_mask_from_bg(expected_bg_tiles, page.bg_grid):
            raise AssertionError(
                f"{page.name.upper()} ROM mask no longer agrees with its English BG label"
            )

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)
    home = args.output_dir / "mesen_core_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    callback_type = configure_core(lib)
    captures_by_frame = {page.capture_frame: page for page in PAGES}
    memories: dict[int, bytes] = {}
    completed = 0
    captured: list[int] = []
    callback_errors: list[str] = []
    reached_stop = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        try:
            completed += 1
            lib.SetInputOverrides(0, input_for_frame(completed + 1))
            if completed in captures_by_frame:
                buffer = (ctypes.c_uint8 * 0x10000)()
                lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
                memories[completed] = bytes(buffer)
                lib.TakeScreenshot()
                captured.append(completed)
            if completed >= STOP_FRAME:
                reached_stop.set()
        except BaseException as exc:  # ctypes callbacks cannot propagate.
            callback_errors.append(repr(exc))
            reached_stop.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    started = time.monotonic()
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the final ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached_stop.wait(args.timeout):
            raise TimeoutError(f"keyboard route timed out at callback frame {completed}")
        if callback_errors:
            raise RuntimeError(f"MesenCore callback failed: {callback_errors[0]}")
        lib.Pause()
        time.sleep(0.3)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 8.0
    while len(list(screenshot_dir.glob("*.png"))) < len(PAGES) and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(screenshot_dir.glob("*.png"))
    expected_frames = [page.capture_frame for page in PAGES]
    if captured != expected_frames or sorted(memories) != expected_frames:
        raise RuntimeError(
            f"expected capture frames {expected_frames}, got screenshots/memory "
            f"{captured}/{sorted(memories)}"
        )
    if len(sources) != len(PAGES):
        raise RuntimeError(f"expected {len(PAGES)} screenshots, found {len(sources)}")

    capture_reports: list[dict[str, object]] = []
    for page, source in zip(PAGES, sources, strict=True):
        screenshot = args.output_dir / f"name_keyboard_{page.name}_{page.capture_frame:05d}.png"
        shutil.copy2(source, screenshot)
        with Image.open(screenshot) as image:
            dimensions = tuple(image.size)
        if dimensions != NATIVE_DISPLAY:
            raise AssertionError(
                f"{page.name.upper()} screenshot is {dimensions}, expected {NATIVE_DISPLAY}"
            )
        crop_hash = screenshot_crop_hash(screenshot)
        if crop_hash != page.keyboard_crop_sha256:
            raise AssertionError(
                f"{page.name.upper()} visible keyboard crop is {crop_hash}, "
                f"expected {page.keyboard_crop_sha256}"
            )

        memory = memories[page.capture_frame]
        memory_path = args.output_dir / f"name_keyboard_{page.name}_{page.capture_frame:05d}_cpu.bin"
        memory_path.write_bytes(memory)

        live_map = memory[BG_MAP_RAM:BG_MAP_RAM + BG_MAP_LENGTH]
        live_tiles = memory[BG_TILES_RAM:BG_TILES_RAM + BG_TILES_LENGTH]
        if live_map != expected_bg_map or live_tiles != expected_bg_tiles:
            raise AssertionError(f"{page.name.upper()} capture changed live keyboard BG0")

        live_mask = memory[page.mask_ram:page.mask_ram + MASK_LENGTH]
        rom_mask = rom[page.mask_rom:page.mask_rom + MASK_LENGTH]
        derived_mask = selector_mask_from_bg(live_tiles, page.bg_grid)
        if live_mask != rom_mask or live_mask != derived_mask:
            raise AssertionError(
                f"{page.name.upper()} live OBJ mask differs from ROM/BG-derived mask"
            )

        obj_tables: list[dict[str, str]] = []
        for address in OBJ_TABLES:
            live_table = memory[address:address + len(page.obj_table)]
            if live_table != page.obj_table:
                raise AssertionError(
                    f"{page.name.upper()} OBJ table at 0x{address:04X} is "
                    f"{live_table.hex()}, expected {page.obj_table.hex()}"
                )
            obj_tables.append({"address": f"0x{address:04X}", "hex": live_table.hex()})

        capture_reports.append(
            {
                "page": page.name.upper(),
                "frame": page.capture_frame,
                "screenshot": screenshot.name,
                "screenshot_sha256": sha256(screenshot.read_bytes()),
                "keyboard_crop_rgb_sha256": crop_hash,
                "dimensions": list(dimensions),
                "cpu_memory": memory_path.name,
                "cpu_memory_sha256": sha256(memory),
                "live_bg0_map": {
                    "address": f"0x{BG_MAP_RAM:04X}",
                    "length": BG_MAP_LENGTH,
                    "sha256": sha256(live_map),
                    "matches_reviewed_asset": True,
                },
                "live_bg0_tiles": {
                    "address": f"0x{BG_TILES_RAM:04X}",
                    "length": BG_TILES_LENGTH,
                    "sha256": sha256(live_tiles),
                    "matches_reviewed_asset": True,
                },
                "live_selector_mask": {
                    "address": f"0x{page.mask_ram:04X}",
                    "length": MASK_LENGTH,
                    "sha256": sha256(live_mask),
                    "matches_rom": True,
                    "matches_english_bg_cutouts": True,
                },
                "obj_tables": obj_tables,
                "status": "PASS",
            }
        )

    report = {
        "format": "n1-name-keyboard-runtime-validation-v0.10.3",
        "status": "PASS",
        "rom": {"file": args.rom.name, "sha256": sha256(rom)},
        "mesen_core": {
            "file": args.mesen_core.name,
            "sha256": sha256(args.mesen_core.read_bytes()),
        },
        "native_display": list(NATIVE_DISPLAY),
        "route": {
            "clean_boot": True,
            "uses_save_or_savestate": False,
            "initial_page_rom_address": f"0x{INITIAL_PAGE_ROM:06X}",
            "initial_page_value": f"0x{INITIAL_PAGE_VALUE:02X}",
            "initial_page": "LOW lowercase",
            "sequence": ["LOW", "CAP", "ABC"],
            "last_callback_frame": completed,
            "elapsed_seconds": round(time.monotonic() - started, 3),
        },
        "reviewed_static_assets": {
            "bg0_map": {
                "rom_offset": f"0x{BG_MAP_ROM:06X}",
                "ram_address": f"0x{BG_MAP_RAM:04X}",
                "length": BG_MAP_LENGTH,
                "sha256": BG_MAP_SHA256,
            },
            "bg0_tiles": {
                "rom_offset": f"0x{BG_TILES_ROM:06X}",
                "ram_address": f"0x{BG_TILES_RAM:04X}",
                "length": BG_TILES_LENGTH,
                "sha256": BG_TILES_SHA256,
            },
        },
        "captures": capture_reports,
        "composition": {
            "selector_layer": "OBJ over English BG0 labels",
            "obj_pixel_7": "cyan selected background",
            "obj_pixel_0": "transparent cut-out exposing BG index-1 black ink",
            "all_three_live_masks_match_bg_labels": True,
            "japanese_selector_mask_residual": False,
            "status": "PASS",
        },
    }
    report_path = args.output_dir / "name_keyboard_runtime_validation_v0_10_3.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    shutil.rmtree(home)
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
