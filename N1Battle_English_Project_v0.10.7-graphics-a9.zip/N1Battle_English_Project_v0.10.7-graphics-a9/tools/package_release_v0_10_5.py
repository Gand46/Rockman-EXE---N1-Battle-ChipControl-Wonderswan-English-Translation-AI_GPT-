#!/usr/bin/env python3
"""Create the deterministic, ROM-free public N1 Battle v0.10.5 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


VERSION = "0.10.5"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.5"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
FINAL_ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"
BASE_IPS_SHA256 = "025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b"

FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".cdl", ".rgd", ".dmp",
    ".deb", ".so", ".dll", ".exe", ".tar", ".gz", ".7z", ".zip",
}
FORBIDDEN_DIRECTORIES = {
    "mesen_core_home", "mesen_home", "savestates", "saves", "memory",
    "emulator", "emulators", "cores", "bios",
}
FORBIDDEN_NAME_MARKERS = (
    "cpu_dump", "cpu-memory", "cpu_memory", "_cpu_", "wram", "ports_",
    "mesencore", "bios", "bootrom", "boot_rom", "savestate",
)
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}
DOC_SUFFIXES = {".md", ".json", ".png", ".tsv"}

REQUIRED = {
    "APPLY_PATCH.bat",
    "BUILD_PATCH.bat",
    "CHANGELOG.md",
    "LICENSE.txt",
    "README_ES.md",
    "RELEASE_SHA256.txt",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips",
    "translation/en_v0_10_5.json",
    "tables/n1battle_jp.tbl",
    "references/bcc_en.tbl",
    "translation/assets/title_logo_reference_v0_10_4.png",
    "translation/assets/title_logo_master_v0_10_4.png",
    "translation/assets/title_logo_master_preview_v0_10_4.png",
    "translation/assets/title_logo_asset_report_v0_10_4.json",
    "translation/assets/pet_root_menu_font_preview_v0_10_4.png",
    "translation/assets/pet_root_menu_font_asset_report_v0_10_4.json",
    "translation/assets/pet_labels_bg0_map_v0_8.bin",
    "translation/assets/pet_labels_tiles_v0_8.bin",
    "translation/assets/main_logo_bg0_map_v0_10_3.bin",
    "translation/assets/main_logo_tiles_v0_10_3.bin",
    "docs/runtime_v0_9_regressions/pet_root_clean_v0_8.png",
    "translation/assets/effect_labels_data_v0_10_5.bin",
    "translation/assets/chip_effect_label_asset_report_v0_10_5.json",
    "docs/STRUCTURAL_VALIDATION_v0_10_5.json",
    "docs/PROGRESO_v0_10_5.md",
    "docs/progress_v0_10_5.json",
    "docs/EMULATOR_VALIDATION_v0_10_5.md",
    "docs/CHIP_EFFECT_LABELS_v0_10_5.md",
    "docs/runtime_v0_10_5/chip_effect/chip_effect_runtime_validation_v0_10_5.json",
    "docs/runtime_v0_10_5/chip_effect/chip_folder_NORM60.png",
    "docs/runtime_v0_10_5/chip_effect/chip_sort_v0_10_5.png",
    "docs/runtime_v0_10_5/chip_effect/chip_backpack_v0_10_5.png",
    "docs/runtime_v0_10_5/chip_effect/chip_effect_before_after_v0_10_5_3x.png",
    "docs/runtime_v0_10_5/chip_effect/chip_effect_nodata_before_after_v0_10_5_3x.png",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.4.ips",
    "translation/en_v0_10_4.json",
    "translation/assets/effect_labels_data_v0_10_1.bin",
    "docs/STRUCTURAL_VALIDATION_v0_10_4.json",
    "docs/PROGRESO_v0_10_4.md",
    "docs/progress_v0_10_4.json",
    "docs/EMULATOR_VALIDATION_v0_10_4.md",
    "docs/PET_ROOT_MENU_FONT_v0_10_4.md",
    "docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json",
    "docs/runtime_v0_10_4/title/title_press_start_visible_450.png",
    "docs/runtime_v0_10_4/title/title_press_start_hidden_550.png",
    "docs/runtime_v0_10_4/title/title_new_game_continue_menu_900.png",
    "docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json",
    "docs/runtime_v0_10_4/pet_root/pet_root_runtime_27000.png",
    "docs/runtime_v0_10_4/pet_root/pet_root_runtime_vs_expected_diff.png",
    "docs/runtime_v0_10_4/pet_root/PET_ROOT_RUNTIME_VALIDATION_v0_10_4.md",
    "docs/STRUCTURAL_VALIDATION_v0_10_3.json",
    "docs/RESIDUAL_TEXT_SCAN_v0_10_3.json",
    "translation/en_v0_10_3.json",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.3.ips",
    "build/build_v0_10_5_delta.json",
    "tools/chip_effect_labels_v0_10_5.py",
    "tools/compose_release_v0_10_5.py",
    "tools/mesen_core_validate_chip_effect_v0_10_5.py",
    "tools/validate_release_v0_10_5.py",
    "tools/package_release_v0_10_5.py",
    "tests/test_chip_effect_labels_v0_10_5.py",
    "build/build_v0_10_4_delta.json",
    "tools/title_logo_assets_v0_10_4.py",
    "tools/pet_root_menu_font_assets_v0_10_4.py",
    "tools/compose_release_v0_10_4.py",
    "tools/mesen_core_validate_title_v0_10_4.py",
    "tools/mesen_core_validate_pet_root_v0_10_4.py",
    "tools/validate_release_v0_10_4.py",
    "tools/package_release_v0_10_4.py",
    "tests/test_title_logo_v0_10_4.py",
    "tests/test_pet_root_menu_font_v0_10_4.py",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict[str, Any]:
    payload = json.loads(require(root, relative).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {relative}")
    return payload


def runtime_rom_hash(report: dict[str, Any]) -> object:
    if report.get("rom_sha256"):
        return report["rom_sha256"]
    inputs = report.get("inputs", {})
    if isinstance(inputs, dict) and isinstance(inputs.get("rom"), dict):
        return inputs["rom"].get("sha256")
    return None


def validate_evidence(root: Path) -> None:
    structural = load_json(root, "docs/STRUCTURAL_VALIDATION_v0_10_5.json")
    progress = load_json(root, "docs/progress_v0_10_5.json")
    runtime = load_json(root, "docs/runtime_v0_10_5/chip_effect/chip_effect_runtime_validation_v0_10_5.json")
    effect_assets = load_json(root, "translation/assets/chip_effect_label_asset_report_v0_10_5.json")
    title = load_json(root, "docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json")
    pet = load_json(root, "docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json")
    title_assets = load_json(root, "translation/assets/title_logo_asset_report_v0_10_4.json")
    font_assets = load_json(root, "translation/assets/pet_root_menu_font_asset_report_v0_10_4.json")
    structural_checks = structural.get("checks", {})
    checks = {
        "structural PASS": structural.get("overall_result") == "PASS",
        "structural version": structural.get("project_version") == VERSION,
        "structural checks": isinstance(structural_checks, dict) and bool(structural_checks)
        and all(row.get("result") == "PASS" for row in structural_checks.values()),
        "progress PASS": progress.get("status") == "PASS",
        "progress version": progress.get("project_version") == VERSION,
        "effect progress": progress.get("effect_labels", {}).get("maximum_visible_glyphs") == 6
        and progress.get("effect_labels", {}).get("changed_unique_targets") == 43
        and progress.get("effect_labels", {}).get("no_data_rows") == 136,
        "effect runtime PASS": runtime.get("status") == "PASS",
        "effect runtime ROM": runtime_rom_hash(runtime) == FINAL_ROM_SHA256,
        "effect runtime labels": runtime.get("runtime", {}).get("visible_effects") == ["NORM60", "NODATA"],
        "effect runtime resources": runtime.get("runtime", {}).get("all_live_maps_and_tiles_match_final_rom") is True,
        "effect asset PASS": effect_assets.get("status") == "PASS",
        "effect asset inventory": effect_assets.get("inventory", {}).get("changed_unique_targets") == 43
        and effect_assets.get("inventory", {}).get("maximum_effect_length") == 6
        and effect_assets.get("inventory", {}).get("abbreviation_collisions") == 0,
        "title runtime PASS": title.get("status") == "PASS",
        "title ROM": runtime_rom_hash(title) == BASE_ROM_SHA256,
        "title native": title.get("native_display") == [224, 144],
        "title QA": title.get("title_visual_qa", {}).get("verified") is True,
        "pet runtime PASS": pet.get("status") == "PASS",
        "pet ROM": runtime_rom_hash(pet) == BASE_ROM_SHA256,
        "pet checks": isinstance(pet.get("checks"), dict) and bool(pet["checks"])
        and all(pet["checks"].values()),
        "pet 0x45": pet.get("runtime", {}).get("protected_tiles", {}).get("0x45", {}).get("matches_base") is True,
        "title assets": title_assets.get("status") == "PASS"
        and title_assets.get("reference", {}).get("sole_art_reference") is True
        and title_assets.get("capacity", {}).get("unique_tiles_used") == 194,
        "font assets": font_assets.get("status") == "PASS"
        and font_assets.get("capacity", {}).get("replacement_tile_ids") == 57
        and font_assets.get("capacity", {}).get("replacement_tile_ids_free") == 0
        and font_assets.get("protections", {}).get("runtime_row_16_corner_tile_0x45_protected") is True,
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise ValueError("release evidence is not final: " + ", ".join(failed))


def validate_manifest(root: Path) -> dict[str, Any]:
    manifest = load_json(root, "translation/en_v0_10_5.json")
    if (
        manifest.get("format") != "n1battle-inplace-translation-v1"
        or manifest.get("project_version") != VERSION
        or manifest.get("source_sha256") != SOURCE_ROM_SHA256
        or len(manifest.get("entries", [])) != 271
        or len(manifest.get("binary_entries", [])) != 77
    ):
        raise ValueError("unexpected v0.10.5 manifest identity")
    return manifest


def collect(root: Path) -> list[Path]:
    manifest = validate_manifest(root)
    files = {require(root, relative) for relative in REQUIRED}

    for entry in manifest["binary_entries"]:
        relative = PurePosixPath("translation") / str(entry["asset"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"manifest asset escapes translation/: {relative}")
        path = require(root, relative.as_posix())
        payload = path.read_bytes()
        if len(payload) != int(entry["length"]) or sha256(payload) != str(entry["asset_sha256"]).lower():
            raise ValueError(f"manifest asset mismatch: {relative}")
        files.add(path)

    # Reproducibility code and inherited unit tests are plain source files.
    for directory in ("tools", "tests"):
        files.update(path for path in (root / directory).glob("*.py") if path.is_file())

    # Publish visual/text evidence only. Raw CPU/WRAM/port captures are private
    # validation intermediates and deliberately excluded by suffix and name.
    files.update(
        path for path in (root / "docs").rglob("*")
        if path.is_file() and path.suffix.lower() in DOC_SUFFIXES
        and "v0_10" in path.relative_to(root / "docs").as_posix()
    )
    files.update(
        path for pattern in ("*v0_10_4*", "*v0_10_5*")
        for path in (root / "translation/assets").glob(pattern)
        if path.is_file() and path.suffix.lower() in {".png", ".json", ".md"}
    )
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def private_reasons(root: Path, path: Path) -> list[str]:
    relative = path.relative_to(root)
    parts = {part.lower() for part in relative.parts}
    name = path.name.lower()
    reasons: list[str] = []
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        reasons.append("extension")
    if path.stat().st_size in FORBIDDEN_SIZES:
        reasons.append("size")
    if parts & FORBIDDEN_DIRECTORIES:
        reasons.append("directory")
    if any(marker in name for marker in FORBIDDEN_NAME_MARKERS):
        reasons.append("name")
    return reasons


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if path.is_symlink():
        raise ValueError(f"symlink not allowed: {relative}")
    reasons = private_reasons(root, path)
    if reasons:
        raise ValueError(f"private file selected: {relative}: {reasons}")
    payload = path.read_bytes()
    suffix = path.suffix.lower()
    if suffix in {".md", ".json", ".tsv", ".bat", ".txt"}:
        text = payload.decode("utf-8")
        found = [marker for marker in ("/workspace/", "/root/", "/tmp/") if marker in text]
        if found:
            raise ValueError(f"private path marker in {relative}: {found}")
    if suffix == ".json":
        json.loads(payload.decode("utf-8"))
    if relative.endswith("v0.10.5.ips") and sha256(payload) != IPS_SHA256:
        raise ValueError("unexpected v0.10.5 IPS hash")
    if relative.endswith("v0.10.4.ips") and sha256(payload) != BASE_IPS_SHA256:
        raise ValueError("unexpected v0.10.4 IPS hash")
    return {"path": relative, "size": len(payload), "sha256": sha256(payload)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    validate_evidence(root)
    release_hashes = require(root, "RELEASE_SHA256.txt").read_text(encoding="utf-8")
    if FINAL_ROM_SHA256 not in release_hashes or IPS_SHA256 not in release_hashes:
        raise ValueError("RELEASE_SHA256.txt does not pin v0.10.5")

    output = (args.output or root / "dist/N1Battle_English_Project_v0.10.5.zip").resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside project root")
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    archive_payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": VERSION,
        "archive": output.name,
        "archive_size": len(archive_payload),
        "archive_sha256": sha256(archive_payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": 0,
        "files": inventory,
    }
    output.with_suffix(".release.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_save_emulator_files",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
