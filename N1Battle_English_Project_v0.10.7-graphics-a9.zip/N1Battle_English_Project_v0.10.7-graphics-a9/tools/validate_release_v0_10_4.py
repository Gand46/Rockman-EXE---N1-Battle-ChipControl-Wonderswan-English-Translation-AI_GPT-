#!/usr/bin/env python3
"""Validate the graphics-only N1 Battle English v0.10.4 release.

The Japanese Rev 1 ROM is never distributed.  This validator chains the
published, canonical v0.10.3 evidence with the deterministic v0.10.4 delta,
then verifies the final private QA ROM, source-compatible IPS, manifest,
assets and clean-boot MesenCore reports.
"""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


VERSION = "0.10.4"
ROM_SIZE = 0x400000
SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
FINAL_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
BASE_IPS_SHA256 = "db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7"
FINAL_IPS_SHA256 = "025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b"
TEXT_DENOMINATOR = 1552
GRAPHICS_DENOMINATOR = 129

FOCUSED_ASSETS = {
    "main_logo_bg0_map": (0x0409A6, 0x0480, "be3a4b84dfed1ff9d51585d4aa71f0148b60f6bea15a96829def8a30294bebf3"),
    "pet_labels_bg0_map": (0x042DBA, 0x0400, "926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c"),
    "main_logo_tiles": (0x071BC0, 0x1A00, "7a4556ddef397cf1a20d0cd8ab6552efa589b23a7b561c6145a12bcc5cb214a8"),
    "pet_labels_tiles": (0x07C330, 0x0980, "f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2"),
}

TEXT_POOLS = (
    (0x34ACB0, 0x34B75E), (0x34B8A0, 0x34CFDA),
    (0x34D0C0, 0x3540B8), (0x354160, 0x3574CE),
    (0x357510, 0x357D38), (0x357D80, 0x358732),
    (0x367170, 0x367592), (0x367660, 0x367AEA),
    (0x368010, 0x369160), (0x369550, 0x36A4E0),
    (0x36A8D0, 0x36B8DE), (0x36BB90, 0x36C7BC),
    (0x36CA30, 0x36D3FC), (0x36D650, 0x36DFAC),
    (0x36E1D0, 0x36EA8C), (0x37CC30, 0x37D7F4),
    (0x37DAE0, 0x37E0CC),
)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {path}")
    return payload


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def check(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def raw_ips_records(payload: bytes) -> list[tuple[int, int]]:
    if not payload.startswith(b"PATCH"):
        raise ValueError("not an IPS patch")
    records: list[tuple[int, int]] = []
    cursor = 5
    while payload[cursor:cursor + 3] != b"EOF":
        if cursor + 5 > len(payload):
            raise ValueError("truncated IPS record")
        offset = int.from_bytes(payload[cursor:cursor + 3], "big")
        length = int.from_bytes(payload[cursor + 3:cursor + 5], "big")
        cursor += 5
        if length:
            cursor += length
            actual = length
        else:
            if cursor + 3 > len(payload):
                raise ValueError("truncated IPS RLE record")
            actual = int.from_bytes(payload[cursor:cursor + 2], "big")
            cursor += 3
        if offset + actual > ROM_SIZE:
            raise ValueError("IPS record exceeds ROM")
        records.append((offset, offset + actual))
    if payload[cursor:cursor + 3] != b"EOF" or cursor + 3 != len(payload):
        raise ValueError("malformed IPS ending")
    ordered = sorted(records)
    if any(left[1] > right[0] for left, right in zip(ordered, ordered[1:])):
        raise ValueError("overlapping IPS records")
    return records


def manifest_delta_ok(old: dict[str, Any], new: dict[str, Any]) -> tuple[bool, list[str]]:
    failures: list[str] = []
    if old.get("entries") != new.get("entries"):
        failures.append("text entries changed")
    if old.get("official_reference") != new.get("official_reference"):
        failures.append("official reference changed")
    old_binary = {row.get("id"): row for row in old.get("binary_entries", [])}
    new_binary = {row.get("id"): row for row in new.get("binary_entries", [])}
    if old_binary.keys() != new_binary.keys():
        failures.append("binary entry IDs changed")
    for entry_id in old_binary.keys() & new_binary.keys():
        before = dict(old_binary[entry_id])
        after = dict(new_binary[entry_id])
        if entry_id in FOCUSED_ASSETS:
            before.pop("asset", None)
            before.pop("asset_sha256", None)
            after.pop("asset", None)
            after.pop("asset_sha256", None)
        if before != after:
            failures.append(f"unexpected manifest delta: {entry_id}")
    return not failures, failures


def runtime_rom_hash(report: dict[str, Any]) -> object:
    direct = report.get("rom_sha256")
    if direct:
        return direct
    inputs = report.get("inputs", {})
    if isinstance(inputs, dict) and isinstance(inputs.get("rom"), dict):
        return inputs["rom"].get("sha256")
    return None


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root_default = Path(__file__).resolve().parents[1]
    parser.add_argument("--project-root", type=Path, default=root_default)
    parser.add_argument("--base-rom", type=Path)
    parser.add_argument("--rom", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    base_path = (args.base_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.3.wsc").resolve()
    rom_path = (args.rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.4.wsc").resolve()
    report_path = (args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10_4.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-structural-validation-v0.10.4",
        "project_version": VERSION,
        "overall_result": "FAIL",
        "checks": {},
        "failures": [],
    }
    try:
        base = base_path.read_bytes()
        final = rom_path.read_bytes()
        ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.4.ips").read_bytes()
        base_ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.3.ips").read_bytes()
        manifest = load_json(root / "translation/en_v0_10_4.json")
        old_manifest = load_json(root / "translation/en_v0_10_3.json")

        identity_ok = (
            len(base) == len(final) == ROM_SIZE
            and sha256(base) == BASE_ROM_SHA256
            and sha256(final) == FINAL_ROM_SHA256
        )
        report["checks"]["rom_identity"] = check(
            identity_ok, size=len(final), base_sha256=sha256(base),
            final_sha256=sha256(final), expected_final_sha256=FINAL_ROM_SHA256,
        )

        stored = int.from_bytes(final[-2:], "little")
        calculated = sum(final[:-2]) & 0xFFFF
        report["checks"]["wonderswan_checksum"] = check(
            stored == calculated, stored=f"0x{stored:04X}", calculated=f"0x{calculated:04X}",
        )

        allowed = bytearray(ROM_SIZE)
        for offset, length, _digest in FOCUSED_ASSETS.values():
            allowed[offset:offset + length] = b"\x01" * length
        allowed[-2:] = b"\x01\x01"
        changed = [index for index, (a, b) in enumerate(zip(base, final)) if a != b]
        outside = [index for index in changed if not allowed[index]]
        text_overlap = [
            index for index in changed
            if any(start <= index < end for start, end in TEXT_POOLS)
        ]
        report["checks"]["v0_10_3_to_v0_10_4_allowlist"] = check(
            not outside and not text_overlap and len(changed) == 7467,
            changed_bytes=len(changed), outside_count=len(outside),
            first_outside=[f"0x{x:06X}" for x in outside[:20]],
            text_pool_overlap_count=len(text_overlap),
            allowed_resources=list(FOCUSED_ASSETS),
        )

        header_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == VERSION
            and manifest.get("source_sha256") == SOURCE_SHA256
            and len(manifest.get("entries", [])) == 271
            and len(manifest.get("binary_entries", [])) == 77
        )
        delta_ok, delta_failures = manifest_delta_ok(old_manifest, manifest)
        binary_rows = []
        binary_ok = True
        focused_seen: set[str] = set()
        for entry in manifest.get("binary_entries", []):
            entry_id = str(entry.get("id"))
            offset = int(str(entry.get("offset")), 0)
            length = int(entry.get("length"))
            asset_path = (root / "translation" / str(entry.get("asset"))).resolve()
            safe = (root / "translation").resolve() in asset_path.parents
            payload = asset_path.read_bytes() if safe and asset_path.is_file() else b""
            digest = sha256(payload)
            ok = (
                safe and len(payload) == length
                and digest == str(entry.get("asset_sha256", "")).lower()
                and final[offset:offset + length] == payload
            )
            binary_ok &= ok
            if entry_id in FOCUSED_ASSETS:
                wanted_offset, wanted_length, wanted_hash = FOCUSED_ASSETS[entry_id]
                ok &= (offset, length, digest) == (wanted_offset, wanted_length, wanted_hash)
                focused_seen.add(entry_id)
                binary_ok &= ok
            binary_rows.append({"id": entry_id, "ok": ok, "sha256": digest})
        report["checks"]["manifest_and_binary_assets"] = check(
            header_ok and delta_ok and binary_ok and focused_seen == set(FOCUSED_ASSETS),
            text_entries=len(manifest.get("entries", [])),
            binary_entries=len(binary_rows),
            binary_failures=[row for row in binary_rows if not row["ok"]],
            manifest_delta_failures=delta_failures,
            focused_assets=sorted(focused_seen),
        )

        compose = load_json(root / "build/build_v0_10_4_delta.json")
        composer = load_module("compose_release_v0104_validation", root / "tools/compose_release_v0_10_4.py")
        old_covered, old_values = composer.parse_ips(base_ips, ROM_SIZE)
        new_covered, new_values = composer.parse_ips(ips, ROM_SIZE)
        synthetic = bytearray(base)
        for index, present in enumerate(old_covered):
            if present:
                synthetic[index] = 0
        old_roundtrip = composer.apply_normalized(bytes(synthetic), old_covered, old_values) == base
        new_roundtrip = composer.apply_normalized(bytes(synthetic), new_covered, new_values) == final
        ips_records = raw_ips_records(ips)
        ips_ok = (
            sha256(base_ips) == BASE_IPS_SHA256
            and sha256(ips) == FINAL_IPS_SHA256
            and old_roundtrip and new_roundtrip
            and compose.get("status") == "PASS"
            and compose.get("final_rom_sha256") == FINAL_ROM_SHA256
            and compose.get("final_ips_sha256") == FINAL_IPS_SHA256
            and compose.get("outside_allowlist") == 0
            and compose.get("ips", {}).get("composition_proof") == "PASS"
        )
        report["checks"]["source_compatible_ips_composition"] = check(
            ips_ok, base_ips_sha256=sha256(base_ips), ips_sha256=sha256(ips),
            record_count=len(ips_records), records_non_overlapping=True,
            inherited_v0_10_3_roundtrip=old_roundtrip,
            composed_v0_10_4_roundtrip=new_roundtrip,
        )

        title_assets = load_json(root / "translation/assets/title_logo_asset_report_v0_10_4.json")
        font_assets = load_json(root / "translation/assets/pet_root_menu_font_asset_report_v0_10_4.json")
        title_asset_ok = (
            title_assets.get("status") == "PASS"
            and title_assets.get("reference", {}).get("sole_art_reference") is True
            and title_assets.get("reference", {}).get("sha256") == "f1394a24454413e44933fb5981825dd97daa93647b05ece03ecb0fbf91b9973e"
            and title_assets.get("capacity", {}).get("unique_tiles_used") == 194
            and title_assets.get("capacity", {}).get("spare_tiles") == 14
            and title_assets.get("protected", {}).get("maximum_logo_y") == 102
        )
        font_asset_ok = (
            font_assets.get("status") == "PASS"
            and font_assets.get("capacity", {}).get("replacement_tile_ids") == 57
            and font_assets.get("capacity", {}).get("unique_patterns_allocated") == 57
            and font_assets.get("capacity", {}).get("replacement_tile_ids_free") == 0
            and font_assets.get("protections", {}).get("runtime_row_16_corner_tile_0x45_protected") is True
        )
        report["checks"]["focused_asset_reports"] = check(
            title_asset_ok and font_asset_ok,
            title_report="translation/assets/title_logo_asset_report_v0_10_4.json",
            font_report="translation/assets/pet_root_menu_font_asset_report_v0_10_4.json",
        )

        title_runtime = load_json(root / "docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json")
        pet_runtime = load_json(root / "docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json")
        title_runtime_ok = (
            title_runtime.get("status") == "PASS"
            and runtime_rom_hash(title_runtime) == FINAL_ROM_SHA256
            and title_runtime.get("native_display") == [224, 144]
            and title_runtime.get("clean_boot", {}).get("fresh_mesen_home") is True
            and title_runtime.get("clean_boot", {}).get("uses_sav_or_savestate") is False
            and all(title_runtime.get("summary_checks", {}).values())
            and title_runtime.get("title_visual_qa", {}).get("verified") is True
        )
        pet_checks = pet_runtime.get("checks", {})
        tile_45 = pet_runtime.get("runtime", {}).get("protected_tiles", {}).get("0x45", {})
        pet_runtime_ok = (
            pet_runtime.get("status") == "PASS"
            and runtime_rom_hash(pet_runtime) == FINAL_ROM_SHA256
            and isinstance(pet_checks, dict) and bool(pet_checks) and all(pet_checks.values())
            and tile_45.get("matches_base") is True
            and pet_runtime.get("runtime", {}).get("bottom_frame", {}).get("corner_cell", {}).get("matches_expected") is True
            and pet_runtime.get("visual", {}).get("screenshot", {}).get("dimensions") == [224, 144]
        )
        report["checks"]["v0_10_4_runtime_evidence"] = check(
            title_runtime_ok and pet_runtime_ok,
            title={"status": title_runtime.get("status"), "rom_sha256": runtime_rom_hash(title_runtime)},
            pet_root={"status": pet_runtime.get("status"), "rom_sha256": runtime_rom_hash(pet_runtime)},
        )

        inherited_structural = load_json(root / "docs/STRUCTURAL_VALIDATION_v0_10_3.json")
        inherited_residual = load_json(root / "docs/RESIDUAL_TEXT_SCAN_v0_10_3.json")
        inherited_ok = (
            inherited_structural.get("overall_result") == "PASS"
            and inherited_structural.get("project_version") == "0.10.3"
            and inherited_residual.get("overall_result") == "PASS"
            and inherited_residual.get("inventory", {}).get("translated") == TEXT_DENOMINATOR
            and inherited_residual.get("inventory", {}).get("denominator") == TEXT_DENOMINATOR
            and inherited_residual.get("inventory", {}).get("remaining_japanese_targets") == 0
            and not text_overlap
            and manifest.get("entries") == old_manifest.get("entries")
        )
        report["checks"]["inherited_text_and_graphics_coverage"] = check(
            inherited_ok, translated_text=TEXT_DENOMINATOR,
            text_denominator=TEXT_DENOMINATOR, remaining_japanese_targets=0,
            graphics_localized=GRAPHICS_DENOMINATOR,
            graphics_denominator=GRAPHICS_DENOMINATOR,
            v0_10_4_text_pool_delta_bytes=len(text_overlap),
        )
    except BaseException as exc:
        report["failures"].append(f"{type(exc).__name__}: {exc}")

    failed = [
        name for name, payload in report["checks"].items()
        if isinstance(payload, dict) and payload.get("result") != "PASS"
    ]
    report["failed_checks"] = failed
    report["overall_result"] = "PASS" if not failed and not report["failures"] else "FAIL"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    print(json.dumps({
        "overall_result": report["overall_result"],
        "failed_checks": failed,
        "failures": report["failures"],
        "final_rom_sha256": FINAL_ROM_SHA256,
        "ips_sha256": FINAL_IPS_SHA256,
        "report": report_path.name,
        "report_sha256": sha256(rendered.encode("utf-8")),
    }, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
