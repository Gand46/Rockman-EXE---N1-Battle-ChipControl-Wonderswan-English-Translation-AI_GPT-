#!/usr/bin/env python3
"""Drive the v0.8 entry-name route through headless MesenCore.

This mirrors the previously validated clean-boot Lua route but deliberately
does not move to, or select, the Latin page.  Seeing numbers and A-Z at the
capture point therefore verifies the v0.8 constructor patch itself.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


CPU_WS = 12
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
CAPTURE_FRAMES = (10480, 10520, 10600)
STOP_FRAME = 10620


class TimingInfo(ctypes.Structure):
    _fields_ = [
        ("fps", ctypes.c_double),
        ("master_clock", ctypes.c_uint64),
        ("master_clock_rate", ctypes.c_uint32),
        ("frame_count", ctypes.c_uint32),
        ("scanline_count", ctypes.c_uint32),
        ("first_scanline", ctypes.c_int32),
        ("cycle_count", ctypes.c_uint32),
    ]


class DebugControllerState(ctypes.Structure):
    _fields_ = [(name, ctypes.c_bool) for name in (
        "A", "B", "X", "Y", "L", "R", "U", "D",
        "Up", "Down", "Left", "Right", "Select", "Start",
    )]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame < last


def input_for_frame(frame: int) -> DebugControllerState:
    # Clean boot: title Start, New Game, advance the complete registration
    # dialogue, and accept the prompt that opens the keyboard.  Unlike the
    # research route, there are no Down/Right inputs and no A at frame 11340.
    press_a = (
        pulse(frame, 950, 958)
        or (1200 <= frame <= 9000 and frame % 300 < 8)
        or pulse(frame, 10320, 10328)
    )
    return DebugControllerState(A=press_a, Start=pulse(frame, 650, 660))


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=60.0, type=float)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    home = args.output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    lib.InitializeEmu.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.GetTimingInfo.argtypes = [ctypes.c_int]
    lib.GetTimingInfo.restype = TimingInfo
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, DebugControllerState]
    for name in ("InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
                 "TakeScreenshot", "Stop", "Release"):
        getattr(lib, name).argtypes = []

    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    captured: list[int] = []
    reached_stop = threading.Event()
    callback_error: list[str] = []

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        try:
            completed += 1
            lib.SetInputOverrides(0, input_for_frame(completed + 1))
            if completed in CAPTURE_FRAMES:
                lib.TakeScreenshot()
                captured.append(completed)
            if completed >= STOP_FRAME:
                reached_stop.set()
        except BaseException as exc:  # ctypes callbacks cannot propagate.
            callback_error.append(repr(exc))
            reached_stop.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    start_time = time.monotonic()
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore notification callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached_stop.wait(args.timeout):
            raise TimeoutError(f"route timed out at callback frame {completed}")
        if callback_error:
            raise RuntimeError(f"notification callback failed: {callback_error[0]}")
        lib.Pause()
        time.sleep(0.2)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5
    while len(list(screenshot_dir.glob("*.png"))) < len(captured) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != len(CAPTURE_FRAMES):
        raise RuntimeError(f"expected {len(CAPTURE_FRAMES)} captures, found {len(screenshots)}")

    evidence = []
    for requested_frame, source in zip(CAPTURE_FRAMES, screenshots):
        destination = args.output_dir / f"name_keyboard_frame_{requested_frame:05d}.png"
        shutil.copy2(source, destination)
        with Image.open(destination) as image:
            dimensions = list(image.size)
        evidence.append({
            "frame": requested_frame,
            "file": destination.name,
            "sha256": sha256(destination),
            "dimensions": dimensions,
        })

    report = {
        "validation": "name_keyboard_v0_8_clean_boot_headless_mesen_core",
        "rom": str(args.rom),
        "rom_sha256": sha256(args.rom),
        "mesen_core": str(args.mesen_core),
        "mesen_core_sha256": sha256(args.mesen_core),
        "route": {
            "clean_boot": True,
            "uses_sav_or_savestate": False,
            "manually_selects_latin_page": False,
            "last_callback_frame": completed,
            "elapsed_seconds": round(time.monotonic() - start_time, 3),
        },
        "captures": evidence,
    }
    (args.output_dir / "name_keyboard_mesen_validation_v0_8.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
