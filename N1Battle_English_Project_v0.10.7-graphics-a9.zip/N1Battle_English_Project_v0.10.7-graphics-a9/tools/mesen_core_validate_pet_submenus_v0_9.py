#!/usr/bin/env python3
"""Validate all four English PET submenus from independent clean Mesen boots.

Each route receives its own empty Mesen home, reaches the PET without SRAM or
savestates, captures the stable submenu frame, dumps CPU memory, and compares
the complete live tile/map regions with the deterministic v0.9 assets.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import ctypes
import hashlib
import json
import multiprocessing
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7

EXPECTED_ASSET_SHA256 = {
    "pet_submenu_chip_library_tiles_v0_9.bin":
        "cedc648b7098547cbe3bbe38b96c455969144fdbb98569b8e46c84779829d45c",
    "pet_submenu_netnavi_tiles_v0_9.bin":
        "927a2a8c64e27e0f6f74da4a86cb67dcded3be7ea33daeed12acd7ab7be60321",
    "pet_submenu_save_tiles_v0_9.bin":
        "4a2d461d734245f9650fba93373f4ba1780e4c23912c8ac91f5f92cd5527e9ad",
    "pet_submenu_chip_folder_bg0_map_v0_9.bin":
        "41e54fd79cc046fa9b5cadfd1c47d2a884f4db2a7dda7ad763185cc40c79f80c",
    "pet_submenu_data_library_bg0_map_v0_9.bin":
        "0cea35569bcfe6b0302a51dd777653ca3089bcd23f87211d5b60d96aa0327f32",
    "pet_submenu_netnavi_bg0_map_v0_9.bin":
        "3966864b141ae128b02cf1020f199879b1aebe636da60e21d7776d7565aa329c",
    "pet_submenu_save_bg0_map_v0_9.bin":
        "bbadd7edba1426411b699c524740889294e449332880c413b9b4ae788fe35806",
}


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


@dataclass(frozen=True)
class Route:
    name: str
    target_frame: int
    down_pulses: tuple[int, ...]
    enter_frame: int
    tile_asset: str
    map_asset: str
    tile_length: int
    map_length: int
    expected_labels: tuple[str, ...]


ROUTES = (
    Route(
        "chip_folder", 27260, (27040,), 27100,
        "pet_submenu_chip_library_tiles_v0_9.bin",
        "pet_submenu_chip_folder_bg0_map_v0_9.bin",
        0x16C0, 0x0680, ("CHIP FOLDER", "Y2 PACK"),
    ),
    Route(
        "data_library", 27290, (27040, 27100), 27160,
        "pet_submenu_chip_library_tiles_v0_9.bin",
        "pet_submenu_data_library_bg0_map_v0_9.bin",
        0x16C0, 0x0680, ("DATA LIBRARY",),
    ),
    Route(
        "netnavi", 27320, (27040, 27100, 27160), 27220,
        "pet_submenu_netnavi_tiles_v0_9.bin",
        "pet_submenu_netnavi_bg0_map_v0_9.bin",
        0x0D40, 0x0480, ("NETNAVI", "Y2 MEGAMAN", "T", "C"),
    ),
    Route(
        "save", 27350, (27040, 27100, 27160, 27220), 27300,
        "pet_submenu_save_tiles_v0_9.bin",
        "pet_submenu_save_bg0_map_v0_9.bin",
        0x0800, 0x0480,
        ("SAVE", "DATA LIBRARY", "BATTLE CHIPS", "CREDITS", "C"),
    ),
)


class TimingInfo(ctypes.Structure):
    _fields_ = [
        ("fps", ctypes.c_double),
        ("master_clock", ctypes.c_uint64),
        ("master_clock_rate", ctypes.c_uint32),
        ("frame_count", ctypes.c_uint32),
        ("scanline_count", ctypes.c_uint32),
        ("first_scanline", ctypes.c_int32),
        ("cycle_count", ctypes.c_uint32),
    ]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def portable_path(path: Path, project_root: Path) -> str:
    try:
        return str(path.resolve().relative_to(project_root.resolve()))
    except ValueError:
        return path.name


def pulse(frame: int, first: int, duration: int = 8) -> bool:
    return first <= frame < first + duration


def input_for_frame(route: Route, frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = pulse(frame, 650, 10)
    intro_and_manual = 1200 <= frame <= 26708 and frame % 300 < 8
    state.A = (
        pulse(frame, 950)
        or intro_and_manual
        or pulse(frame, 26920)
        or pulse(frame, route.enter_frame)
    )
    state.Down = any(pulse(frame, first) for first in route.down_pulses)
    return state


def configure_core(lib: ctypes.CDLL) -> None:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
        "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib._n1_callback_type = callback_type
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]


def route_by_name(name: str) -> Route:
    return next(route for route in ROUTES if route.name == name)


def run_route(payload: dict) -> dict:
    route = route_by_name(payload["route"])
    rom = Path(payload["rom"])
    core = Path(payload["core"])
    assets = Path(payload["assets"])
    output_dir = Path(payload["output"])
    timeout = float(payload["timeout"])

    if output_dir.exists():
        shutil.rmtree(output_dir)
    home = output_dir / "mesen_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    expected_tiles = (assets / route.tile_asset).read_bytes()
    expected_map = (assets / route.map_asset).read_bytes()
    if len(expected_tiles) != route.tile_length:
        raise ValueError(f"{route.name}: unexpected tile asset length")
    if len(expected_map) != route.map_length:
        raise ValueError(f"{route.name}: unexpected map asset length")
    for filename, payload_bytes in (
        (route.tile_asset, expected_tiles), (route.map_asset, expected_map)
    ):
        actual = sha256(payload_bytes)
        expected = EXPECTED_ASSET_SHA256[filename]
        if actual != expected:
            raise ValueError(
                f"{route.name}: {filename} has SHA-256 {actual}; expected {expected}. "
                "A changed asset requires a new visual review."
            )

    lib = ctypes.CDLL(str(core.resolve()))
    configure_core(lib)
    completed = 0
    target_reached = threading.Event()
    callback_type = lib._n1_callback_type

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(route, completed + 1))
        if completed == route.target_frame:
            lib.TakeScreenshot()
            target_reached.set()

    listener = None
    started = time.monotonic()
    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    try:
        if not lib.LoadRom(str(rom.resolve()).encode(), b""):
            raise RuntimeError(f"{route.name}: MesenCore could not load ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(route, 0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError(f"{route.name}: could not register callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not target_reached.wait(timeout):
            raise TimeoutError(f"{route.name}: timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.2)

        buffer = (ctypes.c_uint8 * 0x10000)()
        lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
        cpu = bytes(buffer)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5
    while not list(screenshot_dir.glob("*.png")) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != 1:
        raise RuntimeError(
            f"{route.name}: expected one screenshot, found {len(screenshots)}"
        )
    screenshot = output_dir / f"{route.name}_{route.target_frame}.png"
    shutil.copy2(screenshots[0], screenshot)
    cpu_path = output_dir / f"{route.name}_cpu_{route.target_frame}.bin"
    cpu_path.write_bytes(cpu)

    live_tiles = cpu[0x8000:0x8000 + route.tile_length]
    live_map = cpu[0x2000:0x2000 + route.map_length]
    tiles_match = live_tiles == expected_tiles
    map_match = live_map == expected_map
    if not tiles_match or not map_match:
        raise RuntimeError(
            f"{route.name}: runtime mismatch tiles={tiles_match}, map={map_match}"
        )

    with Image.open(screenshot) as image:
        dimensions = list(image.size)
    persistence_files = sorted(
        str(path.relative_to(home))
        for path in home.rglob("*")
        if path.is_file() and (
            "Saves" in path.parts or "SaveStates" in path.parts
        )
    )
    # Mesen writes automatic persistence files while closing even though the
    # clean route never loaded one.  Remove the isolated home after collecting
    # evidence so the delivered validation contains no SAV or savestate.
    shutil.rmtree(home)
    result = {
        "route": route.name,
        "target_frame": route.target_frame,
        "last_callback_frame": completed,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "clean_boot": True,
        "uses_sav": False,
        "uses_savestate": False,
        "preexisting_persistence_files": 0,
        "runtime_generated_persistence_files_removed": persistence_files,
        "mesen_home_removed_after_capture": True,
        "input": {
            "down_pulses": list(route.down_pulses),
            "enter_frame": route.enter_frame,
        },
        "expected_labels": list(route.expected_labels),
        "screenshot": {
            "file": screenshot.name,
            "sha256": sha256(screenshot.read_bytes()),
            "dimensions": dimensions,
        },
        "cpu_dump": {"file": cpu_path.name, "sha256": sha256(cpu)},
        "runtime": {
            "tiles": {
                "address": "CPU:0x8000",
                "length": len(expected_tiles),
                "asset": route.tile_asset,
                "sha256": sha256(live_tiles),
                "matches_asset": tiles_match,
            },
            "map": {
                "address": "CPU:0x2000",
                "length": len(expected_map),
                "asset": route.map_asset,
                "sha256": sha256(live_map),
                "matches_asset": map_match,
            },
        },
    }
    (output_dir / "route_report.json").write_text(
        json.dumps(result, indent=2) + "\n", encoding="utf-8"
    )
    return result


def build_montage(results: list[dict], output_dir: Path) -> dict:
    cards = []
    for result in results:
        path = output_dir / result["route"] / result["screenshot"]["file"]
        with Image.open(path) as source:
            image = source.convert("RGB")
        scale = 3
        image = image.resize(
            (image.width * scale, image.height * scale), Image.Resampling.NEAREST
        )
        caption = 26
        card = Image.new("RGB", (image.width, image.height + caption), (24, 24, 24))
        card.paste(image, (0, caption))
        draw = ImageDraw.Draw(card)
        draw.text((8, 7), result["route"].replace("_", " ").upper(), fill="white")
        cards.append(card)

    gap = 8
    montage = Image.new(
        "RGB",
        (cards[0].width * 2 + gap, cards[0].height * 2 + gap),
        (10, 10, 10),
    )
    for index, card in enumerate(cards):
        montage.paste(
            card,
            ((index % 2) * (card.width + gap), (index // 2) * (card.height + gap)),
        )
    path = output_dir / "pet_submenus_mesen_montage_v0_9.png"
    montage.save(path)
    return {
        "file": path.name,
        "sha256": sha256(path.read_bytes()),
        "dimensions": list(montage.size),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--assets", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument(
        "--evidence-dir", type=Path,
        help="optional portable destination for captures, montage and JSON report",
    )
    parser.add_argument("--jobs", type=int, default=1)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    project_root = Path(__file__).resolve().parents[1]
    rom = args.rom.read_bytes()
    args.output_dir.mkdir(parents=True, exist_ok=True)
    payloads = [
        {
            "route": route.name,
            "rom": str(args.rom),
            "core": str(args.mesen_core),
            "assets": str(args.assets),
            "output": str(args.output_dir / route.name),
            "timeout": args.timeout,
        }
        for route in ROUTES
    ]
    if args.jobs == 1:
        results = [run_route(payload) for payload in payloads]
    else:
        context = multiprocessing.get_context("spawn")
        with concurrent.futures.ProcessPoolExecutor(
            max_workers=args.jobs, mp_context=context
        ) as executor:
            results = list(executor.map(run_route, payloads))
    results.sort(key=lambda item: [route.name for route in ROUTES].index(item["route"]))

    montage = build_montage(results, args.output_dir)
    evidence = {}
    if args.evidence_dir:
        args.evidence_dir.mkdir(parents=True, exist_ok=True)
        for result in results:
            source = (
                args.output_dir / result["route"] / result["screenshot"]["file"]
            )
            target = args.evidence_dir / f"pet_submenu_{result['route']}_mesen_v0_9.png"
            shutil.copy2(source, target)
            evidence[result["route"]] = {
                "path": portable_path(target, project_root),
                "sha256": sha256(target.read_bytes()),
            }
        montage_source = args.output_dir / montage["file"]
        montage_target = args.evidence_dir / "pet_submenus_mesen_montage_v0_9.png"
        shutil.copy2(montage_source, montage_target)
        evidence["montage"] = {
            "path": portable_path(montage_target, project_root),
            "sha256": sha256(montage_target.read_bytes()),
        }
    report = {
        "validation": "pet_submenus_v0_9_clean_boot_mesen_core",
        "rom": {"path": portable_path(args.rom, project_root), "sha256": sha256(rom)},
        "mesen_core": {
            "path": args.mesen_core.name,
            "sha256": sha256(args.mesen_core.read_bytes()),
        },
        "assets_directory": portable_path(args.assets, project_root),
        "reviewed_asset_sha256": EXPECTED_ASSET_SHA256,
        "clean_boots": len(results),
        "uses_any_sav_or_savestate": False,
        "labels_expected": sum(len(route.expected_labels) for route in ROUTES),
        "all_runtime_tiles_match_assets": all(
            result["runtime"]["tiles"]["matches_asset"] for result in results
        ),
        "all_runtime_maps_match_assets": all(
            result["runtime"]["map"]["matches_asset"] for result in results
        ),
        "routes": results,
        "montage": montage,
        "portable_evidence": evidence,
        "visual_review": {
            "status": "PASS",
            "method": "manual inspection of the four 224x144 captures and 3x montage",
            "labels_confirmed": [
                label for route in ROUTES for label in route.expected_labels
            ],
            "residual_japanese_visible": [],
            "notes": [
                "CHIP FOLDER and Y2 PACK are visible and legible.",
                "DATA LIBRARY is visible and legible.",
                "NETNAVI, Y2 MEGAMAN and the T/C counter units are visible.",
                "SAVE, DATA LIBRARY, BATTLE CHIPS, CREDITS and C are visible.",
            ],
        },
    }
    report_path = args.output_dir / "pet_submenus_mesen_validation_v0_9.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    if args.evidence_dir:
        shutil.copy2(
            report_path,
            args.evidence_dir / "pet_submenus_mesen_validation_v0_9.json",
        )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
