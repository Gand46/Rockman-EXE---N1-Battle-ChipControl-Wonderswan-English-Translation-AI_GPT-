#!/usr/bin/env python3
"""Capture multiple native frames along the clean new-game story route."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
NATIVE_DISPLAY = (224, 144)


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def pulse(frame: int, first: int, duration: int = 8) -> bool:
    return first <= frame < first + duration


def input_for_frame(frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = pulse(frame, 650, 10)
    state.A = (
        pulse(frame, 950)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or pulse(frame, 26920)
    )
    return state


def configure_core(lib: ctypes.CDLL) -> type[ctypes._CFuncPtr]:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause",
        "Resume", "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]
    return callback_type


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--capture-frame", action="append", default=[], type=int)
    parser.add_argument("--capture-start", type=int)
    parser.add_argument("--capture-stop", type=int)
    parser.add_argument("--capture-step", type=int, default=300)
    parser.add_argument("--capture-memory", action="store_true")
    parser.add_argument("--timeout", default=180.0, type=float)
    args = parser.parse_args()

    frames = set(args.capture_frame)
    if args.capture_start is not None or args.capture_stop is not None:
        if args.capture_start is None or args.capture_stop is None:
            raise ValueError("capture-start and capture-stop must be used together")
        if args.capture_step <= 0 or args.capture_stop < args.capture_start:
            raise ValueError("invalid capture range")
        frames.update(range(args.capture_start, args.capture_stop + 1, args.capture_step))
    capture_frames = sorted(frames)
    if not capture_frames or capture_frames[0] < 0:
        raise ValueError("at least one non-negative capture frame is required")
    stop_frame = capture_frames[-1] + 10

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)
    home = args.output_dir / "mesen_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    callback_type = configure_core(lib)
    capture_set = set(capture_frames)
    captured: list[int] = []
    memories: dict[int, bytes] = {}
    callback_errors: list[str] = []
    reached_stop = threading.Event()
    completed = 0

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        try:
            completed += 1
            lib.SetInputOverrides(0, input_for_frame(completed + 1))
            if completed in capture_set:
                if args.capture_memory:
                    buffer = (ctypes.c_uint8 * 0x10000)()
                    lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
                    memories[completed] = bytes(buffer)
                lib.TakeScreenshot()
                captured.append(completed)
            if completed >= stop_frame:
                reached_stop.set()
        except BaseException as exc:  # ctypes callbacks cannot propagate.
            callback_errors.append(repr(exc))
            reached_stop.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    started = time.monotonic()
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached_stop.wait(args.timeout):
            raise TimeoutError(f"story probe timed out at callback frame {completed}")
        if callback_errors:
            raise RuntimeError(f"MesenCore callback failed: {callback_errors[0]}")
        lib.Pause()
        time.sleep(0.3)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 10.0
    while len(list(screenshot_dir.glob("*.png"))) < len(capture_frames) and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(screenshot_dir.glob("*.png"))
    if captured != capture_frames or len(sources) != len(capture_frames):
        raise RuntimeError(f"capture mismatch: frames={captured}, screenshots={len(sources)}")

    reports = []
    for frame, source in zip(capture_frames, sources, strict=True):
        target = args.output_dir / f"story_{frame:05d}.png"
        shutil.copy2(source, target)
        with Image.open(target) as image:
            if image.size != NATIVE_DISPLAY:
                raise AssertionError(f"frame {frame} is not native 224x144")
            rgb = image.convert("RGB")
            nonblack = sum(pixel != (0, 0, 0) for pixel in rgb.get_flattened_data())
        if args.capture_memory:
            (args.output_dir / f"story_{frame:05d}_cpu.bin").write_bytes(memories[frame])
        reports.append({
            "frame": frame, "screenshot": target.name,
            "screenshot_sha256": sha256(target.read_bytes()),
            "nonblack_pixels": nonblack,
        })

    report = {
        "status": "PASS", "rom_sha256": sha256(args.rom.read_bytes()),
        "mesen_core_sha256": sha256(args.mesen_core.read_bytes()),
        "native_resolution": list(NATIVE_DISPLAY), "clean_boot": True,
        "uses_save_or_savestate": False, "capture_memory": args.capture_memory,
        "elapsed_seconds": round(time.monotonic() - started, 3), "captures": reports,
    }
    (args.output_dir / "story_probe_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
