#!/usr/bin/env python3
"""Capture the RC3 red-box PET states from independent clean Mesen boots.

The navigation routes are inherited from the proven v0.10 deep-PET validator.
This wrapper binds them to the reviewed RC3 ROM and its exact changed tile IDs,
updates only the expected visible labels, and prevents MesenCore 2.1.1's final
GUI-oriented Release call from aborting the otherwise completed headless worker.
The operating system releases the process-local core immediately on exit.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from dataclasses import replace
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_pet_deep_v0_10 as legacy  # noqa: E402


VERSION = "0.10.7-rc3"
EXPECTED_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
EXPECTED_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
ROUTE_ORDER = ("program", "program_alt", "chip", "data", "netnavi")
EXPECTED_LABELS = {
    "program_root": ("PROGRAM DECK", "Y2 CHIP FOLDER"),
    "program_start_toolbar": ("DECK FILE", "NAVIGATION", "NAVI CODE"),
    "program_alt_button": ("AUTO CONTROL",),
    "chip_folder": ("CHIP FOLDER", "Y2 PACK"),
    "chip_sort": ("NAME ATK", "TYPE"),
    "chip_backpack": ("BACKPACK",),
    "data_library": ("DATA LIBRARY",),
    "data_no_data": ("DATA LIBRARY",),
    "netnavi_root": ("NETNAVI",),
    "netnavi_stats": ("MENU Y4", "NETNAVI"),
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def bind_final_rom(rom: bytes, report: dict) -> None:
    if sha256(rom) != EXPECTED_ROM_SHA256:
        raise ValueError("runtime validator requires the reviewed RC3 ROM")
    for name, region in list(legacy.MAPS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.MAPS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    for name, region in list(legacy.TILE_BANKS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.TILE_BANKS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    legacy.PROGRAM_V10_TILE_IDS = tuple(
        int(value, 16) for value in report["groups"]["live_program_deck"]["changed_tile_ids"]
    )
    legacy.ROUTES = tuple(
        replace(
            route,
            captures=tuple(
                replace(capture, expected_labels=EXPECTED_LABELS[capture.name])
                for capture in route.captures
            ),
        )
        for route in legacy.ROUTES
    )


def disable_gui_release() -> None:
    original = legacy.configure_core

    def configure(lib) -> None:
        original(lib)
        lib.Release = lambda: None

    legacy.configure_core = configure


def build_montage(results: list[dict], output_dir: Path) -> dict:
    cards = []
    for route in results:
        for capture in route["captures"]:
            path = output_dir / route["route"] / capture["screenshot"]["file"]
            with Image.open(path) as source:
                image = source.convert("RGB").resize((448, 288), Image.Resampling.NEAREST)
            card = Image.new("RGB", (448, 314), (20, 20, 20))
            card.paste(image, (0, 26))
            ImageDraw.Draw(card).text((7, 7), capture["state"].replace("_", " ").upper(), fill="white")
            cards.append(card)
    columns, gap = 2, 8
    rows = (len(cards) + columns - 1) // columns
    montage = Image.new(
        "RGB",
        (columns * 448 + gap, rows * 314 + (rows - 1) * gap),
        (8, 8, 8),
    )
    for index, card in enumerate(cards):
        montage.paste(card, ((index % columns) * (448 + gap), (index // columns) * (314 + gap)))
    path = output_dir / "redbox_pet_runtime_montage_v0_10_7_rc3.png"
    montage.save(path, optimize=False)
    return {"file": path.name, "sha256": sha256(path.read_bytes()), "dimensions": list(montage.size)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.wsc")
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "docs/runtime_v0_10_7_rc3/pet_deep")
    parser.add_argument("--route", choices=ROUTE_ORDER)
    parser.add_argument("--assemble", action="store_true")
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    core = args.mesen_core.read_bytes()
    report = json.loads((ROOT / "translation/assets/redbox_font_asset_report_v0_10_7_rc3.json").read_text())
    if sha256(core) != EXPECTED_CORE_SHA256:
        raise ValueError("MesenCore differs from the user-supplied 2.1.1 build")
    bind_final_rom(rom, report)
    args.output_dir.mkdir(parents=True, exist_ok=True)

    if args.assemble:
        results = [
            json.loads((args.output_dir / name / "route_report.json").read_text())
            for name in ROUTE_ORDER
        ]
        captures = [capture for route in results for capture in route["captures"]]
        if len(captures) != 10:
            raise AssertionError("expected ten reviewed runtime states")
        if not all(capture["runtime_map"]["exact_match"] for capture in captures):
            raise AssertionError("a live map differs from the RC3 ROM")
        if not all(capture["runtime_tiles"]["exact_match"] for capture in captures):
            raise AssertionError("live tiles differ from the RC3 ROM")
        post_process_cleanup = []
        for name in ROUTE_ORDER:
            home = args.output_dir / name / "mesen_home"
            if not home.exists():
                continue
            files = sorted(str(path.relative_to(home)) for path in home.rglob("*") if path.is_file())
            shutil.rmtree(home)
            post_process_cleanup.append({"route": name, "files_removed": files})
        montage = build_montage(results, args.output_dir)
        final = {
            "status": "PASS", "version": VERSION,
            "validation": "ten native PET states from five independent clean boots",
            "rom_sha256": EXPECTED_ROM_SHA256,
            "mesen_core_sha256": EXPECTED_CORE_SHA256,
            "clean_boot_routes": len(results), "native_captures": len(captures),
            "uses_sav_or_savestate": False,
            "all_live_maps_match_final_rom": True,
            "all_live_tiles_match_final_rom": True,
            "post_process_mesen_home_cleanup": post_process_cleanup,
            "all_mesen_homes_removed": True,
            "routes": results, "montage": montage,
        }
        output = args.output_dir / "redbox_pet_runtime_validation_v0_10_7_rc3.json"
        output.write_text(json.dumps(final, ensure_ascii=False, indent=2) + "\n")
        print(json.dumps({k: final[k] for k in ("status", "version", "clean_boot_routes", "native_captures")}, indent=2))
        return 0

    if not args.route:
        parser.error("choose --route for one clean process or --assemble after all five routes")
    disable_gui_release()
    result = legacy.run_route({
        "route": args.route,
        "rom": str(args.rom),
        "core": str(args.mesen_core),
        "output": str(args.output_dir / args.route),
        "timeout": args.timeout,
    })
    # run_route writes before returning; replace it with the RC3-bound result.
    (args.output_dir / args.route / "route_report.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2) + "\n"
    )
    print(json.dumps({
        "status": "PASS", "route": result["route"],
        "captures": [capture["state"] for capture in result["captures"]],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
