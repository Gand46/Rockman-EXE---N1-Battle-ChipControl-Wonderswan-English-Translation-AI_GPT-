#!/usr/bin/env python3
"""Validate the repaired Battle Chip GP class-selection screen in MesenCore.

The route starts from a clean boot and does not use SRAM or a savestate.  It
enters BATTLE CHIP GP, advances the introductory Yai sequence and captures the
class/tournament screen twice.  The validator then proves that:

* the auxiliary pointer table and repaired text pool are the reviewed assets;
* A CLS through E CLS remain inside their original 16-byte slots;
* E CLS occupies only BG character columns 3..7, leaving columns 8/9 clear;
* the cursor and all three 16x16 OBJ icons are still present in both sprite
  tables, including the formerly hidden green icon at x=64..79; and
* the native screenshot actually contains the cursor and green/yellow/pink
  icon pixels.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import struct
import threading
import time
from pathlib import Path

from PIL import Image

import n1tool


VERSION = "0.10.6"
ROM_SIZE = 0x400000
EXPECTED_ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
MESEN_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"

MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
MEM_CPU = 13

CAPTURE_FRAMES = (31000, 31500)
STOP_FRAME = CAPTURE_FRAMES[-1] + 1

POINTER_START = 0x34AB10
POINTER_COUNT = 208
POINTER_LENGTH = POINTER_COUNT * 2
POINTER_SHA256 = "d962913d3b8efb61d9017e5cc1105b8c033c70dfa0db36d7882704075426ce6d"
POOL_START = 0x34ACB0
POOL_LENGTH = 0x0AAE
POOL_SHA256 = "bcb9c0093906398fc80e276e6d9adf7e311e294e847dbd5791f975381d6755cf"
SLOT_LENGTH = 16
END_WORD = n1tool.CONTROL_WORDS["END"]
CLASS_TARGETS = {
    0x1F: 0x34AE76,
    0x20: 0x34AE86,
    0x21: 0x34AE96,
    0x22: 0x34AEA6,
    0x23: 0x34AEB6,
}
CLASS_LABELS = {
    index: f"{letter} CLS"
    for index, letter in zip(range(0x1F, 0x24), "ABCDE")
}

BG_FRAME_MAP_BASE = 0x2000
BG_TEXT_MAP_BASES = (0x2800, 0x3000)
MAP_SIZE = 0x0800
BLANK_TEXT_CELL = 0x21C3
EXPECTED_E_CLS_TOP = (0x0106, 0x0108, 0x010A, 0x010C, 0x010E)
EXPECTED_E_CLS_BOTTOM = (0x0107, 0x0109, 0x010B, 0x010D, 0x010F)

SPRITE_TABLE_BASES = (0x1C00, 0x1E00)
SPRITE_TABLE_CAPTURE_LENGTH = 0x200
SPRITE_GROUPS = {
    "cursor": (
        (0x00, 0x00, 8, 8),
        (0x01, 0x00, 8, 16),
        (0x02, 0x00, 16, 8),
        (0x03, 0x00, 16, 16),
    ),
    "pink_icon": (
        (0x14, 0x04, 8, 96),
        (0x15, 0x04, 8, 104),
        (0x16, 0x04, 16, 96),
        (0x17, 0x04, 16, 104),
    ),
    "yellow_icon": (
        (0x10, 0x04, 8, 80),
        (0x11, 0x04, 8, 88),
        (0x12, 0x04, 16, 80),
        (0x13, 0x04, 16, 88),
    ),
    "green_icon": (
        (0x0C, 0x04, 8, 64),
        (0x0D, 0x04, 8, 72),
        (0x0E, 0x04, 16, 64),
        (0x0F, 0x04, 16, 72),
    ),
}

EXPECTED_CAPTURE_SHA256 = {
    31000: "dea8fea43f9e77cc37af75eb4b3ada3f01ddd1c7879e666572098ae48d1e15fe",
    31500: "83ca36f86252e75b80fcbe3c90b42a04e2ac67ef8a4726b7de352d0102e9d320",
}
EXPECTED_RGB_CROP_SHA256 = {
    "31000:top_panel": "2797ae1d3a06eedbcc8cb5ad5b0dc0b8f93045d8139b4b4b393a23433b88e70c",
    "31000:cursor": "bc2ae32d7f6f910c010f2b28368eaf8c1258131724a3a187f7eea36d08cb63ee",
    "31000:green_icon": "666b0b4a9acbaf28b0fb3581ee7c993d0a6a4856bcdb7afcec82b79e6f7131a2",
    "31000:yellow_icon": "66242c9a2e0c6c9f649a377a85d6cc72ae2abf598de7a00593e9c9260ee883cd",
    "31000:pink_icon": "ec50bb8f7ec2cea3af9c1800c89892ffb07872f0ca90b2fc8e11c6e12b7176f9",
    "31500:top_panel": "8ffb05a60d0d8dc72e9518a720a614a61c87f2a4d73feca5108167ab6f487868",
    "31500:cursor": "2bc2db39868164f51391c44cb81b86da90e378be37b430aec968149f59548b39",
    "31500:green_icon": "1228c76e1d7aabcd97ce2ce9d0e34e04c7e3de9456bbb4229511e603393d573b",
    "31500:yellow_icon": "66242c9a2e0c6c9f649a377a85d6cc72ae2abf598de7a00593e9c9260ee883cd",
    "31500:pink_icon": "ec50bb8f7ec2cea3af9c1800c89892ffb07872f0ca90b2fc8e11c6e12b7176f9",
}
EXPECTED_MEMORY_SHA256 = {
    "bg_frame_map_2000_27ff.bin": "e5e2ded340cfc00705229cd79329babc3896522162e7cd57f9c034e1bf8bd9e4",
    "bg_text_map_2800_2fff.bin": "fbb1a35feb57fdb79f204e90081f6c8580b30a9b4bd3c16fe340650cb318fdb7",
    "bg_text_map_3000_37ff.bin": "fbb1a35feb57fdb79f204e90081f6c8580b30a9b4bd3c16fe340650cb318fdb7",
    "sprite_table_1c00_1dff.bin": "ad9b9e1a8f7352d0de7e917c1bda8b2f0f8dee94efef677ac8528f0d9580a0c4",
    "sprite_table_1e00_1fff.bin": "ad9b9e1a8f7352d0de7e917c1bda8b2f0f8dee94efef677ac8528f0d9580a0c4",
    "tile_ram_8000_bfff.bin": "bef7c89e02bfda81d04df6c99360e67725acd878f069b359076b9a59e56fb049",
    "rom_aux_pointers_34ab10_34acaf.bin": POINTER_SHA256,
    "rom_aux_pool_34acb0_34b75d.bin": POOL_SHA256,
}


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256(path.read_bytes())


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame < last


def input_for(frame: int) -> Controller:
    state = Controller()
    state.Start = pulse(frame, 650, 660)
    state.A = (
        pulse(frame, 950, 958)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or (27500 <= frame <= 31208 and frame % 300 < 8)
    )
    # The clean carousel starts at BATTLE PREP.  Two deliberate pulses reach
    # BATTLE CHIP GP without relying on held-key repeat timing.
    state.Right = pulse(frame, 26920, 26928) or pulse(frame, 27020, 27028)
    return state


def map_word(cpu: bytes, base: int, row: int, column: int) -> int:
    return struct.unpack_from("<H", cpu, base + (row * 32 + column) * 2)[0]


def words_until_end(payload: bytes, offset: int) -> list[int]:
    words: list[int] = []
    for position in range(offset, len(payload), 2):
        word = struct.unpack_from("<H", payload, position)[0]
        words.append(word)
        if word == END_WORD:
            return words
    raise ValueError(f"unterminated text at relative 0x{offset:04X}")


def sprite_records(payload: bytes, base: int) -> list[tuple[int, int, int, int]]:
    return [
        tuple(payload[base + offset:base + offset + 4])  # type: ignore[arg-type]
        for offset in range(0, SPRITE_TABLE_CAPTURE_LENGTH, 4)
    ]


def rgb_crop_hash(image: Image.Image, box: tuple[int, int, int, int]) -> str:
    return sha256(image.convert("RGB").crop(box).tobytes())


def count_pixels(
    image: Image.Image,
    box: tuple[int, int, int, int],
    predicate,
) -> int:
    crop = image.convert("RGB").crop(box)
    return sum(1 for pixel in crop.get_flattened_data() if predicate(*pixel))


def run_clean_route(
    rom: Path,
    mesen_core: Path,
    output_dir: Path,
    timeout: float,
) -> tuple[dict[int, Path], bytes, float, int]:
    if output_dir.exists():
        shutil.rmtree(output_dir)
    output_dir.mkdir(parents=True)
    home = output_dir / "_mesen_core_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(mesen_core.resolve()))
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause",
        "Resume", "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    reached = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for(completed + 1))
        if completed in CAPTURE_FRAMES:
            lib.TakeScreenshot()
        if completed >= STOP_FRAME:
            reached.set()

    listener = None
    started = time.monotonic()
    cpu = b""
    try:
        lib.InitDll()
        lib.InitializeEmu(str(home.resolve()).encode(), None, None, True, True, True, True)
        if not lib.LoadRom(str(rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore LoadRom failed")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("MesenCore notification callback failed")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached.wait(timeout):
            raise TimeoutError(f"class-selection route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.3)
        buffer = (ctypes.c_uint8 * 0x10000)()
        lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
        cpu = bytes(buffer)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        try:
            lib.Stop()
            lib.Release()
        except BaseException:
            pass

    deadline = time.monotonic() + 8.0
    while len(list(screenshot_dir.glob("*.png"))) < len(CAPTURE_FRAMES) and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(screenshot_dir.glob("*.png"))
    if len(sources) != len(CAPTURE_FRAMES):
        raise RuntimeError(
            f"expected {len(CAPTURE_FRAMES)} screenshots, found {len(sources)}"
        )
    captures: dict[int, Path] = {}
    capture_names = {
        31000: "class_selection_e_cls_v0_10_6.png",
        31500: "class_selection_info_v0_10_6.png",
    }
    for frame, source in zip(CAPTURE_FRAMES, sources, strict=True):
        destination = output_dir / capture_names[frame]
        shutil.copy2(source, destination)
        with Image.open(destination) as image:
            if image.size != (224, 144):
                raise RuntimeError(f"unexpected screenshot dimensions: {image.size}")
        captures[frame] = destination
    shutil.rmtree(home)
    return captures, cpu, time.monotonic() - started, completed


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--rom", type=Path,
        default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc",
    )
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument(
        "--output-dir", type=Path,
        default=root / "docs/runtime_v0_10_6/class_selection",
    )
    parser.add_argument("--timeout", default=150.0, type=float)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    if len(rom) != ROM_SIZE or sha256(rom) != EXPECTED_ROM_SHA256:
        raise ValueError("unexpected v0.10.6 ROM")
    if file_sha256(args.mesen_core) != MESEN_CORE_SHA256:
        raise ValueError("unexpected MesenCore build")

    pointer_asset = root / "translation/assets/aux_text_pointers_v0_9.bin"
    pool_asset = root / "translation/assets/aux_text_pool_v0_10_6.bin"
    pointers = rom[POINTER_START:POINTER_START + POINTER_LENGTH]
    pool = rom[POOL_START:POOL_START + POOL_LENGTH]
    pointer_bytes_exact = (
        sha256(pointers) == POINTER_SHA256
        and pointers == pointer_asset.read_bytes()
    )
    pool_bytes_exact = (
        sha256(pool) == POOL_SHA256
        and pool == pool_asset.read_bytes()
    )

    decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")
    class_rows: list[dict[str, object]] = []
    labels_exact = True
    targets_exact = True
    padding_exact = True
    for index, expected_label in CLASS_LABELS.items():
        relative = struct.unpack_from("<H", pointers, index * 2)[0] * 2
        target = POOL_START + relative
        words = words_until_end(pool, relative)
        text = "".join(n1tool.token_for(word, decode) for word in words).removesuffix("[END]")
        expected_words = [*n1tool.encode_text(expected_label, encode), END_WORD]
        expected_slot = n1tool.pack_words(
            expected_words + [END_WORD] * ((SLOT_LENGTH // 2) - len(expected_words))
        )
        slot = pool[relative:relative + SLOT_LENGTH]
        row_target_ok = target == CLASS_TARGETS[index]
        row_label_ok = text == expected_label
        row_padding_ok = slot == expected_slot
        targets_exact &= row_target_ok
        labels_exact &= row_label_ok
        padding_exact &= row_padding_ok
        class_rows.append({
            "pointer_id": f"05:{index:02X}",
            "pointer_table_offset": f"0x{POINTER_START + index * 2:06X}",
            "target": f"0x{target:06X}",
            "target_exact": row_target_ok,
            "decoded": text,
            "label_exact": row_label_ok,
            "slot_sha256": sha256(slot),
            "slot_padding_exact": row_padding_ok,
        })

    captures, cpu, elapsed, completed = run_clean_route(
        args.rom, args.mesen_core, args.output_dir, args.timeout,
    )

    memory_dir = args.output_dir / "memory"
    memory_dir.mkdir(exist_ok=True)
    memory_payloads = {
        "cpu_full_0000_ffff.bin": cpu,
        "bg_frame_map_2000_27ff.bin": cpu[BG_FRAME_MAP_BASE:BG_FRAME_MAP_BASE + MAP_SIZE],
        "bg_text_map_2800_2fff.bin": cpu[0x2800:0x3000],
        "bg_text_map_3000_37ff.bin": cpu[0x3000:0x3800],
        "sprite_table_1c00_1dff.bin": cpu[0x1C00:0x1E00],
        "sprite_table_1e00_1fff.bin": cpu[0x1E00:0x2000],
        "tile_ram_8000_bfff.bin": cpu[0x8000:0xC000],
        "rom_aux_pointers_34ab10_34acaf.bin": pointers,
        "rom_aux_pool_34acb0_34b75d.bin": pool,
    }
    memory_rows: dict[str, dict[str, object]] = {}
    memory_hashes_exact = True
    for name, payload in memory_payloads.items():
        path = memory_dir / name
        path.write_bytes(payload)
        digest = sha256(payload)
        expected = EXPECTED_MEMORY_SHA256.get(name)
        exact = expected is None or digest == expected
        memory_hashes_exact &= exact
        memory_rows[name] = {
            "length": len(payload),
            "sha256": digest,
            "expected_sha256": expected,
            "exact": exact,
        }

    map_rows: dict[str, dict[str, object]] = {}
    bg_labels_exact = True
    released_columns_exact = True
    map_mirrors_exact = True
    for base in BG_TEXT_MAP_BASES:
        top = tuple(map_word(cpu, base, 1, column) for column in range(3, 10))
        bottom = tuple(map_word(cpu, base, 2, column) for column in range(3, 10))
        label_exact = (
            top[:5] == EXPECTED_E_CLS_TOP
            and bottom[:5] == EXPECTED_E_CLS_BOTTOM
        )
        released = (
            top[5:] == (BLANK_TEXT_CELL, BLANK_TEXT_CELL)
            and bottom[5:] == (BLANK_TEXT_CELL, BLANK_TEXT_CELL)
        )
        bg_labels_exact &= label_exact
        released_columns_exact &= released
        map_rows[f"0x{base:04X}"] = {
            "row_1_columns_3_9": [f"0x{value:04X}" for value in top],
            "row_2_columns_3_9": [f"0x{value:04X}" for value in bottom],
            "e_cls_columns_3_7_exact": label_exact,
            "released_columns_8_9_exact": released,
        }
    map_mirrors_exact = (
        cpu[0x2800:0x3000] == cpu[0x3000:0x3800]
    )

    sprite_rows: dict[str, object] = {}
    sprite_icons_exact = True
    sprite_tables_equal = (
        cpu[0x1C00:0x1E00] == cpu[0x1E00:0x2000]
    )
    for base in SPRITE_TABLE_BASES:
        groups: dict[str, object] = {}
        for name, expected in SPRITE_GROUPS.items():
            needle = b"".join(bytes(record) for record in expected)
            table = cpu[base:base + SPRITE_TABLE_CAPTURE_LENGTH]
            occurrences = [
                offset
                for offset in range(0, len(table) - len(needle) + 1, 4)
                if table[offset:offset + len(needle)] == needle
            ]
            # At the final frame the cursor is intentionally in its blink-OFF
            # phase.  Its exact visible pixels are checked in frame 31000;
            # the three permanent icon groups must each occur exactly once in
            # both complete double-buffered OBJ tables.
            exact = len(occurrences) == 1 if name != "cursor" else len(occurrences) <= 1
            if name != "cursor":
                sprite_icons_exact &= exact
            groups[name] = {
                "expected": [list(record) for record in expected],
                "occurrence_offsets": [f"0x{base + offset:04X}" for offset in occurrences],
                "blink_phase_allowed": name == "cursor",
                "exact": exact,
            }
        sprite_rows[f"0x{base:04X}"] = groups

    capture_rows: dict[str, dict[str, object]] = {}
    capture_hashes_exact = True
    crop_hashes_exact = True
    visual_checks: dict[str, bool] = {}
    for frame, path in captures.items():
        digest = file_sha256(path)
        expected = EXPECTED_CAPTURE_SHA256.get(frame)
        exact = expected is None or digest == expected
        capture_hashes_exact &= exact
        with Image.open(path) as source:
            image = source.convert("RGB")
            crop_hashes = {
                "top_panel": rgb_crop_hash(image, (0, 0, 144, 80)),
                "cursor": rgb_crop_hash(image, (8, 8, 24, 24)),
                "green_icon": rgb_crop_hash(image, (64, 8, 80, 24)),
                "yellow_icon": rgb_crop_hash(image, (80, 8, 96, 24)),
                "pink_icon": rgb_crop_hash(image, (96, 8, 112, 24)),
            }
            crop_exact: dict[str, bool] = {}
            for crop_name, crop_digest in crop_hashes.items():
                key = f"{frame}:{crop_name}"
                expected_crop = EXPECTED_RGB_CROP_SHA256.get(key)
                crop_exact[crop_name] = expected_crop is None or crop_digest == expected_crop
                crop_hashes_exact &= crop_exact[crop_name]

            green_icon_pixels = count_pixels(
                image, (64, 8, 80, 24),
                lambda red, green, blue: green >= 160 and green > red + 30 and green > blue + 30,
            )
            yellow_icon_pixels = count_pixels(
                image, (80, 8, 96, 24),
                lambda red, green, blue: red >= 180 and green >= 150 and blue <= 150,
            )
            pink_icon_pixels = count_pixels(
                image, (96, 8, 112, 24),
                lambda red, green, blue: red >= 190 and blue >= 130 and green <= 210,
            )
            cursor_green_pixels = count_pixels(
                image, (8, 8, 24, 24),
                lambda red, green, blue: green >= 160 and green > red + 30 and green > blue + 30,
            )
        visual_checks[f"green_icon_visible_{frame}"] = green_icon_pixels >= 30
        visual_checks[f"yellow_icon_visible_{frame}"] = yellow_icon_pixels >= 20
        visual_checks[f"pink_icon_visible_{frame}"] = pink_icon_pixels >= 20
        # The cursor intentionally blinks.  It is required in the first frame;
        # its OBJ records remain mandatory in both frame phases.
        if frame == CAPTURE_FRAMES[0]:
            visual_checks[f"cursor_visible_{frame}"] = cursor_green_pixels >= 20
        capture_rows[str(frame)] = {
            "file": path.name,
            "sha256": digest,
            "expected_sha256": expected,
            "exact": exact,
            "dimensions": [224, 144],
            "rgb_crop_sha256": crop_hashes,
            "crop_hashes_exact": crop_exact,
            "color_pixel_counts": {
                "cursor_green": cursor_green_pixels,
                "green_icon": green_icon_pixels,
                "yellow_icon": yellow_icon_pixels,
                "pink_icon": pink_icon_pixels,
            },
        }

    checks = {
        "clean_boot_without_save_or_savestate": True,
        "expected_rom_sha256": sha256(rom) == EXPECTED_ROM_SHA256,
        "expected_mesen_core_sha256": file_sha256(args.mesen_core) == MESEN_CORE_SHA256,
        "aux_pointer_table_exact": pointer_bytes_exact,
        "aux_pool_exact": pool_bytes_exact,
        "class_pointer_targets_exact": targets_exact,
        "class_labels_a_cls_through_e_cls_exact": labels_exact,
        "class_slots_end_padded_exact": padding_exact,
        "e_cls_bg_cells_3_7_exact": bg_labels_exact,
        "bg_columns_8_9_released": released_columns_exact,
        "bg_text_map_copies_identical": map_mirrors_exact,
        "sprite_tables_identical": sprite_tables_equal,
        "green_yellow_pink_obj_records_exact": sprite_icons_exact,
        "capture_hashes_exact": capture_hashes_exact,
        "crop_hashes_exact": crop_hashes_exact,
        "memory_hashes_exact": memory_hashes_exact,
        **visual_checks,
    }
    failures = [name for name, passed in checks.items() if not passed]
    report = {
        "validation": "n1-class-selection-runtime-v0.10.6",
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "rom": {
            "file": args.rom.name,
            "sha256": sha256(rom),
        },
        "native_resolution": [224, 144],
        "inputs": {
            "rom_file": args.rom.name,
            "rom_sha256": sha256(rom),
            "mesen_core_file": args.mesen_core.name,
            "mesen_core_sha256": file_sha256(args.mesen_core),
            "uses_bios": False,
            "uses_input_save_or_savestate": False,
        },
        "route": {
            "clean_boot": True,
            "start_pulse": [650, 659],
            "intro_progress": "A pulse every 300 frames through 26700",
            "carousel_navigation": "two Right pulses from BATTLE PREP to BATTLE CHIP GP",
            "battlechip_gp_entry_and_yai_progress": "A pulse every 300 frames through frame 31200",
            "capture_frames": list(CAPTURE_FRAMES),
            "completed_frames": completed,
            "elapsed_seconds": round(elapsed, 3),
        },
        "class_labels": class_rows,
        "bg_text_maps": map_rows,
        "sprite_tables": sprite_rows,
        "captures": capture_rows,
        "memory": memory_rows,
        "checks": checks,
    }
    report_path = args.output_dir / "class_selection_runtime_validation_v0_10_6.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    if failures:
        raise SystemExit(f"class-selection validation failed: {', '.join(failures)}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
