#!/usr/bin/env python3
"""Derive the cumulative v0.10.6 manifest from the reviewed v0.10.5 one."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import compose_release_v0_10_6 as release


BASE_MANIFEST_SHA256 = "f385794c3b105d095305114d5c0bca635aca6e30a135563c097d0457d09d85a9"
SCOPE = (
    "v0.10.6 static-interface correction: rebuilds 25 graphical labels from "
    "the supplied BN5DSEU Font Thin and SF3FontSmall sources, then applies "
    "deterministic native pixel-art masks to repair ambiguous small-size TTF "
    "hinting. No word or line is scaled, filtered, condensed or antialiased; "
    "lower-only shadows preserve a full composite separator between glyphs. "
    "The five Battle Chip GP class labels are shortened in place from A CLASS "
    "through E CLASS to A CLS through E CLS, releasing the two BG cells that "
    "covered the green selection icon without moving any pointer. Bottom "
    "dialogue boxes, dialogue strings, dynamic rank E, 3000Z, shop prices and "
    "the Free Battle numeric streak counter are retained. All v0.10.5 text, "
    "six-character chip-effect labels, graphics and prior corrections remain "
    "byte-identical outside the 21 guarded spans and checksum."
)


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base", type=Path, default=root / "translation/en_v0_10_5.json")
    parser.add_argument("--assets", type=Path, default=root / "translation/assets")
    parser.add_argument(
        "--asset-report", type=Path,
        default=root / "translation/assets/ttf_static_ui_asset_report_v0_10_6.json",
    )
    parser.add_argument(
        "--class-report", type=Path,
        default=root / "translation/assets/class_selection_labels_report_v0_10_6.json",
    )
    parser.add_argument("--output", type=Path, default=root / "translation/en_v0_10_6.json")
    args = parser.parse_args()

    base_bytes = args.base.read_bytes()
    if sha256(base_bytes) != BASE_MANIFEST_SHA256:
        raise ValueError("v0.10.5 manifest differs from the reviewed source")
    manifest = json.loads(base_bytes)
    if manifest.get("project_version") != "0.10.5":
        raise ValueError("unexpected source manifest version")
    asset_report = json.loads(args.asset_report.read_text(encoding="utf-8"))
    if asset_report.get("status") != "PASS" or asset_report.get("version") != "0.10.6":
        raise ValueError("v0.10.6 asset report is not final")
    class_report = json.loads(args.class_report.read_text(encoding="utf-8"))
    if class_report.get("status") != "PASS" or class_report.get("version") != "0.10.6":
        raise ValueError("v0.10.6 class-label report is not final")

    rows = manifest.get("binary_entries", [])
    by_id = {row["id"]: row for row in rows}
    if len(by_id) != len(rows):
        raise ValueError("duplicate binary entry ID")
    outputs = {**asset_report["outputs"], **class_report["outputs"]}
    updated = []
    for patch in release.PATCHES:
        row = by_id.get(patch.id)
        if row is None:
            raise ValueError(f"manifest is missing {patch.id}")
        if int(row["offset"], 16) != patch.offset or row["length"] != patch.length:
            raise ValueError(f"manifest geometry differs for {patch.id}")
        asset = args.assets / patch.file
        payload = asset.read_bytes()
        output = outputs.get(patch.file)
        if (
            len(payload) != patch.length
            or output is None
            or output.get("length") != patch.length
            or output.get("sha256") != sha256(payload)
        ):
            raise ValueError(f"asset/report mismatch for {patch.id}")
        row["asset"] = f"assets/{patch.file}"
        row["asset_sha256"] = sha256(payload)
        updated.append(patch.id)

    manifest["project_version"] = "0.10.6"
    manifest["scope"] = SCOPE
    if len(manifest.get("entries", [])) != 271 or len(rows) != 77:
        raise ValueError("translation coverage changed unexpectedly")
    if len(updated) != 21:
        raise ValueError("expected exactly 21 guarded replacement spans")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(
        json.dumps(manifest, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    report = {
        "status": "PASS",
        "version": "0.10.6",
        "base_manifest_sha256": sha256(base_bytes),
        "output_manifest": args.output.name,
        "output_manifest_sha256": sha256(args.output.read_bytes()),
        "text_entries": 271,
        "binary_entries": 77,
        "updated_binary_entries": updated,
        "dialogue_entries_changed": 0,
    }
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
