#!/usr/bin/env python3
"""Validate RC3 Program Deck statistics at native pixels in a clean boot."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_program_deck_v0_10_3 as route  # noqa: E402
from quality_graphics_assets_v0_10_3 import render_program_page  # noqa: E402


VERSION = "0.10.7-rc3"
EXPECTED_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
EXPECTED_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
FRAME_ASSETS = {
    17400: "program_deck_manual_stats_bg0_map_v0_10_7_rc3.bin",
    21600: "program_deck_manual_order_bg0_map_v0_10_3.bin",
    23400: "program_deck_manual_tool_bg0_map_v0_10_3.bin",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def disable_gui_release() -> None:
    original = route.ctypes.CDLL

    def load(path):
        lib = original(path)
        lib.Release = lambda: None
        return lib

    route.ctypes.CDLL = load


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.wsc")
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=ROOT / "docs/runtime_v0_10_7_rc3/program_deck")
    parser.add_argument("--timeout", type=float, default=150.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    if sha256(rom) != EXPECTED_ROM_SHA256:
        raise ValueError("Program Deck runtime validator requires the reviewed RC3 ROM")
    if sha256(args.mesen_core.read_bytes()) != EXPECTED_CORE_SHA256:
        raise ValueError("MesenCore differs from the user-supplied 2.1.1 build")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    disable_gui_release()
    completed, elapsed, memory, screenshots = route.run_mesen(
        args.rom, args.mesen_core, args.output_dir, args.timeout,
    )

    captures = []
    screenshot_by_frame = {}
    for frame, source in zip(route.CAPTURE_FRAMES, screenshots, strict=True):
        page = route.PAGES[frame]
        name = str(page["name"])
        destination = args.output_dir / f"program_deck_{name}_{frame}.png"
        shutil.copy2(source, destination)
        screenshot_by_frame[frame] = destination
        cpu = memory[frame]
        cpu_path = args.output_dir / f"program_deck_{name}_{frame}_cpu.bin"
        cpu_path.write_bytes(cpu)

        expected_map = (ROOT / "translation/assets" / FRAME_ASSETS[frame]).read_bytes()
        live_map = cpu[route.MAP_VRAM_ADDRESS:route.MAP_VRAM_ADDRESS + 0x400]
        if live_map != expected_map:
            raise AssertionError(f"{name}: live BG0 map differs from final asset")
        tile_offset = int(page["tile_rom_offset"])
        tile_length = int(page["tile_vram_length"])
        expected_tiles = rom[tile_offset:tile_offset + tile_length]
        live_tiles = cpu[route.TILE_VRAM_ADDRESS:route.TILE_VRAM_ADDRESS + tile_length]
        if live_tiles != expected_tiles:
            raise AssertionError(f"{name}: live tiles differ from final ROM")
        with Image.open(destination) as image:
            if image.size != route.NATIVE_SIZE:
                raise AssertionError(f"{name}: capture is not 224x144")
        captures.append({
            "frame": frame, "page": name, "screenshot": destination.name,
            "screenshot_sha256": sha256(destination.read_bytes()),
            "cpu_dump": cpu_path.name, "cpu_dump_sha256": sha256(cpu),
            "live_map_matches_asset": True, "live_tiles_match_final_rom": True,
        })

    stats_map = (ROOT / "translation/assets" / FRAME_ASSETS[17400]).read_bytes()
    manual_tiles = (ROOT / "translation/assets/program_deck_manual_internal_tiles_v0_10_7_rc3.bin").read_bytes()
    expected_top = render_program_page(stats_map, manual_tiles, "stats")
    with Image.open(screenshot_by_frame[17400]) as image:
        native = image.convert("RGB")
        actual_top = native.crop((0, 0, 224, 80))
        bottom = native.crop((0, 80, 224, 144))
    if ImageChops.difference(actual_top, expected_top).getbbox() is not None:
        raise AssertionError("runtime statistics pixels differ from active-palette asset render")

    historical = ROOT / "docs/runtime_v0_10_3/program_deck/program_deck_stats_17400.png"
    with Image.open(historical) as image:
        historical_bottom = image.convert("RGB").crop((0, 80, 224, 144))
    if ImageChops.difference(bottom, historical_bottom).getbbox() is not None:
        raise AssertionError("lower dialogue region changed on the statistics route")

    home = args.output_dir / "mesen_core_home"
    persistence_files = sorted(
        str(path.relative_to(home))
        for path in home.rglob("*")
        if path.is_file() and ("Saves" in path.parts or "SaveStates" in path.parts)
    )
    if home.exists():
        shutil.rmtree(home)

    report = {
        "status": "PASS", "version": VERSION,
        "validation": "Program Deck pages from one clean MesenCore boot",
        "rom_sha256": EXPECTED_ROM_SHA256,
        "mesen_core_sha256": EXPECTED_CORE_SHA256,
        "clean_boot": True, "uses_sav_or_savestate": False,
        "native_resolution": list(route.NATIVE_SIZE),
        "last_callback_frame": completed, "elapsed_seconds": round(elapsed, 3),
        "captures": captures,
        "stats_top_224x80_matches_active_palette_asset_pixel_exactly": True,
        "lower_dialogue_region_matches_approved_reference_pixel_exactly": True,
        "runtime_generated_persistence_files_removed": persistence_files,
        "mesen_home_removed_after_capture": True,
    }
    output = args.output_dir / "program_deck_runtime_validation_v0_10_7_rc3.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps({
        "status": report["status"], "captures": len(captures),
        "native_pixel_match": True, "lower_dialogue_unchanged": True,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
