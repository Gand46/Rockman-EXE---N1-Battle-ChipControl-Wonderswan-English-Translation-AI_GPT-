#!/usr/bin/env python3
"""Reproduce the v0.9 static audit of the ending dialogue and credits."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import struct
import sys
from pathlib import Path


FINAL_SHA256 = "979a70252fdbec47b75f50b2959897cf4258029fb59b572b13027e393f8508f3"
CODE_START, CODE_END = 0x33ACE8, 0x33AEEA
CODE_SHA256 = "13fdfacc8f66625cff72041125d0ef9d2362a89f600babe2000c29a867ca2794"
TABLE_START, POOL_START, POOL_END = 0x34AB10, 0x34ACB0, 0x34B75E
TABLE_SHA256 = "d962913d3b8efb61d9017e5cc1105b8c033c70dfa0db36d7882704075426ce6d"
POOL_SHA256 = "40de4032c9e02e40eb776ade4a58881b0a6144d4492ff2566a93bb116968e749"
CREDIT_FIRST, CREDIT_LAST = 0x96, 0xCF
ENDING_IDS = ("master_tournament_ending_1", "master_tournament_ending_2")


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def contains_japanese(text: str) -> bool:
    return any(
        "\u3040" <= char <= "\u30ff"
        or "\u3400" <= char <= "\u4dbf"
        or "\u4e00" <= char <= "\u9fff"
        for char in text
    )


def load_n1tool(root: Path):
    path = root / "tools/n1tool.py"
    spec = importlib.util.spec_from_file_location("n1tool_credits_audit", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def hexoff(value: int) -> str:
    return f"0x{value:06X}"


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--rom", type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    rom_path = (args.rom or root / "build/Rockman_EXE_N1_Battle_English_v0.9.wsc").resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_9.json").resolve()
    report_path = (args.report or root / "docs/CREDITS_ENDING_AUDIT_v0_9.json").resolve()
    rom = rom_path.read_bytes()
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    n1tool = load_n1tool(root)
    decode, _ = n1tool.load_table(root / "tables/n1battle_jp.tbl")

    failures: list[str] = []
    if sha256(rom) != FINAL_SHA256:
        failures.append("unexpected final ROM SHA-256")
    code = rom[CODE_START:CODE_END]
    if sha256(code) != CODE_SHA256:
        failures.append("credits state-machine code hash mismatch")
    if sha256(rom[TABLE_START:POOL_START]) != TABLE_SHA256:
        failures.append("group-5 pointer-table hash mismatch")
    if sha256(rom[POOL_START:POOL_END]) != POOL_SHA256:
        failures.append("group-5 pool hash mismatch")

    signatures = {
        "group5_table_segment_and_slot00": (0x33ADCD, "b8b14a8ec026a10000"),
        "render_count_bound_0x3a": (0x33ADEA, "26837f043a"),
        "slot96_displacement_0x012c": (0x33AE0C, "b8b14a8ec0268b872c01"),
        "scroll_delay_bound_0x3e": (0x33AE31, "26837f043e"),
    }
    signature_results = {}
    for name, (offset, expected_hex) in signatures.items():
        actual = rom[offset : offset + len(bytes.fromhex(expected_hex))].hex()
        ok = actual == expected_hex
        signature_results[name] = {
            "offset": hexoff(offset), "expected_hex": expected_hex,
            "actual_hex": actual, "result": "PASS" if ok else "FAIL",
        }
        if not ok:
            failures.append(f"code signature mismatch: {name}")

    far_calls = []
    for cursor in range(CODE_START, CODE_END - 4):
        if rom[cursor] != 0x9A:
            continue
        target_offset, target_segment = struct.unpack_from("<HH", rom, cursor + 1)
        far_calls.append({
            "callsite": hexoff(cursor),
            "target": f"{target_segment:04X}:{target_offset:04X}",
        })
    known_graphics_loader_targets = {"205C:0002", "205C:0041"}
    graphics_calls = [call for call in far_calls if call["target"] in known_graphics_loader_targets]
    if graphics_calls:
        failures.append("known ROM graphics loader called inside credits state machine")

    slots = []
    unique_targets: set[int] = set()
    japanese_slots = 0
    unterminated_slots = 0
    for index in range(CREDIT_FIRST, CREDIT_LAST + 1):
        pointer_address = TABLE_START + index * 2
        relative_words = struct.unpack_from("<H", rom, pointer_address)[0]
        target = POOL_START + relative_words * 2
        in_bounds = POOL_START <= target < POOL_END and not (target & 1)
        words = n1tool.words_at(rom, target, POOL_END) if in_bounds else []
        terminated = bool(words) and words[-1][1] == n1tool.CONTROL_WORDS["END"]
        text = "".join(n1tool.token_for(word, decode) for _, word in words)
        japanese = contains_japanese(text)
        if not in_bounds:
            failures.append(f"credit slot 05:{index:02X} out of bounds")
        if not terminated:
            unterminated_slots += 1
            failures.append(f"credit slot 05:{index:02X} lacks END")
        if japanese:
            japanese_slots += 1
            failures.append(f"credit slot 05:{index:02X} contains Japanese")
        if in_bounds:
            unique_targets.add(target)
        encoded = rom[target : words[-1][0] + 2] if words else b""
        slots.append({
            "id": f"05:{index:02X}", "pointer_address": hexoff(pointer_address),
            "relative_words": f"0x{relative_words:04X}", "target": hexoff(target),
            "in_bounds": in_bounds, "terminator": "END" if terminated else "MISSING",
            "contains_japanese": japanese, "encoded_sha256": sha256(encoded), "text": text,
        })

    by_id = {item.get("id"): item for item in manifest.get("entries", [])}
    endings = []
    for entry_id in ENDING_IDS:
        entry = by_id.get(entry_id)
        if entry is None:
            failures.append(f"missing manifest entry {entry_id}")
            continue
        offset = int(entry["offset"], 0)
        length = int(entry["length"])
        words = n1tool.words_at(rom, offset, offset + length)
        terminated = bool(words) and words[-1][1] == n1tool.CONTROL_WORDS["END"]
        text = "".join(n1tool.token_for(word, decode) for _, word in words)
        japanese = contains_japanese(text)
        if not terminated:
            failures.append(f"ending entry {entry_id} lacks END")
        if japanese:
            failures.append(f"ending entry {entry_id} contains Japanese")
        endings.append({
            "id": entry_id, "offset": hexoff(offset), "reserved_length": length,
            "decoded_bytes_through_end": len(words) * 2,
            "terminator": "END" if terminated else "MISSING",
            "contains_japanese": japanese,
            "encoded_sha256": sha256(rom[offset : words[-1][0] + 2]) if words else sha256(b""),
            "text": text,
        })

    try:
        portable_rom_path = rom_path.relative_to(root).as_posix()
    except ValueError:
        portable_rom_path = str(rom_path)

    report = {
        "format": "n1battle-credits-ending-static-audit-v1",
        "project_version": "0.9.0",
        "overall_result": "PASS" if not failures else "FAIL",
        "rom": {"path": portable_rom_path, "size": len(rom), "sha256": sha256(rom)},
        "credits_state_machine": {
            "file_span": {"start": hexoff(CODE_START), "end_inclusive": hexoff(CODE_END - 1), "length": len(code)},
            "sha256": sha256(code),
            "signatures": signature_results,
            "interpretation": {
                "pointer_group": 5,
                "first_slot": "05:96", "last_slot": "05:CF", "rendered_slots": CREDIT_LAST - CREDIT_FIRST + 1,
                "reason": "state+4 is doubled, added to displacement 0x012C (= 0x96*2), and rendering stops at state+4 == 0x003A",
                "post_render_scroll_delay_bound": "0x003E",
            },
            "far_calls": far_calls,
            "known_dedicated_rom_graphics_loader_targets": sorted(known_graphics_loader_targets),
            "graphics_loader_calls_in_span": graphics_calls,
            "dedicated_graphical_text_resource_detected": False,
            "conclusion": "The credits routine uses group-5 encoded strings and the standard font renderers; it contains no call to the known ROM graphics loaders and no dedicated tile/tilemap pointer.",
        },
        "credits_text_window": {
            "pointer_table": {"start": hexoff(TABLE_START), "end_exclusive": hexoff(POOL_START), "sha256": sha256(rom[TABLE_START:POOL_START])},
            "pool": {"start": hexoff(POOL_START), "end_exclusive": hexoff(POOL_END), "sha256": sha256(rom[POOL_START:POOL_END])},
            "slot_count": len(slots), "unique_targets": len(unique_targets),
            "end_terminated_slots": len(slots) - unterminated_slots,
            "remaining_japanese_slots": japanese_slots, "slots": slots,
        },
        "ending_dialogue": {"record_count": len(endings), "remaining_japanese_records": sum(item["contains_japanese"] for item in endings), "records": endings},
        "graphics_denominator_impact": {"new_graphical_occurrences": 0, "existing_denominator": 75, "revised_denominator": 75, "reason": "No dedicated graphical credits title/label or graphics loader exists in the audited state machine."},
        "runtime_validation": {"status": "NOT_CONCLUDED", "reason": "A clean organic playthrough to the ending/credits was not completed. The temporary MesenCore RAM-injection probe did not obtain a writable WonderSwan CPU-memory wrapper; no QA ROM patch was created."},
        "scope_limitations": [
            "PASS is static for the exact final-ROM code span, all 58 credits slots, and both manifest ending-dialogue records.",
            "It does not replace an organic end-to-end runtime traversal of every post-ending transition or prove absence of Japanese pixels in unrelated shared scene artwork.",
        ],
        "final_rom_modified_by_audit": False,
        "failures": failures,
    }
    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"result": report["overall_result"], "report": str(report_path), "sha256": sha256(report_path.read_bytes())}, indent=2))
    return 0 if not failures else 1


if __name__ == "__main__":
    raise SystemExit(main())
