#!/usr/bin/env python3
"""Validate the canonical v0.10.2 manifest, ROM, IPS and title evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import validate_release_v0_9 as v09


PROJECT_VERSION = "0.10.2"
TEXT_ENTRY_COUNT = 271
BINARY_ENTRY_COUNT = 75
TEXT_DENOMINATOR = 1552
GRAPHICS_DENOMINATOR = 129
BASE_GRAPHICS_DENOMINATOR = 75
NEW_GRAPHICS_DENOMINATOR = 54

FINAL_ROM_SHA256 = "b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24"
BASELINE_V0101_SHA256 = "5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b"

TITLE_MAP_OFFSET = 0x0409A6
TITLE_MAP_LENGTH = 0x0480
TITLE_MAP_EDITABLE_ROWS = 14
TITLE_MAP_ROW_BYTES = 32 * 2
TITLE_MAP_SOURCE_SHA256 = "d873b618f601aad1430fe2bb99b68966808d0aeac0f52223f8c58d245391ff56"
TITLE_MAP_OUTPUT_SHA256 = "d16eaa95a1829c462f2e036fa4cde8c8c5416579cb8f0a00c128132358535036"

TITLE_TILES_OFFSET = 0x071BC0
TITLE_TILES_LENGTH = 0x1A00
TITLE_TILES_SOURCE_SHA256 = "a0d931ca05357275d2410dba82a61ee90dd7e673437e89e4f0b506945829c95c"
TITLE_TILES_OUTPUT_SHA256 = "70e121351d3077b8c4e89c6085ed85b0d0e4fc321c4dbbfc632657721e085d2b"

TITLE_PALETTE_OFFSET = 0x074C68
TITLE_PALETTE_LENGTH = 0x00A0
TITLE_PALETTE_SHA256 = "5bbabe397d4dec9fda37d9f6a2e0e5b871118eace3fb1790d8718ce9f7359602"

EFFECT_LABEL_SHA256 = "46d33f0f4c1320ad754696a92f6f98ef97424acf67f3f89d9fe1829fe68acd8e"


REPORT_SPECS = (
    {
        "id": "shop_purchase",
        "path": "translation/assets/shop_purchase_asset_report_v0_10.json",
        "format": "n1-shop-purchase-assets-v0.10",
        "occurrences": 3,
    },
    {
        "id": "pet_carousel",
        "path": "translation/assets/pet_carousel_remaining_asset_report_v0_10.json",
        "format": "n1-pet-carousel-remaining-assets-v0.10",
        "occurrences": 2,
    },
    {
        "id": "host_free",
        "path": "translation/assets/host_free_menu_asset_report_v0_10.json",
        "format": "n1-host-free-menu-assets-v0.10",
        "occurrences": 31,
    },
    {
        "id": "pet_runtime",
        "path": "translation/assets/pet_runtime_remaining_asset_report_v0_10.json",
        "format": "n1-pet-runtime-remaining-assets-v0.10",
        "occurrences": 18,
    },
)


def display_path(path: Path, root: Path) -> str:
    """Keep public reports reproducible without embedding a workspace path."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.name


def parse_manifest_spans(
    source: bytes, manifest: dict[str, Any]
) -> tuple[list[tuple[int, int, str, str]], list[dict[str, Any]], list[str]]:
    spans: list[tuple[int, int, str, str]] = []
    guards: list[dict[str, Any]] = []
    ids: list[str] = []
    for kind, rows in (
        ("text", manifest.get("entries", [])),
        ("binary", manifest.get("binary_entries", [])),
    ):
        if not isinstance(rows, list):
            raise ValueError(f"manifest {kind} entries are not a list")
        for index, entry in enumerate(rows):
            if not isinstance(entry, dict):
                raise ValueError(f"manifest {kind} entry {index} is not an object")
            entry_id = str(entry.get("id", f"{kind}_{index}"))
            offset = v09.number(entry["offset"])
            length = v09.number(entry["length"])
            end = offset + length
            ids.append(entry_id)
            spans.append((offset, end, entry_id, kind))
            in_bounds = length > 0 and 0 <= offset < end <= len(source) - 2
            expected_hex = str(entry.get("expected_hex", "")).replace(" ", "")
            expected_hash = str(entry.get("expected_sha256", "")).lower()
            guard_kind = "missing"
            guard_ok = False
            actual_hash = ""
            error = ""
            if in_bounds:
                payload = source[offset:end]
                actual_hash = v09.sha256(payload)
                try:
                    if expected_hex:
                        guard_kind = "expected_hex"
                        expected = bytes.fromhex(expected_hex)
                        guard_ok = len(expected) == length and payload == expected
                    elif expected_hash:
                        guard_kind = "expected_sha256"
                        guard_ok = actual_hash == expected_hash
                    else:
                        error = "missing source guard"
                except ValueError as exc:
                    error = f"invalid expected_hex: {exc}"
            else:
                error = "span outside ROM or non-positive"
            guards.append(
                {
                    "id": entry_id,
                    "kind": kind,
                    "offset": f"0x{offset:06X}",
                    "length": length,
                    "guard": guard_kind,
                    "guard_ok": guard_ok,
                    "actual_sha256": actual_hash,
                    "error": error,
                }
            )
    duplicates = sorted({entry_id for entry_id in ids if ids.count(entry_id) > 1})
    return spans, guards, duplicates


def span_overlaps(
    spans: list[tuple[int, int, str, str]]
) -> list[dict[str, Any]]:
    overlaps: list[dict[str, Any]] = []
    for index, (start, end, entry_id, kind) in enumerate(spans):
        for other_start, other_end, other_id, other_kind in spans[index + 1 :]:
            overlap_start = max(start, other_start)
            overlap_end = min(end, other_end)
            if overlap_start < overlap_end:
                overlaps.append(
                    {
                        "first": entry_id,
                        "first_kind": kind,
                        "second": other_id,
                        "second_kind": other_kind,
                        "start": f"0x{overlap_start:06X}",
                        "end": f"0x{overlap_end:06X}",
                        "length": overlap_end - overlap_start,
                    }
                )
    return overlaps


def guarded_source_regions(value: Any, trail: str = "$") -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    if isinstance(value, dict):
        hash_key = "source_sha256" if "source_sha256" in value else "sha256"
        if "offset" in value and "length" in value and hash_key in value:
            results.append(
                {
                    "trail": trail,
                    "offset": value["offset"],
                    "length": value["length"],
                    "sha256": value[hash_key],
                }
            )
        for key, child in value.items():
            results.extend(guarded_source_regions(child, f"{trail}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            results.extend(guarded_source_regions(child, f"{trail}[{index}]"))
    return results


def values_for_key(value: Any, wanted: str) -> list[Any]:
    results: list[Any] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == wanted:
                results.append(child)
            results.extend(values_for_key(child, wanted))
    elif isinstance(value, list):
        for child in value:
            results.extend(values_for_key(child, wanted))
    return results


def report_occurrences(report_id: str, payload: dict[str, Any]) -> int:
    if report_id == "shop_purchase":
        labels = payload.get("labels", [])
        return len(labels) if isinstance(labels, list) else -1
    if report_id == "pet_carousel":
        screens = payload.get("screens", [])
        return len(screens) if isinstance(screens, list) else -1
    if report_id == "host_free":
        return int(payload.get("new_graphical_occurrences", -1))
    if report_id == "pet_runtime":
        return int(payload.get("graphical_occurrences", -1))
    raise ValueError(f"unknown report id {report_id}")


def report_specific_ok(report_id: str, payload: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    details: dict[str, Any] = {}
    if report_id == "shop_purchase":
        details = {
            "price_cells_byte_identical": payload.get("price_cells_byte_identical"),
            "protected_price_count": len(payload.get("protected_prices", [])),
            "outside_allowlist": payload.get("changes", {}).get("outside_allowlist"),
        }
        ok = (
            details["price_cells_byte_identical"] is True
            and details["protected_price_count"] == 3
            and details["outside_allowlist"] == 0
        )
    elif report_id == "pet_carousel":
        screens = payload.get("screens", [])
        outside = [row.get("changes", {}).get("outside_allowlist") for row in screens]
        details = {"screen_count": len(screens), "outside_allowlist": outside}
        ok = len(screens) == 2 and all(value == 0 for value in outside)
    elif report_id == "host_free":
        screens = payload.get("screens", [])
        statuses = [row.get("status") for row in screens]
        outside = [row.get("changes", {}).get("outside_allowlist") for row in screens]
        occurrences = sum(int(row.get("graphical_occurrences", 0)) for row in screens)
        details = {
            "screen_count": len(screens),
            "screen_occurrences": occurrences,
            "screen_statuses": statuses,
            "outside_allowlist": outside,
        }
        ok = (
            len(screens) == 10
            and occurrences == 31
            and all(value == "PASS" for value in statuses)
            and all(value == 0 for value in outside)
        )
    elif report_id == "pet_runtime":
        labels = payload.get("labels", [])
        alias_values = values_for_key(payload.get("alias_checks", {}), "outside_targets")
        bank_values = values_for_key(payload.get("tile_banks", {}), "outside_allowlist")
        details = {
            "label_count": len(labels),
            "maps_changed": payload.get("maps_changed"),
            "alias_outside_targets": alias_values,
            "bank_outside_allowlist": bank_values,
        }
        ok = (
            len(labels) == 12
            and payload.get("maps_changed") == 0
            and alias_values
            and all(value == 0 for value in alias_values)
            and bank_values
            and all(value == 0 for value in bank_values)
        )
    else:
        raise ValueError(f"unknown report id {report_id}")
    return ok, details


def validate_asset_reports(root: Path, source: bytes) -> tuple[bool, dict[str, Any]]:
    reports: dict[str, Any] = {}
    all_ok = True
    total_occurrences = 0
    for spec in REPORT_SPECS:
        report_path = (root / str(spec["path"])).resolve()
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        occurrences = report_occurrences(str(spec["id"]), payload)
        total_occurrences += max(occurrences, 0)

        guard_results: list[dict[str, Any]] = []
        for guard in guarded_source_regions(payload):
            offset = v09.number(guard["offset"])
            length = v09.number(guard["length"])
            expected = str(guard["sha256"]).lower()
            in_bounds = length > 0 and 0 <= offset < offset + length <= len(source)
            actual = v09.sha256(source[offset : offset + length]) if in_bounds else ""
            guard_results.append(
                {
                    **guard,
                    "offset": f"0x{offset:06X}",
                    "length": length,
                    "actual_sha256": actual,
                    "match": in_bounds and actual == expected,
                }
            )

        output_results: list[dict[str, Any]] = []
        outputs = payload.get("outputs", {})
        if not isinstance(outputs, dict):
            outputs = {}
        for filename, expected in outputs.items():
            output_path = (report_path.parent / str(filename)).resolve()
            safe = True
            try:
                output_path.relative_to(report_path.parent.resolve())
            except ValueError:
                safe = False
            exists = safe and output_path.is_file()
            actual = v09.sha256(output_path.read_bytes()) if exists else ""
            output_results.append(
                {
                    "file": str(filename),
                    "safe_path": safe,
                    "exists": exists,
                    "expected_sha256": str(expected),
                    "actual_sha256": actual,
                    "match": exists and actual == str(expected).lower(),
                }
            )

        specific_ok, specific_details = report_specific_ok(str(spec["id"]), payload)
        report_ok = (
            payload.get("format") == spec["format"]
            and payload.get("status") == "PASS"
            and payload.get("native_display") == [224, 144]
            and payload.get("source_rom_sha256", payload.get("source", {}).get("rom_sha256"))
            == v09.SOURCE_SHA256
            and occurrences == spec["occurrences"]
            and bool(guard_results)
            and all(row["match"] for row in guard_results)
            and bool(output_results)
            and all(row["match"] for row in output_results)
            and specific_ok
        )
        reports[str(spec["id"])] = {
            "result": "PASS" if report_ok else "FAIL",
            "path": display_path(report_path, root),
            "format": payload.get("format"),
            "status": payload.get("status"),
            "occurrences": occurrences,
            "expected_occurrences": spec["occurrences"],
            "source_guards_checked": len(guard_results),
            "source_guard_failures": [row for row in guard_results if not row["match"]],
            "outputs_checked": len(output_results),
            "output_failures": [row for row in output_results if not row["match"]],
            "specific": specific_details,
        }
        all_ok = all_ok and report_ok
    all_ok = all_ok and total_occurrences == NEW_GRAPHICS_DENOMINATOR
    return all_ok, {
        "new_graphical_occurrences": total_occurrences,
        "expected_new_graphical_occurrences": NEW_GRAPHICS_DENOMINATOR,
        "reports": reports,
    }


def validate_title_logo(
    root: Path,
    source: bytes,
    built: bytes,
    manifest: dict[str, Any],
) -> tuple[bool, dict[str, Any]]:
    """Fail closed around the only v0.10.2 feature: the English title layer."""

    report_path = root / "translation/assets/title_logo_asset_report_v0_10_2.json"
    payload = json.loads(report_path.read_text(encoding="utf-8"))
    source_map = source[TITLE_MAP_OFFSET:TITLE_MAP_OFFSET + TITLE_MAP_LENGTH]
    built_map = built[TITLE_MAP_OFFSET:TITLE_MAP_OFFSET + TITLE_MAP_LENGTH]
    source_tiles = source[TITLE_TILES_OFFSET:TITLE_TILES_OFFSET + TITLE_TILES_LENGTH]
    built_tiles = built[TITLE_TILES_OFFSET:TITLE_TILES_OFFSET + TITLE_TILES_LENGTH]
    source_palettes = source[
        TITLE_PALETTE_OFFSET:TITLE_PALETTE_OFFSET + TITLE_PALETTE_LENGTH
    ]
    built_palettes = built[
        TITLE_PALETTE_OFFSET:TITLE_PALETTE_OFFSET + TITLE_PALETTE_LENGTH
    ]

    entries = {
        str(entry.get("id")): entry
        for entry in manifest.get("binary_entries", [])
        if isinstance(entry, dict)
    }
    expected_entries = {
        "main_logo_bg0_map": {
            "offset": TITLE_MAP_OFFSET,
            "length": TITLE_MAP_LENGTH,
            "expected_sha256": TITLE_MAP_SOURCE_SHA256,
            "asset": "assets/main_logo_bg0_map_v0_10_2.bin",
            "asset_sha256": TITLE_MAP_OUTPUT_SHA256,
        },
        "main_logo_tiles": {
            "offset": TITLE_TILES_OFFSET,
            "length": TITLE_TILES_LENGTH,
            "expected_sha256": TITLE_TILES_SOURCE_SHA256,
            "asset": "assets/main_logo_tiles_v0_10_2.bin",
            "asset_sha256": TITLE_TILES_OUTPUT_SHA256,
        },
    }
    manifest_entry_results: dict[str, Any] = {}
    for entry_id, expected in expected_entries.items():
        entry = entries.get(entry_id, {})
        entry_ok = (
            entry
            and v09.number(entry.get("offset", -1)) == expected["offset"]
            and v09.number(entry.get("length", -1)) == expected["length"]
            and str(entry.get("expected_sha256", "")).lower()
            == expected["expected_sha256"]
            and entry.get("asset") == expected["asset"]
            and str(entry.get("asset_sha256", "")).lower()
            == expected["asset_sha256"]
        )
        manifest_entry_results[entry_id] = {
            "result": "PASS" if entry_ok else "FAIL",
            "offset": entry.get("offset"),
            "length": entry.get("length"),
            "asset": entry.get("asset"),
        }

    output_results: dict[str, Any] = {}
    output_specs = {
        "tiles": ("main_logo_tiles_v0_10_2.bin", TITLE_TILES_LENGTH, TITLE_TILES_OUTPUT_SHA256),
        "map": ("main_logo_bg0_map_v0_10_2.bin", TITLE_MAP_LENGTH, TITLE_MAP_OUTPUT_SHA256),
        "preview": (
            "title_logo_master_preview_v0_10_2.png",
            None,
            "78fdec734a6e4122e5c6475ed57cb1ca02a6ecd1fb5c46e5433e555a68cacc22",
        ),
    }
    for output_id, (filename, length, expected_hash) in output_specs.items():
        path = root / "translation/assets" / filename
        data = path.read_bytes() if path.is_file() else b""
        output_ok = path.is_file() and (length is None or len(data) == length) and v09.sha256(data) == expected_hash
        output_results[output_id] = {
            "result": "PASS" if output_ok else "FAIL",
            "file": display_path(path, root),
            "length": len(data),
            "sha256": v09.sha256(data),
        }

    master_path = root / "translation/assets/title_logo_master_v0_10_2.png"
    master = master_path.read_bytes() if master_path.is_file() else b""
    master_ok = (
        master_path.is_file()
        and v09.sha256(master) == "9f6a15918f5a8016aae4ddef21e71621af3dc0ec137f1adb0f1b21d88cebf83f"
        and master.startswith(b"\x89PNG\r\n\x1a\n")
    )

    protected_row_start = TITLE_MAP_EDITABLE_ROWS * TITLE_MAP_ROW_BYTES
    protected_rows_ok = built_map[protected_row_start:] == source_map[protected_row_start:]
    hidden_column_failures: list[dict[str, int]] = []
    for row in range(18):
        for column in range(28, 32):
            position = row * TITLE_MAP_ROW_BYTES + column * 2
            if built_map[position:position + 2] != source_map[position:position + 2]:
                hidden_column_failures.append({"row": row, "column": column})

    palette_ok = (
        v09.sha256(source_palettes) == TITLE_PALETTE_SHA256
        and built_palettes == source_palettes
    )
    source_guards_ok = (
        v09.sha256(source_map) == TITLE_MAP_SOURCE_SHA256
        and v09.sha256(source_tiles) == TITLE_TILES_SOURCE_SHA256
    )
    output_spans_ok = (
        v09.sha256(built_map) == TITLE_MAP_OUTPUT_SHA256
        and v09.sha256(built_tiles) == TITLE_TILES_OUTPUT_SHA256
    )

    # Revert the two v0.10.2 spans, repair the checksum, and demand the exact
    # v0.10.1 release.  This proves every inherited English byte stayed fixed
    # without requiring the private v0.10.1 ROM as an input.
    baseline = bytearray(built)
    baseline[TITLE_MAP_OFFSET:TITLE_MAP_OFFSET + TITLE_MAP_LENGTH] = source_map
    baseline[TITLE_TILES_OFFSET:TITLE_TILES_OFFSET + TITLE_TILES_LENGTH] = source_tiles
    baseline[-2:] = (sum(baseline[:-2]) & 0xFFFF).to_bytes(2, "little")
    baseline_bytes = bytes(baseline)
    baseline_ok = v09.sha256(baseline_bytes) == BASELINE_V0101_SHA256

    allowed = bytearray(len(built))
    for row in range(TITLE_MAP_EDITABLE_ROWS):
        start = TITLE_MAP_OFFSET + row * TITLE_MAP_ROW_BYTES
        # Visible columns 0..27 only; hidden columns 28..31 stay protected.
        allowed[start:start + 28 * 2] = b"\x01" * (28 * 2)
    allowed[TITLE_TILES_OFFSET:TITLE_TILES_OFFSET + TITLE_TILES_LENGTH] = (
        b"\x01" * TITLE_TILES_LENGTH
    )
    allowed[-2:] = b"\x01\x01"
    delta_offsets = [
        index
        for index, (before, after) in enumerate(zip(baseline_bytes, built))
        if before != after
    ]
    outside_delta = [offset for offset in delta_offsets if not allowed[offset]]
    delta_ok = baseline_ok and not outside_delta and len(delta_offsets) == 6440

    capacity = payload.get("map_and_capacity_audit", {})
    encoding = payload.get("encoding", {})
    report_outputs = payload.get("outputs", {})
    report_ok = (
        payload.get("format") == "n1-title-logo-assets-v0.10.2"
        and payload.get("status") == "PASS"
        and payload.get("reference", {}).get("sha256")
        == "b71924ad32e3870b8c4be33335991621cd5e22120349528c0639308857381d24"
        and payload.get("reference", {}).get("distributed") is False
        and payload.get("master", {}).get("dimensions") == [224, 112]
        and payload.get("master", {}).get("sha256") == v09.sha256(master)
        and encoding.get("native_screen") == [224, 144]
        and encoding.get("logo_layer") == [224, 112]
        and encoding.get("transparent_index") == 0
        and encoding.get("dithering") is False
        and encoding.get("roundtrip_master_exact") is True
        and capacity.get("unique_tiles_used") == 194
        and capacity.get("tile_capacity") == 208
        and capacity.get("spare_tiles") == 14
        and capacity.get("changed_rows") == list(range(14))
        and capacity.get("rows_14_17_byte_identical") is True
        and capacity.get("hidden_columns_28_31_byte_identical") is True
        and report_outputs.get("tiles", {}).get("sha256") == TITLE_TILES_OUTPUT_SHA256
        and report_outputs.get("map", {}).get("sha256") == TITLE_MAP_OUTPUT_SHA256
        and payload.get("source_guards", {}).get("palettes", {}).get("byte_identical") is True
    )

    all_ok = all(
        row["result"] == "PASS"
        for row in (*manifest_entry_results.values(), *output_results.values())
    ) and all((master_ok, protected_rows_ok, not hidden_column_failures, palette_ok,
               source_guards_ok, output_spans_ok, delta_ok, report_ok))
    return all_ok, {
        "asset_report": display_path(report_path, root),
        "asset_report_status": payload.get("status"),
        "manifest_entries": manifest_entry_results,
        "outputs": output_results,
        "master_png_valid": master_ok,
        "tile_capacity": {
            "used": capacity.get("unique_tiles_used"),
            "maximum": capacity.get("tile_capacity"),
            "spare": capacity.get("spare_tiles"),
        },
        "protected_rows_14_17_byte_identical": protected_rows_ok,
        "hidden_columns_28_31_failures": hidden_column_failures,
        "palettes_byte_identical": built_palettes == source_palettes,
        "palette_sha256": v09.sha256(built_palettes),
        "title_map_sha256": v09.sha256(built_map),
        "title_tiles_sha256": v09.sha256(built_tiles),
        "v0_10_1_reconstructed_sha256": v09.sha256(baseline_bytes),
        "v0_10_1_expected_sha256": BASELINE_V0101_SHA256,
        "v0_10_1_to_v0_10_2_changed_bytes": len(delta_offsets),
        "delta_outside_title_allowlist": len(outside_delta),
        "first_outside_offsets": [f"0x{offset:06X}" for offset in outside_delta[:20]],
    }


def audit_text(
    source: bytes,
    built: bytes,
    n1tool: Any,
    bcc: Any,
    decode: dict[int, str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    inventories: dict[str, Any] = {}
    source_dump = n1tool.dump_scripts(source, decode)
    built_dump = n1tool.dump_scripts(built, decode)
    source_dialogue = v09.group_targets(source_dump, {0, 1, 2, 3, 4})
    built_dialogue = v09.group_targets(built_dump, {0, 1, 2, 3, 4})
    source_aux = v09.group_targets(source_dump, {5})
    built_aux = v09.group_targets(built_dump, {5})
    dialogue_bad = [
        {"target": f"0x{target:06X}", "text": text}
        for target, text in built_dialogue.items()
        if v09.contains_japanese(text)
    ]
    aux_source_jp = sum(v09.contains_japanese(text) for text in source_aux.values())
    aux_bad = [
        {"target": f"0x{target:06X}", "text": text}
        for target, text in built_aux.items()
        if v09.contains_japanese(text)
    ]
    dialogue_ok = len(source_dialogue) == 274 and len(built_dialogue) == 274 and not dialogue_bad
    aux_ok = aux_source_jp == 88 and not aux_bad
    inventories["dialogue_groups_0_4"] = {
        "translated": 274 if dialogue_ok else 274 - len(dialogue_bad),
        "denominator": 274,
        "remaining_japanese": len(dialogue_bad),
    }
    inventories["auxiliary_group_5"] = {
        "translated": 88 if aux_ok else 88 - len(aux_bad),
        "denominator": 88,
        "source_unique_targets": len(source_aux),
        "source_japanese_targets": aux_source_jp,
        "output_unique_targets": len(built_aux),
        "remaining_japanese": len(aux_bad),
    }

    prompt_words = n1tool.words_at(built, 0x3578AE, 0x3578AE + 58)
    prompt_text = "".join(n1tool.token_for(word, decode) for _, word in prompt_words)
    prompt_ok = bool(prompt_words) and prompt_words[-1][1] == 0x8000 and not v09.contains_japanese(prompt_text)
    inventories["direct_overwrite_prompt"] = {
        "translated": 1 if prompt_ok else 0,
        "denominator": 1,
        "remaining_japanese": 0 if prompt_ok else 1,
    }

    def effect_label_audit() -> dict[str, Any]:
        records: list[str] = []
        targets: list[int] = []
        incompatible: list[dict[str, Any]] = []
        for index in range(bcc.EFFECT_LABELS.count):
            target = bcc.wsc_pointer(
                built, bcc.EFFECT_LABELS.pointer_start, index, bcc.EFFECT_LABELS.name
            )
            words = bcc.read_words(built, target, f"effect_labels[{index}]")
            payload = words[:-1]
            text = "".join(decode.get(word & 0x01FF, f"[RAW:{word:04X}]") for word in payload)
            style_ok = all((word & 0x7E00) == 0x0600 for word in payload)
            compatible = (
                style_ok
                and len(text) <= 8
                and set(text) <= set("ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789+~ ")
            )
            if not compatible:
                incompatible.append({"index": index, "text": text, "style_ok": style_ok})
            records.append(text)
            targets.append(target)
        if len(records) != 249 or len(set(targets)) != 70:
            raise ValueError("effect-label pointer corpus changed")
        return {
            "record_count": len(records),
            "unique_targets": len(set(targets)),
            "remaining_japanese": sum(v09.contains_japanese(text) for text in records),
            "incompatible_large_card_records": len(incompatible),
            "incompatible_examples": incompatible[:20],
        }

    static = {
        "chip_names": v09.far_table_audit(built, bcc.CHIP_NAMES, bcc, decode),
        "effect_labels": effect_label_audit(),
        "descriptions": v09.description_audit(built, bcc, decode),
        "operator_names": v09.far_table_audit(built, bcc.OPERATOR_NAMES, bcc, decode),
    }
    static_bad = (
        static["chip_names"]["remaining_japanese"]
        + static["effect_labels"]["remaining_japanese"]
        + static["effect_labels"]["incompatible_large_card_records"]
        + static["descriptions"]["remaining_japanese_rows"]
        + static["operator_names"]["remaining_japanese"]
    )
    inventories["static_databases"] = {
        "translated": 882 if static_bad == 0 else 882 - static_bad,
        "denominator": 882,
        "remaining_japanese": static_bad,
        "corpora": static,
    }

    attacks = v09.far_table_audit(built, bcc.NAVI_ATTACK_NAMES, bcc, decode)
    inventories["navi_attack_names"] = {
        "translated": 49 if attacks["remaining_japanese"] == 0 else 49 - attacks["remaining_japanese"],
        "denominator": 49,
        **attacks,
    }
    participants = v09.generic_far_bank_audit(
        built, "participant_names", 0x367AEA, 73, bcc, decode
    )
    participant_source = v09.generic_far_bank_audit(
        source, "participant_names_source", 0x367AEA, 73, bcc, decode
    )
    participants_ok = participant_source["remaining_japanese"] == 73 and participants["remaining_japanese"] == 0
    inventories["participant_names"] = {
        "translated": 73 if participants_ok else 73 - participants["remaining_japanese"],
        "denominator": 73,
        "source_japanese": participant_source["remaining_japanese"],
        **participants,
    }

    battle_b1 = v09.generic_far_bank_audit(built, "battle_b1", 0x37D7F4, 187, bcc, decode)
    battle_b2 = v09.generic_far_bank_audit(built, "battle_b2", 0x37E0CC, 92, bcc, decode)
    source_b1 = v09.generic_far_bank_audit(source, "battle_b1_source", 0x37D7F4, 187, bcc, decode)
    source_b2 = v09.generic_far_bank_audit(source, "battle_b2_source", 0x37E0CC, 92, bcc, decode)
    source_battle_jp = source_b1["remaining_japanese"] + source_b2["remaining_japanese"]
    output_battle_jp = battle_b1["remaining_japanese"] + battle_b2["remaining_japanese"]
    battle_ok = source_battle_jp == 185 and output_battle_jp == 0
    inventories["battle_and_result_messages"] = {
        "translated": 185 if battle_ok else 185 - output_battle_jp,
        "denominator": 185,
        "source_japanese": source_battle_jp,
        "remaining_japanese": output_battle_jp,
        "banks": {"b1": battle_b1, "b2": battle_b2},
    }

    keys = (
        "dialogue_groups_0_4",
        "auxiliary_group_5",
        "direct_overwrite_prompt",
        "static_databases",
        "navi_attack_names",
        "participant_names",
        "battle_and_result_messages",
    )
    translated = sum(inventories[key]["translated"] for key in keys)
    return inventories, v09.pass_check(
        translated == TEXT_DENOMINATOR,
        translated=translated,
        denominator=TEXT_DENOMINATOR,
        percent=round(translated / TEXT_DENOMINATOR * 100, 2),
        remaining_japanese_targets=TEXT_DENOMINATOR - translated,
        note="Every reachable pointer target is audited; unreferenced bytes in bounded pools are excluded.",
    )


def graphics_inventory(asset_ok_by_id: dict[str, bool]) -> tuple[dict[str, Any], dict[str, Any]]:
    families = {
        "main_logo": (1, ["main_logo_bg0_map", "main_logo_tiles"]),
        "title_menu": (4, ["title_new_game_selected", "title_new_game_unselected", "title_continue_selected", "title_continue_unselected"]),
        "name_keyboard": (7, ["name_keyboard_bg0_map", "name_keyboard_tiles"]),
        "manual_headers": (2, ["manual_header_first_cover", "manual_header_final_cover"]),
        "pet_root": (5, ["pet_labels_bg0_map", "pet_labels_tiles"]),
        "program_deck_existing_labels": (20, ["program_deck_live_bg0_map", "program_deck_live_ui_tiles", "program_deck_manual_internal_tiles"]),
        "pet_submenus": (12, ["pet_submenu_chip_library_tiles", "pet_submenu_netnavi_tiles", "pet_submenu_save_tiles", "pet_submenu_chip_folder_bg0_map", "pet_submenu_data_library_bg0_map", "pet_submenu_netnavi_bg0_map", "pet_submenu_save_bg0_map"]),
        "normal30_occurrences": (2, ["program_deck_manual_internal_tiles"]),
        "program_deck_transfer": (1, ["program_deck_transfer_text"]),
        "tournament_header": (1, ["tournament_header_top", "tournament_header_bottom"]),
        "tournament_phase_variants": (15, ["tournament_phase_renderer", "tournament_phase_text_pool"]),
        "location_graphics": (4, ["location_shop_bg0_map", "location_shop_bg0_tiles", "location_battlechip_gp_bg0_map", "location_battlechip_gp_bg0_tiles"]),
        "lan_room_poster": (1, ["lan_room_poster_bg0_tiles"]),
        "shop_purchase": (3, ["shop_purchase_bg0_map", "shop_purchase_bg0_tiles"]),
        "pet_carousel_remaining": (2, ["pet_carousel_free_battle_bg0_map", "pet_carousel_free_battle_bg0_tiles", "pet_carousel_host_tournament_bg0_map", "pet_carousel_host_tournament_bg0_tiles"]),
        "host_free_remaining": (31, ["host_navicode_register_bg0_map", "host_entrant_count_bg0_map", "host_entry_select_bg0_map", "host_entry_delete_bg0_map", "host_setup_bg0_tiles", "host_roster_actions_bg0_tiles", "host_navicode_register_bg0_tiles", "host_brackets_bg0_tiles", "host_entrant_count_bg0_tiles", "host_entry_select_bg0_tiles", "host_result_dialog_bg0_tiles", "host_result_table_bg0_tiles", "host_entry_delete_bg0_tiles", "free_win_streak_bg0_tiles"]),
        "pet_runtime_remaining": (18, ["program_deck_live_ui_tiles", "pet_submenu_chip_library_tiles", "pet_submenu_netnavi_tiles", "pet_no_data_card_tiles"]),
    }
    family_results: dict[str, Any] = {}
    translated = 0
    for family, (count, requirements) in families.items():
        missing = [entry_id for entry_id in requirements if not asset_ok_by_id.get(entry_id, False)]
        ok = not missing
        family_results[family] = {
            "translated": count if ok else 0,
            "denominator": count,
            "assets_match": ok,
            "missing_or_invalid_assets": missing,
        }
        if ok:
            translated += count
    inventory = {
        "translated": translated,
        "denominator": GRAPHICS_DENOMINATOR,
        "remaining": GRAPHICS_DENOMINATOR - translated,
        "baseline_denominator": BASE_GRAPHICS_DENOMINATOR,
        "new_denominator": NEW_GRAPHICS_DENOMINATOR,
        "families": family_results,
    }
    check = v09.pass_check(
        translated == GRAPHICS_DENOMINATOR,
        translated=translated,
        denominator=GRAPHICS_DENOMINATOR,
        percent=round(translated / GRAPHICS_DENOMINATOR * 100, 2),
        scope="all localizable Japanese-bearing graphical occurrences through v0.10.2, including the isolated English title logo",
    )
    return inventory, check


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--source-rom", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--built-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_10_2.json").resolve()
    built_path = (args.built_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.2.wsc").resolve()
    ips_path = (args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.2.ips").resolve()
    report_path = (args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10_2.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-deep-release-validation-v1",
        "project_version": PROJECT_VERSION,
        "report_date": "2026-08-22",
        "overall_result": "FAIL",
        "inputs": {
            "manifest": display_path(manifest_path, root),
            "built_rom": display_path(built_path, root),
            "ips": display_path(ips_path, root),
        },
        "checks": {},
        "inventories": {},
        "errors": [],
    }
    try:
        source = args.source_rom.read_bytes()
        built = built_path.read_bytes()
        ips = ips_path.read_bytes()
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        n1tool = v09.load_module("n1tool_validation_v0102", root / "tools/n1tool.py")
        bcc = v09.load_module("bcc_validation_v0102", root / "tools/bcc_reference.py")
        decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")

        source_ok = len(source) == v09.ROM_SIZE and v09.sha256(source) == v09.SOURCE_SHA256
        report["checks"]["verified_source"] = v09.pass_check(
            source_ok, size=len(source), sha256=v09.sha256(source)
        )

        entries = manifest.get("entries", [])
        binary_entries = manifest.get("binary_entries", [])
        expanded = manifest.get("expanded_inventory", {})
        manifest_header_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == PROJECT_VERSION
            and manifest.get("source_sha256") == v09.SOURCE_SHA256
        )
        report["checks"]["manifest_header"] = v09.pass_check(
            manifest_header_ok,
            sha256=v09.sha256(manifest_bytes),
            format=manifest.get("format"),
            project_version=manifest.get("project_version"),
        )
        expanded_ok = (
            expanded.get("text_units") == {"translated": 1552, "denominator": 1552}
            and expanded.get("newly_recovered_text_units") == 347
            and expanded.get("graphical_occurrences") == {"translated": 129, "denominator": 129}
            and "preserved_brand_graphics" not in expanded
            and isinstance(expanded.get("title_logo_policy"), str)
            and expanded.get("known_residual_japanese_targets") == 0
        )
        inventory_ok = (
            isinstance(entries, list)
            and len(entries) == TEXT_ENTRY_COUNT
            and isinstance(binary_entries, list)
            and len(binary_entries) == BINARY_ENTRY_COUNT
            and expanded_ok
        )
        report["checks"]["manifest_inventory"] = v09.pass_check(
            inventory_ok,
            text_entries=len(entries) if isinstance(entries, list) else None,
            expected_text_entries=TEXT_ENTRY_COUNT,
            binary_entries=len(binary_entries) if isinstance(binary_entries, list) else None,
            expected_binary_entries=BINARY_ENTRY_COUNT,
            expanded_inventory=expanded,
        )

        spans, guards, duplicate_ids = parse_manifest_spans(source, manifest)
        overlaps = span_overlaps(spans)
        invalid_spans = [row for row in guards if row["error"] == "span outside ROM or non-positive"]
        layout_ok = not overlaps and not duplicate_ids and not invalid_spans
        report["checks"]["manifest_span_layout"] = v09.pass_check(
            layout_ok,
            spans=len(spans),
            overlaps=len(overlaps),
            overlap_examples=overlaps[:20],
            duplicate_ids=duplicate_ids,
            invalid_spans=invalid_spans,
        )
        guard_failures = [row for row in guards if not row["guard_ok"]]
        report["checks"]["manifest_source_guards"] = v09.pass_check(
            not guard_failures and len(guards) == TEXT_ENTRY_COUNT + BINARY_ENTRY_COUNT,
            checked=len(guards),
            expected=TEXT_ENTRY_COUNT + BINARY_ENTRY_COUNT,
            failures=guard_failures[:20],
        )

        rebuilt, rebuild_entries = n1tool.patch_entries(source, manifest, encode, manifest_path.parent)
        rebuild_ok = (
            rebuilt == built
            and len(built) == v09.ROM_SIZE
            and v09.sha256(built) == FINAL_ROM_SHA256
        )
        report["checks"]["canonical_rebuild"] = v09.pass_check(
            rebuild_ok,
            built_sha256=v09.sha256(built),
            rebuilt_sha256=v09.sha256(rebuilt),
            byte_identical=rebuilt == built,
            report_entries=len(rebuild_entries),
        )
        applied = n1tool.apply_ips(source, ips)
        canonical_ips = n1tool.make_ips(source, rebuilt)
        ips_ok = applied == built and canonical_ips == ips
        report["checks"]["ips_round_trip"] = v09.pass_check(
            ips_ok,
            ips_sha256=v09.sha256(ips),
            applies_to_exact_build=applied == built,
            canonical_ips_identical=canonical_ips == ips,
        )
        stored = int.from_bytes(built[-2:], "little")
        calculated = sum(built[:-2]) & 0xFFFF
        checksum_ok = len(built) == v09.ROM_SIZE and stored == calculated
        report["checks"]["wonderswan_checksum"] = v09.pass_check(
            checksum_ok,
            size=len(built),
            stored=f"0x{stored:04X}",
            calculated=f"0x{calculated:04X}",
        )

        allowed = bytearray(v09.ROM_SIZE)
        for start, end, _, _ in spans:
            if 0 <= start < end <= v09.ROM_SIZE:
                allowed[start:end] = b"\x01" * (end - start)
        allowed[v09.ROM_SIZE - 2 : v09.ROM_SIZE] = b"\x01\x01"
        outside = [
            index
            for index, (before, after) in enumerate(zip(source, built))
            if before != after and not allowed[index]
        ]
        report["checks"]["manifest_change_allowlist"] = v09.pass_check(
            not outside,
            changed_bytes=sum(before != after for before, after in zip(source, built)),
            outside_count=len(outside),
            first_outside=[f"0x{offset:06X}" for offset in outside[:20]],
        )

        asset_results: list[dict[str, Any]] = []
        for entry in binary_entries:
            start = v09.number(entry["offset"])
            length = v09.number(entry["length"])
            asset_path = (manifest_path.parent / str(entry["asset"])).resolve()
            safe = True
            try:
                asset_path.relative_to(manifest_path.parent.resolve())
            except ValueError:
                safe = False
            asset = asset_path.read_bytes() if safe and asset_path.is_file() else b""
            expected_hash = str(entry.get("asset_sha256", "")).lower()
            asset_results.append(
                {
                    "id": entry["id"],
                    "safe_path": safe,
                    "length_ok": len(asset) == length,
                    "hash_ok": bool(expected_hash) and v09.sha256(asset) == expected_hash,
                    "build_match": built[start : start + length] == asset,
                }
            )
        asset_failures = [
            row
            for row in asset_results
            if not all((row["safe_path"], row["length_ok"], row["hash_ok"], row["build_match"]))
        ]
        report["checks"]["binary_assets"] = v09.pass_check(
            not asset_failures and len(asset_results) == BINARY_ENTRY_COUNT,
            checked=len(asset_results),
            expected=BINARY_ENTRY_COUNT,
            failures=asset_failures,
        )

        reports_ok, reports_detail = validate_asset_reports(root, source)
        report["checks"]["v0_10_asset_reports"] = v09.pass_check(reports_ok, **reports_detail)

        correction_path = root / "translation/assets/chip_effect_label_asset_report_v0_10_1.json"
        correction = json.loads(correction_path.read_text(encoding="utf-8"))
        title_runtime_path = root / "docs/runtime_v0_10_2/title/title_runtime_validation_v0_10_2.json"
        chip_runtime_path = root / "docs/runtime_v0_10_1/chip/chip_effect_runtime_validation_v0_10_1.json"
        title_runtime = json.loads(title_runtime_path.read_text(encoding="utf-8"))
        chip_runtime = json.loads(chip_runtime_path.read_text(encoding="utf-8"))
        logo_ok, logo_detail = validate_title_logo(root, source, built, manifest)
        inherited_effect_ok = (
            correction.get("status") == "PASS"
            and correction.get("output_sha256") == EFFECT_LABEL_SHA256
            and v09.sha256(built[0x369550:0x36A4E0]) == EFFECT_LABEL_SHA256
            and correction.get("inventory", {}).get("all_normalized_uppercase_ascii") is True
        )
        title_captures = title_runtime.get("captures", [])
        title_phase_captures = [
            capture for capture in title_captures
            if isinstance(capture, dict) and capture.get("phase") == "title"
        ]
        runtime_artifact_results: list[dict[str, Any]] = []
        title_runtime_dir = title_runtime_path.parent.resolve()
        for capture in title_captures:
            screenshot = str(capture.get("screenshot", ""))
            screenshot_path = (title_runtime_dir / screenshot).resolve()
            safe = True
            try:
                screenshot_path.relative_to(title_runtime_dir)
            except ValueError:
                safe = False
            exists = safe and screenshot_path.is_file()
            actual_hash = v09.sha256(screenshot_path.read_bytes()) if exists else ""
            runtime_artifact_results.append({
                "screenshot": screenshot,
                "safe_path": safe,
                "exists": exists,
                "expected_sha256": capture.get("screenshot_sha256"),
                "actual_sha256": actual_hash,
                "match": exists and actual_hash == capture.get("screenshot_sha256"),
            })
        runtime_artifacts_ok = (
            len(runtime_artifact_results) == 3
            and all(row["match"] for row in runtime_artifact_results)
        )
        live_title_resources_ok = (
            len(title_captures) == 3
            and len(title_phase_captures) == 2
            and all(capture.get("native_224x144") is True for capture in title_captures)
            and all(
                capture.get("live_resources", {}).get("all_match") is True
                and capture.get("live_resources", {}).get("title_tiles", {}).get("live_sha256")
                == TITLE_TILES_OUTPUT_SHA256
                and capture.get("live_resources", {}).get("title_map", {}).get("match") is True
                and capture.get("live_resources", {}).get("title_palettes", {}).get("live_sha256")
                == TITLE_PALETTE_SHA256
                for capture in title_phase_captures
            )
        )
        title_runtime_ok = (
            title_runtime.get("validation")
            == "title_screen_v0_10_2_clean_boot_and_start_transition"
            and title_runtime.get("status") == "PASS"
            and title_runtime.get("rom_sha256") == FINAL_ROM_SHA256
            and title_runtime.get("expected_rom_sha256") == FINAL_ROM_SHA256
            and title_runtime.get("native_display") == [224, 144]
            and title_runtime.get("clean_boot", {}).get("fresh_mesen_home") is True
            and title_runtime.get("clean_boot", {}).get("uses_sav_or_savestate") is False
            and title_runtime.get("press_start_blink", {}).get("verified") is True
            and title_runtime.get("start_transition", {}).get("verified") is True
            and title_runtime.get("start_transition", {}).get("new_game_selected_live_match") is True
            and title_runtime.get("start_transition", {}).get("continue_unselected_live_match") is True
            and title_runtime.get("start_transition", {}).get("screenshot_changed_from_pre_start") is True
            and live_title_resources_ok
            and runtime_artifacts_ok
        )
        inherited_chip_ok = (
            chip_runtime.get("status") == "PASS"
            and chip_runtime.get("rom_sha256") == BASELINE_V0101_SHA256
            and chip_runtime.get("clean_boot") is True
            and chip_runtime.get("native_display") == [224, 144]
            and chip_runtime.get("manual_visual_review", {}).get("information_preserved") is True
        )
        report["checks"]["v0_10_2_title_logo"] = v09.pass_check(
            logo_ok and inherited_effect_ok and title_runtime_ok and inherited_chip_ok,
            **logo_detail,
            chip_effect_report=display_path(correction_path, root),
            inherited_effect_bank_sha256=v09.sha256(built[0x369550:0x36A4E0]),
            title_runtime_report=display_path(title_runtime_path, root),
            title_runtime_status=title_runtime.get("status"),
            title_runtime_final_rom=title_runtime.get("rom_sha256"),
            title_runtime_live_resources_match=live_title_resources_ok,
            title_runtime_screenshots=runtime_artifact_results,
            chip_runtime_report=display_path(chip_runtime_path, root),
            chip_runtime_inherited_rom=chip_runtime.get("rom_sha256"),
        )

        text_inventories, text_check = audit_text(source, built, n1tool, bcc, decode)
        report["inventories"].update(text_inventories)
        report["checks"]["reachable_text_inventory"] = text_check

        asset_ok_by_id = {
            str(row["id"]): all((row["safe_path"], row["length_ok"], row["hash_ok"], row["build_match"]))
            for row in asset_results
        }
        graphic_inventory, graphic_check = graphics_inventory(asset_ok_by_id)
        report["inventories"]["graphical_occurrences"] = graphic_inventory
        report["checks"]["graphical_asset_inventory"] = graphic_check

    except BaseException as exc:
        report["errors"].append(f"{type(exc).__name__}: {exc}")

    failed = [
        name
        for name, check in report["checks"].items()
        if isinstance(check, dict) and check.get("result") == "FAIL"
    ]
    report["failed_checks"] = failed
    report["overall_result"] = "PASS" if not failed and not report["errors"] else "FAIL"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    print(
        json.dumps(
            {
                "overall_result": report["overall_result"],
                "failed_checks": failed,
                "errors": report["errors"],
                "manifest_inventory": report.get("checks", {}).get("manifest_inventory"),
                "text": report.get("checks", {}).get("reachable_text_inventory"),
                "graphics": report.get("checks", {}).get("graphical_asset_inventory"),
                "asset_reports": report.get("checks", {}).get("v0_10_asset_reports"),
                "report": str(report_path),
                "sha256": v09.sha256(rendered.encode("utf-8")),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
