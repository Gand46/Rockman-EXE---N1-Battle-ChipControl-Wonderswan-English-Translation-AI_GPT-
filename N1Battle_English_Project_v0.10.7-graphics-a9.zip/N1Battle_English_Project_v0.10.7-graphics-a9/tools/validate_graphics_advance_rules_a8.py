#!/usr/bin/env python3
"""Enforce all cumulative graphics gates through Advance 8."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_8_no_chip_card_cleanup as a8  # noqa: E402
import n1tool  # noqa: E402


SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
A7_SHA256 = a8.BASE_A7_SHA256
A8_SHA256 = "aafa083e8781d58858c35cf729ed18c9269126cba70c789e1e631844071e3749"
IPS_SHA256 = "d4f05841889955bd0818994f05637203bbea376b31ef90edf08cd2ba8e1c3165"
MANIFEST_SHA256 = "aef62af89624e73f8b9bc5cab7521477fdae683c4202c6c3188419268843ad59"
ASSET_SHA256 = "33c2d3ca39a21acb2fe0f7bdacd5844ef12e6d637555ef0ac5c6ae7e34331a88"
RUNTIME = Path("docs/runtime_graphics_advances/advance_8_gate_final")


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load_json(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--a7-rom", required=True, type=Path)
    parser.add_argument("--candidate-rom", type=Path)
    parser.add_argument("--direct-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    args = parser.parse_args()

    root = args.root.resolve()
    candidate_path = args.candidate_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a8.wsc"
    direct_path = args.direct_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a8-direct.wsc"
    ips_path = args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a8.ips"
    source = args.source_rom.read_bytes()
    base = args.a7_rom.read_bytes()
    candidate = candidate_path.read_bytes()
    direct = direct_path.read_bytes()
    ips = ips_path.read_bytes()

    require(sha256(source) == SOURCE_SHA256, "Japanese source ROM identity differs")
    require(sha256(base) == A7_SHA256, "approved Advance 7 identity differs")
    require(sha256(candidate) == A8_SHA256, "Advance 8 candidate identity differs")
    require(candidate == direct, "direct manifest build differs from IPS reconstruction")
    require(sha256(ips) == IPS_SHA256, "Advance 8 IPS identity differs")
    require(n1tool.apply_ips(source, ips) == candidate, "IPS does not reconstruct candidate")
    stored, calculated = n1tool.checksum(candidate)
    require(stored == calculated == 0xB6E7, "WonderSwan checksum differs")

    asset_path = root / "translation/assets" / a8.ASSET_NAME
    asset = asset_path.read_bytes()
    require(len(asset) == a8.BANK_LENGTH and sha256(asset) == ASSET_SHA256,
            "A8 card-bank asset differs")
    base_bank = base[a8.BANK_OFFSET:a8.BANK_OFFSET + a8.BANK_LENGTH]
    candidate_bank = candidate[a8.BANK_OFFSET:a8.BANK_OFFSET + a8.BANK_LENGTH]
    require(a8.clean_residual_row(base_bank) == asset == candidate_bank,
            "candidate card bank does not equal the isolated cleanup output")
    require(base_bank[:0x600] == candidate_bank[:0x600], "English card rows changed")

    changed = {index for index, pair in enumerate(zip(base, candidate, strict=True)) if pair[0] != pair[1]}
    bank_changed = {a8.BANK_OFFSET + index for index, pair in enumerate(
        zip(base_bank, candidate_bank, strict=True)) if pair[0] != pair[1]}
    checksum_changed = {len(candidate) - 2, len(candidate) - 1}
    require(len(bank_changed) == 37, "card-bank byte delta differs")
    require(changed == bank_changed | checksum_changed and len(changed) == 39,
            "A8 binary delta escaped its exact bank/checksum allowlist")
    require({(index - a8.BANK_OFFSET) // a8.TILE_BYTES for index in bank_changed} == {0x32, 0x33, 0x34, 0x35},
            "A8 changed a tile outside the residual Japanese glyphs")

    manifest_path = root / "translation/en_v0_10_7_graphics_a8.json"
    manifest = load_json(manifest_path)
    build = load_json(root / "build/build_v0_10_7_graphics_a8.json")
    generator = load_json(root / "translation/assets" / a8.REPORT_NAME)
    rules = load_json(root / "translation/graphics_advance_rules.json")
    runtime = load_json(root / RUNTIME / "graphics_advance_8_runtime_validation.json")
    require(sha256(manifest_path.read_bytes()) == MANIFEST_SHA256, "A8 manifest identity differs")
    require(manifest.get("project_version") == "0.10.7-graphics-a8", "A8 manifest version differs")
    bank_entries = [row for row in manifest.get("binary_entries", [])
                    if row.get("id") == "pet_no_data_card_tiles"]
    require(len(bank_entries) == 1 and bank_entries[0].get("asset") == f"assets/{a8.ASSET_NAME}"
            and bank_entries[0].get("asset_sha256") == ASSET_SHA256,
            "A8 manifest does not select the cleaned shared bank")
    require(build.get("output_sha256") == A8_SHA256, "manifest build identity differs")
    require(build.get("checksum", {}).get("checksum_valid") is True, "manifest checksum invalid")
    require(generator.get("status") == "PASS" and generator.get("output_bank_sha256") == ASSET_SHA256,
            "A8 generator report is not final")
    require(generator.get("changed_bytes_vs_advance_7") == 37
            and generator.get("english_text_changed_bytes") == 0
            and generator.get("residual_japanese_glyph_pixels_after") == 0,
            "A8 generator protection metrics differ")

    require(rules.get("status") == "PASS" and rules.get("project_version") == "0.10.7-graphics-a8",
            "cumulative rule identity differs")
    require(len(rules.get("rules", [])) == 28, "expected 28 cumulative rules")
    require(all(row.get("mandatory") is True for row in rules["rules"]), "a cumulative rule is optional")
    for advance in range(1, 9):
        require(rules.get(f"advance_{advance}", {}).get("status") == "PASS",
                f"Advance {advance} checkpoint missing")

    require(runtime.get("status") == "PASS" and runtime.get("candidate_advance_8_sha256") == A8_SHA256,
            "A8 runtime validation is not final")
    require(runtime.get("clean_boots") == 4 and runtime.get("uses_save_or_savestate") is False,
            "A8 runtime routes were not clean")
    states = runtime.get("target_states", [])
    require(len(states) == 2 and all(row.get("changed_pixels") == 43 for row in states)
            and all(row.get("pixels_outside_target_rectangle") == 0 for row in states)
            and all(row.get("both_live_card_banks_match_rom") is True for row in states),
            "A8 target-state runtime metrics differ")
    require(all(row.get("pixel_exact") is True for row in runtime.get("unrelated_route_states", []))
            and len(runtime.get("unrelated_route_states", [])) == 3,
            "A8 unrelated route regression differs")
    require(runtime.get("residual_japanese_visible") is False
            and runtime.get("manual_semantic_review") == "PASS",
            "A8 visual review is not final")

    report = {
        "status": "PASS", "project_version": "0.10.7-graphics-a8", "rules_enforced": 28,
        "source_rom_sha256": SOURCE_SHA256, "base_advance_7_sha256": A7_SHA256,
        "candidate_rom_sha256": A8_SHA256, "cumulative_ips_sha256": IPS_SHA256,
        "wonder_swan_checksum": "0xB6E7", "ips_reconstructs_candidate": True,
        "manifest_reconstructs_candidate": True, "direct_build_matches_manifest": True,
        "binary_write_allowlist": "PASS", "changed_bytes_vs_advance_7": 39,
        "card_bank_changed_bytes": 37, "changed_tile_ids": ["0x032", "0x033", "0x034", "0x035"],
        "english_card_rows_protection": "PASS", "frame_integrity": "PASS",
        "shared_consumer_runtime_identity": "PASS", "pixels_outside_target_rectangles": 0,
        "advance_1_through_7_checkpoints": "PASS", "advance_8_checkpoint": "PASS",
        "residual_japanese_visible": False, "manual_semantic_review": "PASS",
    }
    output = root / "build/graphics_advance_rules_validation.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
