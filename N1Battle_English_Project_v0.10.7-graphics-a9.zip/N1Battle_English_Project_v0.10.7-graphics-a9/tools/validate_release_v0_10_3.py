#!/usr/bin/env python3
"""Validate the canonical v0.10.3 manifest, ROM, IPS and visual QA evidence."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


PROJECT_VERSION = "0.10.3"
SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
FINAL_ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
BASE_V0102_SHA256 = "b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24"
IPS_SHA256 = "db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7"
ROM_SIZE = 0x400000
TEXT_ENTRY_COUNT = 271
BINARY_ENTRY_COUNT = 77
TEXT_DENOMINATOR = 1552
GRAPHICS_DENOMINATOR = 129

EXPECTED_ASSETS = {
    "main_logo_bg0_map": "3e8911f5e96aec73a93cab9b1a5923aab5f03b56f0ddfb279be685afd8245236",
    "main_logo_tiles": "df551f0e32d0d5954773568063945547bf8361b2fd47cff3c1e024ce435d8915",
    "name_keyboard_obj_low_mask": "2d4b9752c5f396dadfd2f05e5ce4182ce7a750c7909d40e841452f1b09a477eb",
    "name_keyboard_obj_cap_mask": "b1388a7b66111d0f810a1d2b2611a764e4aa5f7178858cb9dc272c3c2f60d078",
    "name_keyboard_obj_abc_mask": "57ee607495b834236e0212f0bd22aa132c57a8550f4dba85f4b8cb0ad649ded9",
    "program_deck_manual_stats_bg0_map": "3dee6f7defb7d4b76c9223660140d861a4c2b0bdb1fffeaa7c9062d327eb4996",
    "program_deck_manual_order_bg0_map": "f5c00161868770672e34e8daa3eedd38c3ac8c05403ba8c962b19a91dd4a6057",
    "program_deck_manual_tool_bg0_map": "de316b72749a1c08d787adcdcf35f0b8fb1ab2e5fa09ebcafd142687d0df5740",
    "program_deck_manual_internal_tiles": "e73fb7e716cafeea1f5c5c707621cf6749694ea982a446b5a4e1ddea8d83df11",
}

RUNTIME_REPORTS = {
    "title": "docs/runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json",
    "keyboard": "docs/runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json",
    "program_deck": "docs/runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def result(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def path_label(path: Path, root: Path) -> str:
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.name


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--built-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    parser.add_argument("--base-v0-10-2-rom", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_10_3.json").resolve()
    built_path = (args.built_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.3.wsc").resolve()
    ips_path = (args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.3.ips").resolve()
    base_path = (args.base_v0_10_2_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.2.wsc").resolve()
    report_path = (args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10_3.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-deep-release-validation-v1",
        "project_version": PROJECT_VERSION,
        "report_date": "2026-08-22",
        "overall_result": "FAIL",
        "inputs": {
            "manifest": path_label(manifest_path, root),
            "built_rom": path_label(built_path, root),
            "ips": path_label(ips_path, root),
        },
        "checks": {}, "inventories": {}, "errors": [],
    }
    try:
        old = load_module("validate_release_v0102_for_v0103", root / "tools/validate_release_v0_10_2.py")
        v09 = old.v09
        n1tool = v09.load_module("n1tool_validation_v0103", root / "tools/n1tool.py")
        bcc = v09.load_module("bcc_validation_v0103", root / "tools/bcc_reference.py")
        source = args.source_rom.read_bytes()
        built = built_path.read_bytes()
        base = base_path.read_bytes()
        ips = ips_path.read_bytes()
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")

        report["checks"]["verified_source"] = result(
            len(source) == ROM_SIZE and sha256(source) == SOURCE_SHA256,
            size=len(source), sha256=sha256(source), expected_sha256=SOURCE_SHA256,
        )
        header_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == PROJECT_VERSION
            and manifest.get("source_sha256") == SOURCE_SHA256
        )
        report["checks"]["manifest_header"] = result(
            header_ok, sha256=sha256(manifest_bytes), project_version=manifest.get("project_version")
        )
        entries = manifest.get("entries", [])
        binary_entries = manifest.get("binary_entries", [])
        expanded = manifest.get("expanded_inventory", {})
        inventory_ok = (
            isinstance(entries, list) and len(entries) == TEXT_ENTRY_COUNT
            and isinstance(binary_entries, list) and len(binary_entries) == BINARY_ENTRY_COUNT
            and expanded.get("text_units") == {"translated": 1552, "denominator": 1552}
            and expanded.get("graphical_occurrences") == {"translated": 129, "denominator": 129}
            and expanded.get("known_residual_japanese_targets") == 0
        )
        report["checks"]["manifest_inventory"] = result(
            inventory_ok, text_entries=len(entries), binary_entries=len(binary_entries),
            expected_text_entries=TEXT_ENTRY_COUNT, expected_binary_entries=BINARY_ENTRY_COUNT,
        )

        spans, guards, duplicate_ids = old.parse_manifest_spans(source, manifest)
        overlaps = old.span_overlaps(spans)
        guard_failures = [row for row in guards if not row["guard_ok"]]
        report["checks"]["manifest_span_layout"] = result(
            not overlaps and not duplicate_ids,
            spans=len(spans), overlaps=overlaps[:20], duplicate_ids=duplicate_ids,
        )
        report["checks"]["manifest_source_guards"] = result(
            not guard_failures and len(guards) == TEXT_ENTRY_COUNT + BINARY_ENTRY_COUNT,
            checked=len(guards), failures=guard_failures[:20],
        )

        rebuilt, rebuild_entries = n1tool.patch_entries(source, manifest, encode, manifest_path.parent)
        rebuild_ok = rebuilt == built and sha256(built) == FINAL_ROM_SHA256
        report["checks"]["canonical_rebuild"] = result(
            rebuild_ok, built_sha256=sha256(built), rebuilt_sha256=sha256(rebuilt),
            byte_identical=rebuilt == built, report_entries=len(rebuild_entries),
        )
        applied = n1tool.apply_ips(source, ips)
        canonical_ips = n1tool.make_ips(source, rebuilt)
        report["checks"]["ips_round_trip"] = result(
            applied == built and canonical_ips == ips and sha256(ips) == IPS_SHA256,
            ips_sha256=sha256(ips), expected_ips_sha256=IPS_SHA256,
            applies_to_exact_build=applied == built, canonical_ips_identical=canonical_ips == ips,
        )
        stored = int.from_bytes(built[-2:], "little")
        calculated = sum(built[:-2]) & 0xFFFF
        report["checks"]["wonderswan_checksum"] = result(
            len(built) == ROM_SIZE and stored == calculated,
            size=len(built), stored=f"0x{stored:04X}", calculated=f"0x{calculated:04X}",
        )

        allowed = bytearray(ROM_SIZE)
        for start, end, _entry_id, _kind in spans:
            allowed[start:end] = b"\x01" * (end - start)
        allowed[-2:] = b"\x01\x01"
        outside = [
            index for index, (before, after) in enumerate(zip(source, built))
            if before != after and not allowed[index]
        ]
        report["checks"]["manifest_change_allowlist"] = result(
            not outside,
            changed_bytes=sum(a != b for a, b in zip(source, built)),
            outside_count=len(outside), first_outside=[f"0x{x:06X}" for x in outside[:20]],
        )

        asset_results = []
        asset_ok_by_id: dict[str, bool] = {}
        for entry in binary_entries:
            entry_id = str(entry["id"])
            start = v09.number(entry["offset"])
            length = v09.number(entry["length"])
            asset_path = (manifest_path.parent / str(entry["asset"])).resolve()
            safe = manifest_path.parent.resolve() in asset_path.parents
            payload = asset_path.read_bytes() if safe and asset_path.is_file() else b""
            expected_hash = str(entry.get("asset_sha256", "")).lower()
            ok = (
                safe and len(payload) == length and bool(expected_hash)
                and sha256(payload) == expected_hash
                and built[start:start + length] == payload
            )
            asset_ok_by_id[entry_id] = ok
            asset_results.append({
                "id": entry_id, "ok": ok, "length": len(payload),
                "sha256": sha256(payload), "expected_sha256": expected_hash,
            })
        asset_failures = [row for row in asset_results if not row["ok"]]
        expected_focus_ok = all(
            asset_ok_by_id.get(entry_id) is True
            and next(row for row in asset_results if row["id"] == entry_id)["sha256"] == wanted
            for entry_id, wanted in EXPECTED_ASSETS.items()
        )
        report["checks"]["binary_assets"] = result(
            not asset_failures and expected_focus_ok and len(asset_results) == BINARY_ENTRY_COUNT,
            checked=len(asset_results), failures=asset_failures[:20],
            focused_v0_10_3_assets=EXPECTED_ASSETS,
        )

        # v0.10.3 is a graphics-only refinement over v0.10.2.  Prove that its
        # delta stays in the exact audited resources, reverted page byte and checksum.
        base_ok = len(base) == ROM_SIZE and sha256(base) == BASE_V0102_SHA256
        delta_allowed = bytearray(ROM_SIZE)
        for start, length in (
            (0x0409A6, 0x0380), (0x071BC0, 0x1A00),
            (0x04EC24, 0x0400), (0x04F528, 0x0400), (0x04F9AA, 0x0400),
            (0x0ACA20, 0x5B60),
            (0x19A47E, 0x00C0), (0x19A55C, 0x00C0), (0x19A63A, 0x00C0),
            (0x32B147, 1), (ROM_SIZE - 2, 2),
        ):
            delta_allowed[start:start + length] = b"\x01" * length
        delta_outside = [
            index for index, (before, after) in enumerate(zip(base, built))
            if before != after and not delta_allowed[index]
        ]
        report["checks"]["v0_10_2_to_v0_10_3_delta"] = result(
            base_ok and not delta_outside,
            base_sha256=sha256(base), changed_bytes=sum(a != b for a, b in zip(base, built)),
            outside_count=len(delta_outside), first_outside=[f"0x{x:06X}" for x in delta_outside[:20]],
            source_low_page_byte=f"0x{source[0x32B147]:02X}",
            v0_10_2_page_byte=f"0x{base[0x32B147]:02X}",
            v0_10_3_page_byte=f"0x{built[0x32B147]:02X}",
        )

        arrow_spans = ((0x07CE80, 0x20), (0x07D080, 0x20))
        arrow_ok = all(built[start:start + length] == source[start:start + length] for start, length in arrow_spans)
        icon_tiles = (0x50, 0x51, 0x58, 0x59, 0x5E, 0x5F)
        icon_ok = all(
            built[0x07CD20 + tile * 32:0x07CD20 + (tile + 1) * 32]
            == source[0x07CD20 + tile * 32:0x07CD20 + (tile + 1) * 32]
            for tile in icon_tiles
        )
        report["checks"]["protected_program_deck_symbols"] = result(
            arrow_ok and icon_ok, direction_arrow_byte_identical=arrow_ok,
            chip_type_pictogram_byte_identical=icon_ok,
        )

        title_report = json.loads((root / "translation/assets/title_logo_asset_report_v0_10_3.json").read_text(encoding="utf-8"))
        quality_report = json.loads((root / "translation/assets/quality_graphics_asset_report_v0_10_3.json").read_text(encoding="utf-8"))
        asset_reports_ok = (
            title_report.get("status") == "PASS"
            and title_report.get("cleanup", {}).get("removed_pixels") == 384
            and title_report.get("cleanup", {}).get("maximum_opaque_y") == 102
            and title_report.get("capacity", {}).get("unique_tiles_used") == 191
            and quality_report.get("status") == "PASS"
            and quality_report.get("keyboard", {}).get("bg_map_and_tiles_changed") is False
            and quality_report.get("program_deck", {}).get("protected_original_art", {}).get("byte_identical_to_japanese_source") is True
        )
        report["checks"]["v0_10_3_asset_reports"] = result(
            asset_reports_ok,
            title_report="translation/assets/title_logo_asset_report_v0_10_3.json",
            quality_report="translation/assets/quality_graphics_asset_report_v0_10_3.json",
        )

        residual_path = root / "docs/RESIDUAL_TEXT_SCAN_v0_10_3.json"
        residual = json.loads(residual_path.read_text(encoding="utf-8"))
        residual_ok = (
            residual.get("overall_result") == "PASS"
            and residual.get("project_version") == PROJECT_VERSION
            and residual.get("checks", {}).get("build_size_and_optional_hash", {}).get("sha256") == FINAL_ROM_SHA256
            and residual.get("inventory", {}).get("translated") == TEXT_DENOMINATOR
            and residual.get("inventory", {}).get("remaining_japanese_targets") == 0
        )
        report["checks"]["residual_text_scan"] = result(
            residual_ok, report="docs/RESIDUAL_TEXT_SCAN_v0_10_3.json",
            status=residual.get("overall_result"),
        )

        runtime_details = {}
        runtime_ok = True
        for name, relative in RUNTIME_REPORTS.items():
            path = root / relative
            if path.is_file():
                payload = json.loads(path.read_text(encoding="utf-8"))
                runtime_rom_sha256 = payload.get("rom_sha256")
                if runtime_rom_sha256 is None and isinstance(payload.get("rom"), dict):
                    runtime_rom_sha256 = payload["rom"].get("sha256")
                ok = payload.get("status") == "PASS" and runtime_rom_sha256 == FINAL_ROM_SHA256
                runtime_details[name] = {
                    "report": relative,
                    "status": payload.get("status"),
                    "rom_sha256": runtime_rom_sha256,
                }
            else:
                ok = False
                runtime_details[name] = {"report": relative, "status": "MISSING"}
            runtime_ok = runtime_ok and ok
        report["checks"]["v0_10_3_runtime_evidence"] = result(runtime_ok, suites=runtime_details)

        text_inventory, text_check = old.audit_text(source, built, n1tool, bcc, decode)
        graphics_inventory, graphics_check = old.graphics_inventory(asset_ok_by_id)
        report["inventories"]["text"] = text_inventory
        report["inventories"]["graphics"] = graphics_inventory
        report["checks"]["expanded_text_inventory"] = text_check
        report["checks"]["expanded_graphics_inventory"] = graphics_check

        failures = [name for name, check in report["checks"].items() if check.get("result") != "PASS"]
        report["overall_result"] = "PASS" if not failures else "FAIL"
        if failures:
            report["errors"].append("failed checks: " + ", ".join(failures))
    except Exception as exc:
        report["errors"].append(f"{type(exc).__name__}: {exc}")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "overall_result": report["overall_result"],
        "failed_checks": [name for name, check in report["checks"].items() if check.get("result") != "PASS"],
        "errors": report["errors"], "report": path_label(report_path, root),
        "report_sha256": sha256(report_path.read_bytes()),
    }, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
