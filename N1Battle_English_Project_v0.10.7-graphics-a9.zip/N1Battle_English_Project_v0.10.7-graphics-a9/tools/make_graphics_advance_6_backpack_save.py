#!/usr/bin/env python3
"""Create a checksummed player save with a deterministic Backpack inventory."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


BLOCKS = (0x1000, 0x2000)
BACKPACK_START = 0x0153
BACKPACK_LENGTH = 0x00F9
QUANTITY_START = 0x024C
QUANTITY_LENGTH = 0x0100
EMPTY_RECORD = b"\xFF"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument(
        "--chip",
        action="append",
        default=[],
        metavar="ID:COUNT",
        help="append one chip ID whose displayed quantity is COUNT",
    )
    args = parser.parse_args()

    source = args.input.read_bytes()
    if len(source) != 0x8000:
        raise ValueError("source must be a 32 KiB Mesen SRAM image")
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")

    records: list[bytes] = []
    quantities = bytearray(QUANTITY_LENGTH)
    requested: list[dict[str, int]] = []
    for specification in args.chip:
        try:
            chip_text, count_text = specification.split(":", 1)
            chip_id = int(chip_text, 0)
            count = int(count_text, 0)
        except ValueError as exc:
            raise ValueError(f"invalid chip specification: {specification}") from exc
        if not 0 <= chip_id < 0xFF or not 0 <= count <= 0xFF:
            raise ValueError(f"invalid chip specification: {specification}")
        if quantities[chip_id] or any(record[0] == chip_id for record in records):
            raise ValueError(f"duplicate chip ID in probe: 0x{chip_id:02X}")
        records.append(bytes((chip_id,)))
        quantities[chip_id] = count
        requested.append({"chip_id": chip_id, "count": count})
    if len(records) > BACKPACK_LENGTH:
        raise ValueError("Backpack probe exceeds 249 one-byte records")

    output = bytearray(source)
    payload = b"".join(records) + EMPTY_RECORD * (BACKPACK_LENGTH - len(records))
    quantity_payload = bytes(quantities)
    for block in BLOCKS:
        if output[block:block + 4] != b"INTI":
            raise ValueError(f"missing player INTI signature at 0x{block:04X}")
        payload_length = int.from_bytes(output[block + 6:block + 8], "little")
        if payload_length != 0x0466:
            raise ValueError("player save payload length differs from 0x0466")
        output[block + BACKPACK_START:block + BACKPACK_START + BACKPACK_LENGTH] = payload
        output[block + QUANTITY_START:block + QUANTITY_START + QUANTITY_LENGTH] = quantity_payload
        checksum = sum(output[block + 0x0C:block + 0x0C + payload_length]) & 0xFFFF
        output[block + 4:block + 6] = checksum.to_bytes(2, "little")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    print(f"source_sha256={sha256(source)}")
    print(f"output_sha256={sha256(output)}")
    print(f"backpack_records={len(records)} requested={requested}")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
