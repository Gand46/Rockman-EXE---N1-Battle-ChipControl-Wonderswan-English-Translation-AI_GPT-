#!/usr/bin/env python3
"""Validate the pixel-polished v0.10.6 Free/Host static labels and menus.

Every route starts with an empty Mesen home and reaches its target using only
normal controller input.  The validator captures native 224x144 frames and
live CPU memory, verifies the exact English ROM assets loaded in BG0/tile RAM,
and checks that Free Battle's two-digit BG1 streak counter remains intact.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import ctypes
import hashlib
import json
import os
import shutil
import subprocess
import sys
import threading
import time
from dataclasses import dataclass
from pathlib import Path

from PIL import Image, ImageDraw


MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
MEM_CPU = 13
NATIVE_SIZE = (224, 144)
EXPECTED_ROM_SHA256 = (
    "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
)


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


@dataclass(frozen=True)
class Capture:
    frame: int
    label: str


@dataclass(frozen=True)
class Route:
    name: str
    stop_frame: int
    right_pulses: tuple[int, ...]
    a_pulses: tuple[int, ...]
    down_pulses: tuple[int, ...]
    repeating_a: tuple[int, int, int] | None
    captures: tuple[Capture, ...]


ROUTES = (
    Route(
        "carousel",
        27400,
        (26920, 27040, 27160, 27280),
        (),
        (),
        None,
        (
            Capture(27000, "shop_carousel"),
            Capture(27120, "battlechip_gp_carousel"),
            Capture(27200, "free_battle_carousel"),
            Capture(27360, "host_tourney_carousel"),
        ),
    ),
    Route(
        "free_interior",
        27340,
        (26920, 27040, 27160),
        (27230,),
        (),
        None,
        (Capture(27320, "free_streak_0"),),
    ),
    Route(
        "host_reachable",
        30900,
        (26920, 27040, 27160, 27280),
        (27350,),
        (),
        (27500, 30801, 300),
        (
            Capture(27360, "host_tourney_before_entry"),
            Capture(30440, "host_setup_choice"),
            Capture(30720, "host_navi_roster"),
            Capture(30880, "host_entry_name_register"),
        ),
    ),
    Route(
        "host_tourney_choice",
        31500,
        (26920, 27040, 27160, 27280),
        (27350,),
        (30460,),
        (27500, 31401, 300),
        (
            Capture(30440, "host_tourney_setup_choice"),
            Capture(30720, "host_entrant_count_prompt"),
            Capture(31040, "host_entrant_count_16"),
            Capture(31200, "host_choose_entrants"),
            Capture(31400, "host_missing_15_entrants"),
        ),
    ),
)


ASSETS = {
    "shop_carousel": {
        "map": (0x041BB2, 0x0480, 0x2000,
                "696cb55cbdbb7f3b335ada4e84b6cf65d9370f1d8e7b833762d01ca3e418e99d"),
        "tiles": (0x0768F0, 0x1740, 0x8000,
                  "d2133c4d6cb0b647608193f346dac3bc6f11730056da7b015961e604636a967e"),
        "expected_visible_text": "SHOP",
    },
    "battlechip_gp_carousel": {
        "map": (0x042034, 0x0480, 0x2000,
                "b340fbc1dd04c7d9088aeab7e203a23d76014edac54e1e7ae9c080c8ec3fadce"),
        "tiles": (0x078100, 0x1480, 0x8000,
                  "8892b633507d8fd6c04457b09229d9b5e538e8bca7aa70eced5f82e530468a2c"),
        "expected_visible_text": "BATTLE CHIP GP",
    },
    "free_battle_carousel": {
        "map": (0x0424B6, 0x0480, 0x2000,
                "8306b6db772a616c544c2abc41729bdff343624e4aff80021a2bee592d2fe011"),
        "tiles": (0x079650, 0x1580, 0x8000,
                  "da5ef59d7fc990d3436c5b20c447481875ac9df254e2d14a02a50fdd46271a00"),
        "japanese_source_hashes": {
            "map": "834a4914cc5ba67c40dfd423a8286d427c516809775e59571b7e155d150c6aae",
            "tiles": "263ed97ad2d875bbeaa127f91c168df5f11f9d4c70fad669468e5c6add599dd4",
        },
        "expected_visible_text": "FREE BATTLE",
    },
    "host_tourney_carousel": {
        "map": (0x042938, 0x0480, 0x2000,
                "e32c3b9c3e47ce8d1adb7ee6dcc0fd989fc4a36f9a04eeea0cfe52772f0c3e34"),
        "tiles": (0x07ACA0, 0x15C0, 0x8000,
                  "8197bbdac7668a5e35e3ae87406992598d214278e96731c67fd50c8e5ea7b1ed"),
        "japanese_source_hashes": {
            "map": "9b4a0d7914ad0e29a1eb12a540eaec1552c1ce7edfca74ea06582d05d2547fb2",
            "tiles": "a3a82671c8c6e79b1876ef3f7a903ded219778cf74b32567d28d5012f3d5ee49",
        },
        "expected_visible_text": "HOST TOURNEY",
    },
    "free_streak_0": {
        "map": (0x049AE8, 0x0480, 0x2000,
                "3606fa7a483c7b0295a070926c9f2ba1cb3871848a42214f4c55e8c6cd4fcf4b"),
        "tiles": (0x0896F0, 0x26C0, 0x8000,
                  "ecae450ef0d97e3f9bf0e330a3b2f28c66db36026fcf6a7b998194720530d848"),
        "japanese_source_hashes": {
            "tiles": "6d133d6c7c8037070b5b796258e8648839fd816e3af3e0daf0cd58979d9dfeba",
        },
        "expected_visible_text": "STREAK 0",
    },
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pulse(frame: int, first: int, duration: int = 8) -> bool:
    return first <= frame < first + duration


def input_for(route: Route, frame: int) -> Controller:
    state = Controller()
    state.Start = pulse(frame, 650, 10)
    intro_and_manual = 1200 <= frame <= 26708 and frame % 300 < 8
    repeated = False
    if route.repeating_a is not None:
        first, end, interval = route.repeating_a
        repeated = first <= frame < end and (frame - first) % interval < 8
    state.A = (
        pulse(frame, 950)
        or intro_and_manual
        or any(pulse(frame, first) for first in route.a_pulses)
        or repeated
    )
    state.Right = any(pulse(frame, first) for first in route.right_pulses)
    state.Down = any(pulse(frame, first) for first in route.down_pulses)
    return state


def configure_core(lib: ctypes.CDLL) -> None:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause",
        "Resume", "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]


def run_route(
    route: Route,
    rom_path: Path,
    core_path: Path,
    output_dir: Path,
    timeout: float,
) -> dict:
    route_dir = output_dir / route.name
    if route_dir.exists():
        shutil.rmtree(route_dir)
    home = route_dir / "mesen_core_home"
    screenshots = home / "Screenshots"
    screenshots.mkdir(parents=True)
    targets = {capture.frame: capture for capture in route.captures}

    lib = ctypes.CDLL(str(core_path.resolve()))
    configure_core(lib)
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    completed = 0
    reached = threading.Event()
    memories: dict[int, bytes] = {}

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for(route, completed + 1))
        if completed in targets:
            lib.TakeScreenshot()
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
            memories[completed] = bytes(buffer)
        if completed >= route.stop_frame:
            reached.set()

    listener = None
    started = time.monotonic()
    try:
        lib.InitDll()
        lib.InitializeEmu(str(home.resolve()).encode(), None, None, True, True, True, True)
        if not lib.LoadRom(str(rom_path.resolve()).encode(), b""):
            raise RuntimeError(f"{route.name}: MesenCore LoadRom failed")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for(route, 0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError(f"{route.name}: callback registration failed")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached.wait(timeout):
            raise TimeoutError(f"{route.name}: timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.5)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        try:
            lib.Stop()
            lib.Release()
        except BaseException:
            pass

    deadline = time.monotonic() + 8.0
    while len(list(screenshots.glob("*.png"))) < len(targets) and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(screenshots.glob("*.png"))
    if len(sources) != len(targets) or len(memories) != len(targets):
        raise RuntimeError(
            f"{route.name}: expected {len(targets)} screenshots/memories, "
            f"found {len(sources)}/{len(memories)}"
        )

    capture_reports = []
    for capture, source in zip(route.captures, sources, strict=True):
        destination = route_dir / f"{capture.label}_{capture.frame:05d}.png"
        shutil.copy2(source, destination)
        with Image.open(destination) as image:
            dimensions = tuple(image.size)
        if dimensions != NATIVE_SIZE:
            raise RuntimeError(
                f"{capture.label}: expected {NATIVE_SIZE}, got {dimensions}"
            )
        memory = memories[capture.frame]
        memory_path = route_dir / f"{capture.label}_{capture.frame:05d}_cpu.bin"
        memory_path.write_bytes(memory)
        capture_reports.append(
            {
                "frame": capture.frame,
                "label": capture.label,
                "file": str(destination.relative_to(output_dir)),
                "sha256": sha256(destination.read_bytes()),
                "dimensions": list(dimensions),
                "cpu_memory": str(memory_path.relative_to(output_dir)),
                "cpu_memory_sha256": sha256(memory),
            }
        )

    shutil.rmtree(home)
    return {
        "name": route.name,
        "clean_boot": True,
        "uses_input_save_or_savestate": False,
        "right_pulses": list(route.right_pulses),
        "a_pulses": list(route.a_pulses),
        "down_pulses": list(route.down_pulses),
        "repeating_a": list(route.repeating_a) if route.repeating_a else None,
        "last_callback_frame": completed,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "captures": capture_reports,
    }


def verify_asset(
    label: str,
    memory: bytes,
    rom: bytes,
    spec: dict,
) -> dict:
    checks = {}
    for kind in ("map", "tiles"):
        rom_offset, length, ram_offset, expected_hash = spec[kind]
        rom_payload = rom[rom_offset:rom_offset + length]
        live_payload = memory[ram_offset:ram_offset + length]
        rom_hash = sha256(rom_payload)
        live_hash = sha256(live_payload)
        if rom_hash != expected_hash:
            raise AssertionError(
                f"{label} {kind}: ROM hash {rom_hash} != {expected_hash}"
            )
        if live_payload != rom_payload:
            raise AssertionError(f"{label} {kind}: live RAM differs from ROM asset")
        source_hash = spec.get("japanese_source_hashes", {}).get(kind)
        if source_hash is not None and live_hash == source_hash:
            raise AssertionError(f"{label} {kind}: Japanese source asset survived")
        checks[kind] = {
            "rom_offset": f"0x{rom_offset:06X}",
            "ram_offset": f"0x{ram_offset:04X}",
            "length": length,
            "sha256": live_hash,
            "matches_v0_10_rom": True,
            "differs_from_japanese_source": source_hash is not None,
        }
    checks["expected_visible_text"] = spec["expected_visible_text"]
    checks["status"] = "PASS"
    return checks


def verify_counter(memory: bytes) -> dict:
    cells = (
        (5, 1, 0x0102),
        (6, 1, 0x0100),
        (5, 2, 0x0103),
        (6, 2, 0x0101),
    )
    records = []
    payload = bytearray()
    for x, y, expected in cells:
        address = 0x3000 + y * 64 + x * 2
        value = memory[address] | (memory[address + 1] << 8)
        if value != expected:
            raise AssertionError(
                f"BG1 counter ({x},{y}) is 0x{value:04X}, expected 0x{expected:04X}"
            )
        payload.extend(memory[address:address + 2])
        records.append(
            {"x": x, "y": y, "address": f"0x{address:04X}",
             "map_word": f"0x{value:04X}"}
        )

    # At zero wins the tens-column tiles 0x102/0x103 are blank; the units
    # column 0x100/0x101 contains the visible zero.  Tile bank 0 starts at 4000.
    digit_tiles = {}
    for tile in (0x100, 0x101, 0x102, 0x103):
        address = 0x4000 + tile * 32
        tile_data = memory[address:address + 32]
        digit_tiles[f"0x{tile:03X}"] = {
            "address": f"0x{address:04X}",
            "sha256": sha256(tile_data),
            "nonzero_bytes": sum(value != 0 for value in tile_data),
        }
    if digit_tiles["0x102"]["nonzero_bytes"] != 0 or digit_tiles["0x103"]["nonzero_bytes"] != 0:
        raise AssertionError("Free streak leading-zero column is not blank")
    if digit_tiles["0x100"]["nonzero_bytes"] == 0 or digit_tiles["0x101"]["nonzero_bytes"] == 0:
        raise AssertionError("Free streak units zero glyph is blank")
    return {
        "layer": "BG1",
        "map_base": "0x3000",
        "cells": records,
        "cells_sha256": sha256(bytes(payload)),
        "digit_tiles": digit_tiles,
        "visible_value": 0,
        "preserved": True,
        "status": "PASS",
    }


def make_montage(output_dir: Path, capture_reports: list[dict]) -> Path:
    margin = 8
    caption_height = 18
    columns = 3
    rows = (len(capture_reports) + columns - 1) // columns
    canvas = Image.new(
        "RGB",
        (
            columns * NATIVE_SIZE[0] + (columns + 1) * margin,
            rows * (NATIVE_SIZE[1] + caption_height) + (rows + 1) * margin,
        ),
        "white",
    )
    draw = ImageDraw.Draw(canvas)
    for index, capture in enumerate(capture_reports):
        image_path = output_dir / capture["file"]
        with Image.open(image_path) as source:
            image = source.convert("RGB")
        column = index % columns
        row = index // columns
        x = margin + column * (NATIVE_SIZE[0] + margin)
        y = margin + row * (NATIVE_SIZE[1] + caption_height + margin)
        canvas.paste(image, (x, y))
        draw.text((x, y + NATIVE_SIZE[1] + 2), capture["label"], fill="black")
    path = output_dir / "free_host_runtime_montage_v0_10_6.png"
    canvas.save(path)
    return path


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=180.0, type=float)
    parser.add_argument("--worker-route", choices=tuple(route.name for route in ROUTES))
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    rom_hash = sha256(rom)
    if rom_hash != EXPECTED_ROM_SHA256:
        raise ValueError(
            f"unsupported final ROM {rom_hash}; expected {EXPECTED_ROM_SHA256}"
        )
    if args.worker_route is not None:
        args.output_dir.mkdir(parents=True, exist_ok=True)
        route = next(route for route in ROUTES if route.name == args.worker_route)
        route_report = run_route(
            route, args.rom, args.mesen_core, args.output_dir, args.timeout
        )
        worker_report = args.output_dir / route.name / "worker_result.json"
        worker_report.write_text(
            json.dumps(route_report, indent=2) + "\n", encoding="utf-8"
        )
        print(json.dumps(route_report, indent=2))
        return 0

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)

    started = time.monotonic()
    # MesenCore owns process-global state and cannot be safely initialized,
    # released and initialized again in one Python process.  Isolate each
    # clean boot in a worker process, then consolidate their deterministic
    # JSON/memory evidence here.
    def invoke_worker(route: Route) -> dict:
        command = [
            sys.executable,
            str(Path(__file__).resolve()),
            "--rom", str(args.rom.resolve()),
            "--mesen-core", str(args.mesen_core.resolve()),
            "--output-dir", str(args.output_dir.resolve()),
            "--timeout", str(args.timeout),
            "--worker-route", route.name,
        ]
        result = subprocess.run(
            command,
            check=False,
            capture_output=True,
            text=True,
            env={**dict(os.environ), "PYTHONDONTWRITEBYTECODE": "1"},
        )
        if result.returncode != 0:
            raise RuntimeError(
                f"{route.name} worker failed with {result.returncode}:\n"
                f"{result.stdout}\n{result.stderr}"
            )
        worker_report = args.output_dir / route.name / "worker_result.json"
        return json.loads(worker_report.read_text(encoding="utf-8"))

    # Each worker owns a different disposable Mesen home and output subtree,
    # so the independent clean boots can run concurrently without sharing
    # emulator state.
    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ROUTES)) as executor:
        futures = {route.name: executor.submit(invoke_worker, route) for route in ROUTES}
        route_reports = [futures[route.name].result() for route in ROUTES]
    by_label = {
        capture["label"]: capture
        for route in route_reports
        for capture in route["captures"]
    }
    asset_checks = {}
    for label, spec in ASSETS.items():
        capture = by_label[label]
        memory = (args.output_dir / capture["cpu_memory"]).read_bytes()
        asset_checks[label] = verify_asset(label, memory, rom, spec)
    free_memory = (
        args.output_dir / by_label["free_streak_0"]["cpu_memory"]
    ).read_bytes()
    counter = verify_counter(free_memory)

    all_captures = [capture for route in route_reports for capture in route["captures"]]
    montage = make_montage(args.output_dir, all_captures)
    report = {
        "format": "n1-free-host-runtime-validation-v0.10.6",
        "status": "PASS",
        "rom": {"file": args.rom.name, "sha256": rom_hash},
        "native_display": list(NATIVE_SIZE),
        "route_discovery": {
            "carousel_order": [
                "BATTLE PREP", "SHOP", "BATTLE CHIP GP", "FREE BATTLE", "HOST TOURNEY"
            ],
            "free_battle": "three Right pulses from Battle Prep",
            "host_tourney": "four Right pulses from Battle Prep",
            "free_entry": "A at frame 27230 after the third Right pulse",
            "host_entry": "A at frame 27350 after the fourth Right pulse",
        },
        "routes": route_reports,
        "live_asset_checks": asset_checks,
        "free_streak_counter": counter,
        "host_without_link": {
            "reached": [
                "Set up? / Navi Roster / Host Tourney",
                "Navi roster? / Register / Delete",
                "ENTRY NAME / REGISTER keyboard",
                "Set entrant count: 16/32/64/128 NAVIS",
                "Entrants 16 / Host fee 1000z / Prize 5000z",
                "ENTRY NAME / SELECT roster",
            ],
            "connection_required_before_these_states": False,
            "blocking_state": "Choose entrants. / 15 more needed.",
            "blocking_reason": (
                "A clean boot has only one usable entry; the selected 16-Navi "
                "tournament requires 15 additional registered entrants."
            ),
            "status": "PASS",
        },
        "residual_japanese": {
            "scope": [
                "SHOP", "BATTLE CHIP GP", "FREE BATTLE", "HOST TOURNEY", "STREAK 0",
                "Navi Roster / Host Tourney", "Register / Delete",
                "16/32/64/128 NAVIS", "ENTRY NAME / SELECT",
            ],
            "exact_live_english_assets": True,
            "japanese_source_asset_hashes_absent": True,
            "visible_residual_detected": False,
            "status": "PASS",
        },
        "montage": {
            "file": montage.name,
            "sha256": sha256(montage.read_bytes()),
        },
        "elapsed_seconds": round(time.monotonic() - started, 3),
    }
    report_path = args.output_dir / "free_host_runtime_validation_v0_10_6.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
