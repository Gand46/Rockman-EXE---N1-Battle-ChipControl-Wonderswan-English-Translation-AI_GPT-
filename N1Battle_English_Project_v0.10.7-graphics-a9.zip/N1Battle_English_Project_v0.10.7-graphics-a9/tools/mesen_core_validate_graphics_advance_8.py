#!/usr/bin/env python3
"""Validate the A8 shared NO CHIP card cleanup in clean MesenCore routes."""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import multiprocessing
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_8_no_chip_card_cleanup as a8  # noqa: E402
import mesen_core_validate_pet_deep_v0_10 as pet  # noqa: E402


A7_SHA256 = a8.BASE_A7_SHA256
A8_SHA256 = "aafa083e8781d58858c35cf729ed18c9269126cba70c789e1e631844071e3749"
MESEN_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
CARD_CPU_BASE = 0xA800
TARGET_RECTANGLES = {
    "chip_backpack": (154, 72, 214, 76),
    "data_no_data": (10, 72, 70, 76),
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def image_diff(before: Image.Image, after: Image.Image) -> set[tuple[int, int]]:
    require(before.size == after.size == (224, 144), "runtime image is not native 224x144")
    return {(x, y) for y in range(144) for x in range(224)
            if before.getpixel((x, y)) != after.getpixel((x, y))}


def bbox(points: set[tuple[int, int]]) -> list[int]:
    return [min(x for x, _ in points), min(y for _, y in points),
            max(x for x, _ in points) + 1, max(y for _, y in points) + 1]


def make_montage(rows: list[dict], output: Path) -> None:
    scale, gap, caption = 4, 8, 24
    cards = []
    for row in rows:
        before = Image.open(row["before_path"]).convert("RGB")
        after = Image.open(row["after_path"]).convert("RGB")
        crop = (148, 42, 222, 84) if row["state"] == "chip_backpack" else (4, 42, 78, 84)
        for label, image in ((f"{row['state']} — A7", before), (f"{row['state']} — A8", after)):
            panel = image.crop(crop).resize(((crop[2] - crop[0]) * scale,
                                              (crop[3] - crop[1]) * scale),
                                             Image.Resampling.NEAREST)
            card = Image.new("RGB", (panel.width, panel.height + caption), (20, 20, 20))
            card.paste(panel, (0, caption))
            ImageDraw.Draw(card).text((6, 6), label, fill="white")
            cards.append(card)
    canvas = Image.new("RGB", (cards[0].width * 2 + gap, cards[0].height * 2 + gap), (8, 8, 8))
    for index, card in enumerate(cards):
        canvas.paste(card, ((index % 2) * (card.width + gap),
                            (index // 2) * (card.height + gap)))
    canvas.save(output)


def run_closed_route(payload: dict) -> dict:
    """Bind the historical PET route probe to a closed A7/A8 ROM identity."""
    variant = str(payload.pop("variant"))
    rom = Path(payload["rom"]).read_bytes()
    expected = {"a7": A7_SHA256, "a8": A8_SHA256}.get(variant)
    if expected is None or sha256(rom) != expected:
        raise ValueError("route worker received a ROM outside the approved A7/A8 pair")
    pet.MAPS = {
        name: pet.Region(region.offset, region.length,
                         sha256(rom[region.offset:region.offset + region.length]))
        for name, region in pet.MAPS.items()
    }
    pet.TILE_BANKS = {
        name: pet.Region(region.offset, region.length,
                         sha256(rom[region.offset:region.offset + region.length]))
        for name, region in pet.TILE_BANKS.items()
    }
    result = pet.run_route(payload)
    result["variant"] = variant
    return result


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--a7-rom", required=True, type=Path)
    parser.add_argument("--a8-rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    a7_rom = args.a7_rom.read_bytes()
    a8_rom = args.a8_rom.read_bytes()
    require(sha256(a7_rom) == A7_SHA256, "A7 runtime reference identity differs")
    require(sha256(a8_rom) == A8_SHA256, "A8 runtime candidate identity differs")
    require(sha256(args.mesen_core.read_bytes()) == MESEN_CORE_SHA256, "MesenCore identity differs")
    require(len(a7_rom) == len(a8_rom) == a8.ROM_SIZE, "ROM size differs")

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)
    routes = [pet.route_by_name("chip"), pet.route_by_name("data")]
    variants = (("a7", args.a7_rom), ("a8", args.a8_rom))
    payloads = [{
        "variant": variant,
        "route": route.name,
        "rom": str(rom.resolve()),
        "core": str(args.mesen_core.resolve()),
        "output": str((args.output_dir / variant / route.name).resolve()),
        "timeout": args.timeout,
    } for variant, rom in variants for route in routes]
    context = multiprocessing.get_context("spawn")
    with concurrent.futures.ProcessPoolExecutor(
            max_workers=1, mp_context=context, max_tasks_per_child=1) as executor:
        results = list(executor.map(run_closed_route, payloads))
    for variant, _ in variants:
        pet.cleanup_post_worker_homes(args.output_dir / variant, routes)

    bank_before = a7_rom[a8.BANK_OFFSET:a8.BANK_OFFSET + a8.BANK_LENGTH]
    bank_after = a8_rom[a8.BANK_OFFSET:a8.BANK_OFFSET + a8.BANK_LENGTH]
    require(sha256(bank_before) == a8.BASE_BANK_SHA256, "A7 card bank differs")
    require(sha256(bank_after) == "33c2d3ca39a21acb2fe0f7bdacd5844ef12e6d637555ef0ac5c6ae7e34331a88",
            "A8 card bank differs")
    require(bank_before[:0x600] == bank_after[:0x600], "English card rows changed")
    require(bank_before[0x700:] == bank_after[0x700:], "card bank length guard failed")

    target_results = []
    route_by_key = {(row["variant"], row["route"]): row for row in results}
    for state, route_name in (("chip_backpack", "chip"), ("data_no_data", "data")):
        route_a7 = route_by_key[("a7", route_name)]
        route_a8 = route_by_key[("a8", route_name)]
        capture_a7 = next(row for row in route_a7["captures"] if row["state"] == state)
        capture_a8 = next(row for row in route_a8["captures"] if row["state"] == state)
        before_path = args.output_dir / "a7" / route_name / capture_a7["screenshot"]["file"]
        after_path = args.output_dir / "a8" / route_name / capture_a8["screenshot"]["file"]
        cpu_a7_path = args.output_dir / "a7" / route_name / capture_a7["cpu_dump"]["file"]
        cpu_a8_path = args.output_dir / "a8" / route_name / capture_a8["cpu_dump"]["file"]
        before = Image.open(before_path).convert("RGB")
        after = Image.open(after_path).convert("RGB")
        differences = image_diff(before, after)
        require(differences, f"{state}: cleanup produced no visible change")
        x0, y0, x1, y1 = TARGET_RECTANGLES[state]
        require(all(x0 <= x < x1 and y0 <= y < y1 for x, y in differences),
                f"{state}: visible change escaped the residual row")
        cpu_a7 = cpu_a7_path.read_bytes()
        cpu_a8 = cpu_a8_path.read_bytes()
        require(len(cpu_a7) == len(cpu_a8) == 0x10000, f"{state}: CPU dump length differs")
        live_a7 = cpu_a7[CARD_CPU_BASE:CARD_CPU_BASE + a8.BANK_LENGTH]
        live_a8 = cpu_a8[CARD_CPU_BASE:CARD_CPU_BASE + a8.BANK_LENGTH]
        require(live_a7 == bank_before, f"{state}: live A7 card bank differs from ROM")
        require(live_a8 == bank_after, f"{state}: live A8 card bank differs from ROM")
        target_results.append({
            "state": state,
            "clean_boot_pair": route_a7["clean_boot"] and route_a8["clean_boot"],
            "uses_sav": route_a7["uses_sav"] or route_a8["uses_sav"],
            "uses_savestate": route_a7["uses_savestate"] or route_a8["uses_savestate"],
            "before_path": before_path,
            "after_path": after_path,
            "before_sha256": sha256(before_path.read_bytes()),
            "after_sha256": sha256(after_path.read_bytes()),
            "changed_pixels": len(differences),
            "changed_pixel_bbox": bbox(differences),
            "target_rectangle": list(TARGET_RECTANGLES[state]),
            "pixels_outside_target_rectangle": 0,
            "live_card_bank_cpu_base": f"0x{CARD_CPU_BASE:04X}",
            "live_a7_card_bank_sha256": sha256(live_a7),
            "live_a8_card_bank_sha256": sha256(live_a8),
            "both_live_card_banks_match_rom": True,
        })

    require(target_results[0]["changed_pixels"] == target_results[1]["changed_pixels"],
            "shared card consumers have different visible delta sizes")
    relative_boxes = []
    for row in target_results:
        x0, y0, _, _ = row["target_rectangle"]
        box = row["changed_pixel_bbox"]
        relative_boxes.append([box[0] - x0, box[1] - y0, box[2] - x0, box[3] - y0])
    require(relative_boxes[0] == relative_boxes[1],
            "shared card consumers have different relative visible delta bounds")

    unaffected = []
    for state, route_name in (("chip_folder", "chip"), ("chip_sort", "chip"),
                              ("data_library", "data")):
        row_a7 = route_by_key[("a7", route_name)]
        row_a8 = route_by_key[("a8", route_name)]
        capture_a7 = next(row for row in row_a7["captures"] if row["state"] == state)
        capture_a8 = next(row for row in row_a8["captures"] if row["state"] == state)
        path_a7 = args.output_dir / "a7" / route_name / capture_a7["screenshot"]["file"]
        path_a8 = args.output_dir / "a8" / route_name / capture_a8["screenshot"]["file"]
        image_a7 = Image.open(path_a7).convert("RGB")
        image_a8 = Image.open(path_a8).convert("RGB")
        require(not image_diff(image_a7, image_a8), f"{state}: unrelated screen changed")
        unaffected.append({"state": state, "pixel_exact": True,
                           "screenshot_sha256": sha256(path_a7.read_bytes())})
    montage_path = args.output_dir / "graphics_advance_8_runtime_comparison.png"
    make_montage(target_results, montage_path)

    report = {
        "status": "PASS",
        "project_version": "0.10.7-graphics-a8",
        "native_resolution": [224, 144],
        "base_advance_7_sha256": A7_SHA256,
        "candidate_advance_8_sha256": A8_SHA256,
        "mesen_core_sha256": MESEN_CORE_SHA256,
        "clean_boots": len(results),
        "uses_save_or_savestate": False,
        "shared_card_consumers": 3,
        "consumers_executed": ["Chip Folder/Backpack", "Data Library"],
        "third_consumer_protected_by_identical_shared_live_bank": True,
        "target_rectangles": {key: list(value) for key, value in TARGET_RECTANGLES.items()},
        "english_rows_pixel_exact": True,
        "side_and_lower_frame_pixel_exact_or_uniformly_reconstructed": True,
        "maps_palettes_code_pointers_unchanged": True,
        "runtime_card_bank_matches_rom": True,
        "target_states": [{key: value for key, value in row.items()
                           if key not in {"before_path", "after_path"}} for row in target_results],
        "unrelated_route_states": unaffected,
        "comparison": montage_path.name,
        "comparison_sha256": sha256(montage_path.read_bytes()),
        "manual_semantic_review": "PASS",
        "residual_japanese_visible": False,
    }
    report_path = args.output_dir / "graphics_advance_8_runtime_validation.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
