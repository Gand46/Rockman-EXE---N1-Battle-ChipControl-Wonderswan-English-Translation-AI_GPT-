#!/usr/bin/env python3
"""Compose the v0.10.4 QA ROM and source-compatible IPS from v0.10.3.

Only the four reviewed graphical resources change.  The public IPS is rebuilt
by normalising the v0.10.3 records, replacing the affected target bytes and
adding any newly changed bytes.  Thus it remains applicable to the original
Japanese Rev 1 ROM without requiring that private ROM for this delta step.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path


ROM_SIZE = 0x400000
BASE_ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
BASE_IPS_SHA256 = "db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7"
FINAL_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
FINAL_IPS_SHA256 = "025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b"


@dataclass(frozen=True)
class Asset:
    id: str
    offset: int
    length: int
    base_sha256: str
    file: str
    sha256: str


ASSETS = (
    Asset(
        "main_logo_bg0_map", 0x0409A6, 0x0480,
        "3e8911f5e96aec73a93cab9b1a5923aab5f03b56f0ddfb279be685afd8245236",
        "main_logo_bg0_map_v0_10_4.bin",
        "be3a4b84dfed1ff9d51585d4aa71f0148b60f6bea15a96829def8a30294bebf3",
    ),
    Asset(
        "pet_labels_bg0_map", 0x042DBA, 0x0400,
        "11a007a699e9b665f80f9b92d2ff59a0632454c04f5f936c6bd2d738950d4162",
        "pet_labels_bg0_map_v0_10_4.bin",
        "926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c",
    ),
    Asset(
        "main_logo_tiles", 0x071BC0, 0x1A00,
        "df551f0e32d0d5954773568063945547bf8361b2fd47cff3c1e024ce435d8915",
        "main_logo_tiles_v0_10_4.bin",
        "7a4556ddef397cf1a20d0cd8ab6552efa589b23a7b561c6145a12bcc5cb214a8",
    ),
    Asset(
        "pet_labels_tiles", 0x07C330, 0x0980,
        "778b7b1a4d7000f53910544e7c2c4d7f2a0f692627e3b5ffaaf39bd2bedd951f",
        "pet_labels_tiles_v0_10_4.bin",
        "f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2",
    ),
)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def parse_ips(patch: bytes, size: int) -> tuple[bytearray, bytearray]:
    if not patch.startswith(b"PATCH"):
        raise ValueError("base file is not an IPS patch")
    covered = bytearray(size)
    values = bytearray(size)
    cursor = 5
    while True:
        if patch[cursor:cursor + 3] == b"EOF":
            cursor += 3
            break
        if cursor + 5 > len(patch):
            raise ValueError("truncated IPS record")
        offset = int.from_bytes(patch[cursor:cursor + 3], "big")
        length = int.from_bytes(patch[cursor + 3:cursor + 5], "big")
        cursor += 5
        if length:
            data = patch[cursor:cursor + length]
            if len(data) != length:
                raise ValueError("truncated IPS data")
            cursor += length
        else:
            if cursor + 3 > len(patch):
                raise ValueError("truncated IPS RLE data")
            run = int.from_bytes(patch[cursor:cursor + 2], "big")
            data = patch[cursor + 2:cursor + 3] * run
            cursor += 3
        end = offset + len(data)
        if end > size:
            raise ValueError("IPS record exceeds the 4 MiB ROM")
        covered[offset:end] = b"\x01" * len(data)
        values[offset:end] = data
    if cursor != len(patch):
        raise ValueError("unexpected IPS bytes after EOF")
    return covered, values


def serialize_ips(covered: bytearray, values: bytearray) -> bytes:
    result = bytearray(b"PATCH")
    cursor = 0
    while cursor < len(covered):
        if not covered[cursor]:
            cursor += 1
            continue
        start = cursor
        while cursor < len(covered) and covered[cursor]:
            cursor += 1
        data = bytes(values[start:cursor])
        while data:
            chunk, data = data[:0xFFFF], data[0xFFFF:]
            if start.to_bytes(3, "big") == b"EOF":
                raise ValueError("IPS record would collide with the EOF marker")
            result += start.to_bytes(3, "big")
            result += len(chunk).to_bytes(2, "big")
            result += chunk
            start += len(chunk)
    result += b"EOF"
    return bytes(result)


def apply_normalized(source: bytes, covered: bytearray, values: bytearray) -> bytes:
    if len(source) != len(covered):
        raise ValueError("source and normalised IPS differ in size")
    output = bytearray(source)
    for index, present in enumerate(covered):
        if present:
            output[index] = values[index]
    return bytes(output)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--base-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.3.wsc")
    parser.add_argument("--base-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.3.ips")
    parser.add_argument("--output-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.4.wsc")
    parser.add_argument("--output-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.4.ips")
    parser.add_argument("--report", type=Path, default=root / "build/build_v0_10_4_delta.json")
    args = parser.parse_args()

    base = args.base_rom.read_bytes()
    base_ips = args.base_ips.read_bytes()
    if len(base) != ROM_SIZE or sha256(base) != BASE_ROM_SHA256:
        raise ValueError("base ROM is not the canonical v0.10.3 build")
    if sha256(base_ips) != BASE_IPS_SHA256:
        raise ValueError("base IPS is not the canonical v0.10.3 patch")

    assets_root = root / "translation/assets"
    output = bytearray(base)
    asset_rows = []
    allowed = bytearray(ROM_SIZE)
    for spec in ASSETS:
        before = base[spec.offset:spec.offset + spec.length]
        if sha256(before) != spec.base_sha256:
            raise ValueError(f"{spec.id}: unexpected v0.10.3 base span")
        payload = (assets_root / spec.file).read_bytes()
        if len(payload) != spec.length or sha256(payload) != spec.sha256:
            raise ValueError(f"{spec.id}: unexpected v0.10.4 asset")
        output[spec.offset:spec.offset + spec.length] = payload
        allowed[spec.offset:spec.offset + spec.length] = b"\x01" * spec.length
        asset_rows.append({
            "id": spec.id,
            "offset": f"0x{spec.offset:06X}",
            "length": spec.length,
            "base_sha256": spec.base_sha256,
            "asset": spec.file,
            "asset_sha256": spec.sha256,
        })

    checksum = sum(output[:-2]) & 0xFFFF
    output[-2:] = checksum.to_bytes(2, "little")
    allowed[-2:] = b"\x01\x01"
    final = bytes(output)
    outside = [
        index for index, (old, new) in enumerate(zip(base, final))
        if old != new and not allowed[index]
    ]
    if outside:
        raise AssertionError(f"v0.10.4 changed outside its four assets: {outside[:8]}")

    covered, values = parse_ips(base_ips, ROM_SIZE)
    old_covered = covered[:]
    old_values = values[:]
    for spec in ASSETS:
        for index in range(spec.offset, spec.offset + spec.length):
            if old_covered[index] or final[index] != base[index]:
                covered[index] = 1
                values[index] = final[index]
            else:
                covered[index] = 0
                values[index] = 0
    for index in (ROM_SIZE - 2, ROM_SIZE - 1):
        covered[index] = 1
        values[index] = final[index]
    final_ips = serialize_ips(covered, values)

    # Build a pseudo-source that is arbitrary only at bytes covered by v0.10.3.
    # The old patch must reconstruct the known v0.10.3 ROM, and the composed
    # patch must reconstruct the exact v0.10.4 ROM from the same pseudo-source.
    synthetic = bytearray(base)
    for index, present in enumerate(old_covered):
        if present:
            synthetic[index] = 0
    if apply_normalized(bytes(synthetic), old_covered, old_values) != base:
        raise AssertionError("v0.10.3 normalisation does not reconstruct its base ROM")
    new_synthetic = apply_normalized(bytes(synthetic), covered, values)
    if new_synthetic != final:
        raise AssertionError("normalised IPS composition proof failed")

    if FINAL_ROM_SHA256 and sha256(final) != FINAL_ROM_SHA256:
        raise AssertionError("final ROM differs from the reviewed v0.10.4 build")
    if FINAL_IPS_SHA256 and sha256(final_ips) != FINAL_IPS_SHA256:
        raise AssertionError("final IPS differs from the reviewed v0.10.4 patch")

    args.output_rom.parent.mkdir(parents=True, exist_ok=True)
    args.output_ips.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.output_rom.write_bytes(final)
    args.output_ips.write_bytes(final_ips)
    report = {
        "status": "PASS",
        "version": "0.10.4",
        "base_rom_sha256": sha256(base),
        "base_ips_sha256": sha256(base_ips),
        "final_rom_sha256": sha256(final),
        "final_ips_sha256": sha256(final_ips),
        "checksum": f"0x{checksum:04X}",
        "checksum_valid": int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF,
        "changed_bytes_vs_v0_10_3": sum(a != b for a, b in zip(base, final)),
        "outside_allowlist": len(outside),
        "assets": asset_rows,
        "ips": {
            "method": "normalised v0.10.3 source patch with four graphical targets replaced",
            "records_do_not_overlap": True,
            "composition_proof": "PASS",
            "size": len(final_ips),
        },
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
