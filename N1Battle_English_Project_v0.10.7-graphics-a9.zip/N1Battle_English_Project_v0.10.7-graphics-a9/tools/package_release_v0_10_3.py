#!/usr/bin/env python3
"""Create the deterministic, ROM-free public N1 Battle v0.10.3 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


PROJECT_VERSION = "0.10.3"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.3"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
FINAL_ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
IPS_SHA256 = "db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7"
INHERITED_V0101_ROM_SHA256 = "5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b"
INHERITED_V010_ROM_SHA256 = "0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69"

FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".cdl", ".rgd", ".dmp",
    ".deb", ".so", ".dll", ".exe", ".tar", ".gz", ".7z", ".zip",
}
FORBIDDEN_DIRECTORIES = {
    "mesen_core_home", "mesen_home", "savestates", "saves", "memory",
    "emulator", "emulators", "cores", "bios",
}
FORBIDDEN_NAME_MARKERS = (
    "cpu_dump", "cpu-memory", "cpu_memory", "_cpu_", "mesencore",
    "bios", "bootrom", "boot_rom", "savestate",
)
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}
DOC_SUFFIXES = {".md", ".json", ".png", ".tsv"}

REQUIRED_V0103 = {
    "docs/STRUCTURAL_VALIDATION_v0_10_3.json",
    "docs/RESIDUAL_TEXT_SCAN_v0_10_3.json",
    "docs/RESIDUAL_JAPANESE_AUDIT_v0_10_3.md",
    "docs/EMULATOR_VALIDATION_v0_10_3.md",
    "docs/PROGRESO_v0_10_3.md",
    "docs/progress_v0_10_3.json",
    "docs/runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json",
    "docs/runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json",
    "docs/runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json",
    "tools/validate_release_v0_10_3.py",
    "tools/audit_residual_japanese_v0_10_3.py",
    "tools/package_release_v0_10_3.py",
    "tools/title_logo_assets_v0_10_3.py",
    "tools/quality_graphics_assets_v0_10_3.py",
    "tools/mesen_core_validate_title_v0_10_3.py",
    "tools/mesen_core_validate_name_keyboard_v0_10_3.py",
    "tools/mesen_core_validate_program_deck_v0_10_3.py",
    "tests/test_title_logo_v0_10_3.py",
    "tests/test_quality_graphics_v0_10_3.py",
    "translation/assets/title_logo_master_v0_10_3.png",
    "translation/assets/title_logo_cleanup_mask_v0_10_3.png",
    "translation/assets/title_logo_master_preview_v0_10_3.png",
    "translation/assets/title_logo_asset_report_v0_10_3.json",
    "translation/assets/name_keyboard_selector_preview_v0_10_3.png",
    "translation/assets/program_deck_design_preview_v0_10_3.png",
    "translation/assets/quality_graphics_asset_report_v0_10_3.json",
}

# Inputs which the two v0.10.3 asset generators intentionally inherit.  They
# are not all manifest payloads, but are required to reproduce those payloads.
GENERATOR_DEPENDENCIES = {
    "translation/assets/title_logo_master_v0_10_2.png",
    "translation/assets/program_deck_manual_stats_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_order_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_tool_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_internal_tiles_v0_9.bin",
}

INHERITED_RUNTIME_EVIDENCE = {
    "docs/runtime_v0_10_1/chip/chip_effect_runtime_validation_v0_10_1.json",
    "docs/runtime_v0_10/shop_runtime_validation_v0_10.json",
    "docs/runtime_v0_10/free_host_runtime_validation_v0_10.json",
    "docs/runtime_v0_10/pet_deep_runtime_validation_v0_10.json",
}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict[str, Any]:
    payload = json.loads(require(root, relative).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {relative}")
    return payload


def runtime_rom_sha256(report: dict[str, Any]) -> object:
    direct = report.get("rom_sha256")
    if direct is not None:
        return direct
    rom = report.get("rom")
    return rom.get("sha256") if isinstance(rom, dict) else None


def validate_release_evidence(root: Path) -> None:
    structural = load_json(root, "docs/STRUCTURAL_VALIDATION_v0_10_3.json")
    residual = load_json(root, "docs/RESIDUAL_TEXT_SCAN_v0_10_3.json")
    title = load_json(
        root, "docs/runtime_v0_10_3/title/title_runtime_validation_v0_10_3.json"
    )
    keyboard = load_json(
        root,
        "docs/runtime_v0_10_3/keyboard/name_keyboard_runtime_validation_v0_10_3.json",
    )
    deck = load_json(
        root,
        "docs/runtime_v0_10_3/program_deck/program_deck_runtime_validation_v0_10_3.json",
    )
    title_assets = load_json(root, "translation/assets/title_logo_asset_report_v0_10_3.json")
    quality_assets = load_json(
        root, "translation/assets/quality_graphics_asset_report_v0_10_3.json"
    )

    structural_checks = structural.get("checks", {})
    if not isinstance(structural_checks, dict):
        structural_checks = {}
    canonical = structural_checks.get("canonical_rebuild", {})
    ips_round_trip = structural_checks.get("ips_round_trip", {})
    runtime_evidence = structural_checks.get("v0_10_3_runtime_evidence", {})
    checks = {
        "structural PASS": structural.get("overall_result") == "PASS",
        "structural project version": structural.get("project_version") == PROJECT_VERSION,
        "structural final ROM": (
            isinstance(canonical, dict)
            and canonical.get("result") == "PASS"
            and canonical.get("built_sha256") == FINAL_ROM_SHA256
        ),
        "structural IPS": (
            isinstance(ips_round_trip, dict)
            and ips_round_trip.get("result") == "PASS"
            and ips_round_trip.get("ips_sha256") == IPS_SHA256
        ),
        "structural runtime evidence": (
            isinstance(runtime_evidence, dict)
            and runtime_evidence.get("result") == "PASS"
        ),
        "residual PASS": residual.get("overall_result") == "PASS",
        "residual project version": residual.get("project_version") == PROJECT_VERSION,
        "residual final ROM": (
            residual.get("checks", {})
            .get("build_size_and_optional_hash", {})
            .get("sha256") == FINAL_ROM_SHA256
        ),
        "residual text inventory": (
            residual.get("inventory", {}).get("translated") == 1552
            and residual.get("inventory", {}).get("denominator") == 1552
            and residual.get("inventory", {}).get("remaining_japanese_targets") == 0
        ),
        "title runtime PASS": title.get("status") == "PASS",
        "title runtime final ROM": runtime_rom_sha256(title) == FINAL_ROM_SHA256,
        "title native display": title.get("native_display") == [224, 144],
        "title clean boot": (
            title.get("clean_boot", {}).get("fresh_mesen_home") is True
            and title.get("clean_boot", {}).get("uses_sav_or_savestate") is False
        ),
        "keyboard runtime PASS": keyboard.get("status") == "PASS",
        "keyboard runtime final ROM": runtime_rom_sha256(keyboard) == FINAL_ROM_SHA256,
        "keyboard native display": keyboard.get("native_display") == [224, 144],
        "keyboard clean boot": (
            keyboard.get("route", {}).get("clean_boot") is True
            and keyboard.get("route", {}).get("uses_save_or_savestate") is False
        ),
        "keyboard composition PASS": (
            keyboard.get("composition", {}).get("status") == "PASS"
            and keyboard.get("composition", {}).get("japanese_selector_mask_residual") is False
        ),
        "Program Deck runtime PASS": deck.get("status") == "PASS",
        "Program Deck runtime final ROM": runtime_rom_sha256(deck) == FINAL_ROM_SHA256,
        "Program Deck native display": deck.get("native_resolution") == [224, 144],
        "title assets PASS": (
            title_assets.get("status") == "PASS"
            and title_assets.get("cleanup", {}).get("removed_pixels") == 384
            and title_assets.get("cleanup", {}).get("maximum_opaque_y") == 102
            and title_assets.get("capacity", {}).get("unique_tiles_used") == 191
        ),
        "quality assets PASS": (
            quality_assets.get("status") == "PASS"
            and quality_assets.get("keyboard", {}).get("bg_map_and_tiles_changed") is False
            and quality_assets.get("program_deck", {})
            .get("protected_original_art", {})
            .get("byte_identical_to_japanese_source") is True
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError("release evidence is not final: " + ", ".join(failed))


def validate_manifest(root: Path) -> tuple[Path, dict[str, Any]]:
    manifest_path = require(root, "translation/en_v0_10_3.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    if not isinstance(manifest, dict):
        raise ValueError("translation/en_v0_10_3.json is not an object")
    if (
        manifest.get("format") != "n1battle-inplace-translation-v1"
        or manifest.get("project_version") != PROJECT_VERSION
        or manifest.get("source_sha256") != SOURCE_ROM_SHA256
    ):
        raise ValueError("unexpected v0.10.3 manifest identity")
    binary_entries = manifest.get("binary_entries")
    if not isinstance(binary_entries, list) or len(binary_entries) != 77:
        raise ValueError("v0.10.3 manifest must contain 77 binary entries")
    return manifest_path, manifest


def collect(root: Path) -> list[Path]:
    manifest_path, manifest = validate_manifest(root)
    files: set[Path] = {manifest_path}

    for relative in (
        "APPLY_PATCH.bat",
        "BUILD_PATCH.bat",
        "CHANGELOG.md",
        "LICENSE.txt",
        "README_ES.md",
        "RELEASE_SHA256.txt",
        "patches/Rockman_EXE_N1_Battle_English_v0.10.3.ips",
        "references/bcc_en.tbl",
        "tables/n1battle_jp.tbl",
    ):
        files.add(require(root, relative))

    for entry in manifest["binary_entries"]:
        if not isinstance(entry, dict) or "asset" not in entry or "asset_sha256" not in entry:
            raise ValueError("malformed manifest binary entry")
        asset = PurePosixPath("translation") / str(entry["asset"])
        if asset.is_absolute() or ".." in asset.parts:
            raise ValueError(f"manifest asset escapes translation/: {asset}")
        path = require(root, asset.as_posix())
        actual = sha256(path.read_bytes())
        if actual != str(entry["asset_sha256"]).lower():
            raise ValueError(f"manifest asset hash mismatch: {asset}")
        files.add(path)

    # Reproducibility code is deliberately selected by extension, never cache.
    for directory, pattern in (("tools", "*.py"), ("tests", "*.py")):
        files.update(path for path in (root / directory).glob(pattern) if path.is_file())

    # Keep the complete published v0.10 evidence chain, but never CPU dumps.
    files.update(
        path
        for path in (root / "docs").rglob("*")
        if path.is_file()
        and path.suffix.lower() in DOC_SUFFIXES
        and (
            "v0_10" in path.relative_to(root / "docs").as_posix()
            or path.name
            in {"CREDITS_ENDING_AUDIT_v0_9.json", "deep_text_inventory_v0_9.json"}
        )
    )
    files.update(
        path
        for path in (root / "translation/assets").glob("*")
        if path.is_file()
        and "v0_10" in path.name
        and path.suffix.lower() in {".json", ".png", ".tsv", ".md"}
    )

    for relative in REQUIRED_V0103 | GENERATOR_DEPENDENCIES | INHERITED_RUNTIME_EVIDENCE:
        files.add(require(root, relative))

    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def private_file_reasons(root: Path, path: Path) -> list[str]:
    """Return calculated reasons why a selected file would be private."""
    relative = path.relative_to(root)
    lowered_parts = {part.lower() for part in relative.parts}
    lowered_name = path.name.lower()
    reasons: list[str] = []
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        reasons.append("extension")
    if path.stat().st_size in FORBIDDEN_SIZES:
        reasons.append("size")
    if lowered_parts & FORBIDDEN_DIRECTORIES:
        reasons.append("directory")
    if any(marker in lowered_name for marker in FORBIDDEN_NAME_MARKERS):
        reasons.append("name")
    return reasons


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if "candidate" in relative.lower():
        raise ValueError(f"candidate artifact in public package: {relative}")
    if path.is_symlink():
        raise ValueError(f"symlink not allowed in public package: {relative}")
    reasons = private_file_reasons(root, path)
    if reasons:
        raise ValueError(f"private file in public package: {relative}: {reasons}")

    suffix = path.suffix.lower()
    payload = path.read_bytes()
    if relative.startswith("docs/") and suffix not in DOC_SUFFIXES:
        raise ValueError(f"unexpected document evidence type: {relative}")
    if (
        (relative.startswith("docs/") or relative.startswith("translation/assets/"))
        and suffix in {".md", ".json", ".tsv"}
    ):
        text = payload.decode("utf-8")
        forbidden_markers = ("/workspace/", "/root/", "/tmp/")
        found = [marker for marker in forbidden_markers if marker in text]
        if found:
            raise ValueError(f"private path marker in {relative}: {found}")
    if relative.endswith(".ips"):
        if sha256(payload) != IPS_SHA256:
            raise ValueError(f"unexpected v0.10.3 IPS hash: {relative}")
        if not payload.startswith(b"PATCH") or b"EOF" not in payload[-11:]:
            raise ValueError(f"malformed IPS: {relative}")
    if relative.endswith(".json"):
        json.loads(payload.decode("utf-8"))
    return {"path": relative, "size": len(payload), "sha256": sha256(payload)}


def validate_release_sha256(root: Path) -> None:
    text = require(root, "RELEASE_SHA256.txt").read_text(encoding="utf-8")
    missing = [value for value in (FINAL_ROM_SHA256, IPS_SHA256) if value not in text]
    if missing:
        raise ValueError(f"RELEASE_SHA256.txt is missing final hashes: {missing}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project-root", type=Path, default=Path(__file__).resolve().parents[1]
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    validate_release_evidence(root)
    validate_release_sha256(root)
    output = (
        args.output or root / "dist/N1Battle_English_Project_v0.10.3.zip"
    ).resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside the project root")

    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(
        output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(
                info,
                path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED,
                compresslevel=9,
            )

    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": PROJECT_VERSION,
        "archive": output.name,
        "archive_size": len(payload),
        "archive_sha256": sha256(payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": 0,
        "files": inventory,
    }
    report_path = output.with_suffix(".release.json")
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(
        json.dumps(
            {
                key: report[key]
                for key in (
                    "archive",
                    "archive_size",
                    "archive_sha256",
                    "file_count",
                    "rom_bios_save_emulator_files",
                )
            },
            indent=2,
        )
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
