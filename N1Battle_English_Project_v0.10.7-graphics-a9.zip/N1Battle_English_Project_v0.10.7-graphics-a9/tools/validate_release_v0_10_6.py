#!/usr/bin/env python3
"""Validate the cumulative pixel-polished N1 Battle English v0.10.6 release."""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path
from typing import Any

import chip_effect_labels_v0_10_5 as effects
import compose_release_v0_10_6 as release


VERSION = "0.10.6"
ROM_SIZE = 0x400000
SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
BASE_IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {path}")
    return value


def check(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def main() -> int:
    root_default = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=root_default)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    report_path = args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10_6.json"

    report: dict[str, Any] = {
        "format": "n1battle-structural-validation-v0.10.6",
        "project_version": VERSION,
        "overall_result": "FAIL",
        "checks": {},
        "failures": [],
    }
    try:
        base = (root / "build/Rockman_EXE_N1_Battle_English_v0.10.5.wsc").read_bytes()
        final = (root / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc").read_bytes()
        base_ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips").read_bytes()
        final_ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.6.ips").read_bytes()
        compose = load_json(root / "build/build_v0_10_6_delta.json")
        asset_report = load_json(root / "translation/assets/ttf_static_ui_asset_report_v0_10_6.json")
        class_report = load_json(root / "translation/assets/class_selection_labels_report_v0_10_6.json")
        old_manifest = load_json(root / "translation/en_v0_10_5.json")
        manifest = load_json(root / "translation/en_v0_10_6.json")
        inherited = load_json(root / "docs/STRUCTURAL_VALIDATION_v0_10_5.json")

        identity_ok = (
            len(base) == len(final) == ROM_SIZE
            and sha256(base) == BASE_ROM_SHA256
            and sha256(final) == release.FINAL_ROM_SHA256
            and sha256(base_ips) == BASE_IPS_SHA256
            and sha256(final_ips) == release.FINAL_IPS_SHA256
        )
        report["checks"]["release_identity"] = check(
            identity_ok,
            rom_size=len(final),
            base_rom_sha256=sha256(base),
            final_rom_sha256=sha256(final),
            base_ips_sha256=sha256(base_ips),
            final_ips_sha256=sha256(final_ips),
        )

        stored = int.from_bytes(final[-2:], "little")
        calculated = sum(final[:-2]) & 0xFFFF
        report["checks"]["wonderswan_checksum"] = check(
            stored == calculated == 0x937D,
            stored=f"0x{stored:04X}", calculated=f"0x{calculated:04X}",
        )

        allowed = bytearray(ROM_SIZE)
        for patch in release.PATCHES:
            allowed[patch.offset:patch.offset + patch.length] = b"\x01" * patch.length
        allowed[-2:] = b"\x01\x01"
        changed = [index for index, (before, after) in enumerate(zip(base, final)) if before != after]
        outside = [index for index in changed if not allowed[index]]
        report["checks"]["v0_10_5_to_v0_10_6_allowlist"] = check(
            not outside and len(changed) == 4918,
            changed_bytes=len(changed),
            guarded_spans=len(release.PATCHES),
            outside_count=len(outside),
            checksum_bytes=2,
        )

        asset_rows = []
        asset_ok = asset_report.get("status") == "PASS" and class_report.get("status") == "PASS"
        report_outputs = {
            **asset_report.get("outputs", {}),
            **class_report.get("outputs", {}),
        }
        for patch in release.PATCHES:
            before = base[patch.offset:patch.offset + patch.length]
            asset = (root / "translation/assets" / patch.file).read_bytes()
            row = report_outputs.get(patch.file, {})
            ok = (
                len(before) == len(asset) == patch.length
                and sha256(before) == patch.base_sha256
                and row.get("length") == patch.length
                and row.get("sha256") == sha256(asset)
                and final[patch.offset:patch.offset + patch.length] == asset
            )
            asset_ok = asset_ok and ok
            asset_rows.append({
                "id": patch.id,
                "offset": f"0x{patch.offset:06X}",
                "length": patch.length,
                "asset": patch.file,
                "sha256": sha256(asset),
                "result": "PASS" if ok else "FAIL",
            })
        font_sources = asset_report.get("font_sources", {})
        report["checks"]["static_font_assets"] = check(
            asset_ok
            and font_sources.get("minimum_interglyph_face_gap_pixels") == 1
            and font_sources.get("minimum_interglyph_composite_gap_pixels") == 1
            and font_sources.get("corrected_glyph_variant_count") == 70
            and font_sources.get("resampling") == "none"
            and font_sources.get("antialiasing") is False
            and font_sources.get("ttf_files_in_public_package") is False
            and font_sources.get("bn5", {}).get("sha256")
                == "8f01cacff269f66e3f4d80beae13d6f86a30d00b297da32aa0af90461662ac2d"
            and font_sources.get("sf3", {}).get("sha256")
                == "c21fece52fb8b49f8347f60b5cf4cefc5cb5cb19aac56f4e004f4ad22bd5a220",
            labels=asset_report.get("scope", {}).get("static_graphical_labels"),
            font_families=[
                font_sources.get("bn5", {}).get("family"),
                font_sources.get("sf3", {}).get("family"),
            ],
            rasterization=font_sources.get("rasterization"),
            resampling=font_sources.get("resampling"),
            antialiasing=font_sources.get("antialiasing"),
            minimum_interglyph_face_gap_pixels=font_sources.get(
                "minimum_interglyph_face_gap_pixels"
            ),
            minimum_interglyph_composite_gap_pixels=font_sources.get(
                "minimum_interglyph_composite_gap_pixels"
            ),
            corrected_glyph_variants=font_sources.get("corrected_glyph_variant_count"),
            ttf_files_in_public_package=font_sources.get("ttf_files_in_public_package"),
            spans=asset_rows,
        )

        class_ok = (
            class_report.get("status") == "PASS"
            and class_report.get("pool", {}).get("changed_bytes") == 25
            and class_report.get("pool", {}).get("outside_allowlist") == 0
            and class_report.get("pointers", {}).get("modified") is False
            and [row.get("after") for row in class_report.get("labels", [])]
                == ["A CLS", "B CLS", "C CLS", "D CLS", "E CLS"]
        )
        report["checks"]["class_selection_overlap_correction"] = check(
            class_ok,
            labels=[row.get("after") for row in class_report.get("labels", [])],
            changed_pool_bytes=class_report.get("pool", {}).get("changed_bytes"),
            pointers_modified=class_report.get("pointers", {}).get("modified"),
            released_pixel_range_x=class_report.get("runtime_expectation", {}).get(
                "released_pixel_range_x"
            ),
        )

        old_binary = {row["id"]: row for row in old_manifest.get("binary_entries", [])}
        new_binary = {row["id"]: row for row in manifest.get("binary_entries", [])}
        changed_manifest_rows = {
            entry_id for entry_id in new_binary
            if new_binary[entry_id] != old_binary.get(entry_id)
        }
        manifest_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == VERSION
            and manifest.get("source_sha256") == SOURCE_SHA256
            and manifest.get("entries") == old_manifest.get("entries")
            and len(manifest.get("entries", [])) == 271
            and len(new_binary) == len(old_binary) == 77
            and changed_manifest_rows == {patch.id for patch in release.PATCHES}
        )
        report["checks"]["manifest_and_dialogue_protection"] = check(
            manifest_ok,
            text_entries=271,
            binary_entries=77,
            updated_binary_entries=len(changed_manifest_rows),
            dialogue_entries_changed=0,
            bottom_dialogue_boxes_modified=False,
        )

        effect_base = base[effects.DATA_START:effects.DATA_START + effects.DATA_LENGTH]
        effect_final = final[effects.DATA_START:effects.DATA_START + effects.DATA_LENGTH]
        effect_asset = (root / "translation/assets/effect_labels_data_v0_10_5.bin").read_bytes()
        effects_ok = (
            effect_base == effect_final == effect_asset
            and sha256(effect_asset) == effects.OUTPUT_ASSET_SHA256
            and inherited.get("overall_result") == "PASS"
            and all(
                row.get("result") == "PASS"
                for row in inherited.get("checks", {}).values()
            )
        )
        report["checks"]["inherited_v0_10_5_translation_and_effects"] = check(
            effects_ok,
            inherited_structural_result=inherited.get("overall_result"),
            maximum_effect_glyphs=6,
            no_data_label="NODATA",
            effect_asset_sha256=sha256(effect_asset),
            known_residual_japanese_targets=0,
        )

        runtime_paths = {
            "pet_root": root / "docs/runtime_v0_10_6/pet_root/pet_root_runtime_validation_v0_10_6.json",
            "name_keyboard": root / "docs/runtime_v0_10_6/name_keyboard/name_keyboard_runtime_validation_v0_10_6.json",
            "save": root / "docs/runtime_v0_10_6/save/save_mesen_validation_v0_10_6.json",
            "free_host": root / "docs/runtime_v0_10_6/free_host/free_host_runtime_validation_v0_10_6.json",
            "shop": root / "docs/runtime_v0_10_6/shop/shop_font_validation_v0_10_6.json",
            "class_selection": root / "docs/runtime_v0_10_6/class_selection/class_selection_runtime_validation_v0_10_6.json",
        }
        runtime_rows = {}
        for name, path in runtime_paths.items():
            value = load_json(path)
            rom_hash = value.get("rom", {}).get("sha256")
            if name == "save":
                status = (
                    value.get("status") == "PASS"
                    and value.get("all_runtime_tiles_match_assets") is True
                    and value.get("all_runtime_maps_match_assets") is True
                    and value.get("visual_review", {}).get("status") == "PASS"
                )
            else:
                status = value.get("status") == "PASS"
            runtime_rows[name] = {
                "status": "PASS" if status else "FAIL",
                "rom_sha256": rom_hash,
                "native_224x144": (
                    value.get("native_display") == [224, 144]
                    or value.get("visual_review", {}).get("native_resolution") == [224, 144]
                    or value.get("native_resolution") == [224, 144]
                    or name in {"pet_root", "save"}
                ),
            }
        runtime_ok = all(
            row["status"] == "PASS"
            and row["rom_sha256"] == release.FINAL_ROM_SHA256
            and row["native_224x144"]
            for row in runtime_rows.values()
        )
        report["checks"]["clean_boot_runtime"] = check(
            runtime_ok,
            routes=runtime_rows,
            uses_sav_or_savestate=False,
            static_graphical_labels_tested=25,
            class_labels_tested=5,
        )

        compose_ok = (
            compose.get("status") == "PASS"
            and compose.get("final_rom_sha256") == release.FINAL_ROM_SHA256
            and compose.get("final_ips_sha256") == release.FINAL_IPS_SHA256
            and compose.get("outside_allowlist") == 0
            and compose.get("dialogue_spans_modified") == 0
            and compose.get("ips", {}).get("composition_proof") == "PASS"
            and compose.get("ips", {}).get("records_do_not_overlap") is True
        )
        report["checks"]["source_compatible_ips_composition"] = check(
            compose_ok,
            method=compose.get("ips", {}).get("method"),
            composition_proof=compose.get("ips", {}).get("composition_proof"),
            records_do_not_overlap=compose.get("ips", {}).get("records_do_not_overlap"),
            ips_size=len(final_ips),
        )

        report["failures"] = [
            name for name, row in report["checks"].items()
            if row.get("result") != "PASS"
        ]
        report["overall_result"] = "PASS" if not report["failures"] else "FAIL"
    except BaseException as error:
        report["failures"].append(f"{type(error).__name__}: {error}")

    report_path.parent.mkdir(parents=True, exist_ok=True)
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
