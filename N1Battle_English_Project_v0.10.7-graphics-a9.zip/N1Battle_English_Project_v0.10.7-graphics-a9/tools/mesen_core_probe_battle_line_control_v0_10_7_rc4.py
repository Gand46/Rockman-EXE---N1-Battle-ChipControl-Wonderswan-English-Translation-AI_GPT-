#!/usr/bin/env python3
"""Probe the battle-log third-line mechanism from an organic clean boot.

This is an isolated engine probe, not the cumulative RC4 runtime test.  It
derives a temporary QA ROM from the exact reviewed RC3 ROM, reaches the first
Free Battle using only controller input, and compares native MesenCore output
with the checked-in evidence.

``null-third`` is a negative control: replacing B1:051's NULL separator draws
the requested third row but also dispatches B1:052 as a clipped fourth row.
``inline-line`` is the safe positive control: word 0x0800 inside B1:050 starts
a third row while B1:051 remains NULL, so the following message group is clean.

Run one mode per process because MesenCore owns process-global state.  The
temporary probe ROM and Mesen home are removed; no ROM, core, save or savestate
is written into the project.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import struct
import sys
import tempfile
from pathlib import Path

from PIL import Image


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_free_host_v0_10_6 as runtime  # noqa: E402
import n1tool  # noqa: E402


VERSION = "0.10.7-rc4"
BASELINE_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
MESEN_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
B1_POINTERS = 0x37D7F4
FAR_BASE = 0x300000
FREE_TARGET = 0x37D700
LINE_WORD = 0x0800

PROBES = {
    "null-third": {
        "rom_sha256": "b3c6fe6c88ab3398fec687ee8bf52d259f3206e7b2f8f1c78226c69e970f1921",
        "checksum": 0xEEF5,
        "stop_frame": 32840,
        "captures": {
            32820: {
                "label": "null_separator_bleed",
                "evidence": "battle_engine_null_separator_bleed_f32820.png",
                "png_sha256": "5fbc59d256ea29edbab7a3444224577fc44252bba4684d5896d836caedcc857d",
                "pixel_sha256": "250d64d66c7c75329fcd1f14b5d75465cfdf6d3309255312365a9fee6af29ca4",
            },
        },
        "verdict": "REJECT_NULL_CONSUMPTION",
        "observation": (
            "The third row appears, but B1:052 is dispatched as a clipped fourth row; "
            "the adjacent groups have merged."
        ),
    },
    "inline-line": {
        "rom_sha256": "d66529df097c7865c9afd481eabaa552528f934f3380dd85c9e25b12f3477b0c",
        "checksum": 0xE907,
        "stop_frame": 33320,
        "captures": {
            32820: {
                "label": "line_control_three_rows",
                "evidence": "battle_engine_line_control_three_rows_f32820.png",
                "png_sha256": "0fc38b68c9cfeb1faa9792c317ecf1c4c47bccfeba2167dfd557595a2112414a",
                "pixel_sha256": "4e41fb7ff97b829c12174cfd7ece891f4a40c64529c41cc9cb0720256e5bccb8",
            },
            33300: {
                "label": "line_control_next_group_clean",
                "evidence": "battle_engine_line_control_next_group_clean_f33300.png",
                "png_sha256": "39aaeedf9caa2f9ada6c957069133f7a65c303f4541c0289b998c1af3915c2a1",
                "pixel_sha256": "0046a6437e36fb7d7a2a040db5708626f0d45df50dc95ad9b3fbd22395430f75",
            },
        },
        "verdict": "ACCEPT_INLINE_LINE_WORD",
        "observation": (
            "Word 0x0800 produces three clean rows and preserves B1:051 as NULL; "
            "the next group renders independently."
        ),
    },
}

EVIDENCE_DIR = ROOT / "docs/runtime_v0_10_7_rc4/battle_dialogue"


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def pixel_sha256(path: Path) -> str:
    with Image.open(path) as image:
        rgba = image.convert("RGBA")
    return sha256(rgba.tobytes())


def far_pointer(target: int) -> bytes:
    segment, offset = divmod(target - FAR_BASE, 16)
    return struct.pack("<HH", offset, segment)


def build_probe(source: bytes, mode: str) -> tuple[bytes, int]:
    if sha256(source) != BASELINE_ROM_SHA256:
        raise ValueError("engine probe requires the exact reviewed RC3 ROM")
    rom = bytearray(source)
    _, encode = n1tool.load_table(ROOT / "tables/n1battle_jp.tbl")

    if mode == "null-third":
        pointer = B1_POINTERS + 51 * 4
        if rom[pointer:pointer + 4] != b"\0\0\0\0":
            raise AssertionError("B1:051 is not the expected NULL separator")
        words = n1tool.encode_text("THIRD LINE OK", encode)
        record = n1tool.pack_words([*words, 0x8000 | len(words)])
        if any(rom[FREE_TARGET:FREE_TARGET + len(record)]):
            raise AssertionError("chosen B1 free-pool target is not empty")
        rom[FREE_TARGET:FREE_TARGET + len(record)] = record
        rom[pointer:pointer + 4] = far_pointer(FREE_TARGET)
    else:
        pointer = B1_POINTERS + 50 * 4
        offset, segment = struct.unpack_from("<HH", rom, pointer)
        target = FAR_BASE + segment * 16 + offset
        old_words = n1tool.encode_text("fired [RAW:0201]!", encode)
        new_words = n1tool.encode_text("fired[LINE][RAW:0201]!", encode)
        if len(new_words) != len(old_words) or new_words.count(LINE_WORD) != 1:
            raise AssertionError("inline QA replacement must be one exact-size LINE record")
        old_record = n1tool.pack_words([*old_words, 0x8000 | len(old_words)])
        if rom[target:target + len(old_record)] != old_record:
            raise AssertionError("B1:050 guard failed")
        rom[target:target + len(old_record)] = n1tool.pack_words(
            [*new_words, 0x8000 | len(new_words)]
        )

    checksum = n1tool.repair_checksum(rom)
    spec = PROBES[mode]
    if sha256(rom) != spec["rom_sha256"] or checksum != spec["checksum"]:
        raise AssertionError("temporary QA ROM differs from the reviewed probe")
    return bytes(rom), checksum


def input_for(_route: runtime.Route, frame: int) -> runtime.Controller:
    state = runtime.Controller()
    state.Start = runtime.pulse(frame, 650, 10)
    state.A = (
        runtime.pulse(frame, 950, 8)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or runtime.pulse(frame, 27230, 8)
        or any(
            runtime.pulse(frame, first, 8)
            for first in range(28800, 35401, 240)
        )
    )
    state.Right = any(
        runtime.pulse(frame, first, 8)
        for first in (26920, 27040, 27160)
    )
    state.Up = runtime.pulse(frame, 28000, 8)
    # At "Edit deck?", move from Yes to No before the next A pulse at 31440.
    state.Down = runtime.pulse(frame, 31340, 8)
    return state


def disable_gui_release() -> None:
    original = runtime.configure_core

    def configure(lib) -> None:
        original(lib)
        # MesenCore 2.1.1's GUI-oriented Release can abort a completed
        # headless worker; the operating system releases this process-local DLL.
        lib.Release = lambda: None

    runtime.configure_core = configure


def verify_evidence(result: dict, mode: str, output_dir: Path) -> list[dict]:
    by_frame = {int(row["frame"]): row for row in result["captures"]}
    checks = []
    for frame, expected in PROBES[mode]["captures"].items():
        actual = by_frame[frame]
        actual_path = output_dir / actual["file"]
        evidence_path = EVIDENCE_DIR / expected["evidence"]
        if sha256(evidence_path.read_bytes()) != expected["png_sha256"]:
            raise AssertionError(f"checked-in evidence changed: {evidence_path.name}")
        actual_pixels = pixel_sha256(actual_path)
        evidence_pixels = pixel_sha256(evidence_path)
        if evidence_pixels != expected["pixel_sha256"] or actual_pixels != evidence_pixels:
            raise AssertionError(f"frame {frame}: native pixels differ from reviewed evidence")
        checks.append({
            "frame": frame,
            "label": expected["label"],
            "actual_file": actual["file"],
            "actual_png_sha256": actual["sha256"],
            "pixel_sha256": actual_pixels,
            "evidence_file": str(evidence_path.relative_to(ROOT)),
            "evidence_png_sha256": expected["png_sha256"],
            "native_pixel_match": True,
        })
    return checks


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path, help="exact reviewed RC3 ROM")
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--mode", required=True, choices=tuple(PROBES))
    parser.add_argument("--timeout", default=180.0, type=float)
    args = parser.parse_args()

    source = args.rom.read_bytes()
    core_hash = sha256(args.mesen_core.read_bytes())
    if core_hash != MESEN_CORE_SHA256:
        raise ValueError("MesenCore differs from the user-supplied 2.1.1 build")
    probe_rom, checksum = build_probe(source, args.mode)
    spec = PROBES[args.mode]

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    args.output_dir.mkdir(parents=True)
    runtime.input_for = input_for
    disable_gui_release()
    captures = tuple(
        runtime.Capture(frame, str(row["label"]))
        for frame, row in spec["captures"].items()
    )
    route = runtime.Route(
        f"battle_line_engine_{args.mode.replace('-', '_')}",
        int(spec["stop_frame"]),
        (), (), (), None,
        captures,
    )

    with tempfile.TemporaryDirectory(prefix="n1_battle_line_probe_") as temp:
        probe_path = Path(temp) / f"battle_line_engine_{args.mode}.wsc"
        probe_path.write_bytes(probe_rom)
        result = runtime.run_route(
            route, probe_path, args.mesen_core, args.output_dir, args.timeout
        )
    checks = verify_evidence(result, args.mode, args.output_dir)

    report = {
        "format": "n1-battle-line-engine-probe-v0.10.7-rc4",
        "status": "PASS",
        "version": VERSION,
        "scope": "isolated engine-mechanism probe; not cumulative RC4 validation",
        "mode": args.mode,
        "verdict": spec["verdict"],
        "observation": spec["observation"],
        "baseline_rom_sha256": BASELINE_ROM_SHA256,
        "temporary_probe_rom": {
            "sha256": spec["rom_sha256"],
            "checksum": f"0x{checksum:04X}",
            "deleted_after_run": True,
        },
        "mesen_core_sha256": core_hash,
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "input_schedule": {
            "start": "650..659",
            "title_confirm": "A 950..957",
            "intro_advance": "A every 300 frames from 1200 through 26708",
            "free_battle_carousel": "Right at 26920, 27040, 27160; A at 27230",
            "confirm_free_battle": "Up at 28000; A every 240 frames from 28800",
            "skip_deck_edit": "Down at 31340; next A at 31440 selects No",
            "battle_advance": "same 240-frame A cadence through captured messages",
        },
        "runtime": result,
        "evidence_checks": checks,
        "probe_rom_absent_after_run": True,
        "mesen_home_absent_after_run": True,
    }
    report_path = args.output_dir / f"battle_line_engine_probe_{args.mode}_v0_10_7_rc4.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps({
        "status": report["status"],
        "mode": report["mode"],
        "verdict": report["verdict"],
        "captures": [row["frame"] for row in checks],
        "report": str(report_path),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
