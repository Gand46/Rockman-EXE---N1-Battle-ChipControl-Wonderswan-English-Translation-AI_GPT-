#!/usr/bin/env python3
"""Create the deterministic ROM-free cumulative Graphics Advance 3 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath

import package_release_v0_10_7_rc4 as rc4


VERSION = "0.10.7-graphics-a3"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.7-graphics-a3"
FIXED_TIME = (2026, 8, 24, 0, 0, 0)
ROM_SHA256 = "2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c"
IPS_SHA256 = "0d7d2ca8d516489b8452f55438dda497fc39ecff363ed5fd6b299facf274b316"

ADVANCE_FILES = {
    "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a3.ips",
    "translation/en_v0_10_7_graphics_a3.json",
    "translation/graphics_advance_rules.json",
    "translation/assets/program_deck_manual_overview_bg0_map_graphics_a2.bin",
    "translation/assets/program_deck_manual_internal_tiles_graphics_a2.bin",
    "translation/assets/graphics_advance_2_font_report.json",
    "translation/assets/graphics_advance_2_font_preview.png",
    "translation/assets/pet_submenu_chip_library_tiles_graphics_a3.bin",
    "translation/assets/program_deck_chip_folder_bg0_map_graphics_a3.bin",
    "translation/assets/graphics_advance_3_header_report.json",
    "translation/assets/graphics_advance_3_header_preview.png",
    "translation/assets/battle_messages_b1_data_v0_9.bin",
    "translation/assets/battle_messages_b1_pointers_v0_9.bin",
    "translation/assets/battle_messages_b2_data_v0_9.bin",
    "translation/assets/battle_messages_b2_pointers_v0_9.bin",
    "translation/assets/redbox_font_asset_report_v0_10_7_rc3.json",
    "translation/assets/redbox_font_comparison_v0_10_7_rc3.png",
    "translation/assets/program_deck_stats_palette_comparison_v0_10_7_rc3.png",
    "build/build_v0_10_7_graphics_a3.json",
    "build/graphics_advance_rules_validation.json",
    "docs/GRAPHICS_ADVANCE_RULES.md",
    "docs/GRAPHICS_ADVANCE_1_CORRECTED.md",
    "docs/GRAPHICS_ADVANCE_2.md",
    "docs/GRAPHICS_ADVANCE_3.md",
    "docs/runtime_graphics_advances/advance_3_gate_final/graphics_advance_3_runtime_validation.json",
    "docs/runtime_graphics_advances/advance_3_gate_final/program_alt_button_27440.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/graphics_advance_2_runtime_validation.json",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/graphics_advance_2_runtime_comparison.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/program_overview_15800.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/program_overview_16100.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/program_overview_16400.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/program_overview_16700.png",
    "docs/runtime_graphics_advances/advance_3_a2_checkpoint/program_overview_17000.png",
    "docs/runtime_graphics_advances/advance_3_a1_checkpoint/graphics_advance_1_runtime_validation.json",
    "docs/runtime_graphics_advances/advance_3_a1_checkpoint/program_root_27200.png",
    "docs/runtime_graphics_advances/advance_3_a1_checkpoint/program_start_toolbar_27680.png",
    "docs/runtime_graphics_advances/advance_3_a1_checkpoint/program_root_advance_1_changed_pixels.png",
    "tools/graphics_advances_v0_10_7.py",
    "tools/graphics_advance_2_font.py",
    "tools/graphics_advance_3_header.py",
    "tools/mesen_core_validate_graphics_advance_1.py",
    "tools/mesen_core_validate_graphics_advance_2.py",
    "tools/mesen_core_validate_graphics_advance_3.py",
    "tools/validate_graphics_advance_rules.py",
    "tools/package_graphics_advance_3.py",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def required(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def collect(root: Path) -> list[Path]:
    rc4.validate_evidence(root)
    files = set(rc4.collect(root))
    files.update(required(root, relative) for relative in ADVANCE_FILES)
    manifest = json.loads(required(root, "translation/en_v0_10_7_graphics_a3.json").read_text())
    if manifest.get("project_version") != VERSION:
        raise ValueError("unexpected Graphics Advance 3 manifest")
    for entry in manifest.get("binary_entries", []):
        relative = PurePosixPath("translation") / str(entry["asset"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"unsafe manifest asset: {relative}")
        path = required(root, relative.as_posix())
        payload = path.read_bytes()
        if len(payload) != int(entry["length"]) or sha256(payload) != entry["asset_sha256"]:
            raise ValueError(f"manifest asset mismatch: {relative}")
        files.add(path)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def validate_file(root: Path, path: Path) -> dict[str, object]:
    info = rc4.validate_file(root, path)
    relative = path.relative_to(root).as_posix()
    payload = path.read_bytes()
    if relative.endswith("v0.10.7-graphics-a3.ips") and sha256(payload) != IPS_SHA256:
        raise ValueError("unexpected cumulative Graphics Advance 3 IPS")
    return info


def validate_archive(path: Path) -> None:
    rc4.validate_archive(path)
    with zipfile.ZipFile(path) as archive:
        names = set(archive.namelist())
        expected = {f"{PACKAGE_ROOT}/{relative}" for relative in ADVANCE_FILES}
        missing = sorted(expected - names)
        if missing:
            raise ValueError(f"missing Graphics Advance 3 files: {missing}")
        if any(name.lower().endswith((".wsc", ".ws", ".ttf", ".sav", ".state")) for name in names):
            raise ValueError("archive contains private runtime content")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    rules = json.loads(required(root, "build/graphics_advance_rules_validation.json").read_text())
    if rules.get("status") != "PASS" or rules.get("candidate_rom_sha256") != ROM_SHA256:
        raise ValueError("cumulative rules validation is not final")
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output = (args.output or root / "dist/N1Battle_English_Project_v0.10.7-graphics-a3.zip").resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside project root")
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED,
                             compresslevel=9)
    validate_archive(output)
    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": VERSION,
        "status": "PASS",
        "archive": output.name,
        "archive_size": len(payload),
        "archive_sha256": sha256(payload),
        "file_count": len(inventory),
        "cumulative_ips_sha256": IPS_SHA256,
        "validation_rom_sha256": ROM_SHA256,
        "rom_bios_ttf_save_savestate_emulator_files": 0,
        "rules_enforced": 21,
        "files": inventory,
    }
    output.with_suffix(".release.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "status", "archive", "archive_size", "archive_sha256", "file_count",
        "cumulative_ips_sha256", "rom_bios_ttf_save_savestate_emulator_files",
        "rules_enforced",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
