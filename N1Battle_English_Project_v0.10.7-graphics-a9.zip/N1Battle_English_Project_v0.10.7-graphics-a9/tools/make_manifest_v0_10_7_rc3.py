#!/usr/bin/env python3
"""Create the cumulative source-ROM manifest for v0.10.7 RC3."""

from __future__ import annotations

import hashlib
import json
from pathlib import Path


VERSION = "0.10.7-rc3"
ROOT = Path(__file__).resolve().parents[1]


PATCHES = {
    "program_deck_live_bg0_map": ("0x04323C", 0x0400, None, "assets/program_deck_live_bg0_map_v0_10_7_rc3.bin"),
    "program_deck_auto_control_bg0_map": ("0x0438BE", 0x0680, "d9e6f17908ad2da229bdf53a339e20a4e78a2641e447dd700d852d14485ef2cf", "assets/program_deck_auto_control_bg0_map_v0_10_7_rc3.bin"),
    "pet_submenu_backpack_bg0_map": ("0x0445C2", 0x0680, "782e352204c6e53684b8579668a3f1a8d6cdf9487247387bc5cb5334adec4c59", "assets/pet_submenu_backpack_bg0_map_v0_10_7_rc3.bin"),
    "pet_submenu_data_library_bg0_map": ("0x044C44", 0x0680, None, "assets/pet_submenu_data_library_bg0_map_v0_10_7_rc3.bin"),
    "pet_submenu_netnavi_bg0_map": ("0x0452C6", 0x0480, None, "assets/pet_submenu_netnavi_bg0_map_v0_10_7_rc3.bin"),
    "pet_submenu_netnavi_stats_bg0_map": ("0x045748", 0x0480, "51d99c5d476ad281e3e454a81c24723bdd0ac4863ef36e7c0b5038d3f1b1940f", "assets/pet_submenu_netnavi_stats_bg0_map_v0_10_7_rc3.bin"),
    "program_deck_manual_overview_bg0_map": ("0x04E7A2", 0x0400, None, "assets/program_deck_manual_overview_bg0_map_v0_10_7_rc3.bin"),
    "program_deck_manual_stats_bg0_map": ("0x04EC24", 0x0400, None, "assets/program_deck_manual_stats_bg0_map_v0_10_7_rc3.bin"),
    "program_deck_live_ui_tiles": ("0x07CD20", 0x1EF0, None, "assets/program_deck_live_ui_tiles_v0_10_7_rc3.bin"),
    "pet_submenu_chip_library_tiles": ("0x07EC10", 0x16C0, None, "assets/pet_submenu_chip_library_tiles_v0_10_7_rc3.bin"),
    "pet_submenu_netnavi_tiles": ("0x080300", 0x0D40, None, "assets/pet_submenu_netnavi_tiles_v0_10_7_rc3.bin"),
    "program_deck_manual_internal_tiles": ("0x0ACA20", 0x5B60, None, "assets/program_deck_manual_internal_tiles_v0_10_7_rc3.bin"),
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    source_path = ROOT / "translation/en_v0_10_6.json"
    output_path = ROOT / "translation/en_v0_10_7_rc3.json"
    manifest = json.loads(source_path.read_text(encoding="utf-8"))
    manifest["project_version"] = VERSION
    manifest["scope"] = (
        "v0.10.7 RC3 corrective pixel-art audit built directly from the approved "
        "v0.10.6: seventeen marked static PET and Program Deck text instances plus "
        "one shared NETNAVI duplicate are "
        "redrawn at final 1:1 WonderSwan resolution from the approved BN5 role and "
        "manual native masks. Literal uppercase wording is preserved and the unrelated "
        "symbol below the live PROGRAM DECK heading is removed. RC2 assets and font "
        "decisions are excluded. No line is scaled, filtered or antialiased. Lower "
        "dialogue boxes, dialogue strings, dynamic values, cursors, frames, class "
        "selection, icons, pictograms and every other v0.10.6 behavior remain unchanged "
        "outside twelve guarded spans and the checksum."
    )

    existing = {entry["id"]: entry for entry in manifest["binary_entries"]}
    for entry_id, (offset, length, expected, asset) in PATCHES.items():
        asset_path = ROOT / "translation" / asset
        payload = asset_path.read_bytes()
        if len(payload) != length:
            raise ValueError(f"{entry_id}: asset length mismatch")
        if entry_id in existing:
            entry = existing[entry_id]
            if entry["offset"] != offset or int(entry["length"]) != length:
                raise ValueError(f"{entry_id}: inherited span differs")
            if expected is not None and entry["expected_sha256"] != expected:
                raise ValueError(f"{entry_id}: inherited source guard differs")
        else:
            if expected is None:
                raise ValueError(f"{entry_id}: new entry lacks a source guard")
            entry = {"id": entry_id, "offset": offset, "length": length, "expected_sha256": expected}
            manifest["binary_entries"].append(entry)
            existing[entry_id] = entry
        entry["asset"] = asset
        entry["asset_sha256"] = sha256(payload)

    manifest["binary_entries"].sort(key=lambda entry: int(entry["offset"], 16))
    ranges = [
        (int(entry["offset"], 16), int(entry["offset"], 16) + int(entry["length"]), entry["id"])
        for entry in manifest["binary_entries"]
    ]
    for (_, previous_end, previous_id), (start, _, current_id) in zip(ranges, ranges[1:]):
        if start < previous_end:
            raise ValueError(f"manifest overlap: {previous_id}/{current_id}")
    output_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": "PASS", "project_version": VERSION,
        "entries": len(manifest["entries"]), "binary_entries": len(manifest["binary_entries"]),
        "output": output_path.as_posix(), "sha256": sha256(output_path.read_bytes()),
    }, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
