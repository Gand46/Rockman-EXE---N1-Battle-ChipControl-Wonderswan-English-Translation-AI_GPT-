#!/usr/bin/env python3
"""Capture candidate frames around the Program Deck manual overview route."""

from __future__ import annotations

import argparse
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_program_deck_v0_10_3 as route  # noqa: E402


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--frames", default="14000,14300,14600,14900,15200,15500,15800,16100,16400,16700,17000")
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()
    frames = tuple(int(value) for value in args.frames.split(","))
    if not frames or tuple(sorted(set(frames))) != frames:
        raise ValueError("frames must be unique and increasing")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    route.CAPTURE_FRAMES = frames
    route.STOP_FRAME = frames[-1] + 40
    completed, elapsed, memory, screenshots = route.run_mesen(
        args.rom, args.mesen_core, args.output_dir, args.timeout,
    )
    rows = []
    for frame, source in zip(frames, screenshots, strict=True):
        destination = args.output_dir / f"program_probe_{frame}.png"
        shutil.copy2(source, destination)
        rows.append({"frame": frame, "screenshot": destination.name})
    scale = 2
    montage = Image.new("RGB", (224 * scale * 2, (144 * scale + 22) * ((len(rows) + 1) // 2)), (20, 20, 20))
    draw = ImageDraw.Draw(montage)
    for index, row in enumerate(rows):
        x = (index % 2) * 224 * scale
        y = (index // 2) * (144 * scale + 22)
        with Image.open(args.output_dir / row["screenshot"]) as source:
            image = source.convert("RGB").resize((224 * scale, 144 * scale), Image.Resampling.NEAREST)
        montage.paste(image, (x, y + 22))
        draw.text((x + 4, y + 4), f"frame {row['frame']}", fill=(255, 255, 255))
    montage_path = args.output_dir / "program_overview_probe_montage.png"
    montage.save(montage_path, optimize=False)
    report = {
        "status": "PASS", "frames": rows, "completed": completed,
        "elapsed_seconds": round(elapsed, 3), "montage": montage_path.name,
        "memory_captures": len(memory),
    }
    (args.output_dir / "program_overview_probe.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    home = args.output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
