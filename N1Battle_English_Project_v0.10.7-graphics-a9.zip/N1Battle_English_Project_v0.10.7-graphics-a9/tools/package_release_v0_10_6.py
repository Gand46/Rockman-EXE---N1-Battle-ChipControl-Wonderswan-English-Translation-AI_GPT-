#!/usr/bin/env python3
"""Create the deterministic, ROM-free public N1 Battle v0.10.6 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath
from typing import Any


VERSION = "0.10.6"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.6"
FIXED_TIME = (2026, 8, 23, 0, 0, 0)
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
FINAL_ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
IPS_SHA256 = "d7df4954bd3509865abf3fabf99a3ba6bc8b17bb22b2855d52cd85907e7a56f6"
BASE_IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"

FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".cdl", ".rgd", ".dmp",
    ".deb", ".so", ".dll", ".exe", ".tar", ".gz", ".7z", ".zip", ".ttf",
}
FORBIDDEN_DIRECTORIES = {
    "mesen_core_home", "mesen_home", "savestates", "saves", "memory",
    "emulator", "emulators", "cores", "bios",
}
FORBIDDEN_NAME_MARKERS = (
    "cpu_dump", "cpu-memory", "cpu_memory", "_cpu_", "_cpu.", "wram",
    "ports_", "mesencore", "bios", "bootrom", "boot_rom", "savestate",
)
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}
DOC_SUFFIXES = {".md", ".json", ".png", ".tsv"}

REQUIRED = {
    "APPLY_PATCH.bat",
    "BUILD_PATCH.bat",
    "CHANGELOG.md",
    "LICENSE.txt",
    "README_ES.md",
    "RELEASE_SHA256.txt",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.6.ips",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips",
    "translation/en_v0_10_6.json",
    "translation/en_v0_10_5.json",
    "tables/n1battle_jp.tbl",
    "references/bcc_en.tbl",
    "translation/assets/ttf_static_ui_asset_report_v0_10_6.json",
    "translation/assets/ttf_static_ui_preview_v0_10_6.png",
    "translation/assets/pet_root_menu_font_preview_v0_10_6.png",
    "translation/assets/class_selection_labels_report_v0_10_6.json",
    "build/build_v0_10_6_delta.json",
    "docs/FONT_ATLAS_STATIC_UI_v0_10_6.md",
    "docs/PROGRESO_v0_10_6.md",
    "docs/progress_v0_10_6.json",
    "docs/EMULATOR_VALIDATION_v0_10_6.md",
    "docs/STRUCTURAL_VALIDATION_v0_10_6.json",
    "docs/runtime_v0_10_6/pet_root/pet_root_runtime_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/pet_root/pet_root_runtime_27000.png",
    "docs/runtime_v0_10_6/name_keyboard/name_keyboard_runtime_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/save/save_mesen_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/shop/shop_font_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/shop/shop_font_montage_v0_10_6.png",
    "docs/runtime_v0_10_6/free_host/free_host_runtime_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/free_host/free_host_runtime_montage_v0_10_6.png",
    "docs/runtime_v0_10_6/pixel_art_font_comparison_v0_10_6.png",
    "docs/runtime_v0_10_6/class_selection/class_selection_runtime_validation_v0_10_6.json",
    "docs/runtime_v0_10_6/class_selection/class_selection_e_cls_v0_10_6.png",
    "tools/font_atlas_assets_v0_10_6.py",
    "tools/class_selection_labels_v0_10_6.py",
    "tools/make_manifest_v0_10_6.py",
    "tools/compose_release_v0_10_6.py",
    "tools/mesen_core_validate_pet_root_v0_10_6.py",
    "tools/mesen_core_validate_name_keyboard_v0_10_6.py",
    "tools/mesen_core_validate_save_v0_10_6.py",
    "tools/mesen_core_validate_free_host_v0_10_6.py",
    "tools/mesen_core_validate_class_selection_v0_10_6.py",
    "tools/validate_shop_font_v0_10_6.py",
    "tools/validate_release_v0_10_6.py",
    "tools/package_release_v0_10_6.py",
    "tests/test_font_atlas_assets_v0_10_6.py",
    "tests/test_class_selection_labels_v0_10_6.py",
    # Dependencies required by the inherited regression suite.
    "translation/en_v0_10_3.json",
    "translation/assets/chip_effect_label_asset_report_v0_10_5.json",
    "translation/assets/pet_labels_bg0_map_v0_8.bin",
    "translation/assets/pet_labels_tiles_v0_8.bin",
    "translation/assets/pet_labels_bg0_map_v0_10_4.bin",
    "translation/assets/pet_labels_tiles_v0_10_4.bin",
    "translation/assets/pet_root_menu_font_preview_v0_10_4.png",
    "translation/assets/pet_root_menu_font_asset_report_v0_10_4.json",
    "docs/runtime_v0_9_regressions/pet_root_clean_v0_8.png",
    "translation/assets/name_keyboard_tiles_v0_9.bin",
    "translation/assets/name_keyboard_obj_low_mask_v0_10_3.bin",
    "translation/assets/name_keyboard_obj_cap_mask_v0_10_3.bin",
    "translation/assets/name_keyboard_obj_abc_mask_v0_10_3.bin",
    "translation/assets/program_deck_manual_stats_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_order_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_tool_bg0_map_v0_8.bin",
    "translation/assets/program_deck_manual_internal_tiles_v0_9.bin",
    "translation/assets/program_deck_manual_stats_bg0_map_v0_10_3.bin",
    "translation/assets/program_deck_manual_order_bg0_map_v0_10_3.bin",
    "translation/assets/program_deck_manual_tool_bg0_map_v0_10_3.bin",
    "translation/assets/program_deck_manual_internal_tiles_v0_10_3.bin",
    "translation/assets/quality_graphics_asset_report_v0_10_3.json",
    "translation/assets/title_logo_master_v0_10_2.png",
    "translation/assets/main_logo_tiles_v0_10_2.bin",
    "translation/assets/main_logo_bg0_map_v0_10_2.bin",
    "translation/assets/title_logo_asset_report_v0_10_2.json",
    "translation/assets/title_logo_master_v0_10_3.png",
    "translation/assets/main_logo_tiles_v0_10_3.bin",
    "translation/assets/main_logo_bg0_map_v0_10_3.bin",
    "translation/assets/title_logo_asset_report_v0_10_3.json",
    "translation/assets/title_logo_reference_v0_10_4.png",
    "translation/assets/title_logo_master_v0_10_4.png",
    "translation/assets/main_logo_tiles_v0_10_4.bin",
    "translation/assets/main_logo_bg0_map_v0_10_4.bin",
    "translation/assets/title_logo_asset_report_v0_10_4.json",
}

OBSOLETE_V0_10_6_ASSETS = {
    "SF3FontSmall_atlas_native_v0_10_6.png",
    "font_atlas_static_ui_asset_report_v0_10_6.json",
    "font_atlas_static_ui_preview_v0_10_6.png",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict[str, Any]:
    value = json.loads(require(root, relative).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {relative}")
    return value


def validate_evidence(root: Path) -> None:
    structural = load_json(root, "docs/STRUCTURAL_VALIDATION_v0_10_6.json")
    progress = load_json(root, "docs/progress_v0_10_6.json")
    assets = load_json(root, "translation/assets/ttf_static_ui_asset_report_v0_10_6.json")
    class_assets = load_json(root, "translation/assets/class_selection_labels_report_v0_10_6.json")
    pet = load_json(root, "docs/runtime_v0_10_6/pet_root/pet_root_runtime_validation_v0_10_6.json")
    keyboard = load_json(root, "docs/runtime_v0_10_6/name_keyboard/name_keyboard_runtime_validation_v0_10_6.json")
    save = load_json(root, "docs/runtime_v0_10_6/save/save_mesen_validation_v0_10_6.json")
    free_host = load_json(root, "docs/runtime_v0_10_6/free_host/free_host_runtime_validation_v0_10_6.json")
    shop = load_json(root, "docs/runtime_v0_10_6/shop/shop_font_validation_v0_10_6.json")
    class_selection = load_json(root, "docs/runtime_v0_10_6/class_selection/class_selection_runtime_validation_v0_10_6.json")
    checks = {
        "structural PASS": structural.get("overall_result") == "PASS",
        "structural checks": all(
            row.get("result") == "PASS" for row in structural.get("checks", {}).values()
        ),
        "progress PASS": progress.get("status") == "PASS"
        and progress.get("project_version") == VERSION,
        "asset PASS": assets.get("status") == "PASS"
        and assets.get("scope", {}).get("static_graphical_labels") == 25
        and assets.get("font_sources", {}).get("resampling") == "none"
        and assets.get("font_sources", {}).get("antialiasing") is False
        and assets.get("font_sources", {}).get("minimum_interglyph_face_gap_pixels") == 1
        and assets.get("font_sources", {}).get("minimum_interglyph_composite_gap_pixels") == 1
        and assets.get("font_sources", {}).get("corrected_glyph_variant_count") == 70
        and assets.get("font_sources", {}).get("ttf_files_in_public_package") is False,
        "class-label asset PASS": class_assets.get("status") == "PASS"
        and class_assets.get("pool", {}).get("outside_allowlist") == 0
        and class_assets.get("pointers", {}).get("modified") is False,
        "pet runtime": pet.get("status") == "PASS"
        and pet.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "keyboard runtime": keyboard.get("status") == "PASS"
        and keyboard.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "save runtime": save.get("status") == "PASS"
        and save.get("rom", {}).get("sha256") == FINAL_ROM_SHA256
        and save.get("all_runtime_tiles_match_assets") is True
        and save.get("all_runtime_maps_match_assets") is True,
        "free/host runtime": free_host.get("status") == "PASS"
        and free_host.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "shop runtime": shop.get("status") == "PASS"
        and shop.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
        "class-selection runtime": class_selection.get("status") == "PASS"
        and class_selection.get("rom", {}).get("sha256") == FINAL_ROM_SHA256,
    }
    failed = [name for name, ok in checks.items() if not ok]
    if failed:
        raise ValueError("release evidence is not final: " + ", ".join(failed))


def validate_manifest(root: Path) -> dict[str, Any]:
    manifest = load_json(root, "translation/en_v0_10_6.json")
    if (
        manifest.get("format") != "n1battle-inplace-translation-v1"
        or manifest.get("project_version") != VERSION
        or manifest.get("source_sha256") != SOURCE_ROM_SHA256
        or len(manifest.get("entries", [])) != 271
        or len(manifest.get("binary_entries", [])) != 77
    ):
        raise ValueError("unexpected v0.10.6 manifest identity")
    return manifest


def collect(root: Path) -> list[Path]:
    manifest = validate_manifest(root)
    files = {require(root, relative) for relative in REQUIRED}
    for entry in manifest["binary_entries"]:
        relative = PurePosixPath("translation") / str(entry["asset"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"manifest asset escapes translation/: {relative}")
        path = require(root, relative.as_posix())
        payload = path.read_bytes()
        if len(payload) != int(entry["length"]) or sha256(payload) != str(entry["asset_sha256"]).lower():
            raise ValueError(f"manifest asset mismatch: {relative}")
        files.add(path)

    files.update(path for directory in ("tools", "tests") for path in (root / directory).glob("*.py") if path.is_file())
    files.update(
        path for path in (root / "docs").rglob("*")
        if path.is_file() and path.suffix.lower() in DOC_SUFFIXES
        and "v0_10" in path.relative_to(root / "docs").as_posix()
        and not ({part.lower() for part in path.relative_to(root).parts} & FORBIDDEN_DIRECTORIES)
    )
    files.update(
        path for path in (root / "translation/assets").glob("*v0_10_6*")
        if path.is_file() and path.suffix.lower() in {".png", ".json", ".md"}
        and path.name not in OBSOLETE_V0_10_6_ASSETS
    )
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def private_reasons(root: Path, path: Path) -> list[str]:
    relative = path.relative_to(root)
    parts = {part.lower() for part in relative.parts}
    name = path.name.lower()
    reasons = []
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        reasons.append("extension")
    if path.stat().st_size in FORBIDDEN_SIZES:
        reasons.append("size")
    if parts & FORBIDDEN_DIRECTORIES:
        reasons.append("directory")
    if any(marker in name for marker in FORBIDDEN_NAME_MARKERS):
        reasons.append("name")
    return reasons


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if path.is_symlink():
        raise ValueError(f"symlink not allowed: {relative}")
    reasons = private_reasons(root, path)
    if reasons:
        raise ValueError(f"private file selected: {relative}: {reasons}")
    payload = path.read_bytes()
    if path.suffix.lower() in {".md", ".json", ".tsv", ".bat", ".txt"}:
        text = payload.decode("utf-8")
        found = [marker for marker in ("/workspace/", "/root/", "/tmp/") if marker in text]
        if found:
            raise ValueError(f"private path marker in {relative}: {found}")
    if path.suffix.lower() == ".json":
        json.loads(payload.decode("utf-8"))
    if relative.endswith("v0.10.6.ips") and sha256(payload) != IPS_SHA256:
        raise ValueError("unexpected v0.10.6 IPS hash")
    if relative.endswith("v0.10.5.ips") and sha256(payload) != BASE_IPS_SHA256:
        raise ValueError("unexpected v0.10.5 IPS hash")
    return {"path": relative, "size": len(payload), "sha256": sha256(payload)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    validate_evidence(root)
    release_hashes = require(root, "RELEASE_SHA256.txt").read_text(encoding="utf-8")
    if FINAL_ROM_SHA256 not in release_hashes or IPS_SHA256 not in release_hashes:
        raise ValueError("RELEASE_SHA256.txt does not pin v0.10.6")

    output = (args.output or root / "dist/N1Battle_English_Project_v0.10.6.zip").resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside project root")
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    archive_payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": VERSION,
        "archive": output.name,
        "archive_size": len(archive_payload),
        "archive_sha256": sha256(archive_payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": 0,
        "files": inventory,
    }
    output.with_suffix(".release.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_save_emulator_files",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
