#!/usr/bin/env python3
"""Compose the effect-label-only v0.10.5 ROM and source-compatible IPS.

The canonical v0.10.4 ROM/IPS are guarded inputs.  Only the live effect-label
bank and the two-byte WonderSwan checksum may differ in the resulting build.
The public IPS remains directly applicable to the original Japanese Rev 1 ROM.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path

import compose_release_v0_10_4 as previous


VERSION = "0.10.5"
ROM_SIZE = 0x400000
BASE_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
BASE_IPS_SHA256 = "025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b"
BASE_ASSET_SHA256 = "46d33f0f4c1320ad754696a92f6f98ef97424acf67f3f89d9fe1829fe68acd8e"
ASSET_SHA256 = "9973bd4e3042d71189c26ea6ab852c5b86472aba0b35396e08be2cc048aea52f"
FINAL_ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
FINAL_IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"
ASSET_OFFSET = 0x369550
ASSET_LENGTH = 0x0F90
ASSET_FILE = "effect_labels_data_v0_10_5.bin"


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument(
        "--base-rom", type=Path,
        default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.4.wsc",
    )
    parser.add_argument(
        "--base-ips", type=Path,
        default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.4.ips",
    )
    parser.add_argument(
        "--output-rom", type=Path,
        default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.5.wsc",
    )
    parser.add_argument(
        "--output-ips", type=Path,
        default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips",
    )
    parser.add_argument(
        "--report", type=Path, default=root / "build/build_v0_10_5_delta.json",
    )
    args = parser.parse_args()

    base = args.base_rom.read_bytes()
    base_ips = args.base_ips.read_bytes()
    if len(base) != ROM_SIZE or sha256(base) != BASE_ROM_SHA256:
        raise ValueError("base ROM is not the canonical v0.10.4 build")
    if sha256(base_ips) != BASE_IPS_SHA256:
        raise ValueError("base IPS is not the canonical v0.10.4 patch")

    before_asset = base[ASSET_OFFSET:ASSET_OFFSET + ASSET_LENGTH]
    asset = (root / "translation/assets" / ASSET_FILE).read_bytes()
    if len(before_asset) != ASSET_LENGTH or sha256(before_asset) != BASE_ASSET_SHA256:
        raise ValueError("unexpected v0.10.4 effect-label span")
    if len(asset) != ASSET_LENGTH or sha256(asset) != ASSET_SHA256:
        raise ValueError("unexpected v0.10.5 effect-label asset")

    output = bytearray(base)
    output[ASSET_OFFSET:ASSET_OFFSET + ASSET_LENGTH] = asset
    checksum = sum(output[:-2]) & 0xFFFF
    output[-2:] = checksum.to_bytes(2, "little")
    final = bytes(output)

    allowed = bytearray(ROM_SIZE)
    allowed[ASSET_OFFSET:ASSET_OFFSET + ASSET_LENGTH] = b"\x01" * ASSET_LENGTH
    allowed[-2:] = b"\x01\x01"
    changed = [index for index, (old, new) in enumerate(zip(base, final)) if old != new]
    outside = [index for index in changed if not allowed[index]]
    if outside:
        raise AssertionError(f"v0.10.5 changed outside the effect bank: {outside[:8]}")

    covered, values = previous.parse_ips(base_ips, ROM_SIZE)
    old_covered = covered[:]
    old_values = values[:]
    for index in range(ASSET_OFFSET, ASSET_OFFSET + ASSET_LENGTH):
        if old_covered[index] or final[index] != base[index]:
            covered[index] = 1
            values[index] = final[index]
        else:
            covered[index] = 0
            values[index] = 0
    for index in (ROM_SIZE - 2, ROM_SIZE - 1):
        covered[index] = 1
        values[index] = final[index]
    final_ips = previous.serialize_ips(covered, values)

    synthetic = bytearray(base)
    for index, present in enumerate(old_covered):
        if present:
            synthetic[index] = 0
    if previous.apply_normalized(bytes(synthetic), old_covered, old_values) != base:
        raise AssertionError("v0.10.4 normalization does not reconstruct its ROM")
    if previous.apply_normalized(bytes(synthetic), covered, values) != final:
        raise AssertionError("v0.10.5 normalized IPS composition proof failed")

    final_rom_hash = sha256(final)
    final_ips_hash = sha256(final_ips)
    if FINAL_ROM_SHA256 and final_rom_hash != FINAL_ROM_SHA256:
        raise AssertionError("final ROM differs from the reviewed v0.10.5 build")
    if FINAL_IPS_SHA256 and final_ips_hash != FINAL_IPS_SHA256:
        raise AssertionError("final IPS differs from the reviewed v0.10.5 patch")

    args.output_rom.parent.mkdir(parents=True, exist_ok=True)
    args.output_ips.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.output_rom.write_bytes(final)
    args.output_ips.write_bytes(final_ips)
    report = {
        "status": "PASS",
        "version": VERSION,
        "base_rom_sha256": sha256(base),
        "base_ips_sha256": sha256(base_ips),
        "final_rom_sha256": final_rom_hash,
        "final_ips_sha256": final_ips_hash,
        "checksum": f"0x{checksum:04X}",
        "checksum_valid": int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF,
        "changed_bytes_vs_v0_10_4": len(changed),
        "outside_allowlist": len(outside),
        "asset": {
            "id": "database_effect_labels",
            "offset": f"0x{ASSET_OFFSET:06X}",
            "length": ASSET_LENGTH,
            "base_sha256": sha256(before_asset),
            "file": ASSET_FILE,
            "sha256": sha256(asset),
        },
        "ips": {
            "method": "normalized v0.10.4 source patch with the effect-label target replaced",
            "records_do_not_overlap": True,
            "composition_proof": "PASS",
            "size": len(final_ips),
        },
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
