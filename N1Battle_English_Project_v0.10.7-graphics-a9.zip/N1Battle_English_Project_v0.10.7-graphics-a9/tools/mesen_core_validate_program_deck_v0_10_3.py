#!/usr/bin/env python3
"""Validate the final v0.10.3 Program Deck pages in a clean MesenCore run.

The validator combines static ROM/asset checks with native 224x144 captures and
live CPU-memory checks at the three reviewed Program Deck frames.  It also
decodes the edited tile rectangles to prove that their 5x7 lettering is exact,
and protects the source-original arrow/card pictograms from collateral edits.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from collections import Counter
from pathlib import Path
from typing import Iterable

from PIL import Image


EXPECTED_ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
CAPTURE_FRAMES = (17400, 21600, 23400)
STOP_FRAME = 23440
MEM_CPU = 13
MAP_VRAM_ADDRESS = 0x2000
TILE_VRAM_ADDRESS = 0x8000
NATIVE_SIZE = (224, 144)

PROJECT_ROOT = Path(__file__).resolve().parents[1]
DEFAULT_OUTPUT_DIR = Path("/tmp/deck_v0103_final_qa")

ASSETS = {
    "stats_map": {
        "path": "translation/assets/program_deck_manual_stats_bg0_map_v0_10_3.bin",
        "rom_offset": 0x04EC24,
        "length": 0x400,
        "sha256": "3dee6f7defb7d4b76c9223660140d861a4c2b0bdb1fffeaa7c9062d327eb4996",
    },
    "order_map": {
        "path": "translation/assets/program_deck_manual_order_bg0_map_v0_10_3.bin",
        "rom_offset": 0x04F528,
        "length": 0x400,
        "sha256": "f5c00161868770672e34e8daa3eedd38c3ac8c05403ba8c962b19a91dd4a6057",
    },
    "tool_map": {
        "path": "translation/assets/program_deck_manual_tool_bg0_map_v0_10_3.bin",
        "rom_offset": 0x04F9AA,
        "length": 0x400,
        "sha256": "de316b72749a1c08d787adcdcf35f0b8fb1ab2e5fa09ebcafd142687d0df5740",
    },
    "manual_atlas": {
        "path": "translation/assets/program_deck_manual_internal_tiles_v0_10_3.bin",
        "rom_offset": 0x0ACA20,
        "length": 0x5B60,
        "sha256": "e73fb7e716cafeea1f5c5c707621cf6749694ea982a446b5a4e1ddea8d83df11",
    },
}

PAGES = {
    17400: {
        "name": "stats",
        "map_asset": "stats_map",
        "tile_rom_offset": 0x0ADB70,
        "tile_vram_length": 0x1000,
    },
    21600: {
        "name": "order",
        "map_asset": "order_map",
        "tile_rom_offset": 0x0B03B0,
        "tile_vram_length": 0x1000,
    },
    23400: {
        "name": "tool",
        "map_asset": "tool_map",
        "tile_rom_offset": 0x0B1600,
        "tile_vram_length": 0x0800,
    },
}

# The redrawn labels use one deliberately small, console-native alphabet.
FONT_5X7 = {
    "1": ("00100", "01100", "00100", "00100", "00100", "00100", "01110"),
    "2": ("01110", "10001", "00001", "00010", "00100", "01000", "11111"),
    "A": ("01110", "10001", "10001", "11111", "10001", "10001", "10001"),
    "C": ("01111", "10000", "10000", "10000", "10000", "10000", "01111"),
    "D": ("11110", "10001", "10001", "10001", "10001", "10001", "11110"),
    "E": ("11111", "10000", "10000", "11110", "10000", "10000", "11111"),
    "F": ("11111", "10000", "10000", "11110", "10000", "10000", "10000"),
    "H": ("10001", "10001", "10001", "11111", "10001", "10001", "10001"),
    "I": ("11111", "00100", "00100", "00100", "00100", "00100", "11111"),
    "K": ("10001", "10010", "10100", "11000", "10100", "10010", "10001"),
    "L": ("10000", "10000", "10000", "10000", "10000", "10000", "11111"),
    "M": ("10001", "11011", "10101", "10101", "10001", "10001", "10001"),
    "N": ("10001", "11001", "10101", "10011", "10001", "10001", "10001"),
    "O": ("01110", "10001", "10001", "10001", "10001", "10001", "01110"),
    "P": ("11110", "10001", "10001", "11110", "10000", "10000", "10000"),
    "R": ("11110", "10001", "10001", "11110", "10100", "10010", "10001"),
    "S": ("01111", "10000", "10000", "01110", "00001", "00001", "11110"),
    "T": ("11111", "00100", "00100", "00100", "00100", "00100", "00100"),
    "Y": ("10001", "10001", "01010", "00100", "00100", "00100", "00100"),
}

LABEL_RECTS = (
    {
        "id": "order_likely_chips",
        "page": "order",
        "rect": (3, 0, 6, 3),
        "background": 2,
        "foreground": 15,
        "lines": (("LIKELY", 3), ("CHIPS", 14)),
    },
    {
        "id": "order_two_chips_left",
        "page": "order",
        "rect": (2, 5, 7, 2),
        "background": 2,
        "foreground": 13,
        "lines": (("2 CHIPS", 0), ("LEFT", 9)),
    },
    {
        "id": "order_middle_one_chip",
        "page": "order",
        "rect": (22, 4, 6, 2),
        "background": 2,
        "foreground": 13,
        "lines": (("MIDDLE", 0), ("1 CHIP", 9)),
    },
    {
        "id": "tool_press_start_deck_info",
        "page": "tool",
        "rect": (4, 4, 8, 2),
        "background": 14,
        "foreground": 15,
        "lines": (("PRESS START", 0), ("DECK INFO", 9)),
    },
)

LIVE_PROGRAM_MAP_OFFSET = 0x04323C
LIVE_PROGRAM_TILE_OFFSET = 0x07CD20
ORIGINAL_ARROW_CELLS = ((18, 0, 0x240B), (18, 1, 0x241B))
ORIGINAL_ARROW_TILE_IDS = (0x00B, 0x01B)
ORIGINAL_ARROW_SHA256 = "fd46751854983722e969eb835d39ab3c78204c0ea9bf8c386ece98e9da582142"
ORIGINAL_CARD_CELLS = (
    (11, 5, 0x2650), (12, 5, 0x2651),
    (11, 6, 0x2658), (12, 6, 0x2659),
    (11, 7, 0x265E), (12, 7, 0x265F),
)
ORIGINAL_CARD_TILE_IDS = (0x050, 0x051, 0x058, 0x059, 0x05E, 0x05F)
ORIGINAL_CARD_SHA256 = "33ec6cf730e810339945d86c61b913e5f591d6e2b5a34cd42cec87c802734605"


class Controller(ctypes.Structure):
    _fields_ = [(name, ctypes.c_bool) for name in (
        "A", "B", "X", "Y", "L", "R", "U", "D",
        "Up", "Down", "Left", "Right", "Select", "Start",
    )]


def sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def sha256(path: Path) -> str:
    return sha256_bytes(path.read_bytes())


def require(condition: bool, message: str) -> None:
    if not condition:
        raise RuntimeError(message)


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame < last


def input_for_frame(frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = pulse(frame, 650, 660)
    state.A = pulse(frame, 950, 958) or (1200 <= frame <= 26708 and frame % 300 < 8)
    return state


def map_word(tilemap: bytes, x: int, y: int) -> int:
    offset = 2 * (y * 32 + x)
    return int.from_bytes(tilemap[offset:offset + 2], "little")


def tile_id(word: int) -> int:
    return word & 0x01FF


def palette_id(word: int) -> int:
    return (word >> 9) & 0x0F


def unpack_tile(tile: bytes) -> list[list[int]]:
    require(len(tile) == 32, f"4bpp tile has {len(tile)} bytes instead of 32")
    pixels: list[int] = []
    for value in tile:
        pixels.extend((value >> 4, value & 0x0F))
    return [pixels[row * 8:(row + 1) * 8] for row in range(8)]


def render_index_rect(
    tilemap: bytes,
    tiles: bytes,
    x0: int,
    y0: int,
    columns: int,
    rows: int,
) -> list[list[int]]:
    canvas = [[0] * (columns * 8) for _ in range(rows * 8)]
    for tile_y in range(rows):
        for tile_x in range(columns):
            index = tile_id(map_word(tilemap, x0 + tile_x, y0 + tile_y))
            start = index * 32
            decoded = unpack_tile(tiles[start:start + 32])
            for pixel_y in range(8):
                destination = canvas[tile_y * 8 + pixel_y]
                destination[tile_x * 8:(tile_x + 1) * 8] = decoded[pixel_y]
    return canvas


def rendered_width(text: str) -> int:
    require(bool(text), "empty 5x7 label")
    return sum(4 if character == " " else 6 for character in text) - 1


def make_label_canvas(
    width: int,
    height: int,
    background: int,
    foreground: int,
    lines: Iterable[tuple[str, int]],
) -> list[list[int]]:
    canvas = [[background] * width for _ in range(height)]
    for text, y0 in lines:
        width_used = rendered_width(text)
        require(width_used <= width, f"{text!r} is {width_used}px wide in a {width}px field")
        x0 = (width - width_used) // 2
        cursor = x0
        for character in text:
            if character == " ":
                cursor += 4
                continue
            require(character in FONT_5X7, f"missing 5x7 glyph {character!r}")
            for glyph_y, row in enumerate(FONT_5X7[character]):
                require(y0 + glyph_y < height, f"{text!r} exceeds its label rectangle")
                for glyph_x, bit in enumerate(row):
                    if bit == "1":
                        canvas[y0 + glyph_y][cursor + glyph_x] = foreground
            cursor += 6
    return canvas


def flattened_mismatch_count(left: list[list[int]], right: list[list[int]]) -> int:
    require(len(left) == len(right), "canvas height mismatch")
    require(all(len(a) == len(b) for a, b in zip(left, right)), "canvas width mismatch")
    return sum(a != b for left_row, right_row in zip(left, right) for a, b in zip(left_row, right_row))


def validate_assets_and_rom(rom: bytes) -> tuple[dict[str, bytes], list[dict[str, object]]]:
    loaded: dict[str, bytes] = {}
    evidence: list[dict[str, object]] = []
    for name, metadata in ASSETS.items():
        path = PROJECT_ROOT / str(metadata["path"])
        require(path.is_file(), f"missing required asset: {path}")
        data = path.read_bytes()
        expected_length = int(metadata["length"])
        expected_sha = str(metadata["sha256"])
        offset = int(metadata["rom_offset"])
        require(len(data) == expected_length, f"{name} length mismatch")
        require(sha256_bytes(data) == expected_sha, f"{name} SHA-256 mismatch")
        require(rom[offset:offset + expected_length] == data, f"{name} is not embedded at 0x{offset:06X}")
        loaded[name] = data
        evidence.append({
            "name": name,
            "file": str(metadata["path"]),
            "rom_offset": f"0x{offset:06X}",
            "length": expected_length,
            "sha256": expected_sha,
            "embedded_exactly": True,
        })
    return loaded, evidence


def validate_label_composition(rom: bytes, assets: dict[str, bytes]) -> list[dict[str, object]]:
    page_by_name = {str(metadata["name"]): metadata for metadata in PAGES.values()}
    results: list[dict[str, object]] = []
    for specification in LABEL_RECTS:
        page = page_by_name[str(specification["page"])]
        tile_offset = int(page["tile_rom_offset"])
        tile_bytes = rom[tile_offset:]
        tilemap = assets[str(page["map_asset"])]
        x0, y0, columns, rows = specification["rect"]
        actual = render_index_rect(tilemap, tile_bytes, x0, y0, columns, rows)
        expected = make_label_canvas(
            columns * 8,
            rows * 8,
            int(specification["background"]),
            int(specification["foreground"]),
            specification["lines"],
        )
        mismatches = flattened_mismatch_count(actual, expected)
        require(mismatches == 0, f"{specification['id']} has {mismatches} unexpected pixels")
        line_results = []
        for text, y0_line in specification["lines"]:
            width = rendered_width(text)
            line_results.append({
                "text": text,
                "y": y0_line,
                "rendered_width": width,
                "center_x": (columns * 8 - width) // 2,
                "glyph_height": 7,
                "nonspace_advance": 6,
                "space_advance": 4,
            })
        results.append({
            "id": specification["id"],
            "page": specification["page"],
            "tile_rect": [x0, y0, columns, rows],
            "pixel_size": [columns * 8, rows * 8],
            "background_index": specification["background"],
            "foreground_index": specification["foreground"],
            "lines": line_results,
            "pixel_mismatches": 0,
            "exact_5x7_composition": True,
        })

    # The tool banner has one untouched blank tile row above and below the label.
    tool_map = assets["tool_map"]
    for y in (3, 6):
        words = [map_word(tool_map, x, y) for x in range(4, 12)]
        require(words == [0x2633] * 8, f"tool banner guard row {y} is not blank/original")
    return results


def validate_capacity_block(stats_map: bytes) -> dict[str, object]:
    expected = {
        (12, 6): 0x2452, (13, 6): 0x2453, (14, 6): 0x2454,
        (12, 7): 0x2457, (13, 7): 0x2458, (14, 7): 0x245D,
    }
    actual = {(x, y): map_word(stats_map, x, y) for x, y in expected}
    require(actual == expected, "CAPACITY map words differ from the corrected v0.10.3 layout")
    require(all(palette_id(word) == 2 for word in actual.values()), "CAPACITY block still selects purple palette 3")
    return {
        "tile_cells": [
            {"x": x, "y": y, "word": f"0x{actual[(x, y)]:04X}", "palette": palette_id(actual[(x, y)])}
            for x, y in expected
        ],
        "expected_palette": 2,
        "purple_palette_3_absent": True,
    }


def validate_original_pictograms(rom: bytes) -> dict[str, object]:
    live_map = rom[LIVE_PROGRAM_MAP_OFFSET:LIVE_PROGRAM_MAP_OFFSET + 0x400]

    def validate_cells(cells: Iterable[tuple[int, int, int]], label: str) -> list[dict[str, object]]:
        details = []
        for x, y, expected in cells:
            actual = map_word(live_map, x, y)
            require(actual == expected, f"source-original {label} map cell ({x},{y}) changed")
            details.append({"x": x, "y": y, "word": f"0x{actual:04X}"})
        return details

    def tile_digest(tile_ids: Iterable[int]) -> str:
        data = b"".join(
            rom[LIVE_PROGRAM_TILE_OFFSET + index * 32:LIVE_PROGRAM_TILE_OFFSET + (index + 1) * 32]
            for index in tile_ids
        )
        return sha256_bytes(data)

    arrow_sha = tile_digest(ORIGINAL_ARROW_TILE_IDS)
    card_sha = tile_digest(ORIGINAL_CARD_TILE_IDS)
    require(arrow_sha == ORIGINAL_ARROW_SHA256, "source-original navigation arrow tiles changed")
    require(card_sha == ORIGINAL_CARD_SHA256, "source-original selected-card pictogram tiles changed")
    return {
        "live_map_rom_offset": f"0x{LIVE_PROGRAM_MAP_OFFSET:06X}",
        "live_tile_rom_offset": f"0x{LIVE_PROGRAM_TILE_OFFSET:06X}",
        "navigation_arrow": {
            "cells": validate_cells(ORIGINAL_ARROW_CELLS, "navigation arrow"),
            "tile_ids": [f"0x{index:03X}" for index in ORIGINAL_ARROW_TILE_IDS],
            "tile_sha256": arrow_sha,
            "source_original_preserved": True,
        },
        "selected_card_pictogram": {
            "cells": validate_cells(ORIGINAL_CARD_CELLS, "selected-card pictogram"),
            "tile_ids": [f"0x{index:03X}" for index in ORIGINAL_CARD_TILE_IDS],
            "tile_sha256": card_sha,
            "source_original_preserved": True,
        },
    }


def run_mesen(
    rom_path: Path,
    core_path: Path,
    output_dir: Path,
    timeout: float,
) -> tuple[int, float, dict[int, bytes], list[Path]]:
    home = output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(core_path.resolve()))
    lib.InitializeEmu.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
                                    ctypes.POINTER(ctypes.c_uint8)]
    for name in ("InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
                 "TakeScreenshot", "Stop", "Release"):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    captured: list[int] = []
    memory_captures: dict[int, bytes] = {}
    route_done = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(completed + 1))
        if completed in CAPTURE_FRAMES:
            lib.TakeScreenshot()
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
            memory_captures[completed] = bytes(buffer)
            captured.append(completed)
        if completed >= STOP_FRAME:
            route_done.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    start_time = time.monotonic()
    try:
        if not lib.LoadRom(str(rom_path.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not route_done.wait(timeout):
            raise TimeoutError(f"Program Deck route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.2)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    require(captured == list(CAPTURE_FRAMES), f"captured frames are {captured}, expected {list(CAPTURE_FRAMES)}")
    deadline = time.monotonic() + 5.0
    while len(list(screenshot_dir.glob("*.png"))) < len(CAPTURE_FRAMES) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    require(len(screenshots) == len(CAPTURE_FRAMES),
            f"expected {len(CAPTURE_FRAMES)} native captures, found {len(screenshots)}")
    return completed, time.monotonic() - start_time, memory_captures, screenshots


def validate_runtime_evidence(
    rom: bytes,
    assets: dict[str, bytes],
    memory_captures: dict[int, bytes],
    screenshots: list[Path],
    output_dir: Path,
) -> tuple[list[dict[str, object]], dict[str, object]]:
    capture_results: list[dict[str, object]] = []
    screenshot_by_frame: dict[int, Path] = {}
    for frame, source in zip(CAPTURE_FRAMES, screenshots):
        page = PAGES[frame]
        page_name = str(page["name"])
        destination = output_dir / f"program_deck_{page_name}_{frame}.png"
        shutil.copy2(source, destination)
        screenshot_by_frame[frame] = destination

        cpu = memory_captures[frame]
        require(len(cpu) == 0x10000, f"frame {frame} CPU dump has unexpected length")
        memory_path = output_dir / f"program_deck_{page_name}_{frame}_cpu.bin"
        memory_path.write_bytes(cpu)

        expected_map = assets[str(page["map_asset"])]
        live_map = cpu[MAP_VRAM_ADDRESS:MAP_VRAM_ADDRESS + 0x400]
        require(live_map == expected_map, f"frame {frame} live BG0 map differs from final asset")

        tile_offset = int(page["tile_rom_offset"])
        tile_length = int(page["tile_vram_length"])
        expected_tiles = rom[tile_offset:tile_offset + tile_length]
        live_tiles = cpu[TILE_VRAM_ADDRESS:TILE_VRAM_ADDRESS + tile_length]
        require(live_tiles == expected_tiles, f"frame {frame} live tile VRAM differs from ROM page")

        with Image.open(destination) as image:
            require(image.size == NATIVE_SIZE, f"frame {frame} is {image.size}, expected {NATIVE_SIZE}")
            require(image.mode in ("RGB", "RGBA"), f"frame {frame} unexpected image mode {image.mode}")
        capture_results.append({
            "frame": frame,
            "page": page_name,
            "screenshot": destination.name,
            "screenshot_sha256": sha256(destination),
            "dimensions": list(NATIVE_SIZE),
            "cpu_dump": memory_path.name,
            "cpu_dump_sha256": sha256(memory_path),
            "bg0_map_vram_address": f"0x{MAP_VRAM_ADDRESS:04X}",
            "bg0_map_sha256": sha256_bytes(live_map),
            "bg0_map_matches_asset": True,
            "tile_vram_address": f"0x{TILE_VRAM_ADDRESS:04X}",
            "tile_vram_checked_length": tile_length,
            "tile_vram_sha256": sha256_bytes(live_tiles),
            "tile_vram_matches_rom": True,
        })

    # Exact native-pixel proof that the old palette-3 purple rectangle is gone.
    stats_path = screenshot_by_frame[17400]
    with Image.open(stats_path) as image:
        crop = image.convert("RGB").crop((80, 48, 120, 64))
        histogram = Counter(crop.get_flattened_data())
    expected_histogram = Counter({(0, 0, 0): 510, (255, 255, 221): 130})
    require(histogram == expected_histogram,
            f"CAPACITY native crop differs: {dict(histogram)}")
    purple_colors = {(136, 85, 136), (136, 119, 170)}
    require(not (set(histogram) & purple_colors), "purple CAPACITY artifact remains in native capture")
    capacity_visual = {
        "frame": 17400,
        "screenshot": stats_path.name,
        "crop_xyxy": [80, 48, 120, 64],
        "pixel_count": sum(histogram.values()),
        "rgb_histogram": {
            f"#{red:02X}{green:02X}{blue:02X}": count
            for (red, green, blue), count in sorted(histogram.items())
        },
        "forbidden_purple_rgb": ["#885588", "#8877AA"],
        "purple_absent": True,
    }
    return capture_results, capacity_visual


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path,
                        default=PROJECT_ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.3.wsc")
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=DEFAULT_OUTPUT_DIR)
    parser.add_argument("--timeout", default=120.0, type=float)
    args = parser.parse_args()

    require(args.rom.is_file(), f"ROM not found: {args.rom}")
    require(args.mesen_core.is_file(), f"MesenCore not found: {args.mesen_core}")
    args.output_dir.mkdir(parents=True, exist_ok=True)

    rom = args.rom.read_bytes()
    actual_rom_sha = sha256_bytes(rom)
    require(actual_rom_sha == EXPECTED_ROM_SHA256,
            f"final ROM SHA-256 is {actual_rom_sha}, expected {EXPECTED_ROM_SHA256}")

    assets, asset_evidence = validate_assets_and_rom(rom)
    label_evidence = validate_label_composition(rom, assets)
    capacity_map_evidence = validate_capacity_block(assets["stats_map"])
    pictogram_evidence = validate_original_pictograms(rom)

    completed, elapsed, memory, screenshots = run_mesen(
        args.rom, args.mesen_core, args.output_dir, args.timeout
    )
    captures, capacity_visual = validate_runtime_evidence(
        rom, assets, memory, screenshots, args.output_dir
    )

    report = {
        "validation": "program_deck_final_v0_10_3_clean_boot_headless_mesen_core",
        "status": "PASS",
        "rom": args.rom.name,
        "rom_sha256": actual_rom_sha,
        "expected_rom_sha256": EXPECTED_ROM_SHA256,
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "native_resolution": list(NATIVE_SIZE),
        "capture_frames": list(CAPTURE_FRAMES),
        "last_callback_frame": completed,
        "elapsed_seconds": round(elapsed, 3),
        "assets": asset_evidence,
        "runtime_captures": captures,
        "capacity_artifact": {
            "map": capacity_map_evidence,
            "native_capture": capacity_visual,
            "status": "PASS",
        },
        "five_by_seven_composition": {
            "rule": {
                "glyph_size": [5, 7],
                "nonspace_advance": 6,
                "space_advance": 4,
                "centering": "floor((field_width - rendered_width) / 2)",
            },
            "rectangles": label_evidence,
            "status": "PASS",
        },
        "source_original_graphics": pictogram_evidence,
    }
    report_path = args.output_dir / "program_deck_runtime_validation_v0_10_3.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
