#!/usr/bin/env python3
"""Capture the real Shop flow from a clean N1 Battle boot in MesenCore.

The v0.9 location check only highlighted Shop in the PET carousel.  This
route deliberately enters Shop and records a dense 224x144 frame sweep so
that dialogue, menu and tile-based labels can be reviewed separately.  A
clean game starts with 3000z, so selecting the 5000z ten-chip row exercises
the insufficient-funds branch.  The gated confirmation is validated by the
separate, explicitly documented QA probe in the release evidence.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
MEM_CPU = 13
CAPTURE_FRAMES = tuple(range(26700, 29001, 100))
STOP_FRAME = CAPTURE_FRAMES[-1] + 1


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame < last


def input_for(frame: int) -> Controller:
    state = Controller()
    state.Start = pulse(frame, 650, 660)
    state.A = (
        pulse(frame, 950, 958)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or pulse(frame, 27500, 27508)
        or pulse(frame, 28500, 28508)
    )
    # PET root defaults to Battle Prep.  One step right selects Shop.
    state.Right = pulse(frame, 26920, 26928)
    # After entering Shop, select the ten-chip row.  On a clean 3000z start,
    # this intentionally reaches the 5000z insufficient-funds branch.
    state.Down = pulse(frame, 28400, 28408)
    return state


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=120.0, type=float)
    args = parser.parse_args()

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    home = args.output_dir / "mesen_core_home"
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause",
        "Resume", "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    reached = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for(completed + 1))
        if completed in CAPTURE_FRAMES:
            lib.TakeScreenshot()
        if completed >= STOP_FRAME:
            reached.set()

    listener = None
    started = time.monotonic()
    cpu_memory = b""
    try:
        lib.InitDll()
        lib.InitializeEmu(str(home.resolve()).encode(), None, None, True, True, True, True)
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore LoadRom failed")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("MesenCore notification callback failed")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached.wait(args.timeout):
            raise TimeoutError(f"Shop route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.5)
        cpu_buffer = (ctypes.c_uint8 * 0x10000)()
        lib.GetMemoryValues(MEM_CPU, 0, 0x10000, cpu_buffer)
        cpu_memory = bytes(cpu_buffer)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        try:
            lib.Stop()
            lib.Release()
        except BaseException:
            pass

    deadline = time.monotonic() + 8.0
    while len(list(screenshot_dir.glob("*.png"))) < len(CAPTURE_FRAMES) and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(screenshot_dir.glob("*.png"))
    if len(sources) != len(CAPTURE_FRAMES):
        raise RuntimeError(
            f"expected {len(CAPTURE_FRAMES)} captures, found {len(sources)}"
        )

    captures = []
    for frame, source in zip(CAPTURE_FRAMES, sources, strict=True):
        destination = args.output_dir / f"shop_frame_{frame:05d}.png"
        shutil.copy2(source, destination)
        with Image.open(destination) as image:
            dimensions = list(image.size)
        if dimensions != [224, 144]:
            raise RuntimeError(f"unexpected frame dimensions: {dimensions}")
        captures.append(
            {
                "frame": frame,
                "file": destination.name,
                "sha256": sha256(destination.read_bytes()),
                "dimensions": dimensions,
            }
        )

    memory_dir = args.output_dir / "memory"
    memory_dir.mkdir()
    memory_spans = {
        "cpu_full_0000_ffff.bin": cpu_memory,
        "bg0_map_2000_247f.bin": cpu_memory[0x2000:0x2480],
        "tile_ram_8000_bfff.bin": cpu_memory[0x8000:0xC000],
    }
    memory_report = {}
    for name, payload in memory_spans.items():
        path = memory_dir / name
        path.write_bytes(payload)
        memory_report[name] = {
            "length": len(payload),
            "sha256": sha256(payload),
        }

    report = {
        "format": "n1-shop-runtime-audit-v0.10",
        "rom": {
            "file": args.rom.name,
            "sha256": sha256(args.rom.read_bytes()),
        },
        "route": {
            "clean_boot": True,
            "uses_input_save_or_savestate": False,
            "pet_selection": "one step right from Battle Prep to Shop",
            "enters_shop": True,
            "ten_chip_selection_attempt": "Down at frame 28400; A at frame 28500",
            "expected_result": "Low on Zenny. (clean start: 3000z; price: 5000z)",
            "capture_frames": list(CAPTURE_FRAMES),
        },
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "last_callback_frame": completed,
        "captures": captures,
        "final_frame_memory": memory_report,
        "review_status": "PENDING_MANUAL_VISUAL_REVIEW",
    }
    report_path = args.output_dir / "shop_runtime_audit_v0_10.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
