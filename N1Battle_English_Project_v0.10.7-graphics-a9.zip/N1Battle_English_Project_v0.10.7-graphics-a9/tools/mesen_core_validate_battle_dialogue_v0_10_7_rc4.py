#!/usr/bin/env python3
"""Validate RC4 lower dialogue, PAUSE and battle third-row layouts in Mesen.

Every route starts from an empty Mesen home and uses controller input only.
The normal-dialogue and PAUSE captures run on the unmodified final RC4 ROM.
Three temporary battle probes only redirect the first deterministic Shotgun
message group to the exact final RC4 records supplied by the user; the final
ROM is never changed and every probe ROM is deleted after its worker exits.

Run without ``--worker-route`` to execute the five independent clean boots and
assemble the public JSON/montage.  MesenCore is process-global, so each route
runs in its own subprocess.
"""

from __future__ import annotations

import argparse
import concurrent.futures
import hashlib
import json
import os
import shutil
import struct
import subprocess
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_free_host_v0_10_6 as runtime  # noqa: E402
import n1tool  # noqa: E402


VERSION = "0.10.7-rc4"
FINAL_ROM_SHA256 = "129ef89f09e2fef3a6c7f1acce11f62ff0c615ca583317e5e5b106f029bbe1b8"
FINAL_CHECKSUM = 0xCB1C
MESEN_CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
NATIVE_SIZE = (224, 144)
B1_POINTERS = 0x37D7F4
FAR_BASE = 0x300000
EMPTY_RECORD = 0x37D700
OUTPUT_DEFAULT = ROOT / "docs/runtime_v0_10_7_rc4/battle_dialogue"

ROUTE_ORDER = ("normal_dialogue", "pause", "paralyzed", "numb", "match")
SUPPORT_POINTERS = {
    "paralyzed": (137, None),
    "numb": (139, 140),
    "match": (172, 173),
}
PROBE_IDENTITIES = {
    "paralyzed": ("4b9b9e203afb51a41cea2ad8fd00a8d9184805f144adcd7e437937839fd27f89", 0xCA54),
    "numb": ("d3cbc8abe4cb9a6033f351004a7149a3fdd791b48d2a2ee41eb9e6c4d7a35570", 0xC9A0),
    "match": ("e064533e909f107e9fe8dced3637b69c286869a30d4f116f33509afd385a6acc", 0xC9F0),
}

# PNGs are native MesenCore output.  The match hash is pinned after the final
# typewriter-stable f32860 capture.
EVIDENCE = {
    "normal_dialogue": {
        8550: ("normal_dialogue_three_rows_f8550.png", "f7ed838391cba92799f3589cacffc4e5d075df8deb614037818c206ab6363f37"),
    },
    "pause": {
        32592: ("battle_pause_menu_f32592.png", "ecd37680386d10f445d9654b9400ccba9390cc6ab86c12e14b4193879e57045f"),
    },
    "paralyzed": {
        32820: ("battle_support_paralyzed_f32820.png", "5545bbc8a4a2c194a0cbdeaf2ca8b4e54d81b213b8873c76e386132ca43ddabf"),
        33300: ("battle_support_next_group_clean_f33300.png", "39aaeedf9caa2f9ada6c957069133f7a65c303f4541c0289b998c1af3915c2a1"),
    },
    "numb": {
        32820: ("battle_support_numb_f32820.png", "138068d2b223c292d04674e11593df1d055536058b4b8f224115a06e0c09519a"),
        33300: ("battle_support_next_group_clean_f33300.png", "39aaeedf9caa2f9ada6c957069133f7a65c303f4541c0289b998c1af3915c2a1"),
    },
    "match": {
        32860: ("battle_support_match_f32860.png", "d3adb2a389a273a2cadcdb05026b251a991c6ce9ff841e582176c2859d0bd0e7"),
        33300: ("battle_support_next_group_clean_f33300.png", "39aaeedf9caa2f9ada6c957069133f7a65c303f4541c0289b998c1af3915c2a1"),
    },
}


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def pointer_target(rom: bytes | bytearray, index: int) -> int:
    offset, segment = struct.unpack_from("<HH", rom, B1_POINTERS + index * 4)
    if offset == segment == 0:
        raise AssertionError(f"B1:{index:03} unexpectedly NULL")
    return FAR_BASE + segment * 16 + offset


def far_pointer(target: int) -> bytes:
    segment, offset = divmod(target - FAR_BASE, 16)
    return struct.pack("<HH", offset, segment)


def build_support_probe(source: bytes, mode: str) -> tuple[bytes, int]:
    """Redirect accessible B1:049/050 to exact RC4 support records."""

    if sha256(source) != FINAL_ROM_SHA256:
        raise ValueError("support probe requires the exact final RC4 ROM")
    rom = bytearray(source)
    first, second = SUPPORT_POINTERS[mode]
    rom[B1_POINTERS + 49 * 4:B1_POINTERS + 50 * 4] = far_pointer(
        pointer_target(rom, first)
    )
    if second is None:
        # B1:137 already contains [RAW:0200] was[LINE]paralyzed.  A zero-word
        # second record preserves the accessible group's two-pointer topology
        # without adding visible text.
        if any(rom[EMPTY_RECORD:EMPTY_RECORD + 2]):
            raise AssertionError("reviewed empty-record target is occupied")
        rom[EMPTY_RECORD:EMPTY_RECORD + 2] = b"\x00\x80"
        second_target = EMPTY_RECORD
    else:
        second_target = pointer_target(rom, second)
    rom[B1_POINTERS + 50 * 4:B1_POINTERS + 51 * 4] = far_pointer(second_target)
    if rom[B1_POINTERS + 51 * 4:B1_POINTERS + 52 * 4] != b"\0" * 4:
        raise AssertionError("B1:051 NULL dispatch separator changed")
    checksum = n1tool.repair_checksum(rom)
    expected_hash, expected_checksum = PROBE_IDENTITIES[mode]
    if sha256(rom) != expected_hash or checksum != expected_checksum:
        raise AssertionError(f"{mode}: temporary probe identity changed")
    return bytes(rom), checksum


def base_input(frame: int) -> runtime.Controller:
    state = runtime.Controller()
    state.Start = runtime.pulse(frame, 650, 10)
    state.A = runtime.pulse(frame, 950, 8) or (
        1200 <= frame <= 26708 and frame % 300 < 8
    )
    return state


def input_for(route_name: str, frame: int) -> runtime.Controller:
    state = base_input(frame)
    if route_name == "normal_dialogue":
        return state
    state.Right = any(
        runtime.pulse(frame, first, 8) for first in (26920, 27040, 27160)
    )
    state.A = state.A or runtime.pulse(frame, 27230, 8)
    state.Up = runtime.pulse(frame, 28000, 8)
    state.Down = runtime.pulse(frame, 31340, 8)
    if route_name == "pause":
        state.A = state.A or any(
            runtime.pulse(frame, first, 8)
            for first in range(28800, 32401, 240)
        )
        # The pause edge exists just after A closes TURN 1 / FIGHT.
        state.Start = state.Start or runtime.pulse(frame, 32412, 8)
    else:
        state.A = state.A or any(
            runtime.pulse(frame, first, 8)
            for first in range(28800, 35401, 240)
        )
    return state


def route_for(name: str) -> runtime.Route:
    if name == "normal_dialogue":
        return runtime.Route(name, 8570, (), (), (), None, (
            runtime.Capture(8550, "normal_dialogue_three_rows"),
        ))
    if name == "pause":
        return runtime.Route(name, 32612, (), (), (), None, (
            runtime.Capture(32592, "battle_pause_menu"),
        ))
    composition_frame = 32860 if name == "match" else 32820
    return runtime.Route(name, 33320, (), (), (), None, (
        runtime.Capture(composition_frame, f"battle_support_{name}"),
        runtime.Capture(33300, "battle_support_next_group_clean"),
    ))


def disable_gui_release() -> None:
    original = runtime.configure_core

    def configure(lib) -> None:
        original(lib)
        lib.Release = lambda: None

    runtime.configure_core = configure


def verify_final_inputs(rom: bytes, core: bytes) -> None:
    if len(rom) != 0x400000 or sha256(rom) != FINAL_ROM_SHA256:
        raise ValueError("runtime validator requires the exact final RC4 ROM")
    stored = int.from_bytes(rom[-2:], "little")
    if stored != FINAL_CHECKSUM or sum(rom[:-2]) & 0xFFFF != FINAL_CHECKSUM:
        raise ValueError("final RC4 WonderSwan checksum mismatch")
    if sha256(core) != MESEN_CORE_SHA256:
        raise ValueError("MesenCore differs from the user-supplied 2.1.1 build")


def run_worker(args: argparse.Namespace) -> int:
    name = args.worker_route
    rom = args.rom.read_bytes()
    verify_final_inputs(rom, args.mesen_core.read_bytes())
    probe_identity = None
    temp = None
    rom_path = args.rom
    if name in SUPPORT_POINTERS:
        payload, checksum = build_support_probe(rom, name)
        temp = tempfile.TemporaryDirectory(prefix=f"n1_rc4_{name}_probe_")
        rom_path = Path(temp.name) / f"{name}.wsc"
        rom_path.write_bytes(payload)
        probe_identity = {
            "sha256": sha256(payload),
            "checksum": f"0x{checksum:04X}",
            "deleted_after_worker": True,
        }
    runtime.input_for = lambda _route, frame: input_for(name, frame)
    disable_gui_release()
    try:
        result = runtime.run_route(
            route_for(name), rom_path, args.mesen_core, args.output_dir, args.timeout
        )
    finally:
        if temp is not None:
            temp.cleanup()
    result.pop("elapsed_seconds", None)
    checks = []
    by_frame = {int(row["frame"]): row for row in result["captures"]}
    for frame, (evidence_name, expected_hash) in EVIDENCE[name].items():
        evidence = args.output_dir / evidence_name
        actual = args.output_dir / by_frame[frame]["file"]
        if sha256(evidence.read_bytes()) != expected_hash:
            raise AssertionError(f"reviewed evidence changed: {evidence_name}")
        if actual.read_bytes() != evidence.read_bytes():
            raise AssertionError(f"{name} frame {frame}: pixels differ from evidence")
        checks.append({
            "frame": frame,
            "evidence_file": evidence_name,
            "png_sha256": expected_hash,
            "native_pixel_match": True,
        })
    memory_hashes = []
    for capture in result["captures"]:
        memory_path = args.output_dir / capture.pop("cpu_memory")
        memory_hashes.append({
            "frame": capture["frame"],
            "cpu_memory_sha256": capture.pop("cpu_memory_sha256"),
            "removed_after_validation": True,
        })
        memory_path.unlink()
    worker = {
        "status": "PASS",
        "route": name,
        "final_rom_sha256": FINAL_ROM_SHA256,
        "temporary_probe": probe_identity,
        "runtime": result,
        "evidence_checks": checks,
        "memory_checks": memory_hashes,
        "uses_sav_or_savestate": False,
        "mesen_home_removed": True,
    }
    path = args.output_dir / name / "worker_result.json"
    path.write_text(json.dumps(worker, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({"status": "PASS", "route": name}, indent=2))
    return 0


def dark_text_bbox(path: Path) -> list[int]:
    with Image.open(path) as source:
        image = source.convert("RGB")
    points = []
    for y in range(86, 132):
        for x in range(64, 208):
            if max(image.getpixel((x, y))) < 150:
                points.append((x, y))
    return [
        min(x for x, _ in points), min(y for _, y in points),
        max(x for x, _ in points), max(y for _, y in points),
    ]


def make_montage(output_dir: Path) -> dict:
    items = [
        ("NORMAL DIALOGUE — 3 ROWS", "normal_dialogue_three_rows_f8550.png"),
        ("PAUSE — DECK / RETRY / GIVE UP", "battle_pause_menu_f32592.png"),
        ("PARALYZED", "battle_support_paralyzed_f32820.png"),
        ("NUMB — 3 ROWS", "battle_support_numb_f32820.png"),
        ("TYPE MATCH — 3 ROWS", "battle_support_match_f32860.png"),
        ("NEXT GROUP CLEAN", "battle_support_next_group_clean_f33300.png"),
    ]
    cards = []
    for label, name in items:
        with Image.open(output_dir / name) as source:
            image = source.convert("RGB").resize((448, 288), Image.Resampling.NEAREST)
        card = Image.new("RGB", (448, 314), (16, 16, 16))
        card.paste(image, (0, 26))
        ImageDraw.Draw(card).text((7, 7), label, fill="white")
        cards.append(card)
    montage = Image.new("RGB", (904, 958), (8, 8, 8))
    for index, card in enumerate(cards):
        montage.paste(card, ((index % 2) * 456, (index // 2) * 322))
    path = output_dir / "battle_dialogue_runtime_montage_v0_10_7_rc4.png"
    montage.save(path, optimize=False)
    return {"file": path.name, "sha256": sha256(path.read_bytes()), "dimensions": list(montage.size)}


def assemble(args: argparse.Namespace, workers: list[dict]) -> dict:
    battle = json.loads((ROOT / "translation/assets/battle_message_asset_report_v0_10_7_rc4.json").read_text())
    layout = json.loads((ROOT / "translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json").read_text())
    translations = {
        row["id"]: row["translation"]
        for bank in battle["banks"] for row in bank["translations"]
    }
    expected = {
        "B1:137": "[RAW:0200] was[LINE]paralyzed",
        "B1:139": "[RAW:0200]",
        "B1:140": "is numb and cannot[LINE]move!",
        "B1:172": "Navi and chip match",
        "B1:173": "type! Chip Attack[LINE]increased!",
        "B2:053": "PAUSE", "B2:055": "DECK",
        "B2:056": "RETRY", "B2:057": "GIVE UP",
    }
    if any(translations.get(key) != value for key, value in expected.items()):
        raise AssertionError("final RC4 battle semantics differ from reviewed text")
    normal_bbox = dark_text_bbox(args.output_dir / "normal_dialogue_three_rows_f8550.png")
    if normal_bbox != [64, 90, 150, 131]:
        raise AssertionError(f"normal-dialogue ink bounds changed: {normal_bbox}")
    report = {
        "format": "n1-battle-dialogue-runtime-validation-v0.10.7-rc4",
        "status": "PASS",
        "version": VERSION,
        "final_rom": {"sha256": FINAL_ROM_SHA256, "checksum": "0xCB1C"},
        "mesen_core_sha256": MESEN_CORE_SHA256,
        "native_display": list(NATIVE_SIZE),
        "clean_boot_routes": len(workers),
        "uses_sav_or_savestate": False,
        "all_mesen_homes_removed": True,
        "all_temporary_probe_roms_removed": True,
        "input_schedule": {
            "clean_boot": "Start f650..659; A f950..957",
            "opening_advance": "A every 300 frames from f1200 through f26708",
            "free_battle": "Right f26920/f27040/f27160; A f27230; Up f28000",
            "skip_deck_edit": "A every 240 frames from f28800; Down f31340; A f31440 selects No",
            "pause": "A f32400..32407, then Start f32412..32419; capture f32592",
            "battle_support": "same organic route; injected records visible at f32820/f32860; next group f33300",
        },
        "normal_dialogue": {
            "entry": "intro_registration_prompt",
            "frame": 8550,
            "lines": ["I'm here to", "register for", "BattleChipGP."],
            "widths": [11, 12, 13],
            "text_ink_bbox": normal_bbox,
            "safe_right_edge": 215,
            "overflow_pixels": 0,
            "evidence": "normal_dialogue_three_rows_f8550.png",
            "status": "PASS",
        },
        "pause": {
            "route": "A f32400..32407, then Start f32412..32419",
            "frame": 32592,
            "labels": ["PAUSE", "DECK", "RETRY", "GIVE UP"],
            "label_bounds_x": {"DECK": [24, 49], "RETRY": [88, 126], "GIVE UP": [152, 206]},
            "inter_label_gaps_pixels": [38, 25],
            "right_margin_pixels": 12,
            "overlap_or_overflow": False,
            "evidence": "battle_pause_menu_f32592.png",
            "status": "PASS",
        },
        "battle_support_cases": [
            {"case": "paralyzed", "lines": ["MegaMan was", "paralyzed"], "asset_ids": [137], "evidence": "battle_support_paralyzed_f32820.png", "status": "PASS"},
            {"case": "numb", "lines": ["MegaMan", "is numb and cannot", "move!"], "asset_ids": [139, 140], "evidence": "battle_support_numb_f32820.png", "status": "PASS"},
            {"case": "type_match", "lines": ["Navi and chip match", "type! Chip Attack", "increased!"], "asset_ids": [172, 173], "evidence": "battle_support_match_f32860.png", "status": "PASS"},
        ],
        "dispatch_safety": battle["dispatch_safety"],
        "next_group_clean": {"frame": 33300, "evidence": "battle_support_next_group_clean_f33300.png", "status": "PASS"},
        "structural_layout": {
            "normal_report_status": layout["status"],
            "remaining_literal_overflow_lines": layout["remaining_literal_overflow_lines"],
            "remaining_vertical_overflow_pages": layout["remaining_vertical_overflow_pages"],
            "battle_report_status": battle["status"],
            "exact_text_contract": expected,
            "status": "PASS",
        },
        "routes": workers,
        "montage": make_montage(args.output_dir),
    }
    path = args.output_dir / "battle_dialogue_runtime_validation_v0_10_7_rc4.json"
    path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc4.wsc")
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", type=Path, default=OUTPUT_DEFAULT)
    parser.add_argument("--worker-route", choices=ROUTE_ORDER)
    parser.add_argument("--assemble-only", action="store_true")
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()
    verify_final_inputs(args.rom.read_bytes(), args.mesen_core.read_bytes())
    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.worker_route:
        return run_worker(args)
    if args.assemble_only:
        workers = [
            json.loads((args.output_dir / name / "worker_result.json").read_text())
            for name in ROUTE_ORDER
        ]
        report = assemble(args, workers)
        print(json.dumps({"status": report["status"], "assemble_only": True}, indent=2))
        return 0

    def invoke(name: str) -> dict:
        command = [
            sys.executable, str(Path(__file__).resolve()),
            "--rom", str(args.rom.resolve()),
            "--mesen-core", str(args.mesen_core.resolve()),
            "--output-dir", str(args.output_dir.resolve()),
            "--worker-route", name,
            "--timeout", str(args.timeout),
        ]
        process = subprocess.run(
            command, capture_output=True, text=True, check=False,
            env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
        )
        if process.returncode:
            raise RuntimeError(f"{name} worker failed:\n{process.stdout}\n{process.stderr}")
        return json.loads((args.output_dir / name / "worker_result.json").read_text())

    with concurrent.futures.ThreadPoolExecutor(max_workers=len(ROUTE_ORDER)) as pool:
        futures = {name: pool.submit(invoke, name) for name in ROUTE_ORDER}
        workers = [futures[name].result() for name in ROUTE_ORDER]
    report = assemble(args, workers)
    print(json.dumps({
        "status": report["status"],
        "clean_boot_routes": report["clean_boot_routes"],
        "battle_support_cases": len(report["battle_support_cases"]),
        "report": "docs/runtime_v0_10_7_rc4/battle_dialogue/battle_dialogue_runtime_validation_v0_10_7_rc4.json",
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
