#!/usr/bin/env python3
"""Create the deterministic ROM-free public N1 Battle v0.10.7 RC4 package.

The final ROM and IPS identities are pinned after structural validation.  The
ROM itself is never selected for the public archive.
"""

from __future__ import annotations

import argparse
import hashlib
import json
import re
import zipfile
from pathlib import Path, PurePosixPath


VERSION = "0.10.7-rc4"
PACKAGE_ROOT = "N1Battle_English_Project_v0.10.7-rc4"
FIXED_TIME = (2026, 8, 24, 0, 0, 0)
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
FINAL_ROM_SHA256 = "129ef89f09e2fef3a6c7f1acce11f62ff0c615ca583317e5e5b106f029bbe1b8"
IPS_SHA256 = "1f4270eab41a0401381c8ba53087faa337436337933932dc3623d1cf4321d2e9"
BASE_RC3_IPS_SHA256 = "165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980"
BASE_V0106_IPS_SHA256 = "d7df4954bd3509865abf3fabf99a3ba6bc8b17bb22b2855d52cd85907e7a56f6"
SHA256_RE = re.compile(r"^[0-9a-f]{64}$")

FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".cdl", ".rgd", ".dmp",
    ".deb", ".so", ".dll", ".exe", ".tar", ".gz", ".7z", ".zip", ".ttf",
}
FORBIDDEN_DIRECTORIES = {
    "mesen_core_home", "mesen_home", "savestates", "saves", "memory",
    "emulator", "emulators", "cores", "bios",
}
FORBIDDEN_NAME_MARKERS = (
    "cpu_dump", "cpu-memory", "cpu_memory", "_cpu_", "_cpu.", "wram",
    "ports_", "bios", "bootrom", "boot_rom", "savestate",
)
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}
DOC_SUFFIXES = {".md", ".json", ".png", ".tsv"}

REQUIRED = {
    "APPLY_PATCH.bat", "BUILD_PATCH.bat", "CHANGELOG.md", "LICENSE.txt",
    "README_ES.md", "RELEASE_SHA256.txt",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.7-rc4.ips",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.ips",
    "patches/Rockman_EXE_N1_Battle_English_v0.10.6.ips",
    "translation/en_v0_10_7_rc4.json",
    "translation/en_v0_10_7_rc4_dialogue.json",
    "translation/en_v0_10_7_rc3.json", "translation/en_v0_10_6.json",
    "tables/n1battle_jp.tbl", "references/bcc_en.tbl",
    "translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json",
    "translation/assets/battle_message_asset_report_v0_10_7_rc4.json",
    "translation/assets/manifest_report_v0_10_7_rc4.json",
    "translation/assets/battle_messages_b1_data_v0_10_7_rc4.bin",
    "translation/assets/battle_messages_b1_pointers_v0_10_7_rc4.bin",
    "translation/assets/battle_messages_b2_data_v0_10_7_rc4.bin",
    "translation/assets/battle_messages_b2_pointers_v0_10_7_rc4.bin",
    "build/build_v0_10_7_rc4.json",
    "build/validation_v0_10_7_rc4.json",
    "docs/LOWER_DIALOGUE_LAYOUT_v0_10_7_RC4.md",
    "docs/EMULATOR_VALIDATION_v0_10_7_RC4.md",
    "docs/RELEASE_CANDIDATE_v0_10_7_RC4.md",
    "docs/PROGRESO_v0_10_7_RC4.md",
    "docs/progress_v0_10_7_rc4.json",
    "docs/STRUCTURAL_VALIDATION_v0_10_7_RC4.json",
    "docs/runtime_v0_10_7_rc4/battle_dialogue/"
    "battle_dialogue_runtime_validation_v0_10_7_rc4.json",
    "docs/runtime_v0_10_7_rc4/battle_dialogue/"
    "battle_engine_line_mechanism_comparison_v0_10_7_rc4.png",
    "tools/lower_dialogue_layout_v0_10_7_rc4.py",
    "tools/battle_message_assets_v0_10_7_rc4.py",
    "tools/make_manifest_v0_10_7_rc4.py",
    "tools/validate_release_v0_10_7_rc4.py",
    "tools/mesen_core_validate_battle_dialogue_v0_10_7_rc4.py",
    "tools/package_release_v0_10_7_rc4.py",
    "tests/test_lower_dialogue_layout_v0_10_7_rc4.py",
    "tests/test_battle_message_assets_v0_10_7_rc4.py",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require_final_hashes() -> None:
    pending = [
        name for name, value in (
            ("FINAL_ROM_SHA256", FINAL_ROM_SHA256),
            ("IPS_SHA256", IPS_SHA256),
        )
        if SHA256_RE.fullmatch(value) is None
    ]
    if pending:
        raise ValueError(
            "RC4 release hashes are still placeholders: " + ", ".join(pending)
        )


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict:
    value = json.loads(require(root, relative).read_text(encoding="utf-8"))
    if not isinstance(value, dict):
        raise ValueError(f"expected JSON object: {relative}")
    return value


def validate_evidence(root: Path) -> None:
    structural = load_json(root, "build/validation_v0_10_7_rc4.json")
    layout = load_json(
        root, "translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json"
    )
    battle = load_json(
        root, "translation/assets/battle_message_asset_report_v0_10_7_rc4.json"
    )
    runtime = load_json(
        root,
        "docs/runtime_v0_10_7_rc4/battle_dialogue/"
        "battle_dialogue_runtime_validation_v0_10_7_rc4.json",
    )

    bank_topology = all(
        row.get("pointers", {}).get("null_topology_preserved") is True
        for row in battle.get("banks", [])
    )
    checks = {
        "structural": structural.get("status") == "PASS"
        and structural.get("final_rom_sha256") == FINAL_ROM_SHA256
        and structural.get("outside_allowlist") == 0,
        "normal lower dialogue": layout.get("status") == "PASS"
        and layout.get("remaining_literal_overflow_lines") == 0
        and layout.get("remaining_vertical_overflow_pages") == 0,
        "battle message banks": battle.get("status") == "PASS"
        and battle.get("project_version") == VERSION
        and len(battle.get("banks", [])) == 2
        and all(
            max(row.get("physical_line_widths_worst_case", [999]))
            <= int(row.get("line_limit", -1))
            for row in battle.get("width_audit", [])
        )
        and bank_topology,
        "runtime": runtime.get("status") == "PASS"
        and runtime.get("uses_sav_or_savestate") is False,
    }
    failed = [name for name, result in checks.items() if not result]
    if failed:
        raise ValueError("RC4 release evidence is not final: " + ", ".join(failed))


def validate_manifest(root: Path) -> dict:
    manifest = load_json(root, "translation/en_v0_10_7_rc4.json")
    if (
        manifest.get("format") != "n1battle-inplace-translation-v1"
        or manifest.get("project_version") != VERSION
        or manifest.get("source_sha256") != SOURCE_ROM_SHA256
        or len(manifest.get("entries", [])) != 271
        or len(manifest.get("binary_entries", [])) != 80
    ):
        raise ValueError("unexpected RC4 manifest identity")
    return manifest


def collect(root: Path) -> list[Path]:
    manifest = validate_manifest(root)
    files = {require(root, relative) for relative in REQUIRED}
    for entry in manifest["binary_entries"]:
        relative = PurePosixPath("translation") / str(entry["asset"])
        if relative.is_absolute() or ".." in relative.parts:
            raise ValueError(f"manifest asset escapes translation/: {relative}")
        path = require(root, relative.as_posix())
        payload = path.read_bytes()
        if (
            len(payload) != int(entry["length"])
            or sha256(payload) != str(entry["asset_sha256"]).lower()
        ):
            raise ValueError(f"manifest asset mismatch: {relative}")
        files.add(path)

    files.update(
        path for path in (root / "tools").glob("*.py") if path.is_file()
    )
    # The recovered historical package does not contain every private source
    # asset required by several old generator unit tests.  Include only the
    # self-contained inherited tests plus the complete RC4 suites.
    public_tests = {
        "test_bcc_reference_v0_6.py", "test_n1save.py",
        "test_redbox_font_v0_10_7_rc3.py",
        "test_lower_dialogue_layout_v0_10_7_rc4.py",
        "test_battle_message_assets_v0_10_7_rc4.py",
    }
    files.update(
        require(root, f"tests/{name}") for name in public_tests
    )
    files.update(
        path for path in (root / "docs").rglob("*")
        if path.is_file() and path.suffix.lower() in DOC_SUFFIXES
        and "v0_10" in path.relative_to(root / "docs").as_posix().lower()
        and not ({part.lower() for part in path.relative_to(root).parts}
                 & FORBIDDEN_DIRECTORIES)
        and not any(marker in path.name.lower() for marker in FORBIDDEN_NAME_MARKERS)
    )
    files.update(
        path for path in (root / "translation/assets").glob("*")
        if path.is_file() and path.suffix.lower() in {".png", ".json", ".md"}
        and "v0_10_7_rc4" in path.name.lower()
    )
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def private_reasons(root: Path, path: Path) -> list[str]:
    relative = path.relative_to(root)
    parts = {part.lower() for part in relative.parts}
    name = path.name.lower()
    reasons = []
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        reasons.append("extension")
    if path.stat().st_size in FORBIDDEN_SIZES:
        reasons.append("size")
    if parts & FORBIDDEN_DIRECTORIES:
        reasons.append("directory")
    if any(marker in name for marker in FORBIDDEN_NAME_MARKERS):
        reasons.append("name")
    return reasons


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if path.is_symlink():
        raise ValueError(f"symlink not allowed: {relative}")
    reasons = private_reasons(root, path)
    if reasons:
        raise ValueError(f"private file selected: {relative}: {reasons}")
    payload = path.read_bytes()
    if path.suffix.lower() in {".md", ".json", ".tsv", ".bat", ".txt"}:
        text = payload.decode("utf-8")
        found = [marker for marker in ("/workspace/", "/root/") if marker in text]
        if found:
            raise ValueError(f"private path marker in {relative}: {found}")
    if path.suffix.lower() == ".json":
        json.loads(payload.decode("utf-8"))
    if relative.endswith("v0.10.7-rc4.ips") and sha256(payload) != IPS_SHA256:
        raise ValueError("unexpected RC4 IPS hash")
    if relative.endswith("v0.10.7-rc3.ips") and sha256(payload) != BASE_RC3_IPS_SHA256:
        raise ValueError("unexpected RC3 IPS hash")
    if relative.endswith("v0.10.6.ips") and sha256(payload) != BASE_V0106_IPS_SHA256:
        raise ValueError("unexpected v0.10.6 IPS hash")
    return {"path": relative, "size": len(payload), "sha256": sha256(payload)}


def validate_archive(path: Path) -> None:
    with zipfile.ZipFile(path) as archive:
        names = archive.namelist()
        if len(names) != len(set(names)):
            raise ValueError("archive contains duplicate members")
        for info in archive.infolist():
            relative = PurePosixPath(info.filename)
            if relative.is_absolute() or ".." in relative.parts:
                raise ValueError(f"unsafe archive path: {info.filename}")
            if info.date_time != FIXED_TIME:
                raise ValueError(f"non-deterministic timestamp: {info.filename}")
            lowered = {part.lower() for part in relative.parts}
            if lowered & FORBIDDEN_DIRECTORIES or relative.suffix.lower() in FORBIDDEN_SUFFIXES:
                raise ValueError(f"private archive member: {info.filename}")


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    require_final_hashes()
    validate_evidence(root)
    release_hashes = require(root, "RELEASE_SHA256.txt").read_text(encoding="utf-8")
    if FINAL_ROM_SHA256 not in release_hashes or IPS_SHA256 not in release_hashes:
        raise ValueError("RELEASE_SHA256.txt does not pin RC4")

    output = (args.output or root / "dist/N1Battle_English_Project_v0.10.7-rc4.zip").resolve()
    if root not in output.parents:
        raise ValueError("output must stay inside project root")
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(
                info, path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED, compresslevel=9,
            )
    validate_archive(output)

    archive_payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": VERSION,
        "archive": output.name,
        "archive_size": len(archive_payload),
        "archive_sha256": sha256(archive_payload),
        "file_count": len(inventory),
        "rom_bios_ttf_save_emulator_files": 0,
        "rc3_preserved_as_base": True,
        "files": inventory,
    }
    output.with_suffix(".release.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_ttf_save_emulator_files", "rc3_preserved_as_base",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
