#!/usr/bin/env python3
"""Validate Advance 5 on the live main Chip Folder route in MesenCore."""

from __future__ import annotations

import argparse
from concurrent.futures import ProcessPoolExecutor
import hashlib
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_3_header as a3  # noqa: E402
import graphics_advance_5_chip_folder as asset  # noqa: E402
import mesen_core_validate_pet_deep_v0_10 as legacy  # noqa: E402
import n1tool  # noqa: E402


SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
A4_ROM_SHA256 = "e640da75a810a3cc7699c93333d164dfbf444baef006c5d26bbec176d84d62c8"
A5_ROM_SHA256 = "254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522"
A5_IPS_SHA256 = "2beb302099fc4b6c661c1db39722978cf83f6705b8edf7856d21e812e0627faf"
CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
TARGET_RECT = (88, 0, 136, 16)
EXPECTED_CHIP_FOLDER_CHANGED_PIXELS = 524
EXPECTED_CHIP_FOLDER_CHANGED_BBOX = (88, 0, 132, 16)
EXPECTED_A5_SCREENSHOT_SHA256 = "a6a63b959016bb67da60970b7c32af65e0e0219262e0cdf687d07561ec5d692a"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def bind_candidate(rom: bytes) -> None:
    for name, region in list(legacy.MAPS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.MAPS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    for name, region in list(legacy.TILE_BANKS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.TILE_BANKS[name] = legacy.Region(region.offset, region.length, sha256(payload))


def run(rom_path: Path, core: Path, output: Path, timeout: float) -> dict:
    rom = rom_path.read_bytes()
    bind_candidate(rom)
    return legacy.run_route({
        "route": "chip", "rom": str(rom_path), "core": str(core),
        "output": str(output), "timeout": timeout,
    })


def run_isolated(rom_path: Path, core: Path, output: Path, timeout: float) -> dict:
    """MesenCore is process-global, so each clean boot gets a fresh process."""
    with ProcessPoolExecutor(max_workers=1) as executor:
        return executor.submit(run, rom_path, core, output, timeout).result()


def image_diff(before: Image.Image, after: Image.Image) -> dict[str, object]:
    changed = []
    outside = 0
    left, top, right, bottom = TARGET_RECT
    for y in range(144):
        for x in range(224):
            if before.getpixel((x, y)) == after.getpixel((x, y)):
                continue
            changed.append((x, y))
            if not (left <= x < right and top <= y < bottom):
                outside += 1
    bbox = ImageChops.difference(before, after).getbbox()
    return {
        "changed_pixels": len(changed),
        "changed_bbox": list(bbox) if bbox else None,
        "pixels_outside_target": outside,
    }


def audit_runtime_canvas(crop: Image.Image, canvas: list[list[int]]) -> dict[str, object]:
    if crop.size != (48, 16):
        raise AssertionError("A5 runtime crop geometry differs")
    index_colours: dict[int, set[tuple[int, int, int]]] = {}
    for y, row in enumerate(canvas):
        for x, value in enumerate(row):
            index_colours.setdefault(value, set()).add(crop.getpixel((x, y)))
    if set(index_colours) != {3, 9, 15} or any(len(colours) != 1 for colours in index_colours.values()):
        raise AssertionError("A5 runtime palette is not a stable mapping of the approved A3 mask")
    expected = Image.new("RGB", crop.size)
    for y, row in enumerate(canvas):
        for x, value in enumerate(row):
            expected.putpixel((x, y), next(iter(index_colours[value])))
    if expected.tobytes() != crop.tobytes():
        raise AssertionError("A5 runtime crop differs from the approved A3 pattern")
    return {
        "matches_approved_a3_pattern": True,
        "palette_indices": sorted(index_colours),
        "index_to_runtime_rgb": {
            str(index): list(next(iter(colours)))
            for index, colours in sorted(index_colours.items())
        },
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--a4-rom", required=True, type=Path)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--ips", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=180.0)
    parser.add_argument(
        "--reuse-captures", action="store_true",
        help="audit existing A4/A5 route reports instead of starting MesenCore again",
    )
    args = parser.parse_args()
    source = args.source_rom.read_bytes()
    a4 = args.a4_rom.read_bytes()
    a5 = args.rom.read_bytes()
    ips = args.ips.read_bytes()
    identities = (
        ("Japanese source ROM", source, SOURCE_ROM_SHA256),
        ("Advance 4 ROM", a4, A4_ROM_SHA256),
        ("Advance 5 ROM", a5, A5_ROM_SHA256),
        ("Advance 5 IPS", ips, A5_IPS_SHA256),
        ("MesenCore", args.mesen_core.read_bytes(), CORE_SHA256),
    )
    for name, payload, expected in identities:
        if sha256(payload) != expected:
            raise ValueError(f"{name} identity differs")
    if n1tool.apply_ips(source, ips) != a5:
        raise AssertionError("A5 IPS does not reconstruct the candidate")
    stored, calculated = n1tool.checksum(a5)
    if stored != calculated != 0x5286 or stored != 0x5286:
        raise AssertionError("A5 WonderSwan checksum differs")

    allowed = {
        asset.MAP_OFFSET + (y * 32 + x) * 2
        for x, y in asset.TARGET_CELLS
    } | {len(a5) - 2, len(a5) - 1}
    changed_offsets = {i for i, pair in enumerate(zip(a4, a5, strict=True)) if pair[0] != pair[1]}
    if changed_offsets != allowed:
        raise AssertionError("A5 binary delta is not exactly twelve map low bytes plus checksum")
    if a4[asset.TILES_OFFSET:asset.TILES_OFFSET + asset.TILES_LENGTH] != a5[asset.TILES_OFFSET:asset.TILES_OFFSET + asset.TILES_LENGTH]:
        raise AssertionError("A5 changed the shared CHIP FOLDER tile bank")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    if args.reuse_captures:
        base_result = json.loads((args.output_dir / "a4/route_report.json").read_text(encoding="utf-8"))
        candidate_result = json.loads((args.output_dir / "a5/route_report.json").read_text(encoding="utf-8"))
    else:
        base_result = run_isolated(args.a4_rom, args.mesen_core, args.output_dir / "a4", args.timeout)
        candidate_result = run_isolated(args.rom, args.mesen_core, args.output_dir / "a5", args.timeout)
    states = [capture.name for capture in legacy.route_by_name("chip").captures]
    comparisons = {}
    for state in states:
        frame = next(capture.frame for capture in legacy.route_by_name("chip").captures if capture.name == state)
        before_path = args.output_dir / "a4" / f"{state}_{frame}.png"
        after_path = args.output_dir / "a5" / f"{state}_{frame}.png"
        with Image.open(before_path) as source_image, Image.open(after_path) as target_image:
            before = source_image.convert("RGB")
            after = target_image.convert("RGB")
        if before.size != (224, 144) or after.size != (224, 144):
            raise AssertionError("runtime screenshot is not native 224x144")
        comparison = image_diff(before, after)
        if comparison["pixels_outside_target"] != 0:
            raise AssertionError(f"{state}: A5 changed pixels outside the header")
        comparisons[state] = comparison
    if comparisons["chip_backpack"]["changed_pixels"] != 0:
        raise AssertionError("backpack screen changed despite using another map")
    primary_diff = comparisons["chip_folder"]
    if primary_diff["changed_pixels"] != EXPECTED_CHIP_FOLDER_CHANGED_PIXELS:
        raise AssertionError(f"pinned A5 pixel delta differs: {primary_diff}")
    if tuple(primary_diff["changed_bbox"] or ()) != EXPECTED_CHIP_FOLDER_CHANGED_BBOX:
        raise AssertionError(f"pinned A5 pixel bounds differ: {primary_diff}")

    primary_source = args.output_dir / "a5" / "chip_folder_27320.png"
    primary = args.output_dir / "chip_folder_27320.png"
    shutil.copy2(primary_source, primary)
    screenshot_hash = sha256(primary.read_bytes())
    if EXPECTED_A5_SCREENSHOT_SHA256 and screenshot_hash != EXPECTED_A5_SCREENSHOT_SHA256:
        raise AssertionError("pinned A5 screenshot identity differs")
    with Image.open(primary) as image:
        crop = image.convert("RGB").crop(TARGET_RECT)
    bank = a5[asset.TILES_OFFSET:asset.TILES_OFFSET + asset.TILES_LENGTH]
    canvas = a3.read_canvas(bank, asset.APPROVED_TILE_IDS, 6)
    canvas_audit = audit_runtime_canvas(crop, canvas)

    for route_result in (base_result, candidate_result):
        for capture in route_result["captures"]:
            if not capture["runtime_map"]["exact_match"] or not capture["runtime_tiles"]["exact_match"]:
                raise AssertionError("live map or tile bank differs from candidate ROM")
    report = {
        "status": "PASS",
        "version": "0.10.7-graphics-a5",
        "advance": "5 of 6",
        "rom_sha256": A5_ROM_SHA256,
        "base_a4_rom_sha256": A4_ROM_SHA256,
        "cumulative_ips_sha256": A5_IPS_SHA256,
        "mesen_core_sha256": CORE_SHA256,
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "native_resolution": [224, 144],
        "target_rectangle": list(TARGET_RECT),
        "binary_delta_vs_a4": {
            "changed_bytes": len(changed_offsets),
            "map_low_bytes": 12,
            "checksum_bytes": 2,
            "outside_allowlist": 0,
            "tile_bytes": 0,
            "palette_bytes": 0,
        },
        "screen_comparisons_vs_a4": comparisons,
        "approved_a3_pattern_runtime_audit": canvas_audit,
        "all_pixels_outside_target_unchanged": True,
        "other_map_backpack_screen_pixel_exact_vs_a4": True,
        "runtime_map_matches_rom": True,
        "runtime_tiles_match_rom": True,
        "ips_reconstructs_candidate": True,
        "wonder_swan_checksum": "0x5286",
        "a1_through_a4_binary_regressions_protected_by_exact_delta": True,
        "primary_screenshot": primary.name,
        "primary_screenshot_sha256": screenshot_hash,
        "route_reports": ["a4/route_report.json", "a5/route_report.json"],
    }
    output = args.output_dir / "graphics_advance_5_runtime_validation.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
