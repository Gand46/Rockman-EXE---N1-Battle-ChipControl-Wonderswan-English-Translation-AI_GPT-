#!/usr/bin/env python3
"""Validate the expanded v0.9 build, IPS and all reachable text corpora."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import struct
import sys
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
ROM_SIZE = 0x400000
TEXT_DENOMINATOR = 1552
GRAPHICS_DENOMINATOR = 75


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def number(value: int | str) -> int:
    return value if isinstance(value, int) else int(value, 0)


def contains_japanese(text: str) -> bool:
    return any(
        "\u3040" <= char <= "\u30ff"
        or "\u3400" <= char <= "\u4dbf"
        or "\u4e00" <= char <= "\u9fff"
        for char in text
    )


def load_module(name: str, path: Path) -> Any:
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def decode_static(words: list[int], decode: dict[int, str]) -> str:
    return "".join(decode.get(word & 0x0FFF, f"[RAW:{word:04X}]") for word in words[:-1])


def far_table_audit(
    rom: bytes, layout: Any, bcc: Any, decode: dict[int, str]
) -> dict[str, Any]:
    targets: list[int] = []
    residual: list[dict[str, Any]] = []
    for index in range(layout.count):
        target = bcc.wsc_pointer(rom, layout.pointer_start, index, layout.name)
        words = bcc.read_words(rom, target, f"{layout.name}[{index}]")
        text = decode_static(words, decode)
        targets.append(target)
        if contains_japanese(text):
            residual.append({"index": index, "target": f"0x{target:06X}", "text": text})
    return {
        "records": layout.count,
        "unique_targets": len(set(targets)),
        "remaining_japanese": len(residual),
        "residual_examples": residual[:10],
    }


def description_audit(
    rom: bytes, bcc: Any, decode: dict[int, str]
) -> dict[str, Any]:
    bad_rows: list[dict[str, Any]] = []
    line_count = 0
    line_targets: set[int] = set()
    list_targets: set[int] = set()
    for row in range(bcc.DESCRIPTION_COUNT):
        list_target = bcc.wsc_pointer(
            rom, bcc.DESCRIPTION_OUTER_POINTERS, row, "chip_descriptions"
        )
        list_targets.add(list_target)
        row_bad: list[dict[str, Any]] = []
        for line in range(16):
            offset, segment = struct.unpack_from("<HH", rom, list_target + line * 4)
            if offset == segment == 0:
                break
            target = 0x300000 + segment * 16 + offset
            words = bcc.read_words(rom, target, f"chip_descriptions[{row}][{line}]")
            text = decode_static(words, decode)
            line_count += 1
            line_targets.add(target)
            if contains_japanese(text):
                row_bad.append({"line": line, "target": f"0x{target:06X}", "text": text})
        else:
            raise ValueError(f"chip description {row}: no null line sentinel")
        if row_bad:
            bad_rows.append({"row": row, "lines": row_bad})
    return {
        "records": bcc.DESCRIPTION_COUNT,
        "line_records": line_count,
        "unique_list_targets": len(list_targets),
        "unique_line_targets": len(line_targets),
        "remaining_japanese_rows": len(bad_rows),
        "residual_examples": bad_rows[:5],
    }


def generic_far_bank_audit(
    rom: bytes,
    name: str,
    pointer_start: int,
    pointer_count: int,
    bcc: Any,
    decode: dict[int, str],
) -> dict[str, Any]:
    non_null = 0
    targets: list[int] = []
    bad: list[dict[str, Any]] = []
    for index in range(pointer_count):
        offset, segment = struct.unpack_from("<HH", rom, pointer_start + index * 4)
        if offset == segment == 0:
            continue
        non_null += 1
        target = 0x300000 + segment * 16 + offset
        words = bcc.read_words(rom, target, f"{name}[{index}]")
        text = decode_static(words, decode)
        targets.append(target)
        if contains_japanese(text):
            bad.append({"index": index, "target": f"0x{target:06X}", "text": text})
    return {
        "pointer_slots": pointer_count,
        "non_null": non_null,
        "unique_targets": len(set(targets)),
        "remaining_japanese": len(bad),
        "residual_examples": bad[:10],
    }


def group_targets(script_dump: dict[str, Any], indices: set[int]) -> dict[int, str]:
    result: dict[int, str] = {}
    for group in script_dump["groups"]:
        if int(group["group"]) not in indices:
            continue
        for pointer in group["pointers"]:
            if pointer["valid"]:
                result.setdefault(number(pointer["target"]), str(pointer["text"]))
    return result


def pass_check(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--source-rom", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--built-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_9.json").resolve()
    built_path = (
        args.built_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.9.wsc"
    ).resolve()
    ips_path = (
        args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.9.ips"
    ).resolve()
    report_path = (args.report or root / "docs/STRUCTURAL_VALIDATION_v0_9.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-deep-release-validation-v1",
        "project_version": "0.9.0",
        "report_date": "2026-08-22",
        "overall_result": "FAIL",
        "checks": {},
        "inventories": {},
        "errors": [],
    }
    try:
        source = args.source_rom.read_bytes()
        built = built_path.read_bytes()
        ips = ips_path.read_bytes()
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        n1tool = load_module("n1tool_validation_v09", root / "tools/n1tool.py")
        bcc = load_module("bcc_validation_v09", root / "tools/bcc_reference.py")
        decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")

        source_ok = len(source) == ROM_SIZE and sha256(source) == SOURCE_SHA256
        report["checks"]["verified_source"] = pass_check(
            source_ok, size=len(source), sha256=sha256(source)
        )
        header_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == "0.9.0"
            and manifest.get("source_sha256") == SOURCE_SHA256
        )
        report["checks"]["manifest_header"] = pass_check(
            header_ok,
            sha256=sha256(manifest_bytes),
            text_entries=len(manifest.get("entries", [])),
            binary_entries=len(manifest.get("binary_entries", [])),
        )

        rebuilt, rebuild_entries = n1tool.patch_entries(
            source, manifest, encode, manifest_path.parent
        )
        rebuild_ok = rebuilt == built
        report["checks"]["canonical_rebuild"] = pass_check(
            rebuild_ok,
            built_sha256=sha256(built),
            rebuilt_sha256=sha256(rebuilt),
            byte_identical=rebuild_ok,
            report_entries=len(rebuild_entries),
        )
        applied = n1tool.apply_ips(source, ips)
        canonical_ips = n1tool.make_ips(source, rebuilt)
        ips_ok = applied == built and canonical_ips == ips
        report["checks"]["ips_round_trip"] = pass_check(
            ips_ok,
            ips_sha256=sha256(ips),
            applies_to_exact_build=applied == built,
            canonical_ips_identical=canonical_ips == ips,
        )
        stored = int.from_bytes(built[-2:], "little")
        calculated = sum(built[:-2]) & 0xFFFF
        checksum_ok = len(built) == ROM_SIZE and stored == calculated
        report["checks"]["wonderswan_checksum"] = pass_check(
            checksum_ok,
            stored=f"0x{stored:04X}",
            calculated=f"0x{calculated:04X}",
        )

        manifest_spans: list[tuple[int, int, str]] = []
        asset_results: list[dict[str, Any]] = []
        for entry in [*manifest["entries"], *manifest["binary_entries"]]:
            start = number(entry["offset"])
            end = start + number(entry["length"])
            manifest_spans.append((start, end, str(entry["id"])))
        manifest_spans.append((ROM_SIZE - 2, ROM_SIZE, "checksum"))
        allowed = bytearray(ROM_SIZE)
        for start, end, _ in manifest_spans:
            allowed[start:end] = b"\x01" * (end - start)
        outside = [
            index
            for index, (before, after) in enumerate(zip(source, built))
            if before != after and not allowed[index]
        ]
        for entry in manifest["binary_entries"]:
            start, length = number(entry["offset"]), number(entry["length"])
            asset = (manifest_path.parent / str(entry["asset"])).read_bytes()
            expected_asset_hash = str(entry.get("asset_sha256", ""))
            asset_results.append({
                "id": entry["id"],
                "length_ok": len(asset) == length,
                "hash_ok": bool(expected_asset_hash) and sha256(asset) == expected_asset_hash,
                "build_match": built[start:start + length] == asset,
            })
        assets_ok = all(
            item["length_ok"] and item["hash_ok"] and item["build_match"]
            for item in asset_results
        )
        report["checks"]["manifest_change_allowlist"] = pass_check(
            not outside,
            changed_bytes=sum(a != b for a, b in zip(source, built)),
            outside_count=len(outside),
            first_outside=[f"0x{x:06X}" for x in outside[:20]],
        )
        report["checks"]["binary_assets"] = pass_check(
            assets_ok, checked=len(asset_results), failures=[x for x in asset_results if not all((x["length_ok"], x["hash_ok"], x["build_match"]))]
        )

        source_dump = n1tool.dump_scripts(source, decode)
        built_dump = n1tool.dump_scripts(built, decode)
        source_dialogue = group_targets(source_dump, {0, 1, 2, 3, 4})
        built_dialogue = group_targets(built_dump, {0, 1, 2, 3, 4})
        source_aux = group_targets(source_dump, {5})
        built_aux = group_targets(built_dump, {5})
        dialogue_bad = [
            {"target": f"0x{target:06X}", "text": text}
            for target, text in built_dialogue.items() if contains_japanese(text)
        ]
        aux_source_jp = sum(contains_japanese(text) for text in source_aux.values())
        aux_bad = [
            {"target": f"0x{target:06X}", "text": text}
            for target, text in built_aux.items() if contains_japanese(text)
        ]
        dialogue_ok = len(source_dialogue) == 274 and len(built_dialogue) == 274 and not dialogue_bad
        aux_ok = aux_source_jp == 88 and not aux_bad
        report["inventories"]["dialogue_groups_0_4"] = {
            "translated": 274 if dialogue_ok else 274 - len(dialogue_bad),
            "denominator": 274,
            "remaining_japanese": len(dialogue_bad),
        }
        report["inventories"]["auxiliary_group_5"] = {
            "translated": 88 if aux_ok else 88 - len(aux_bad),
            "denominator": 88,
            "source_unique_targets": len(source_aux),
            "source_japanese_targets": aux_source_jp,
            "output_unique_targets": len(built_aux),
            "remaining_japanese": len(aux_bad),
        }

        prompt_words = n1tool.words_at(built, 0x3578AE, 0x3578AE + 58)
        prompt_text = "".join(n1tool.token_for(word, decode) for _, word in prompt_words)
        prompt_ok = bool(prompt_words) and prompt_words[-1][1] == 0x8000 and not contains_japanese(prompt_text)
        report["inventories"]["direct_overwrite_prompt"] = {
            "translated": 1 if prompt_ok else 0, "denominator": 1,
            "remaining_japanese": 0 if prompt_ok else 1,
        }

        static = {
            "chip_names": far_table_audit(built, bcc.CHIP_NAMES, bcc, decode),
            "effect_labels": far_table_audit(built, bcc.EFFECT_LABELS, bcc, decode),
            "descriptions": description_audit(built, bcc, decode),
            "operator_names": far_table_audit(built, bcc.OPERATOR_NAMES, bcc, decode),
        }
        static_bad = (
            static["chip_names"]["remaining_japanese"]
            + static["effect_labels"]["remaining_japanese"]
            + static["descriptions"]["remaining_japanese_rows"]
            + static["operator_names"]["remaining_japanese"]
        )
        static_ok = static_bad == 0
        report["inventories"]["static_databases"] = {
            "translated": 882 if static_ok else 882 - static_bad,
            "denominator": 882,
            "remaining_japanese": static_bad,
            "corpora": static,
        }
        attacks = far_table_audit(built, bcc.NAVI_ATTACK_NAMES, bcc, decode)
        attacks_ok = attacks["remaining_japanese"] == 0
        report["inventories"]["navi_attack_names"] = {
            "translated": 49 if attacks_ok else 49 - attacks["remaining_japanese"],
            "denominator": 49,
            **attacks,
        }
        participants = generic_far_bank_audit(
            built, "participant_names", 0x367AEA, 73, bcc, decode
        )
        participant_source = generic_far_bank_audit(
            source, "participant_names_source", 0x367AEA, 73, bcc, decode
        )
        participants_ok = (
            participant_source["remaining_japanese"] == 73
            and participants["remaining_japanese"] == 0
        )
        report["inventories"]["participant_names"] = {
            "translated": 73 if participants_ok else 73 - participants["remaining_japanese"],
            "denominator": 73,
            "source_japanese": participant_source["remaining_japanese"],
            **participants,
        }
        battle_b1 = generic_far_bank_audit(built, "battle_b1", 0x37D7F4, 187, bcc, decode)
        battle_b2 = generic_far_bank_audit(built, "battle_b2", 0x37E0CC, 92, bcc, decode)
        source_b1 = generic_far_bank_audit(source, "battle_b1_source", 0x37D7F4, 187, bcc, decode)
        source_b2 = generic_far_bank_audit(source, "battle_b2_source", 0x37E0CC, 92, bcc, decode)
        source_battle_jp = source_b1["remaining_japanese"] + source_b2["remaining_japanese"]
        output_battle_jp = battle_b1["remaining_japanese"] + battle_b2["remaining_japanese"]
        battle_ok = source_battle_jp == 185 and output_battle_jp == 0
        report["inventories"]["battle_and_result_messages"] = {
            "translated": 185 if battle_ok else 185 - output_battle_jp,
            "denominator": 185,
            "source_japanese": source_battle_jp,
            "remaining_japanese": output_battle_jp,
            "banks": {"b1": battle_b1, "b2": battle_b2},
        }

        text_translated = sum(
            report["inventories"][key]["translated"]
            for key in (
                "dialogue_groups_0_4", "auxiliary_group_5", "direct_overwrite_prompt",
                "static_databases", "navi_attack_names", "participant_names",
                "battle_and_result_messages",
            )
        )
        text_ok = text_translated == TEXT_DENOMINATOR
        report["checks"]["reachable_text_inventory"] = pass_check(
            text_ok,
            translated=text_translated,
            denominator=TEXT_DENOMINATOR,
            percent=round(text_translated / TEXT_DENOMINATOR * 100, 2),
            remaining_japanese_targets=TEXT_DENOMINATOR - text_translated,
            note="Unreferenced source bytes in bounded static pools are not counted as live strings; every actual pointer target is audited.",
        )

        asset_ok_by_id = {
            str(item["id"]): item["length_ok"] and item["hash_ok"] and item["build_match"]
            for item in asset_results
        }
        graphic_families = {
            "title_menu": (4, ["title_new_game_selected", "title_new_game_unselected", "title_continue_selected", "title_continue_unselected"]),
            "main_logo": (1, ["main_logo_tiles"]),
            "name_keyboard": (7, ["name_keyboard_bg0_map", "name_keyboard_tiles"]),
            "manual_headers": (2, ["manual_header_first_cover", "manual_header_final_cover"]),
            "pet_root": (5, ["pet_labels_bg0_map", "pet_labels_tiles"]),
            "program_deck_existing_labels": (20, ["program_deck_live_bg0_map", "program_deck_live_ui_tiles", "program_deck_manual_internal_tiles"]),
            "pet_submenus": (12, ["pet_submenu_chip_library_tiles", "pet_submenu_netnavi_tiles", "pet_submenu_save_tiles", "pet_submenu_chip_folder_bg0_map", "pet_submenu_data_library_bg0_map", "pet_submenu_netnavi_bg0_map", "pet_submenu_save_bg0_map"]),
            "normal30_occurrences": (2, ["program_deck_manual_internal_tiles"]),
            "program_deck_transfer": (1, ["program_deck_transfer_text"]),
            "tournament_header": (1, ["tournament_header_top", "tournament_header_bottom"]),
            "tournament_phase_variants": (15, ["tournament_phase_renderer", "tournament_phase_text_pool"]),
            "location_graphics": (4, ["location_shop_bg0_map", "location_shop_bg0_tiles", "location_battlechip_gp_bg0_map", "location_battlechip_gp_bg0_tiles"]),
            "lan_room_poster": (1, ["lan_room_poster_bg0_tiles"]),
        }
        graphic_results: dict[str, Any] = {}
        graphic_translated = 0
        for family, (count, requirements) in graphic_families.items():
            ok = all(asset_ok_by_id.get(item, False) for item in requirements)
            graphic_results[family] = {
                "translated": count if ok else 0,
                "denominator": count,
                "assets_match": ok,
            }
            if ok:
                graphic_translated += count
        graphics_ok = graphic_translated == GRAPHICS_DENOMINATOR
        report["inventories"]["graphical_occurrences"] = {
            "translated": graphic_translated,
            "denominator": GRAPHICS_DENOMINATOR,
            "remaining": GRAPHICS_DENOMINATOR - graphic_translated,
            "families": graphic_results,
        }
        report["checks"]["graphical_asset_inventory"] = pass_check(
            graphics_ok,
            translated=graphic_translated,
            denominator=GRAPHICS_DENOMINATOR,
            percent=round(graphic_translated / GRAPHICS_DENOMINATOR * 100, 2),
            scope="all catalogued Japanese-bearing graphical occurrences",
        )

    except BaseException as exc:
        report["errors"].append(f"{type(exc).__name__}: {exc}")

    failed = [
        name for name, check in report["checks"].items()
        if isinstance(check, dict) and check.get("result") == "FAIL"
    ]
    report["failed_checks"] = failed
    report["overall_result"] = "PASS" if not failed and not report["errors"] else "FAIL"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    print(json.dumps({
        "overall_result": report["overall_result"],
        "failed_checks": failed,
        "errors": report["errors"],
        "text": report.get("checks", {}).get("reachable_text_inventory"),
        "graphics": report.get("checks", {}).get("graphical_asset_inventory"),
        "report": str(report_path),
        "sha256": sha256(rendered.encode("utf-8")),
    }, ensure_ascii=False, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
