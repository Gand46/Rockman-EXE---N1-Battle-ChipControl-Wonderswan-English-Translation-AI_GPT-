#!/usr/bin/env python3
"""Validate the v0.10.4 PET root menu from an independent clean MesenCore boot.

The route starts with an empty Mesen home, never loads SRAM or a savestate,
passes the title with START, advances the new-game flow, and opens the PET.
At the stable PET frame it captures the native 224x144 output and the live CPU
memory.  It then checks the complete translated tile bank and ROM-backed map,
plus runtime-only visible map rows that are not present in the 32x16 ROM map.

This latter check is important: a tile that appears unused in the serialized
map may still be referenced by rows assembled by the game at runtime.  Changed
lettering tiles are therefore forbidden outside the five audited label boxes.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from dataclasses import dataclass
from pathlib import Path
from typing import Iterable

from PIL import Image


EXPECTED_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
EXPECTED_ROM_SIZE = 0x400000
EXPECTED_MAP_LENGTH = 0x0400
EXPECTED_TILES_LENGTH = 0x0980
EXPECTED_MAP_SHA256 = "926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c"
EXPECTED_TILES_SHA256 = "f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2"

CPU_WS = 12
MEM_CPU = 13
MEM_WS_WRAM = 85
MEM_WS_PORT = 90
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
TARGET_FRAME = 27000

MAP_CPU_BASE = 0x2000
TILES_CPU_BASE = 0x8020
MAP_WIDTH = 32
VISIBLE_COLUMNS = 28
VISIBLE_ROWS = 18
TILE_BYTES = 32
FIRST_TILE_ID = 1

# The five label rectangles occupy two tile rows in slots spaced three rows
# apart.  Their third row is deliberately left as the original spacer.
LABEL_RECTS = (
    ("program_deck", 2, 2, 8, 2),
    ("chip_folder", 2, 5, 7, 2),
    ("data_library", 2, 8, 8, 2),
    ("netnavi", 2, 11, 5, 2),
    ("save", 2, 14, 3, 2),
)

CLASS_TILE_IDS = tuple(range(0x3C, 0x42))
STATIC_Z_TILE_IDS = (0x2B, 0x30)
FRAME_TILE_IDS = (0x0F, 0x10, 0x31, 0x45, 0x46)
PROTECTED_TILE_IDS = (*CLASS_TILE_IDS, *STATIC_Z_TILE_IDS, *FRAME_TILE_IDS)


class TimingInfo(ctypes.Structure):
    _fields_ = [
        ("fps", ctypes.c_double),
        ("master_clock", ctypes.c_uint64),
        ("master_clock_rate", ctypes.c_uint32),
        ("frame_count", ctypes.c_uint32),
        ("scanline_count", ctypes.c_uint32),
        ("first_scanline", ctypes.c_int32),
        ("cycle_count", ctypes.c_uint32),
    ]


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


@dataclass(frozen=True)
class RuntimeCapture:
    completed_frames: int
    elapsed_seconds: float
    screenshot: Path
    cpu: bytes
    wram: bytes
    ports: bytes


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def file_sha256(path: Path) -> str:
    return sha256(path.read_bytes())


def portable_path(path: Path) -> str:
    """Return a stable public path without machine-specific workspace prefixes."""
    project_root = Path(__file__).resolve().parents[1]
    resolved = path.resolve()
    try:
        return resolved.relative_to(project_root).as_posix()
    except ValueError:
        return resolved.name


def bbox(points: Iterable[tuple[int, int]]) -> list[int] | None:
    values = list(points)
    if not values:
        return None
    xs = [point[0] for point in values]
    ys = [point[1] for point in values]
    return [min(xs), min(ys), max(xs), max(ys)]


def tile_bytes(payload: bytes, tile_id: int) -> bytes:
    start = (tile_id - FIRST_TILE_ID) * TILE_BYTES
    end = start + TILE_BYTES
    if tile_id < FIRST_TILE_ID or start < 0 or end > len(payload):
        raise ValueError(f"tile ID {tile_id:#x} is outside the PET root bank")
    return payload[start:end]


def map_word(payload: bytes, x: int, y: int) -> int:
    start = (y * MAP_WIDTH + x) * 2
    if start + 2 > len(payload):
        raise ValueError(f"map cell ({x},{y}) is outside the supplied map")
    return int.from_bytes(payload[start:start + 2], "little")


def label_cells() -> set[tuple[int, int]]:
    return {
        (x + dx, y + dy)
        for _name, x, y, width, height in LABEL_RECTS
        for dy in range(height)
        for dx in range(width)
    }


def label_pixels() -> set[tuple[int, int]]:
    return {
        (x * 8 + dx, y * 8 + dy)
        for _name, x, y, width, height in LABEL_RECTS
        for dy in range(height * 8)
        for dx in range(width * 8)
    }


def input_for_frame(frame: int) -> Controller:
    """Deterministic clean route retained from the independently proven v0.8 QA."""
    state = Controller(X=True)
    # START leaves the title screen.  No synthetic memory/state injection is used.
    state.Start = 650 <= frame < 660
    # Confirm new game/name/story prompts, then open the PET at the stable end.
    state.A = (
        950 <= frame < 958
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or 26920 <= frame < 26928
    )
    return state


def configure_core(lib: ctypes.CDLL) -> ctypes._CFuncPtr:  # type: ignore[name-defined]
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
        "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]
    return callback_type


def dump_memory(lib: ctypes.CDLL, memory_type: int) -> bytes:
    buffer = (ctypes.c_uint8 * 0x10000)()
    lib.GetMemoryValues(memory_type, 0, 0x10000, buffer)
    return bytes(buffer)


def run_clean_boot(
    rom: Path, mesen_core: Path, output_dir: Path, timeout: float
) -> RuntimeCapture:
    home = output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(mesen_core.resolve()))
    callback_type = configure_core(lib)
    completed = 0
    target_reached = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(completed + 1))
        if completed == TARGET_FRAME:
            lib.TakeScreenshot()
            target_reached.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    start_time = time.monotonic()
    try:
        if not lib.LoadRom(str(rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not target_reached.wait(timeout):
            raise TimeoutError(f"clean PET route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.2)
        cpu = dump_memory(lib, MEM_CPU)
        wram = dump_memory(lib, MEM_WS_WRAM)
        ports = dump_memory(lib, MEM_WS_PORT)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5.0
    while not list(screenshot_dir.glob("*.png")) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != 1:
        raise RuntimeError(f"expected one PET screenshot, found {len(screenshots)}")
    screenshot = output_dir / f"pet_root_runtime_{TARGET_FRAME}.png"
    shutil.copy2(screenshots[0], screenshot)
    # Mesen creates output SRAM/autosave/debugger files during shutdown.  They
    # are not inputs and are deliberately excluded from the evidence bundle.
    shutil.rmtree(home)
    return RuntimeCapture(
        completed_frames=completed,
        elapsed_seconds=time.monotonic() - start_time,
        screenshot=screenshot,
        cpu=cpu,
        wram=wram,
        ports=ports,
    )


def compare_images(
    reference_path: Path, actual_path: Path, allowed_pixels: set[tuple[int, int]]
) -> dict[str, object]:
    with Image.open(reference_path) as reference_source, Image.open(actual_path) as actual_source:
        reference = reference_source.convert("RGB")
        actual = actual_source.convert("RGB")
    if reference.size != (224, 144) or actual.size != (224, 144):
        raise ValueError(
            f"native images must be 224x144, got reference={reference.size}, actual={actual.size}"
        )

    all_differences: list[tuple[int, int]] = []
    protected_differences: list[tuple[int, int]] = []
    for y in range(144):
        for x in range(224):
            if reference.getpixel((x, y)) == actual.getpixel((x, y)):
                continue
            all_differences.append((x, y))
            if (x, y) not in allowed_pixels:
                protected_differences.append((x, y))
    return {
        "reference": portable_path(reference_path),
        "actual": portable_path(actual_path),
        "all_difference_pixels": len(all_differences),
        "all_difference_bbox_inclusive": bbox(all_differences),
        "protected_difference_pixels": len(protected_differences),
        "protected_difference_bbox_inclusive": bbox(protected_differences),
        "protected_pixels_identical": not protected_differences,
        "images_identical": not all_differences,
        "protected_difference_coordinates": [list(point) for point in protected_differences[:256]],
    }


def create_difference_image(
    reference_path: Path, actual_path: Path, allowed_pixels: set[tuple[int, int]], output: Path
) -> None:
    with Image.open(reference_path) as reference_source, Image.open(actual_path) as actual_source:
        reference = reference_source.convert("RGB")
        actual = actual_source.convert("RGB")
    rendered = actual.copy()
    for y in range(144):
        for x in range(224):
            if reference.getpixel((x, y)) == actual.getpixel((x, y)):
                continue
            rendered.putpixel((x, y), (255, 255, 0) if (x, y) in allowed_pixels else (255, 0, 0))
    rendered.save(output, format="PNG", optimize=False)


def image_crop_equal(first: Path, second: Path, box: tuple[int, int, int, int]) -> bool:
    with Image.open(first) as first_source, Image.open(second) as second_source:
        return (
            first_source.convert("RGB").crop(box).tobytes()
            == second_source.convert("RGB").crop(box).tobytes()
        )


def build_report(
    args: argparse.Namespace,
    capture: RuntimeCapture,
    rom: bytes,
    expected_map: bytes,
    expected_tiles: bytes,
    base_map: bytes,
    base_tiles: bytes,
) -> dict[str, object]:
    live_tiles = capture.cpu[TILES_CPU_BASE:TILES_CPU_BASE + len(expected_tiles)]
    live_map = capture.cpu[MAP_CPU_BASE:MAP_CPU_BASE + len(expected_map)]
    runtime_visible_map = capture.cpu[
        MAP_CPU_BASE:MAP_CPU_BASE + MAP_WIDTH * VISIBLE_ROWS * 2
    ]
    target_cells = label_cells()

    changed_tile_ids = [
        tile_id
        for tile_id in range(FIRST_TILE_ID, EXPECTED_TILES_LENGTH // TILE_BYTES + FIRST_TILE_ID)
        if tile_bytes(base_tiles, tile_id) != tile_bytes(expected_tiles, tile_id)
    ]
    changed_tile_set = set(changed_tile_ids)
    runtime_collisions = []
    for y in range(VISIBLE_ROWS):
        for x in range(VISIBLE_COLUMNS):
            word = map_word(runtime_visible_map, x, y)
            tile_id = word & 0x01FF
            if tile_id in changed_tile_set and (x, y) not in target_cells:
                runtime_collisions.append(
                    {"x": x, "y": y, "map_word": f"0x{word:04X}", "tile_id": f"0x{tile_id:02X}"}
                )

    map_changed_outside = []
    for index in range(0, len(base_map), 2):
        if base_map[index:index + 2] == expected_map[index:index + 2]:
            continue
        cell = ((index // 2) % MAP_WIDTH, (index // 2) // MAP_WIDTH)
        if cell not in target_cells:
            map_changed_outside.append(list(cell))

    protected_tiles = {}
    for tile_id in PROTECTED_TILE_IDS:
        live = tile_bytes(live_tiles, tile_id)
        base = tile_bytes(base_tiles, tile_id)
        protected_tiles[f"0x{tile_id:02X}"] = {
            "live_sha256": sha256(live),
            "base_sha256": sha256(base),
            "matches_base": live == base,
        }

    image_comparison = compare_images(
        args.expected_preview, capture.screenshot, label_pixels()
    )
    base_protection = compare_images(
        args.base_screenshot, capture.screenshot, label_pixels()
    )
    with Image.open(capture.screenshot) as screenshot_source:
        screenshot = screenshot_source.convert("RGB")
        dimensions = list(screenshot.size)
        rgb444_exact = all(
            channel % 17 == 0
            for pixel in screenshot.get_flattened_data()
            for channel in pixel
        )

    class_ids_ok = all(protected_tiles[f"0x{tile_id:02X}"]["matches_base"] for tile_id in CLASS_TILE_IDS)
    static_z_ok = all(protected_tiles[f"0x{tile_id:02X}"]["matches_base"] for tile_id in STATIC_Z_TILE_IDS)
    frame_ids_ok = all(protected_tiles[f"0x{tile_id:02X}"]["matches_base"] for tile_id in FRAME_TILE_IDS)
    runtime_bottom_frame = {
        "row_16_left_words": [
            f"0x{map_word(runtime_visible_map, x, 16):04X}" for x in range(12)
        ],
        "corner_cell": {
            "x": 11,
            "y": 16,
            "map_word": f"0x{map_word(runtime_visible_map, 11, 16):04X}",
            "expected_map_word": "0x2445",
            "matches_expected": map_word(runtime_visible_map, 11, 16) == 0x2445,
        },
    }

    checks = {
        "rom_hash": sha256(rom) == args.expected_rom_sha256,
        "asset_hashes": (
            sha256(expected_map) == EXPECTED_MAP_SHA256
            and sha256(expected_tiles) == EXPECTED_TILES_SHA256
        ),
        "live_tiles_match_asset": live_tiles == expected_tiles,
        "live_map_match_asset": live_map == expected_map,
        "serialized_map_changes_only_labels": not map_changed_outside,
        "changed_tiles_confined_at_runtime": not runtime_collisions,
        "class_tiles_preserved": class_ids_ok,
        "static_z_tiles_preserved": static_z_ok,
        "frame_tiles_preserved": frame_ids_ok,
        "cursor_pixels_preserved": image_crop_equal(
            args.base_screenshot, capture.screenshot, (0, 16, 16, 32)
        ),
        "class_values_panel_pixels_preserved": image_crop_equal(
            args.base_screenshot, capture.screenshot, (112, 8, 224, 64)
        ),
        "protected_screen_pixels_preserved": bool(base_protection["protected_pixels_identical"]),
        "runtime_matches_expected_preview": bool(image_comparison["images_identical"]),
        "native_224x144": dimensions == [224, 144],
        "rgb444_exact": rgb444_exact,
        "clean_boot": True,
        "no_sav_or_savestate": True,
    }
    failures = [name for name, passed in checks.items() if not passed]
    return {
        "validation": "pet_root_v0_10_4_clean_boot_mesen_core",
        "status": "PASS" if not failures else "FAIL",
        "failures": failures,
        "inputs": {
            "rom": {"path": portable_path(args.rom), "size": len(rom), "sha256": sha256(rom)},
            "mesen_core": {"path": portable_path(args.mesen_core), "sha256": file_sha256(args.mesen_core)},
            "tiles": {"path": portable_path(args.tiles), "length": len(expected_tiles), "sha256": sha256(expected_tiles)},
            "tilemap": {"path": portable_path(args.tilemap), "length": len(expected_map), "sha256": sha256(expected_map)},
            "base_tiles": {"path": portable_path(args.base_tiles), "sha256": sha256(base_tiles)},
            "base_map": {"path": portable_path(args.base_tilemap), "sha256": sha256(base_map)},
            "expected_preview": {"path": portable_path(args.expected_preview), "sha256": file_sha256(args.expected_preview)},
            "base_screenshot": {"path": portable_path(args.base_screenshot), "sha256": file_sha256(args.base_screenshot)},
        },
        "route": {
            "clean_mesen_home": True,
            "uses_sav": False,
            "uses_savestate": False,
            "uses_memory_injection": False,
            "start_press_frames": [650, 659],
            "target_frame": TARGET_FRAME,
            "last_callback_frame": capture.completed_frames,
            "elapsed_seconds": round(capture.elapsed_seconds, 3),
        },
        "runtime": {
            "tiles": {
                "address": f"CPU:0x{TILES_CPU_BASE:04X}",
                "length": len(expected_tiles),
                "live_sha256": sha256(live_tiles),
                "expected_sha256": sha256(expected_tiles),
                "matches_asset": live_tiles == expected_tiles,
            },
            "bg0_map_serialized": {
                "address": f"CPU:0x{MAP_CPU_BASE:04X}",
                "length": len(expected_map),
                "live_sha256": sha256(live_map),
                "expected_sha256": sha256(expected_map),
                "matches_asset": live_map == expected_map,
            },
            "bg0_visible_rows": {
                "address": f"CPU:0x{MAP_CPU_BASE:04X}",
                "dimensions_tiles": [VISIBLE_COLUMNS, VISIBLE_ROWS],
                "captured_stride_tiles": MAP_WIDTH,
                "sha256_first_18_rows": sha256(runtime_visible_map),
            },
            "changed_tile_ids": [f"0x{tile_id:02X}" for tile_id in changed_tile_ids],
            "changed_tile_references_outside_labels": runtime_collisions,
            "serialized_map_changes_outside_labels": map_changed_outside,
            "bottom_frame": runtime_bottom_frame,
            "protected_tiles": protected_tiles,
        },
        "visual": {
            "screenshot": {
                "file": capture.screenshot.name,
                "sha256": file_sha256(capture.screenshot),
                "dimensions": dimensions,
                "rgb444_exact": rgb444_exact,
            },
            "expected_preview_comparison": image_comparison,
            "base_protected_comparison": base_protection,
            "protected_crops": {
                "cursor_x0_15_y16_31_identical": checks["cursor_pixels_preserved"],
                "class_values_panel_x112_223_y8_63_identical": checks["class_values_panel_pixels_preserved"],
            },
        },
        "checks": checks,
    }


def write_markdown(report: dict[str, object], output: Path) -> None:
    status = report["status"]
    failures = report["failures"]
    runtime = report["runtime"]
    visual = report["visual"]
    collisions = runtime["changed_tile_references_outside_labels"]
    protected_diff = visual["base_protected_comparison"]["protected_difference_pixels"]
    lines = [
        "# PET root runtime validation v0.10.4",
        "",
        f"- Result: **{status}**",
        f"- ROM SHA-256: `{report['inputs']['rom']['sha256']}`",
        f"- Clean boot: yes; SAV/savestate/memory injection: no",
        f"- START: frames 650–659",
        f"- Capture: frame {report['route']['target_frame']}, 224×144",
        f"- Live tiles match asset: `{report['checks']['live_tiles_match_asset']}`",
        f"- Live BG0 map matches asset: `{report['checks']['live_map_match_asset']}`",
        f"- Changed-tile references outside labels: `{len(collisions)}`",
        f"- Protected screen-pixel differences: `{protected_diff}`",
        "",
    ]
    if failures:
        lines.extend(["## Failures", ""])
        lines.extend(f"- `{failure}`" for failure in failures)
        lines.append("")
    if collisions:
        lines.extend(["## Runtime tile collisions", ""])
        for collision in collisions:
            lines.append(
                f"- BG0 `({collision['x']},{collision['y']})` → "
                f"`{collision['map_word']}` / tile `{collision['tile_id']}`"
            )
        lines.append("")
    lines.extend([
        "## Protected elements",
        "",
        f"- CLASS tiles: `{report['checks']['class_tiles_preserved']}`",
        f"- Static Z tiles: `{report['checks']['static_z_tiles_preserved']}`",
        f"- Frame/separator tiles: `{report['checks']['frame_tiles_preserved']}`",
        f"- Cursor pixels: `{report['checks']['cursor_pixels_preserved']}`",
        f"- CLASS/rank/credits panel pixels: `{report['checks']['class_values_panel_pixels_preserved']}`",
        "",
        "Red pixels in `pet_root_runtime_vs_expected_diff.png` are changes outside "
        "the five allowed label rectangles; yellow pixels would be differences inside them.",
        "",
    ])
    output.write_text("\n".join(lines), encoding="utf-8")


def main() -> int:
    project_root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--rom", type=Path,
        default=project_root / "build/Rockman_EXE_N1_Battle_English_v0.10.4.wsc",
    )
    parser.add_argument("--mesen-core", type=Path, default=Path("/tmp/MesenCore.so"))
    parser.add_argument(
        "--tiles", type=Path,
        default=project_root / "translation/assets/pet_labels_tiles_v0_10_4.bin",
    )
    parser.add_argument(
        "--tilemap", type=Path,
        default=project_root / "translation/assets/pet_labels_bg0_map_v0_10_4.bin",
    )
    parser.add_argument(
        "--base-tiles", type=Path,
        default=project_root / "translation/assets/pet_labels_tiles_v0_8.bin",
    )
    parser.add_argument(
        "--base-tilemap", type=Path,
        default=project_root / "translation/assets/pet_labels_bg0_map_v0_8.bin",
    )
    parser.add_argument(
        "--base-screenshot", type=Path,
        default=project_root / "docs/runtime_v0_9_regressions/pet_root_clean_v0_8.png",
    )
    parser.add_argument(
        "--expected-preview", type=Path,
        default=project_root / "translation/assets/pet_root_menu_font_preview_v0_10_4.png",
    )
    parser.add_argument(
        "--output-dir", type=Path,
        default=project_root / "docs/runtime_v0_10_4/pet_root",
    )
    parser.add_argument("--expected-rom-sha256", default=EXPECTED_ROM_SHA256)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    rom = args.rom.read_bytes()
    expected_map = args.tilemap.read_bytes()
    expected_tiles = args.tiles.read_bytes()
    base_map = args.base_tilemap.read_bytes()
    base_tiles = args.base_tiles.read_bytes()
    if len(rom) != EXPECTED_ROM_SIZE:
        raise ValueError(f"ROM size {len(rom)} != {EXPECTED_ROM_SIZE}")
    if sha256(rom) != args.expected_rom_sha256:
        raise ValueError(
            f"ROM SHA-256 {sha256(rom)} != expected {args.expected_rom_sha256}"
        )
    if len(expected_map) != EXPECTED_MAP_LENGTH or len(base_map) != EXPECTED_MAP_LENGTH:
        raise ValueError("PET root maps must contain exactly 0x400 bytes")
    if len(expected_tiles) != EXPECTED_TILES_LENGTH or len(base_tiles) != EXPECTED_TILES_LENGTH:
        raise ValueError("PET root tile banks must contain exactly 0x980 bytes")

    capture = run_clean_boot(args.rom, args.mesen_core, args.output_dir, args.timeout)
    (args.output_dir / f"cpu_{TARGET_FRAME}.bin").write_bytes(capture.cpu)
    (args.output_dir / f"wram_{TARGET_FRAME}.bin").write_bytes(capture.wram)
    (args.output_dir / f"ports_{TARGET_FRAME}.bin").write_bytes(capture.ports)
    (args.output_dir / "bg0_runtime_first_18_rows.bin").write_bytes(
        capture.cpu[MAP_CPU_BASE:MAP_CPU_BASE + MAP_WIDTH * VISIBLE_ROWS * 2]
    )

    report = build_report(
        args, capture, rom, expected_map, expected_tiles, base_map, base_tiles
    )
    diff_path = args.output_dir / "pet_root_runtime_vs_expected_diff.png"
    create_difference_image(
        args.expected_preview, capture.screenshot, label_pixels(), diff_path
    )
    report["visual"]["difference_image"] = {
        "file": diff_path.name,
        "sha256": file_sha256(diff_path),
        "legend": {"red": "difference outside label rectangles", "yellow": "difference inside label rectangles"},
    }
    report_path = args.output_dir / "pet_root_runtime_validation_v0_10_4.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    write_markdown(report, args.output_dir / "PET_ROOT_RUNTIME_VALIDATION_v0_10_4.md")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0 if report["status"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
