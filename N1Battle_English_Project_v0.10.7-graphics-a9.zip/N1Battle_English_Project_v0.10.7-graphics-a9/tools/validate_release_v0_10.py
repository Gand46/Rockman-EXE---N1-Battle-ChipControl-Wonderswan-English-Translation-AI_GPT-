#!/usr/bin/env python3
"""Validate the canonical v0.10 manifest, ROM, IPS and asset evidence."""

from __future__ import annotations

import argparse
import json
from pathlib import Path
from typing import Any

import validate_release_v0_9 as v09


PROJECT_VERSION = "0.10.0"
TEXT_ENTRY_COUNT = 271
BINARY_ENTRY_COUNT = 74
TEXT_DENOMINATOR = 1552
GRAPHICS_DENOMINATOR = 129
BASE_GRAPHICS_DENOMINATOR = 75
NEW_GRAPHICS_DENOMINATOR = 54


REPORT_SPECS = (
    {
        "id": "shop_purchase",
        "path": "translation/assets/shop_purchase_asset_report_v0_10.json",
        "format": "n1-shop-purchase-assets-v0.10",
        "occurrences": 3,
    },
    {
        "id": "pet_carousel",
        "path": "translation/assets/pet_carousel_remaining_asset_report_v0_10.json",
        "format": "n1-pet-carousel-remaining-assets-v0.10",
        "occurrences": 2,
    },
    {
        "id": "host_free",
        "path": "translation/assets/host_free_menu_asset_report_v0_10.json",
        "format": "n1-host-free-menu-assets-v0.10",
        "occurrences": 31,
    },
    {
        "id": "pet_runtime",
        "path": "translation/assets/pet_runtime_remaining_asset_report_v0_10.json",
        "format": "n1-pet-runtime-remaining-assets-v0.10",
        "occurrences": 18,
    },
)


def display_path(path: Path, root: Path) -> str:
    """Keep public reports reproducible without embedding a workspace path."""
    try:
        return path.relative_to(root).as_posix()
    except ValueError:
        return path.name


def parse_manifest_spans(
    source: bytes, manifest: dict[str, Any]
) -> tuple[list[tuple[int, int, str, str]], list[dict[str, Any]], list[str]]:
    spans: list[tuple[int, int, str, str]] = []
    guards: list[dict[str, Any]] = []
    ids: list[str] = []
    for kind, rows in (
        ("text", manifest.get("entries", [])),
        ("binary", manifest.get("binary_entries", [])),
    ):
        if not isinstance(rows, list):
            raise ValueError(f"manifest {kind} entries are not a list")
        for index, entry in enumerate(rows):
            if not isinstance(entry, dict):
                raise ValueError(f"manifest {kind} entry {index} is not an object")
            entry_id = str(entry.get("id", f"{kind}_{index}"))
            offset = v09.number(entry["offset"])
            length = v09.number(entry["length"])
            end = offset + length
            ids.append(entry_id)
            spans.append((offset, end, entry_id, kind))
            in_bounds = length > 0 and 0 <= offset < end <= len(source) - 2
            expected_hex = str(entry.get("expected_hex", "")).replace(" ", "")
            expected_hash = str(entry.get("expected_sha256", "")).lower()
            guard_kind = "missing"
            guard_ok = False
            actual_hash = ""
            error = ""
            if in_bounds:
                payload = source[offset:end]
                actual_hash = v09.sha256(payload)
                try:
                    if expected_hex:
                        guard_kind = "expected_hex"
                        expected = bytes.fromhex(expected_hex)
                        guard_ok = len(expected) == length and payload == expected
                    elif expected_hash:
                        guard_kind = "expected_sha256"
                        guard_ok = actual_hash == expected_hash
                    else:
                        error = "missing source guard"
                except ValueError as exc:
                    error = f"invalid expected_hex: {exc}"
            else:
                error = "span outside ROM or non-positive"
            guards.append(
                {
                    "id": entry_id,
                    "kind": kind,
                    "offset": f"0x{offset:06X}",
                    "length": length,
                    "guard": guard_kind,
                    "guard_ok": guard_ok,
                    "actual_sha256": actual_hash,
                    "error": error,
                }
            )
    duplicates = sorted({entry_id for entry_id in ids if ids.count(entry_id) > 1})
    return spans, guards, duplicates


def span_overlaps(
    spans: list[tuple[int, int, str, str]]
) -> list[dict[str, Any]]:
    overlaps: list[dict[str, Any]] = []
    for index, (start, end, entry_id, kind) in enumerate(spans):
        for other_start, other_end, other_id, other_kind in spans[index + 1 :]:
            overlap_start = max(start, other_start)
            overlap_end = min(end, other_end)
            if overlap_start < overlap_end:
                overlaps.append(
                    {
                        "first": entry_id,
                        "first_kind": kind,
                        "second": other_id,
                        "second_kind": other_kind,
                        "start": f"0x{overlap_start:06X}",
                        "end": f"0x{overlap_end:06X}",
                        "length": overlap_end - overlap_start,
                    }
                )
    return overlaps


def guarded_source_regions(value: Any, trail: str = "$") -> list[dict[str, Any]]:
    results: list[dict[str, Any]] = []
    if isinstance(value, dict):
        hash_key = "source_sha256" if "source_sha256" in value else "sha256"
        if "offset" in value and "length" in value and hash_key in value:
            results.append(
                {
                    "trail": trail,
                    "offset": value["offset"],
                    "length": value["length"],
                    "sha256": value[hash_key],
                }
            )
        for key, child in value.items():
            results.extend(guarded_source_regions(child, f"{trail}.{key}"))
    elif isinstance(value, list):
        for index, child in enumerate(value):
            results.extend(guarded_source_regions(child, f"{trail}[{index}]"))
    return results


def values_for_key(value: Any, wanted: str) -> list[Any]:
    results: list[Any] = []
    if isinstance(value, dict):
        for key, child in value.items():
            if key == wanted:
                results.append(child)
            results.extend(values_for_key(child, wanted))
    elif isinstance(value, list):
        for child in value:
            results.extend(values_for_key(child, wanted))
    return results


def report_occurrences(report_id: str, payload: dict[str, Any]) -> int:
    if report_id == "shop_purchase":
        labels = payload.get("labels", [])
        return len(labels) if isinstance(labels, list) else -1
    if report_id == "pet_carousel":
        screens = payload.get("screens", [])
        return len(screens) if isinstance(screens, list) else -1
    if report_id == "host_free":
        return int(payload.get("new_graphical_occurrences", -1))
    if report_id == "pet_runtime":
        return int(payload.get("graphical_occurrences", -1))
    raise ValueError(f"unknown report id {report_id}")


def report_specific_ok(report_id: str, payload: dict[str, Any]) -> tuple[bool, dict[str, Any]]:
    details: dict[str, Any] = {}
    if report_id == "shop_purchase":
        details = {
            "price_cells_byte_identical": payload.get("price_cells_byte_identical"),
            "protected_price_count": len(payload.get("protected_prices", [])),
            "outside_allowlist": payload.get("changes", {}).get("outside_allowlist"),
        }
        ok = (
            details["price_cells_byte_identical"] is True
            and details["protected_price_count"] == 3
            and details["outside_allowlist"] == 0
        )
    elif report_id == "pet_carousel":
        screens = payload.get("screens", [])
        outside = [row.get("changes", {}).get("outside_allowlist") for row in screens]
        details = {"screen_count": len(screens), "outside_allowlist": outside}
        ok = len(screens) == 2 and all(value == 0 for value in outside)
    elif report_id == "host_free":
        screens = payload.get("screens", [])
        statuses = [row.get("status") for row in screens]
        outside = [row.get("changes", {}).get("outside_allowlist") for row in screens]
        occurrences = sum(int(row.get("graphical_occurrences", 0)) for row in screens)
        details = {
            "screen_count": len(screens),
            "screen_occurrences": occurrences,
            "screen_statuses": statuses,
            "outside_allowlist": outside,
        }
        ok = (
            len(screens) == 10
            and occurrences == 31
            and all(value == "PASS" for value in statuses)
            and all(value == 0 for value in outside)
        )
    elif report_id == "pet_runtime":
        labels = payload.get("labels", [])
        alias_values = values_for_key(payload.get("alias_checks", {}), "outside_targets")
        bank_values = values_for_key(payload.get("tile_banks", {}), "outside_allowlist")
        details = {
            "label_count": len(labels),
            "maps_changed": payload.get("maps_changed"),
            "alias_outside_targets": alias_values,
            "bank_outside_allowlist": bank_values,
        }
        ok = (
            len(labels) == 12
            and payload.get("maps_changed") == 0
            and alias_values
            and all(value == 0 for value in alias_values)
            and bank_values
            and all(value == 0 for value in bank_values)
        )
    else:
        raise ValueError(f"unknown report id {report_id}")
    return ok, details


def validate_asset_reports(root: Path, source: bytes) -> tuple[bool, dict[str, Any]]:
    reports: dict[str, Any] = {}
    all_ok = True
    total_occurrences = 0
    for spec in REPORT_SPECS:
        report_path = (root / str(spec["path"])).resolve()
        payload = json.loads(report_path.read_text(encoding="utf-8"))
        occurrences = report_occurrences(str(spec["id"]), payload)
        total_occurrences += max(occurrences, 0)

        guard_results: list[dict[str, Any]] = []
        for guard in guarded_source_regions(payload):
            offset = v09.number(guard["offset"])
            length = v09.number(guard["length"])
            expected = str(guard["sha256"]).lower()
            in_bounds = length > 0 and 0 <= offset < offset + length <= len(source)
            actual = v09.sha256(source[offset : offset + length]) if in_bounds else ""
            guard_results.append(
                {
                    **guard,
                    "offset": f"0x{offset:06X}",
                    "length": length,
                    "actual_sha256": actual,
                    "match": in_bounds and actual == expected,
                }
            )

        output_results: list[dict[str, Any]] = []
        outputs = payload.get("outputs", {})
        if not isinstance(outputs, dict):
            outputs = {}
        for filename, expected in outputs.items():
            output_path = (report_path.parent / str(filename)).resolve()
            safe = True
            try:
                output_path.relative_to(report_path.parent.resolve())
            except ValueError:
                safe = False
            exists = safe and output_path.is_file()
            actual = v09.sha256(output_path.read_bytes()) if exists else ""
            output_results.append(
                {
                    "file": str(filename),
                    "safe_path": safe,
                    "exists": exists,
                    "expected_sha256": str(expected),
                    "actual_sha256": actual,
                    "match": exists and actual == str(expected).lower(),
                }
            )

        specific_ok, specific_details = report_specific_ok(str(spec["id"]), payload)
        report_ok = (
            payload.get("format") == spec["format"]
            and payload.get("status") == "PASS"
            and payload.get("native_display") == [224, 144]
            and payload.get("source_rom_sha256", payload.get("source", {}).get("rom_sha256"))
            == v09.SOURCE_SHA256
            and occurrences == spec["occurrences"]
            and bool(guard_results)
            and all(row["match"] for row in guard_results)
            and bool(output_results)
            and all(row["match"] for row in output_results)
            and specific_ok
        )
        reports[str(spec["id"])] = {
            "result": "PASS" if report_ok else "FAIL",
            "path": display_path(report_path, root),
            "format": payload.get("format"),
            "status": payload.get("status"),
            "occurrences": occurrences,
            "expected_occurrences": spec["occurrences"],
            "source_guards_checked": len(guard_results),
            "source_guard_failures": [row for row in guard_results if not row["match"]],
            "outputs_checked": len(output_results),
            "output_failures": [row for row in output_results if not row["match"]],
            "specific": specific_details,
        }
        all_ok = all_ok and report_ok
    all_ok = all_ok and total_occurrences == NEW_GRAPHICS_DENOMINATOR
    return all_ok, {
        "new_graphical_occurrences": total_occurrences,
        "expected_new_graphical_occurrences": NEW_GRAPHICS_DENOMINATOR,
        "reports": reports,
    }


def audit_text(
    source: bytes,
    built: bytes,
    n1tool: Any,
    bcc: Any,
    decode: dict[int, str],
) -> tuple[dict[str, Any], dict[str, Any]]:
    inventories: dict[str, Any] = {}
    source_dump = n1tool.dump_scripts(source, decode)
    built_dump = n1tool.dump_scripts(built, decode)
    source_dialogue = v09.group_targets(source_dump, {0, 1, 2, 3, 4})
    built_dialogue = v09.group_targets(built_dump, {0, 1, 2, 3, 4})
    source_aux = v09.group_targets(source_dump, {5})
    built_aux = v09.group_targets(built_dump, {5})
    dialogue_bad = [
        {"target": f"0x{target:06X}", "text": text}
        for target, text in built_dialogue.items()
        if v09.contains_japanese(text)
    ]
    aux_source_jp = sum(v09.contains_japanese(text) for text in source_aux.values())
    aux_bad = [
        {"target": f"0x{target:06X}", "text": text}
        for target, text in built_aux.items()
        if v09.contains_japanese(text)
    ]
    dialogue_ok = len(source_dialogue) == 274 and len(built_dialogue) == 274 and not dialogue_bad
    aux_ok = aux_source_jp == 88 and not aux_bad
    inventories["dialogue_groups_0_4"] = {
        "translated": 274 if dialogue_ok else 274 - len(dialogue_bad),
        "denominator": 274,
        "remaining_japanese": len(dialogue_bad),
    }
    inventories["auxiliary_group_5"] = {
        "translated": 88 if aux_ok else 88 - len(aux_bad),
        "denominator": 88,
        "source_unique_targets": len(source_aux),
        "source_japanese_targets": aux_source_jp,
        "output_unique_targets": len(built_aux),
        "remaining_japanese": len(aux_bad),
    }

    prompt_words = n1tool.words_at(built, 0x3578AE, 0x3578AE + 58)
    prompt_text = "".join(n1tool.token_for(word, decode) for _, word in prompt_words)
    prompt_ok = bool(prompt_words) and prompt_words[-1][1] == 0x8000 and not v09.contains_japanese(prompt_text)
    inventories["direct_overwrite_prompt"] = {
        "translated": 1 if prompt_ok else 0,
        "denominator": 1,
        "remaining_japanese": 0 if prompt_ok else 1,
    }

    static = {
        "chip_names": v09.far_table_audit(built, bcc.CHIP_NAMES, bcc, decode),
        "effect_labels": v09.far_table_audit(built, bcc.EFFECT_LABELS, bcc, decode),
        "descriptions": v09.description_audit(built, bcc, decode),
        "operator_names": v09.far_table_audit(built, bcc.OPERATOR_NAMES, bcc, decode),
    }
    static_bad = (
        static["chip_names"]["remaining_japanese"]
        + static["effect_labels"]["remaining_japanese"]
        + static["descriptions"]["remaining_japanese_rows"]
        + static["operator_names"]["remaining_japanese"]
    )
    inventories["static_databases"] = {
        "translated": 882 if static_bad == 0 else 882 - static_bad,
        "denominator": 882,
        "remaining_japanese": static_bad,
        "corpora": static,
    }

    attacks = v09.far_table_audit(built, bcc.NAVI_ATTACK_NAMES, bcc, decode)
    inventories["navi_attack_names"] = {
        "translated": 49 if attacks["remaining_japanese"] == 0 else 49 - attacks["remaining_japanese"],
        "denominator": 49,
        **attacks,
    }
    participants = v09.generic_far_bank_audit(
        built, "participant_names", 0x367AEA, 73, bcc, decode
    )
    participant_source = v09.generic_far_bank_audit(
        source, "participant_names_source", 0x367AEA, 73, bcc, decode
    )
    participants_ok = participant_source["remaining_japanese"] == 73 and participants["remaining_japanese"] == 0
    inventories["participant_names"] = {
        "translated": 73 if participants_ok else 73 - participants["remaining_japanese"],
        "denominator": 73,
        "source_japanese": participant_source["remaining_japanese"],
        **participants,
    }

    battle_b1 = v09.generic_far_bank_audit(built, "battle_b1", 0x37D7F4, 187, bcc, decode)
    battle_b2 = v09.generic_far_bank_audit(built, "battle_b2", 0x37E0CC, 92, bcc, decode)
    source_b1 = v09.generic_far_bank_audit(source, "battle_b1_source", 0x37D7F4, 187, bcc, decode)
    source_b2 = v09.generic_far_bank_audit(source, "battle_b2_source", 0x37E0CC, 92, bcc, decode)
    source_battle_jp = source_b1["remaining_japanese"] + source_b2["remaining_japanese"]
    output_battle_jp = battle_b1["remaining_japanese"] + battle_b2["remaining_japanese"]
    battle_ok = source_battle_jp == 185 and output_battle_jp == 0
    inventories["battle_and_result_messages"] = {
        "translated": 185 if battle_ok else 185 - output_battle_jp,
        "denominator": 185,
        "source_japanese": source_battle_jp,
        "remaining_japanese": output_battle_jp,
        "banks": {"b1": battle_b1, "b2": battle_b2},
    }

    keys = (
        "dialogue_groups_0_4",
        "auxiliary_group_5",
        "direct_overwrite_prompt",
        "static_databases",
        "navi_attack_names",
        "participant_names",
        "battle_and_result_messages",
    )
    translated = sum(inventories[key]["translated"] for key in keys)
    return inventories, v09.pass_check(
        translated == TEXT_DENOMINATOR,
        translated=translated,
        denominator=TEXT_DENOMINATOR,
        percent=round(translated / TEXT_DENOMINATOR * 100, 2),
        remaining_japanese_targets=TEXT_DENOMINATOR - translated,
        note="Every reachable pointer target is audited; unreferenced bytes in bounded pools are excluded.",
    )


def graphics_inventory(asset_ok_by_id: dict[str, bool]) -> tuple[dict[str, Any], dict[str, Any]]:
    families = {
        "title_menu": (4, ["title_new_game_selected", "title_new_game_unselected", "title_continue_selected", "title_continue_unselected"]),
        "main_logo": (1, ["main_logo_tiles"]),
        "name_keyboard": (7, ["name_keyboard_bg0_map", "name_keyboard_tiles"]),
        "manual_headers": (2, ["manual_header_first_cover", "manual_header_final_cover"]),
        "pet_root": (5, ["pet_labels_bg0_map", "pet_labels_tiles"]),
        "program_deck_existing_labels": (20, ["program_deck_live_bg0_map", "program_deck_live_ui_tiles", "program_deck_manual_internal_tiles"]),
        "pet_submenus": (12, ["pet_submenu_chip_library_tiles", "pet_submenu_netnavi_tiles", "pet_submenu_save_tiles", "pet_submenu_chip_folder_bg0_map", "pet_submenu_data_library_bg0_map", "pet_submenu_netnavi_bg0_map", "pet_submenu_save_bg0_map"]),
        "normal30_occurrences": (2, ["program_deck_manual_internal_tiles"]),
        "program_deck_transfer": (1, ["program_deck_transfer_text"]),
        "tournament_header": (1, ["tournament_header_top", "tournament_header_bottom"]),
        "tournament_phase_variants": (15, ["tournament_phase_renderer", "tournament_phase_text_pool"]),
        "location_graphics": (4, ["location_shop_bg0_map", "location_shop_bg0_tiles", "location_battlechip_gp_bg0_map", "location_battlechip_gp_bg0_tiles"]),
        "lan_room_poster": (1, ["lan_room_poster_bg0_tiles"]),
        "shop_purchase": (3, ["shop_purchase_bg0_map", "shop_purchase_bg0_tiles"]),
        "pet_carousel_remaining": (2, ["pet_carousel_free_battle_bg0_map", "pet_carousel_free_battle_bg0_tiles", "pet_carousel_host_tournament_bg0_map", "pet_carousel_host_tournament_bg0_tiles"]),
        "host_free_remaining": (31, ["host_navicode_register_bg0_map", "host_entrant_count_bg0_map", "host_entry_select_bg0_map", "host_entry_delete_bg0_map", "host_setup_bg0_tiles", "host_roster_actions_bg0_tiles", "host_navicode_register_bg0_tiles", "host_brackets_bg0_tiles", "host_entrant_count_bg0_tiles", "host_entry_select_bg0_tiles", "host_result_dialog_bg0_tiles", "host_result_table_bg0_tiles", "host_entry_delete_bg0_tiles", "free_win_streak_bg0_tiles"]),
        "pet_runtime_remaining": (18, ["program_deck_live_ui_tiles", "pet_submenu_chip_library_tiles", "pet_submenu_netnavi_tiles", "pet_no_data_card_tiles"]),
    }
    family_results: dict[str, Any] = {}
    translated = 0
    for family, (count, requirements) in families.items():
        missing = [entry_id for entry_id in requirements if not asset_ok_by_id.get(entry_id, False)]
        ok = not missing
        family_results[family] = {
            "translated": count if ok else 0,
            "denominator": count,
            "assets_match": ok,
            "missing_or_invalid_assets": missing,
        }
        if ok:
            translated += count
    inventory = {
        "translated": translated,
        "denominator": GRAPHICS_DENOMINATOR,
        "remaining": GRAPHICS_DENOMINATOR - translated,
        "baseline_denominator": BASE_GRAPHICS_DENOMINATOR,
        "new_denominator": NEW_GRAPHICS_DENOMINATOR,
        "families": family_results,
    }
    check = v09.pass_check(
        translated == GRAPHICS_DENOMINATOR,
        translated=translated,
        denominator=GRAPHICS_DENOMINATOR,
        percent=round(translated / GRAPHICS_DENOMINATOR * 100, 2),
        scope="all catalogued Japanese-bearing graphical occurrences through v0.10",
    )
    return inventory, check


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, required=True)
    parser.add_argument("--source-rom", type=Path, required=True)
    parser.add_argument("--manifest", type=Path)
    parser.add_argument("--built-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    manifest_path = (args.manifest or root / "translation/en_v0_10.json").resolve()
    built_path = (args.built_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.wsc").resolve()
    ips_path = (args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.ips").resolve()
    report_path = (args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10.json").resolve()

    report: dict[str, Any] = {
        "format": "n1battle-deep-release-validation-v1",
        "project_version": PROJECT_VERSION,
        "report_date": "2026-08-22",
        "overall_result": "FAIL",
        "inputs": {
            "manifest": display_path(manifest_path, root),
            "built_rom": display_path(built_path, root),
            "ips": display_path(ips_path, root),
        },
        "checks": {},
        "inventories": {},
        "errors": [],
    }
    try:
        source = args.source_rom.read_bytes()
        built = built_path.read_bytes()
        ips = ips_path.read_bytes()
        manifest_bytes = manifest_path.read_bytes()
        manifest = json.loads(manifest_bytes.decode("utf-8"))
        n1tool = v09.load_module("n1tool_validation_v010", root / "tools/n1tool.py")
        bcc = v09.load_module("bcc_validation_v010", root / "tools/bcc_reference.py")
        decode, encode = n1tool.load_table(root / "tables/n1battle_jp.tbl")

        source_ok = len(source) == v09.ROM_SIZE and v09.sha256(source) == v09.SOURCE_SHA256
        report["checks"]["verified_source"] = v09.pass_check(
            source_ok, size=len(source), sha256=v09.sha256(source)
        )

        entries = manifest.get("entries", [])
        binary_entries = manifest.get("binary_entries", [])
        expanded = manifest.get("expanded_inventory", {})
        manifest_header_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == PROJECT_VERSION
            and manifest.get("source_sha256") == v09.SOURCE_SHA256
        )
        report["checks"]["manifest_header"] = v09.pass_check(
            manifest_header_ok,
            sha256=v09.sha256(manifest_bytes),
            format=manifest.get("format"),
            project_version=manifest.get("project_version"),
        )
        expanded_ok = (
            expanded.get("text_units") == {"translated": 1552, "denominator": 1552}
            and expanded.get("newly_recovered_text_units") == 347
            and expanded.get("graphical_occurrences") == {"translated": 129, "denominator": 129}
            and expanded.get("known_residual_japanese_targets") == 0
        )
        inventory_ok = (
            isinstance(entries, list)
            and len(entries) == TEXT_ENTRY_COUNT
            and isinstance(binary_entries, list)
            and len(binary_entries) == BINARY_ENTRY_COUNT
            and expanded_ok
        )
        report["checks"]["manifest_inventory"] = v09.pass_check(
            inventory_ok,
            text_entries=len(entries) if isinstance(entries, list) else None,
            expected_text_entries=TEXT_ENTRY_COUNT,
            binary_entries=len(binary_entries) if isinstance(binary_entries, list) else None,
            expected_binary_entries=BINARY_ENTRY_COUNT,
            expanded_inventory=expanded,
        )

        spans, guards, duplicate_ids = parse_manifest_spans(source, manifest)
        overlaps = span_overlaps(spans)
        invalid_spans = [row for row in guards if row["error"] == "span outside ROM or non-positive"]
        layout_ok = not overlaps and not duplicate_ids and not invalid_spans
        report["checks"]["manifest_span_layout"] = v09.pass_check(
            layout_ok,
            spans=len(spans),
            overlaps=len(overlaps),
            overlap_examples=overlaps[:20],
            duplicate_ids=duplicate_ids,
            invalid_spans=invalid_spans,
        )
        guard_failures = [row for row in guards if not row["guard_ok"]]
        report["checks"]["manifest_source_guards"] = v09.pass_check(
            not guard_failures and len(guards) == TEXT_ENTRY_COUNT + BINARY_ENTRY_COUNT,
            checked=len(guards),
            expected=TEXT_ENTRY_COUNT + BINARY_ENTRY_COUNT,
            failures=guard_failures[:20],
        )

        rebuilt, rebuild_entries = n1tool.patch_entries(source, manifest, encode, manifest_path.parent)
        rebuild_ok = rebuilt == built and len(built) == v09.ROM_SIZE
        report["checks"]["canonical_rebuild"] = v09.pass_check(
            rebuild_ok,
            built_sha256=v09.sha256(built),
            rebuilt_sha256=v09.sha256(rebuilt),
            byte_identical=rebuilt == built,
            report_entries=len(rebuild_entries),
        )
        applied = n1tool.apply_ips(source, ips)
        canonical_ips = n1tool.make_ips(source, rebuilt)
        ips_ok = applied == built and canonical_ips == ips
        report["checks"]["ips_round_trip"] = v09.pass_check(
            ips_ok,
            ips_sha256=v09.sha256(ips),
            applies_to_exact_build=applied == built,
            canonical_ips_identical=canonical_ips == ips,
        )
        stored = int.from_bytes(built[-2:], "little")
        calculated = sum(built[:-2]) & 0xFFFF
        checksum_ok = len(built) == v09.ROM_SIZE and stored == calculated
        report["checks"]["wonderswan_checksum"] = v09.pass_check(
            checksum_ok,
            size=len(built),
            stored=f"0x{stored:04X}",
            calculated=f"0x{calculated:04X}",
        )

        allowed = bytearray(v09.ROM_SIZE)
        for start, end, _, _ in spans:
            if 0 <= start < end <= v09.ROM_SIZE:
                allowed[start:end] = b"\x01" * (end - start)
        allowed[v09.ROM_SIZE - 2 : v09.ROM_SIZE] = b"\x01\x01"
        outside = [
            index
            for index, (before, after) in enumerate(zip(source, built))
            if before != after and not allowed[index]
        ]
        report["checks"]["manifest_change_allowlist"] = v09.pass_check(
            not outside,
            changed_bytes=sum(before != after for before, after in zip(source, built)),
            outside_count=len(outside),
            first_outside=[f"0x{offset:06X}" for offset in outside[:20]],
        )

        asset_results: list[dict[str, Any]] = []
        for entry in binary_entries:
            start = v09.number(entry["offset"])
            length = v09.number(entry["length"])
            asset_path = (manifest_path.parent / str(entry["asset"])).resolve()
            safe = True
            try:
                asset_path.relative_to(manifest_path.parent.resolve())
            except ValueError:
                safe = False
            asset = asset_path.read_bytes() if safe and asset_path.is_file() else b""
            expected_hash = str(entry.get("asset_sha256", "")).lower()
            asset_results.append(
                {
                    "id": entry["id"],
                    "safe_path": safe,
                    "length_ok": len(asset) == length,
                    "hash_ok": bool(expected_hash) and v09.sha256(asset) == expected_hash,
                    "build_match": built[start : start + length] == asset,
                }
            )
        asset_failures = [
            row
            for row in asset_results
            if not all((row["safe_path"], row["length_ok"], row["hash_ok"], row["build_match"]))
        ]
        report["checks"]["binary_assets"] = v09.pass_check(
            not asset_failures and len(asset_results) == BINARY_ENTRY_COUNT,
            checked=len(asset_results),
            expected=BINARY_ENTRY_COUNT,
            failures=asset_failures,
        )

        reports_ok, reports_detail = validate_asset_reports(root, source)
        report["checks"]["v0_10_asset_reports"] = v09.pass_check(reports_ok, **reports_detail)

        text_inventories, text_check = audit_text(source, built, n1tool, bcc, decode)
        report["inventories"].update(text_inventories)
        report["checks"]["reachable_text_inventory"] = text_check

        asset_ok_by_id = {
            str(row["id"]): all((row["safe_path"], row["length_ok"], row["hash_ok"], row["build_match"]))
            for row in asset_results
        }
        graphic_inventory, graphic_check = graphics_inventory(asset_ok_by_id)
        report["inventories"]["graphical_occurrences"] = graphic_inventory
        report["checks"]["graphical_asset_inventory"] = graphic_check

    except BaseException as exc:
        report["errors"].append(f"{type(exc).__name__}: {exc}")

    failed = [
        name
        for name, check in report["checks"].items()
        if isinstance(check, dict) and check.get("result") == "FAIL"
    ]
    report["failed_checks"] = failed
    report["overall_result"] = "PASS" if not failed and not report["errors"] else "FAIL"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    print(
        json.dumps(
            {
                "overall_result": report["overall_result"],
                "failed_checks": failed,
                "errors": report["errors"],
                "manifest_inventory": report.get("checks", {}).get("manifest_inventory"),
                "text": report.get("checks", {}).get("reachable_text_inventory"),
                "graphics": report.get("checks", {}).get("graphical_asset_inventory"),
                "asset_reports": report.get("checks", {}).get("v0_10_asset_reports"),
                "report": str(report_path),
                "sha256": v09.sha256(rendered.encode("utf-8")),
            },
            ensure_ascii=False,
            indent=2,
        )
    )
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
