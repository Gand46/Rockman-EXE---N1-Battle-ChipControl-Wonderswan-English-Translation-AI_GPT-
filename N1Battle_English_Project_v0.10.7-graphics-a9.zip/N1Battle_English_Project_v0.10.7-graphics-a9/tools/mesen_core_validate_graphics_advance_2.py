#!/usr/bin/env python3
"""Validate the cumulative Graphics Advance 2 checkpoint on the Advance 3 ROM."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import mesen_core_validate_program_deck_v0_10_3 as route  # noqa: E402
import graphics_advance_2_font as font_asset  # noqa: E402


A1_ROM_SHA256 = "63ce8069d89106fdc96167a14d139641db202d23e0a2cd539347e19f8fcd8575"
A2_ROM_SHA256 = "2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c"
CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
FRAMES = (15800, 16100, 16400, 16700, 17000)
OVERVIEW_MAP_OFFSET = 0x04E7A2
OVERVIEW_MAP_LENGTH = 0x0400
MANUAL_TILES_OFFSET = 0x0ACA20
MANUAL_TILES_LENGTH = 0x5B60
OVERVIEW_TILES_LENGTH = 0x1140
TARGET_ASSET_IDS = (
    0x00F, 0x010, 0x011, 0x012, 0x013, 0x014, 0x015,
    0x021, 0x022, 0x023, 0x024, 0x025, 0x026, 0x027, 0x028,
    0x054, 0x055, 0x056, 0x057, 0x058, 0x059, 0x05A, 0x05B,
    0x05C, 0x05D, 0x05E, 0x069, 0x06A, 0x06B, 0x06C, 0x06D, 0x06E,
)
TARGET_RECTS = {
    "PROGRAM DECK": (8, 8, 56, 24),
    "NAVICHIP": (8, 56, 48, 72),
    "BATTLECHIP": (176, 48, 216, 64),
}
RESTORED_SPILL_RECT = (176, 64, 216, 72)
TARGET_MAP_CELLS = {
    (x, y)
    for left, top, right, bottom in TARGET_RECTS.values()
    for y in range(top // 8, bottom // 8)
    for x in range(left // 8, right // 8)
}
EXPECTED_CHANGED_PIXELS = 832
EXPECTED_CHANGED_BBOX = (8, 8, 215, 71)
EXPECTED_ROOT_SCREENSHOT_SHA256 = "5cef0f15af583e1b8d83d96d573054320cf5cf3c3887b5ae8dd32e9855ba3dba"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def inside_allowed(x: int, y: int) -> bool:
    return any(left <= x < right and top <= y < bottom
               for left, top, right, bottom in TARGET_RECTS.values())


def expected_mask(label: font_asset.Label) -> tuple[list[bool], int]:
    patterns, _ = font_asset.render_label(label)
    width, height = label.columns * 8, label.rows * 8
    mask = [False] * (width * height)
    for tile_index, payload in enumerate(patterns):
        cell_x = tile_index % label.columns
        cell_y = tile_index // label.columns
        pixels = font_asset.unpack_tile(payload)
        for y in range(8):
            for x in range(8):
                mask[(cell_y * 8 + y) * width + cell_x * 8 + x] = (
                    pixels[y * 8 + x] != font_asset.BACKGROUND
                )
    return mask, connected_components(mask, width, height)


def connected_components(mask: list[bool], width: int, height: int) -> int:
    unseen = {index for index, value in enumerate(mask) if value}
    components = 0
    while unseen:
        components += 1
        stack = [unseen.pop()]
        while stack:
            index = stack.pop()
            x, y = index % width, index // width
            for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                neighbour = ny * width + nx
                if 0 <= nx < width and 0 <= ny < height and neighbour in unseen:
                    unseen.remove(neighbour)
                    stack.append(neighbour)
    return components


def audit_label_mask(image: Image.Image, label: font_asset.Label) -> dict[str, object]:
    rect = (label.x * 8, label.y * 8,
            (label.x + label.columns) * 8, (label.y + label.rows) * 8)
    crop = image.crop(rect)
    width, height = crop.size
    expected, expected_components = expected_mask(label)
    background = crop.getpixel((0, 0))
    actual = [pixel != background for pixel in crop.getdata()]
    actual_components = connected_components(actual, width, height)
    mismatches = sum(left != right for left, right in zip(expected, actual, strict=True))
    palette = sorted(set(crop.getdata()))
    if mismatches:
        raise AssertionError(f"{label.text}: {mismatches} internal mask pixels differ")
    if actual_components != expected_components:
        raise AssertionError(
            f"{label.text}: {actual_components} components, expected {expected_components}"
        )
    if len(palette) != 2:
        raise AssertionError(f"{label.text}: expected exactly background and face colours")
    return {
        "rectangle": list(rect),
        "internal_foreground_mask_exact": True,
        "foreground_components": actual_components,
        "expected_foreground_components": expected_components,
        "palette_rgb": [list(colour) for colour in palette],
        "palette_colour_count": len(palette),
    }


def montage(before_path: Path, after_path: Path, output: Path) -> None:
    scale = 5
    labels = list(TARGET_RECTS.items())
    width = max(rect[2] - rect[0] for _, rect in labels) * scale
    label_height = max(rect[3] - rect[1] for _, rect in labels)
    row_height = label_height * scale + 22
    canvas = Image.new("RGB", (width * 2 + 16, row_height * len(labels) + 26), (24, 24, 24))
    draw = ImageDraw.Draw(canvas)
    draw.text((0, 5), "Advance 1", fill=(255, 255, 255))
    draw.text((width + 16, 5), "Advance 2", fill=(255, 255, 255))
    with Image.open(before_path) as source:
        before = source.convert("RGB")
    with Image.open(after_path) as source:
        after = source.convert("RGB")
    for index, (name, rect) in enumerate(labels):
        y = 26 + index * row_height
        crop_size = ((rect[2] - rect[0]) * scale, (rect[3] - rect[1]) * scale)
        left = before.crop(rect).resize(crop_size, Image.Resampling.NEAREST)
        right = after.crop(rect).resize(crop_size, Image.Resampling.NEAREST)
        canvas.paste(left, (0, y))
        canvas.paste(right, (width + 16, y))
        draw.text((0, y + label_height * scale + 3), name, fill=(220, 220, 220))
    canvas.save(output, optimize=False)


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--a1-rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--a1-baseline-dir", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()
    rom = args.rom.read_bytes()
    a1 = args.a1_rom.read_bytes()
    if sha256(rom) != A2_ROM_SHA256:
        raise ValueError("Advance 2 runtime validator requires the exact candidate")
    if sha256(a1) != A1_ROM_SHA256:
        raise ValueError("Advance 1 comparison ROM differs")
    if sha256(args.mesen_core.read_bytes()) != CORE_SHA256:
        raise ValueError("MesenCore differs from the validated 2.1.1 build")
    args.output_dir.mkdir(parents=True, exist_ok=True)
    route.CAPTURE_FRAMES = FRAMES
    route.STOP_FRAME = FRAMES[-1] + 40
    completed, elapsed, memory, screenshots = route.run_mesen(
        args.rom, args.mesen_core, args.output_dir, args.timeout,
    )

    map_a1 = a1[OVERVIEW_MAP_OFFSET:OVERVIEW_MAP_OFFSET + OVERVIEW_MAP_LENGTH]
    map_a2 = rom[OVERVIEW_MAP_OFFSET:OVERVIEW_MAP_OFFSET + OVERVIEW_MAP_LENGTH]
    tiles_a1 = a1[MANUAL_TILES_OFFSET:MANUAL_TILES_OFFSET + MANUAL_TILES_LENGTH]
    tiles_a2 = rom[MANUAL_TILES_OFFSET:MANUAL_TILES_OFFSET + MANUAL_TILES_LENGTH]
    changed_map_cells = {
        (index // 2 % 32, index // 2 // 32)
        for index in range(0, OVERVIEW_MAP_LENGTH, 2)
        if map_a1[index:index + 2] != map_a2[index:index + 2]
    }
    if not changed_map_cells <= TARGET_MAP_CELLS:
        raise AssertionError("Program Deck overview map changed outside label rectangles")
    if tiles_a2[OVERVIEW_TILES_LENGTH:] != tiles_a1[OVERVIEW_TILES_LENGTH:]:
        raise AssertionError("another Program Deck page tile segment changed")
    target_byte_offsets = {
        asset_id * 32 + byte
        for asset_id in TARGET_ASSET_IDS
        for byte in range(32)
    }
    outside_target_tile_changes = [
        index for index, (left, right) in enumerate(zip(
            tiles_a1[:OVERVIEW_TILES_LENGTH], tiles_a2[:OVERVIEW_TILES_LENGTH]
        )) if left != right and index not in target_byte_offsets
    ]
    if outside_target_tile_changes:
        raise AssertionError("overview atlas changed outside target label assets")

    captures = []
    diff_counts = []
    diff_bboxes = []
    root_after = None
    root_before = None
    root_mask_audit = None
    for frame, source in zip(FRAMES, screenshots, strict=True):
        destination = args.output_dir / f"program_overview_{frame}.png"
        shutil.copy2(source, destination)
        baseline = args.a1_baseline_dir / f"program_probe_{frame}.png"
        if not baseline.is_file():
            raise FileNotFoundError(baseline)
        with Image.open(baseline) as before_source, Image.open(destination) as after_source:
            before = before_source.convert("RGB")
            after = after_source.convert("RGB")
        if before.size != (224, 144) or after.size != (224, 144):
            raise AssertionError("runtime comparison is not native 224x144")
        difference = ImageChops.difference(before, after)
        bbox = difference.getbbox()
        changed = sum(before.getpixel((x, y)) != after.getpixel((x, y))
                      for y in range(144) for x in range(224))
        outside = sum(before.getpixel((x, y)) != after.getpixel((x, y))
                      for y in range(144) for x in range(224) if not inside_allowed(x, y))
        if outside:
            raise AssertionError(f"frame {frame}: {outside} pixels changed outside the marked labels")
        if before.crop((0, 80, 224, 144)).tobytes() != after.crop((0, 80, 224, 144)).tobytes():
            raise AssertionError(f"frame {frame}: lower dialogue changed")
        if before.crop(RESTORED_SPILL_RECT).tobytes() != after.crop(RESTORED_SPILL_RECT).tobytes():
            raise AssertionError(f"frame {frame}: the former row-8 spill area was not restored")
        mask_audit = {
            label.text: audit_label_mask(after, label)
            for label in font_asset.LABELS
        }
        cpu = memory[frame]
        live_map = cpu[0x2000:0x2000 + OVERVIEW_MAP_LENGTH]
        # The loader places asset slot 0 at CPU 0x8020; therefore map tile N
        # consumes asset slot N-1.  Pin the live destination, not a guessed
        # one-to-one relation between map IDs and ROM asset indices.
        if live_map != map_a2:
            raise AssertionError(f"frame {frame}: live overview map differs from ROM")
        for asset_id in TARGET_ASSET_IDS:
            rom_start = asset_id * 32
            cpu_start = 0x8020 + asset_id * 32
            if cpu[cpu_start:cpu_start + 32] != tiles_a2[rom_start:rom_start + 32]:
                raise AssertionError(
                    f"frame {frame}: live target asset 0x{asset_id:03X} differs from ROM"
                )
        captures.append({
            "frame": frame,
            "screenshot": destination.name,
            "screenshot_sha256": sha256(destination.read_bytes()),
            "changed_pixels_vs_a1": changed,
            "changed_bbox_vs_a1": list(bbox) if bbox else None,
            "pixels_outside_target_rectangles": outside,
            "lower_dialogue_pixel_exact_vs_a1": True,
            "restored_previous_spill_area_pixel_exact_vs_a1": True,
            "label_internal_mask_audit": mask_audit,
            "live_map_matches_rom": True,
            "live_target_tiles_match_rom": True,
        })
        diff_counts.append(changed)
        diff_bboxes.append(bbox)
        if frame == FRAMES[0]:
            root_after = destination
            root_before = baseline
            root_mask_audit = mask_audit

    if len(set(diff_counts)) != 1 or len(set(diff_bboxes)) != 1:
        raise AssertionError("static label delta changes between dialogue states")
    if EXPECTED_CHANGED_PIXELS is not None and diff_counts[0] != EXPECTED_CHANGED_PIXELS:
        raise AssertionError("pinned visual delta count differs")
    if EXPECTED_CHANGED_BBOX is not None and diff_bboxes[0] != EXPECTED_CHANGED_BBOX:
        raise AssertionError("pinned visual delta bounds differ")
    screenshot_sha = sha256(root_after.read_bytes())
    if EXPECTED_ROOT_SCREENSHOT_SHA256 is not None and screenshot_sha != EXPECTED_ROOT_SCREENSHOT_SHA256:
        raise AssertionError("pinned Advance 2 screenshot identity differs")

    montage_path = args.output_dir / "graphics_advance_2_runtime_comparison.png"
    montage(root_before, root_after, montage_path)
    home = args.output_dir / "mesen_core_home"
    persistence_files = []
    if home.exists():
        persistence_files = sorted(
            path.relative_to(home).as_posix() for path in home.rglob("*") if path.is_file()
            and ("Saves" in path.parts or "SaveStates" in path.parts)
        )
        shutil.rmtree(home)
    report = {
        "status": "PASS",
        "version": "0.10.7-graphics-a3",
        "advance": "2 of 6",
        "rom_sha256": A2_ROM_SHA256,
        "base_advance_1_sha256": A1_ROM_SHA256,
        "mesen_core_sha256": CORE_SHA256,
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "native_resolution": [224, 144],
        "target_rectangles": {name: list(rect) for name, rect in TARGET_RECTS.items()},
        "restored_previous_spill_rectangle": list(RESTORED_SPILL_RECT),
        "live_tile_mapping": "map tile N consumes ROM asset N-1 (asset 0 at CPU 0x8020)",
        "target_asset_ids": [f"0x{asset_id:03X}" for asset_id in TARGET_ASSET_IDS],
        "changed_map_cells": [list(cell) for cell in sorted(changed_map_cells)],
        "changed_pixels_vs_a1": diff_counts[0],
        "changed_bbox_vs_a1": list(diff_bboxes[0]),
        "pixels_outside_target_rectangles": 0,
        "overview_map_changes_confined_to_target_rectangles": True,
        "non_target_overview_tiles_unchanged_vs_a1": True,
        "other_manual_page_segments_unchanged_vs_a1": True,
        "lower_dialogue_pixel_exact_vs_a1": True,
        "restored_previous_spill_area_pixel_exact_vs_a1": True,
        "label_internal_foreground_masks_exact": True,
        "label_foreground_components_exact": True,
        "label_palette_is_background_plus_face_only": True,
        "label_internal_mask_audit": root_mask_audit,
        "runtime_map_matches_rom": True,
        "runtime_target_tiles_match_rom": True,
        "captures": captures,
        "primary_screenshot": root_after.name,
        "primary_screenshot_sha256": screenshot_sha,
        "comparison_montage": montage_path.name,
        "comparison_montage_sha256": sha256(montage_path.read_bytes()),
        "runtime_generated_persistence_files": persistence_files,
        "last_callback_frame": completed,
        "elapsed_seconds": round(elapsed, 3),
    }
    report_path = args.output_dir / "graphics_advance_2_runtime_validation.json"
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
