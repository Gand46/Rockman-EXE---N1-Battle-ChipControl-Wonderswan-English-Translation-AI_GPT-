#!/usr/bin/env python3
"""Enforce all cumulative graphics gates through Advance 5."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_5_chip_folder as a5  # noqa: E402
import n1tool  # noqa: E402


SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
A1_SHA256 = "63ce8069d89106fdc96167a14d139641db202d23e0a2cd539347e19f8fcd8575"
A2_SHA256 = "55616bc011c8439a693587c08dae9cf814801e61879ce280e253b0674e6004e5"
A3_SHA256 = "2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c"
A4_SHA256 = "e640da75a810a3cc7699c93333d164dfbf444baef006c5d26bbec176d84d62c8"
A5_SHA256 = "254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522"
IPS_SHA256 = "2beb302099fc4b6c661c1db39722978cf83f6705b8edf7856d21e812e0627faf"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def load(path: Path) -> dict:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"JSON root must be an object: {path}")
    return value


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--root", type=Path, default=ROOT)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--a4-rom", required=True, type=Path)
    parser.add_argument("--candidate-rom", type=Path)
    parser.add_argument("--ips", type=Path)
    args = parser.parse_args()
    root = args.root.resolve()
    candidate_path = args.candidate_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a5.wsc"
    ips_path = args.ips or root / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-graphics-a5.ips"
    source = args.source_rom.read_bytes()
    base = args.a4_rom.read_bytes()
    candidate = candidate_path.read_bytes()
    ips = ips_path.read_bytes()
    require(sha256(source) == SOURCE_SHA256, "Japanese source ROM identity differs")
    require(sha256(base) == A4_SHA256, "approved Advance 4 identity differs")
    require(sha256(candidate) == A5_SHA256, "Advance 5 candidate identity differs")
    require(sha256(ips) == IPS_SHA256, "Advance 5 IPS identity differs")
    require(n1tool.apply_ips(source, ips) == candidate, "IPS does not reconstruct candidate")
    stored, calculated = n1tool.checksum(candidate)
    require(stored == calculated == 0x5286, "WonderSwan checksum differs")

    allowed = {
        a5.MAP_OFFSET + (y * 32 + x) * 2 for x, y in a5.TARGET_CELLS
    } | {len(candidate) - 2, len(candidate) - 1}
    changed = {i for i, pair in enumerate(zip(base, candidate, strict=True)) if pair[0] != pair[1]}
    require(changed == allowed, "A5 changed bytes outside the map-only allowlist")
    require(
        base[a5.TILES_OFFSET:a5.TILES_OFFSET + a5.TILES_LENGTH]
        == candidate[a5.TILES_OFFSET:a5.TILES_OFFSET + a5.TILES_LENGTH],
        "A5 changed the approved CHIP FOLDER tile bank",
    )

    rules = load(root / "translation/graphics_advance_rules.json")
    generator = load(root / "translation/assets/graphics_advance_5_chip_folder_report.json")
    runtime = load(root / "docs/runtime_graphics_advances/advance_5_gate_final/graphics_advance_5_runtime_validation.json")
    build = load(root / "build/build_v0_10_7_graphics_a5.json")
    a4_build = load(root / "build/build_v0_10_7_graphics_a4.json")
    a4_runtime = load(root / "docs/runtime_graphics_advances/advance_4_gate_final/graphics_advance_4_runtime_validation.json")
    require(rules.get("status") == "PASS" and rules.get("project_version") == "0.10.7-graphics-a5", "rules identity differs")
    require(len(rules.get("rules", [])) == 25, "expected 25 cumulative rules")
    require(all(row.get("mandatory") is True for row in rules["rules"]), "a cumulative rule is optional")
    for advance in range(1, 6):
        require(rules.get(f"advance_{advance}", {}).get("status") == "PASS", f"Advance {advance} rule checkpoint missing")
    require(a4_build.get("output_sha256") == A4_SHA256, "A4 reconstructed build identity differs")
    require(a4_runtime.get("status") == "PASS", "A4 runtime checkpoint is not PASS")
    require(build.get("output_sha256") == A5_SHA256, "A5 manifest build identity differs")
    require(build.get("checksum", {}).get("checksum_valid") is True, "A5 build checksum invalid")
    require(generator.get("status") == "PASS", "A5 generator report is not PASS")
    require(generator.get("changed_map_bytes") == 12, "A5 map delta differs")
    require(generator.get("changed_tile_bytes") == 0, "A5 changed tile bytes")
    require(generator.get("changed_palette_bytes") == 0, "A5 changed palette bytes")
    require(generator.get("changed_map_attributes") == 0, "A5 changed map attributes")
    require(generator.get("consumers_per_approved_tile_after") == 2, "A5 consumer graph differs")
    require(generator.get("approved_pattern_bytes_reused_without_modification") is True, "A3 pattern was not reused exactly")
    require(runtime.get("status") == "PASS", "A5 runtime report is not PASS")
    require(runtime.get("all_pixels_outside_target_unchanged") is True, "A5 changed a pixel outside the header")
    require(runtime.get("other_map_backpack_screen_pixel_exact_vs_a4") is True, "A5 regressed the backpack screen")
    require(runtime.get("runtime_map_matches_rom") is True, "A5 live map differs from ROM")
    require(runtime.get("runtime_tiles_match_rom") is True, "A5 live tiles differ from ROM")
    require(runtime.get("approved_a3_pattern_runtime_audit", {}).get("matches_approved_a3_pattern") is True, "live header differs from approved A3 mask")
    comparisons = runtime.get("screen_comparisons_vs_a4", {})
    require(comparisons.get("chip_folder", {}).get("changed_pixels") == 524, "A5 visual delta differs")
    require(comparisons.get("chip_sort", {}).get("changed_pixels") == 0, "chip sort regressed")
    require(comparisons.get("chip_backpack", {}).get("changed_pixels") == 0, "backpack regressed")

    report = {
        "status": "PASS", "project_version": "0.10.7-graphics-a5",
        "rules_enforced": 25, "source_rom_sha256": SOURCE_SHA256,
        "base_advance_1_sha256": A1_SHA256, "base_advance_2_sha256": A2_SHA256,
        "base_advance_3_sha256": A3_SHA256, "base_advance_4_sha256": A4_SHA256,
        "candidate_rom_sha256": A5_SHA256, "cumulative_ips_sha256": IPS_SHA256,
        "ips_reconstructs_candidate": True, "binary_write_allowlist": "PASS",
        "canonical_equivalent_pattern_reuse": "PASS", "complete_consumer_graph": "PASS",
        "map_attributes_preserved": "PASS", "tile_and_palette_banks_unchanged": "PASS",
        "visual_allowlist": "PASS", "advance_1_checkpoint": "PASS",
        "advance_2_checkpoint": "PASS", "advance_3_checkpoint": "PASS",
        "advance_4_checkpoint": "PASS", "advance_5_checkpoint": "PASS",
        "clean_native_runtime": "PASS", "rom_ram_identity": "PASS",
        "manual_semantic_review": "PASS",
    }
    output = root / "build/graphics_advance_rules_validation.json"
    output.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    from validate_graphics_advance_rules_a6 import main as current_main
    raise SystemExit(current_main())
