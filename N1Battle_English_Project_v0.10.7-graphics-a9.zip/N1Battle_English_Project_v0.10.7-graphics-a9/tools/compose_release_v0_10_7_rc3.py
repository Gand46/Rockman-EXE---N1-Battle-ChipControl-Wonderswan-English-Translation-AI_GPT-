#!/usr/bin/env python3
"""Compose v0.10.7 RC3 directly from the approved pixel-polished v0.10.6."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import compose_release_v0_10_4 as ipslib


VERSION = "0.10.7-rc3"
BASE_VERSION = "0.10.6"
ROM_SIZE = 0x400000
BASE_ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
BASE_IPS_SHA256 = "d7df4954bd3509865abf3fabf99a3ba6bc8b17bb22b2855d52cd85907e7a56f6"
FINAL_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
FINAL_IPS_SHA256 = "165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980"


@dataclass(frozen=True)
class Patch:
    id: str
    offset: int
    length: int
    base_sha256: str
    file: str


PATCHES = (
    Patch("program_deck_live_bg0_map", 0x04323C, 0x0400, "ab70da1102f0d0f6c07416e2e5be2178e3b2f5a5f74497e483df33ebccab476f", "program_deck_live_bg0_map_v0_10_7_rc3.bin"),
    Patch("program_deck_auto_control_bg0_map", 0x0438BE, 0x0680, "d9e6f17908ad2da229bdf53a339e20a4e78a2641e447dd700d852d14485ef2cf", "program_deck_auto_control_bg0_map_v0_10_7_rc3.bin"),
    Patch("pet_submenu_backpack_bg0_map", 0x0445C2, 0x0680, "782e352204c6e53684b8579668a3f1a8d6cdf9487247387bc5cb5334adec4c59", "pet_submenu_backpack_bg0_map_v0_10_7_rc3.bin"),
    Patch("pet_submenu_data_library_bg0_map", 0x044C44, 0x0680, "0cea35569bcfe6b0302a51dd777653ca3089bcd23f87211d5b60d96aa0327f32", "pet_submenu_data_library_bg0_map_v0_10_7_rc3.bin"),
    Patch("pet_submenu_netnavi_bg0_map", 0x0452C6, 0x0480, "3966864b141ae128b02cf1020f199879b1aebe636da60e21d7776d7565aa329c", "pet_submenu_netnavi_bg0_map_v0_10_7_rc3.bin"),
    Patch("pet_submenu_netnavi_stats_bg0_map", 0x045748, 0x0480, "51d99c5d476ad281e3e454a81c24723bdd0ac4863ef36e7c0b5038d3f1b1940f", "pet_submenu_netnavi_stats_bg0_map_v0_10_7_rc3.bin"),
    Patch("program_deck_manual_overview_bg0_map", 0x04E7A2, 0x0400, "62a4dfc9378cc2158fad79259b49b6565b67927bb7abe5b139afd9d388a6e275", "program_deck_manual_overview_bg0_map_v0_10_7_rc3.bin"),
    Patch("program_deck_manual_stats_bg0_map", 0x04EC24, 0x0400, "3dee6f7defb7d4b76c9223660140d861a4c2b0bdb1fffeaa7c9062d327eb4996", "program_deck_manual_stats_bg0_map_v0_10_7_rc3.bin"),
    Patch("program_deck_live_ui_tiles", 0x07CD20, 0x1EF0, "fafec0b9d72bf2c1a6222e8bf074f2e41aeb3d3f94b8b8c4db45572deb73cf37", "program_deck_live_ui_tiles_v0_10_7_rc3.bin"),
    Patch("pet_submenu_chip_library_tiles", 0x07EC10, 0x16C0, "6df9cb1a34503c6996b31d29ac569b0c4827bf5c43deb7c65f789e4e8144f0ea", "pet_submenu_chip_library_tiles_v0_10_7_rc3.bin"),
    Patch("pet_submenu_netnavi_tiles", 0x080300, 0x0D40, "9630d2731ff5ed25b818f1164d2163846df521a0ee4ed7fcb9c1ba6a800fdf91", "pet_submenu_netnavi_tiles_v0_10_7_rc3.bin"),
    Patch("program_deck_manual_internal_tiles", 0x0ACA20, 0x5B60, "e73fb7e716cafeea1f5c5c707621cf6749694ea982a446b5a4e1ddea8d83df11", "program_deck_manual_internal_tiles_v0_10_7_rc3.bin"),
)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--base-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc")
    parser.add_argument("--base-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.6.ips")
    parser.add_argument("--asset-dir", type=Path, default=root / "translation/assets")
    parser.add_argument("--asset-report", type=Path, default=root / "translation/assets/redbox_font_asset_report_v0_10_7_rc3.json")
    parser.add_argument("--output-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.wsc")
    parser.add_argument("--output-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.ips")
    parser.add_argument("--report", type=Path, default=root / "build/build_v0_10_7_rc3_delta.json")
    args = parser.parse_args()

    base = args.base_rom.read_bytes()
    base_ips = args.base_ips.read_bytes()
    if len(base) != ROM_SIZE or sha256(base) != BASE_ROM_SHA256:
        raise ValueError("base ROM is not the approved pixel-polished v0.10.6")
    if sha256(base_ips) != BASE_IPS_SHA256:
        raise ValueError("base IPS is not the approved pixel-polished v0.10.6")
    asset_report = json.loads(args.asset_report.read_text(encoding="utf-8"))
    if asset_report.get("status") != "PASS" or asset_report.get("version") != VERSION:
        raise ValueError("red-box font report is not final")
    outputs = asset_report.get("outputs", {})

    ranges = sorted((patch.offset, patch.offset + patch.length, patch.id) for patch in PATCHES)
    for (_, previous_end, previous_id), (start, _, current_id) in zip(ranges, ranges[1:]):
        if start < previous_end:
            raise AssertionError(f"overlapping spans: {previous_id}/{current_id}")

    final_buffer = bytearray(base)
    allowed = bytearray(ROM_SIZE)
    records = []
    for patch in PATCHES:
        before = base[patch.offset:patch.offset + patch.length]
        if len(before) != patch.length or sha256(before) != patch.base_sha256:
            raise ValueError(f"{patch.id}: approved v0.10.6 base span differs")
        asset = (args.asset_dir / patch.file).read_bytes()
        row = outputs.get(patch.file, {})
        if len(asset) != patch.length or row.get("length") != patch.length or row.get("sha256") != sha256(asset):
            raise ValueError(f"{patch.id}: asset/report mismatch")
        final_buffer[patch.offset:patch.offset + patch.length] = asset
        allowed[patch.offset:patch.offset + patch.length] = b"\x01" * patch.length
        records.append({
            "id": patch.id,
            "offset": f"0x{patch.offset:06X}",
            "length": patch.length,
            "base_sha256": patch.base_sha256,
            "file": patch.file,
            "asset_sha256": sha256(asset),
            "changed_bytes": sum(old != new for old, new in zip(before, asset)),
        })

    checksum = sum(final_buffer[:-2]) & 0xFFFF
    final_buffer[-2:] = checksum.to_bytes(2, "little")
    allowed[-2:] = b"\x01\x01"
    final = bytes(final_buffer)
    changed = [index for index, (old, new) in enumerate(zip(base, final)) if old != new]
    outside = [index for index in changed if not allowed[index]]
    if outside:
        raise AssertionError(f"RC3 changed outside audited spans: {outside[:8]}")

    covered, values = ipslib.parse_ips(base_ips, ROM_SIZE)
    old_covered, old_values = covered[:], values[:]
    for patch in PATCHES:
        for index in range(patch.offset, patch.offset + patch.length):
            if old_covered[index] or final[index] != base[index]:
                covered[index], values[index] = 1, final[index]
            else:
                covered[index], values[index] = 0, 0
    for index in (ROM_SIZE - 2, ROM_SIZE - 1):
        covered[index], values[index] = 1, final[index]
    final_ips = ipslib.serialize_ips(covered, values)

    synthetic = bytearray(base)
    for index, present in enumerate(old_covered):
        if present:
            synthetic[index] = 0
    if ipslib.apply_normalized(bytes(synthetic), old_covered, old_values) != base:
        raise AssertionError("v0.10.6 normalized IPS does not reconstruct its ROM")
    if ipslib.apply_normalized(bytes(synthetic), covered, values) != final:
        raise AssertionError("RC3 normalized IPS composition proof failed")

    final_rom_hash, final_ips_hash = sha256(final), sha256(final_ips)
    if FINAL_ROM_SHA256 and final_rom_hash != FINAL_ROM_SHA256:
        raise AssertionError("final ROM differs from the reviewed RC3 build")
    if FINAL_IPS_SHA256 and final_ips_hash != FINAL_IPS_SHA256:
        raise AssertionError("final IPS differs from the reviewed RC3 patch")

    args.output_rom.parent.mkdir(parents=True, exist_ok=True)
    args.output_ips.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.output_rom.write_bytes(final)
    args.output_ips.write_bytes(final_ips)
    report = {
        "status": "PASS", "version": VERSION, "base_version": BASE_VERSION,
        "rc2_reused": False,
        "base_rom_sha256": sha256(base), "base_ips_sha256": sha256(base_ips),
        "final_rom_sha256": final_rom_hash, "final_ips_sha256": final_ips_hash,
        "checksum": f"0x{checksum:04X}",
        "checksum_valid": int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF,
        "changed_bytes_vs_v0_10_6": len(changed), "outside_allowlist": len(outside),
        "patched_spans": records, "bottom_dialogue_spans_modified": 0,
        "ips": {
            "method": "normalized approved-v0.10.6 source patch plus red-box-only pixel-art assets",
            "records_do_not_overlap": True, "composition_proof": "PASS", "size": len(final_ips),
        },
    }
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
