#!/usr/bin/env python3
"""Compose the pixel-polished v0.10.6 ROM and source-compatible IPS."""

from __future__ import annotations

import argparse
import hashlib
import json
from dataclasses import dataclass
from pathlib import Path

import compose_release_v0_10_4 as ipslib


VERSION = "0.10.6"
ROM_SIZE = 0x400000
BASE_ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
BASE_IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"
FINAL_ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
FINAL_IPS_SHA256 = "d7df4954bd3509865abf3fabf99a3ba6bc8b17bb22b2855d52cd85907e7a56f6"


@dataclass(frozen=True)
class Patch:
    id: str
    offset: int
    length: int
    base_sha256: str
    file: str


PATCHES = (
    Patch("name_keyboard_bg0_map", 0x0412AA, 0x0480, "85c718873c336c1d66739f97ce37408b98c0ee85b483145c1f27294df4fe8e3b", "name_keyboard_bg0_map_v0_10_6.bin"),
    Patch("location_shop_bg0_map", 0x041BB2, 0x0480, "94f0d15a5419df3479e61e6dbd08bacbe5f39f3701686629c9d6bd4b21b51396", "location_shop_bg0_map_v0_10_6.bin"),
    Patch("location_battlechip_gp_bg0_map", 0x042034, 0x0480, "0c519fe3dec91a42b4f985e1ef5773f6fd86d5bdb972633306b33c86ef7e78c7", "location_battlechip_gp_bg0_map_v0_10_6.bin"),
    Patch("pet_carousel_free_battle_bg0_map", 0x0424B6, 0x0480, "5e3ffaffd778b1d894fd7194ff5ab2755d4e3717cc7b840fb55fe82a0ce99d23", "pet_carousel_free_battle_bg0_map_v0_10_6.bin"),
    Patch("pet_carousel_host_tournament_bg0_map", 0x042938, 0x0480, "52c91b3fa6d68a7a08a65bc5c443544185f161fd9d46cc33689f1daba196520c", "pet_carousel_host_tournament_bg0_map_v0_10_6.bin"),
    Patch("pet_labels_bg0_map", 0x042DBA, 0x0400, "926376a47eaca5620b0fd2e58a0a9d85d01dd3cc0588d3c59acfe02f3c590c9c", "pet_labels_bg0_map_v0_10_6.bin"),
    Patch("pet_submenu_save_bg0_map", 0x045BCA, 0x0480, "bbadd7edba1426411b699c524740889294e449332880c413b9b4ae788fe35806", "pet_submenu_save_bg0_map_v0_10_6.bin"),
    Patch("shop_purchase_bg0_map", 0x04604C, 0x0480, "8898ff87ccd9d0cf50940155ec1975ed83c208dba114ccf51d075032a6563539", "shop_purchase_bg0_map_v0_10_6.bin"),
    Patch("name_keyboard_tiles", 0x074E10, 0x0760, "516f83ee3eba54416785d81d836e697bfb8036646f06377217ae6994c72a631e", "name_keyboard_tiles_v0_10_6.bin"),
    Patch("location_shop_bg0_tiles", 0x0768F0, 0x1740, "b493de5939a36a61b7c1156ab2124749b6a3f19ffef1a54345c77224f33b9c10", "location_shop_bg0_tiles_v0_10_6.bin"),
    Patch("location_battlechip_gp_bg0_tiles", 0x078100, 0x1480, "4285ce7fc0be79f949a33b3eeb19682342e5c9ee9b61f32531e0652a2f8f69db", "location_battlechip_gp_bg0_tiles_v0_10_6.bin"),
    Patch("pet_carousel_free_battle_bg0_tiles", 0x079650, 0x1580, "1d575315d2e4459e9cf1ee5af1c97bdfb037838deafcb8b110762d6f50683d17", "pet_carousel_free_battle_bg0_tiles_v0_10_6.bin"),
    Patch("pet_carousel_host_tournament_bg0_tiles", 0x07ACA0, 0x15C0, "2ce50fb0fc81546fe19e3c8713ce1ca25452a2f912f28514c7b6af2a687c28ba", "pet_carousel_host_tournament_bg0_tiles_v0_10_6.bin"),
    Patch("pet_labels_tiles", 0x07C330, 0x0980, "f1767e86841d884a737d0b7137be1eefa287a3849e41a2d04c6abfc18357d2a2", "pet_labels_tiles_v0_10_6.bin"),
    Patch("pet_submenu_save_tiles", 0x081070, 0x0800, "4a2d461d734245f9650fba93373f4ba1780e4c23912c8ac91f5f92cd5527e9ad", "pet_submenu_save_tiles_v0_10_6.bin"),
    Patch("shop_purchase_bg0_tiles", 0x0818A0, 0x0600, "1dde1b1b22c4a7441910b80a13fe8915c7b6400fa2ca23ed6879a50f912ce4d8", "shop_purchase_bg0_tiles_v0_10_6.bin"),
    Patch("free_win_streak_bg0_tiles", 0x0896F0, 0x26C0, "a2bf87d95f58579e4ea4485639e3d3d3abdf5a36670c9901af2f2c1026ad28dc", "free_win_streak_bg0_tiles_v0_10_6.bin"),
    Patch("name_keyboard_obj_low_mask", 0x19A47E, 0x00C0, "2d4b9752c5f396dadfd2f05e5ce4182ce7a750c7909d40e841452f1b09a477eb", "name_keyboard_obj_low_mask_v0_10_6.bin"),
    Patch("name_keyboard_obj_cap_mask", 0x19A55C, 0x00C0, "b1388a7b66111d0f810a1d2b2611a764e4aa5f7178858cb9dc272c3c2f60d078", "name_keyboard_obj_cap_mask_v0_10_6.bin"),
    Patch("name_keyboard_obj_abc_mask", 0x19A63A, 0x00C0, "57ee607495b834236e0212f0bd22aa132c57a8550f4dba85f4b8cb0ad649ded9", "name_keyboard_obj_abc_mask_v0_10_6.bin"),
    Patch("auxiliary_text_pool", 0x34ACB0, 0x0AAE, "40de4032c9e02e40eb776ade4a58881b0a6144d4492ff2566a93bb116968e749", "aux_text_pool_v0_10_6.bin"),
)


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    root = Path(__file__).resolve().parents[1]
    parser.add_argument("--base-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.5.wsc")
    parser.add_argument("--base-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips")
    parser.add_argument("--asset-dir", type=Path, default=root / "translation/assets")
    parser.add_argument("--asset-report", type=Path, default=root / "translation/assets/ttf_static_ui_asset_report_v0_10_6.json")
    parser.add_argument("--class-report", type=Path, default=root / "translation/assets/class_selection_labels_report_v0_10_6.json")
    parser.add_argument("--output-rom", type=Path, default=root / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc")
    parser.add_argument("--output-ips", type=Path, default=root / "patches/Rockman_EXE_N1_Battle_English_v0.10.6.ips")
    parser.add_argument("--report", type=Path, default=root / "build/build_v0_10_6_delta.json")
    args = parser.parse_args()

    base = args.base_rom.read_bytes()
    base_ips = args.base_ips.read_bytes()
    if len(base) != ROM_SIZE or sha256(base) != BASE_ROM_SHA256:
        raise ValueError("base ROM is not the canonical v0.10.5 build")
    if sha256(base_ips) != BASE_IPS_SHA256:
        raise ValueError("base IPS is not the canonical v0.10.5 patch")
    asset_report = json.loads(args.asset_report.read_text(encoding="utf-8"))
    if asset_report.get("status") != "PASS" or asset_report.get("version") != VERSION:
        raise ValueError("font asset report is not final")
    class_report = json.loads(args.class_report.read_text(encoding="utf-8"))
    if class_report.get("status") != "PASS" or class_report.get("version") != VERSION:
        raise ValueError("class-label report is not final")
    report_outputs = {
        **asset_report.get("outputs", {}),
        **class_report.get("outputs", {}),
    }

    ranges = sorted((patch.offset, patch.offset + patch.length, patch.id) for patch in PATCHES)
    for (_, previous_end, previous_id), (start, _, current_id) in zip(ranges, ranges[1:]):
        if start < previous_end:
            raise AssertionError(f"overlapping patches: {previous_id}/{current_id}")

    output = bytearray(base)
    patch_records = []
    allowed = bytearray(ROM_SIZE)
    for patch in PATCHES:
        before = base[patch.offset:patch.offset + patch.length]
        if len(before) != patch.length or sha256(before) != patch.base_sha256:
            raise ValueError(f"{patch.id}: unexpected v0.10.5 base span")
        asset_path = args.asset_dir / patch.file
        asset = asset_path.read_bytes()
        row = report_outputs.get(patch.file, {})
        if len(asset) != patch.length or row.get("length") != patch.length or row.get("sha256") != sha256(asset):
            raise ValueError(f"{patch.id}: asset/report mismatch")
        output[patch.offset:patch.offset + patch.length] = asset
        allowed[patch.offset:patch.offset + patch.length] = b"\x01" * patch.length
        patch_records.append({
            "id": patch.id,
            "offset": f"0x{patch.offset:06X}",
            "length": patch.length,
            "base_sha256": patch.base_sha256,
            "file": patch.file,
            "asset_sha256": sha256(asset),
            "changed_bytes": sum(old != new for old, new in zip(before, asset)),
        })

    checksum = sum(output[:-2]) & 0xFFFF
    output[-2:] = checksum.to_bytes(2, "little")
    allowed[-2:] = b"\x01\x01"
    final = bytes(output)
    changed = [index for index, (old, new) in enumerate(zip(base, final)) if old != new]
    outside = [index for index in changed if not allowed[index]]
    if outside:
        raise AssertionError(f"v0.10.6 changed outside the audited spans: {outside[:8]}")

    covered, values = ipslib.parse_ips(base_ips, ROM_SIZE)
    old_covered = covered[:]
    old_values = values[:]
    for patch in PATCHES:
        for index in range(patch.offset, patch.offset + patch.length):
            if old_covered[index] or final[index] != base[index]:
                covered[index] = 1
                values[index] = final[index]
            else:
                covered[index] = 0
                values[index] = 0
    for index in (ROM_SIZE - 2, ROM_SIZE - 1):
        covered[index] = 1
        values[index] = final[index]
    final_ips = ipslib.serialize_ips(covered, values)

    synthetic = bytearray(base)
    for index, present in enumerate(old_covered):
        if present:
            synthetic[index] = 0
    if ipslib.apply_normalized(bytes(synthetic), old_covered, old_values) != base:
        raise AssertionError("v0.10.5 normalization does not reconstruct its ROM")
    if ipslib.apply_normalized(bytes(synthetic), covered, values) != final:
        raise AssertionError("v0.10.6 normalized IPS composition proof failed")

    final_rom_hash = sha256(final)
    final_ips_hash = sha256(final_ips)
    if FINAL_ROM_SHA256 and final_rom_hash != FINAL_ROM_SHA256:
        raise AssertionError("final ROM differs from the reviewed v0.10.6 build")
    if FINAL_IPS_SHA256 and final_ips_hash != FINAL_IPS_SHA256:
        raise AssertionError("final IPS differs from the reviewed v0.10.6 patch")

    args.output_rom.parent.mkdir(parents=True, exist_ok=True)
    args.output_ips.parent.mkdir(parents=True, exist_ok=True)
    args.report.parent.mkdir(parents=True, exist_ok=True)
    args.output_rom.write_bytes(final)
    args.output_ips.write_bytes(final_ips)
    report = {
        "status": "PASS",
        "version": VERSION,
        "base_rom_sha256": sha256(base),
        "base_ips_sha256": sha256(base_ips),
        "final_rom_sha256": final_rom_hash,
        "final_ips_sha256": final_ips_hash,
        "checksum": f"0x{checksum:04X}",
        "checksum_valid": int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF,
        "changed_bytes_vs_v0_10_5": len(changed),
        "outside_allowlist": len(outside),
        "patched_spans": patch_records,
        "dialogue_spans_modified": 0,
        "ips": {
            "method": "normalized v0.10.5 source patch with pixel-polished static spans and in-place class labels",
            "records_do_not_overlap": True,
            "composition_proof": "PASS",
            "size": len(final_ips),
        },
    }
    args.report.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
