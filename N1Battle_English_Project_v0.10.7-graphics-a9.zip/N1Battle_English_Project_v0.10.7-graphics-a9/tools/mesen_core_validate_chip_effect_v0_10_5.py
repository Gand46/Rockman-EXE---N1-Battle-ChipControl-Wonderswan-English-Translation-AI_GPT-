#!/usr/bin/env python3
"""Clean-boot runtime QA for the v0.10.5 six-glyph chip effects."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import shutil
import sys
import tempfile
from pathlib import Path

from PIL import Image, ImageChops, ImageDraw


ROOT = Path(__file__).resolve().parents[1]
ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
EXPECTED_CAPTURE_SHA256 = {
    "chip_folder": "96f61e7ff2bd2e060c9525efa43597c57b5142f79666138921a6ab6ad762be9c",
    "chip_backpack": "42398b24ae0a5bacf2e626cc42601bcfd2d03cdea6b13fdde95ab28bd9924750",
}
EXPECTED_DIFF_BBOX = {
    "chip_folder": (56, 82, 88, 95),
    "chip_backpack": (184, 82, 224, 95),
}
SCREEN_SIZE = (224, 144)
EFFECT_REGION = {
    "chip_folder": (48, 78, 96, 98),
    "chip_backpack": (176, 78, 224, 98),
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def build_comparison(
    before_path: Path, after_path: Path, output: Path,
    before_label: str, after_label: str,
) -> dict:
    with Image.open(before_path) as source:
        before = source.convert("RGB")
    with Image.open(after_path) as source:
        after = source.convert("RGB")
    if before.size != SCREEN_SIZE or after.size != SCREEN_SIZE:
        raise ValueError("comparison screenshots must be native 224x144")
    scale = 3
    panel_size = (SCREEN_SIZE[0] * scale, SCREEN_SIZE[1] * scale)
    canvas = Image.new("RGB", (panel_size[0] * 2 + 8, panel_size[1] + 30), (16, 16, 16))
    draw = ImageDraw.Draw(canvas)
    draw.text((8, 8), f"v0.10.4  {before_label}", fill="white")
    draw.text((panel_size[0] + 16, 8), f"v0.10.5  {after_label}", fill="white")
    canvas.paste(before.resize(panel_size, Image.Resampling.NEAREST), (0, 30))
    canvas.paste(after.resize(panel_size, Image.Resampling.NEAREST), (panel_size[0] + 8, 30))
    output.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(output)
    return {
        "file": output.name,
        "sha256": sha256(output.read_bytes()),
        "dimensions": list(canvas.size),
        "scale": "3x nearest-neighbor",
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--rom", type=Path,
        default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.5.wsc",
    )
    parser.add_argument("--mesen-core", type=Path, required=True)
    parser.add_argument(
        "--output-dir", type=Path,
        default=ROOT / "docs/runtime_v0_10_5/chip_effect",
    )
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()

    rom_before = args.rom.read_bytes()
    if len(rom_before) != 0x400000 or sha256(rom_before) != ROM_SHA256:
        raise ValueError("ROM is not the canonical v0.10.5 build")
    if not args.mesen_core.is_file():
        raise FileNotFoundError(args.mesen_core)

    deep = load_module(
        "pet_deep_runtime_for_v0105",
        ROOT / "tools/mesen_core_validate_pet_deep_v0_10.py",
    )
    args.output_dir.mkdir(parents=True, exist_ok=True)
    with tempfile.TemporaryDirectory(prefix="n1_v0105_chip_") as temporary:
        route_dir = Path(temporary) / "chip"
        route = deep.run_route({
            "route": "chip",
            "rom": str(args.rom.resolve()),
            "core": str(args.mesen_core.resolve()),
            "output": str(route_dir),
            "timeout": args.timeout,
        })
        captures = {row["state"]: row for row in route["captures"]}
        copied: dict[str, Path] = {}
        names = {
            "chip_folder": "chip_folder_NORM60.png",
            "chip_sort": "chip_sort_v0_10_5.png",
            "chip_backpack": "chip_backpack_v0_10_5.png",
        }
        for state, filename in names.items():
            source = route_dir / captures[state]["screenshot"]["file"]
            target = args.output_dir / filename
            shutil.copy2(source, target)
            copied[state] = target

    reference_dir = ROOT / "docs/runtime_v0_10_1/chip"
    references = {
        "chip_folder": reference_dir / "chip_folder_NORMAL60.png",
        "chip_sort": reference_dir / "chip_sort.png",
        "chip_backpack": reference_dir / "chip_backpack.png",
    }
    for path in (*copied.values(), *references.values()):
        if not path.is_file():
            raise FileNotFoundError(path)

    differences: dict[str, dict[str, object]] = {}
    for state in ("chip_folder", "chip_backpack"):
        with Image.open(references[state]) as source:
            before = source.convert("RGB")
        with Image.open(copied[state]) as source:
            after = source.convert("RGB")
        diff_bbox = ImageChops.difference(before, after).getbbox()
        if diff_bbox is None:
            raise AssertionError(f"{state}: effect-label pixels did not change")
        region = EFFECT_REGION[state]
        inside_effect_region = (
            region[0] <= diff_bbox[0] and region[1] <= diff_bbox[1]
            and diff_bbox[2] <= region[2] and diff_bbox[3] <= region[3]
        )
        if not inside_effect_region:
            raise AssertionError(f"{state}: pixels changed outside effect field: {diff_bbox}")
        if tuple(diff_bbox) != EXPECTED_DIFF_BBOX[state]:
            raise AssertionError(f"{state}: unexpected reviewed diff bounds: {diff_bbox}")
        differences[state] = {
            "bbox": list(diff_bbox),
            "confined_to_effect_region": inside_effect_region,
        }

    runtime_resource_checks = {
        capture["state"]: (
            capture["runtime_map"]["exact_match"]
            and capture["runtime_tiles"]["exact_match"]
        )
        for capture in route["captures"]
    }
    if not all(runtime_resource_checks.values()):
        raise AssertionError(f"live map/tile mismatch: {runtime_resource_checks}")

    capture_rows = []
    for state, path in copied.items():
        with Image.open(path) as image:
            dimensions = list(image.size)
        if dimensions != list(SCREEN_SIZE):
            raise AssertionError(f"{state} is not native 224x144")
        capture_hash = sha256(path.read_bytes())
        expected_hash = EXPECTED_CAPTURE_SHA256.get(state)
        if expected_hash and capture_hash != expected_hash:
            raise AssertionError(f"{state} capture differs from reviewed v0.10.5 pixels")
        capture_rows.append({
            "state": state,
            "file": path.name,
            "sha256": capture_hash,
            "dimensions": dimensions,
        })

    comparison_norm = build_comparison(
        references["chip_folder"], copied["chip_folder"],
        args.output_dir / "chip_effect_before_after_v0_10_5_3x.png",
        "NORMAL60", "NORM60",
    )
    comparison_no_data = build_comparison(
        references["chip_backpack"], copied["chip_backpack"],
        args.output_dir / "chip_effect_nodata_before_after_v0_10_5_3x.png",
        "NO DATA", "NODATA",
    )
    rom_after = args.rom.read_bytes()
    report = {
        "format": "n1-chip-effect-runtime-validation-v0.10.5",
        "project_version": "0.10.5",
        "status": "PASS",
        "rom_sha256": sha256(rom_before),
        "native_display": [224, 144],
        "clean_boot": {
            "fresh_mesen_home": True,
            "uses_sav_or_savestate": False,
            "route": "real START transition -> PET -> CHIP FOLDER",
            "capture_frame": 27320,
        },
        "runtime": {
            "default_chip": "Cannon",
            "visible_effects": ["NORM60", "NODATA"],
            "previous_visible_effects": ["NORMAL60", "NO DATA"],
            "differences": differences,
            "all_live_maps_and_tiles_match_final_rom": all(runtime_resource_checks.values()),
            "live_resource_checks": runtime_resource_checks,
        },
        "captures": capture_rows,
        "comparisons": [comparison_norm, comparison_no_data],
        "rom_unchanged_by_validation": rom_after == rom_before,
        "manual_visual_review": {
            "status": "PASS",
            "artifact_or_clipping_detected": False,
            "six_glyph_label_legible": True,
        },
    }
    report_path = args.output_dir / "chip_effect_runtime_validation_v0_10_5.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": report["status"],
        "capture_sha256": next(row["sha256"] for row in capture_rows if row["state"] == "chip_folder"),
        "difference_bboxes": {state: row["bbox"] for state, row in differences.items()},
        "manual_visual_review": report["manual_visual_review"]["status"],
        "report": str(report_path),
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
