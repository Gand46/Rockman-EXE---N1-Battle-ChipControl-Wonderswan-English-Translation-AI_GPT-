#!/usr/bin/env python3
"""Create a deterministic, ROM-free public package for N1 Battle v0.9."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


PACKAGE_ROOT = "N1Battle_English_Project_v0.9.0"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".deb", ".so", ".dll",
    ".exe", ".tar", ".gz", ".7z",
}
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def add_if_present(files: set[Path], root: Path, relative: str) -> None:
    path = root / relative
    if path.is_file():
        files.add(path)


def collect(root: Path) -> list[Path]:
    manifest_path = root / "translation/en_v0_9.json"
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files: set[Path] = {manifest_path}

    for relative in (
        "APPLY_PATCH.bat", "BUILD_PATCH.bat", "CHANGELOG.md", "LICENSE.txt",
        "README_ES.md", "RELEASE_SHA256.txt", "tables/n1battle_jp.tbl",
        "docs/GRAPHICS_DEEP_AUDIT_REPRESENTATIVES_v0_9.tsv",
        "references/bcc_en.tbl", "tests/test_bcc_reference_v0_6.py",
        "tests/test_n1save.py", "tools/n1tool.py", "tools/n1save.py",
        "tools/bcc_reference.py", "tools/make_manifest_v0_9.py",
        "tools/validate_release_v0_9.py", "tools/package_release_v0_9.py",
        "tools/audit_residual_japanese_v0_9.py",
        "tools/audit_credits_ending_v0_9.py",
        "tools/auxiliary_text_assets_v0_9.py",
        "tools/battle_message_assets_v0_9.py",
        "tools/participant_name_assets_v0_9.py",
        "tools/name_keyboard_assets_v0_9.py",
        "tools/pet_submenu_assets_v0_9.py",
        "tools/program_deck_overlap_assets_v0_9.py",
        "tools/program_deck_remaining_assets_v0_9.py",
        "tools/program_tournament_assets_v0_9.py",
        "tools/location_graphics_assets_v0_9.py",
        "tools/lan_room_poster_assets_v0_9.py",
        "tools/mesen_core_validate_name_keyboard_v0_8.py",
        "tools/mesen_core_validate_pet_v0_8.py",
        "tools/mesen_core_validate_pet_submenus_v0_9.py",
        "tools/mesen_core_validate_program_deck_v0_8.py",
        "tools/mesen_core_validate_lan_poster_v0_9.py",
    ):
        add_if_present(files, root, relative)

    for entry in manifest.get("binary_entries", []):
        asset = PurePosixPath("translation") / str(entry["asset"])
        if asset.is_absolute() or ".." in asset.parts:
            raise ValueError(f"manifest asset escapes translation/: {asset}")
        path = root / asset
        if not path.is_file():
            raise FileNotFoundError(path)
        files.add(path)

    for pattern in (
        "docs/*v0_9*.md", "docs/*v0_9*.json", "docs/*v0_9*.png",
        "translation/assets/*_report_v0_9.json",
        "translation/assets/*_validation_v0_9.json",
        "translation/assets/*_preview_v0_9.png",
        "translation/assets/*_comparison_v0_9.png",
        "translation/assets/*_runtime_v0_9.png",
    ):
        files.update(path for path in root.glob(pattern) if path.is_file())

    # Runtime evidence directories keep the original capture/report names so
    # their JSON references remain valid.  The v0.9 identity is carried by the
    # parent directory when an inherited regression runner says v0_8.
    for directory in root.glob("docs/runtime_v0_9_*"):
        if directory.is_dir():
            files.update(path for path in directory.rglob("*") if path.is_file())

    result = sorted(files, key=lambda path: path.relative_to(root).as_posix())
    required = {
        "patches/Rockman_EXE_N1_Battle_English_v0.9.ips",
        "docs/STRUCTURAL_VALIDATION_v0_9.json",
        "docs/PROGRESO_v0_9.md",
        "docs/progress_v0_9.json",
        "docs/EMULATOR_VALIDATION_v0_9.md",
        "docs/RESIDUAL_JAPANESE_AUDIT_v0_9.md",
        "docs/CREDITS_ENDING_AUDIT_v0_9.json",
    }
    for relative in required:
        path = root / relative
        if not path.is_file():
            raise FileNotFoundError(path)
        if path not in files:
            files.add(path)
    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    suffix = path.suffix.lower()
    size = path.stat().st_size
    if suffix in FORBIDDEN_SUFFIXES:
        raise ValueError(f"forbidden extension in public package: {relative}")
    if size in FORBIDDEN_SIZES:
        raise ValueError(f"forbidden ROM/save-sized file: {relative} ({size})")
    payload = path.read_bytes()
    if relative.endswith(".ips"):
        if not payload.startswith(b"PATCH") or b"EOF" not in payload[-11:]:
            raise ValueError(f"malformed IPS: {relative}")
    if relative.endswith(".json"):
        json.loads(payload.decode("utf-8"))
    return {"path": relative, "size": size, "sha256": sha256(payload)}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    output = (args.output or root / "dist/N1Battle_English_Project_v0.9.0.zip").resolve()
    files = collect(root)
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, path.read_bytes(), compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)

    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": "0.9.0",
        "archive": output.name,
        "archive_size": len(payload),
        "archive_sha256": sha256(payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": 0,
        "files": inventory,
    }
    report_path = output.with_suffix(".release.json")
    report_path.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_save_emulator_files",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
