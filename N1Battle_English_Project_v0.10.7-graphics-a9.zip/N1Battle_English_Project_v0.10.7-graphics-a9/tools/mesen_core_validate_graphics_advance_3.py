#!/usr/bin/env python3
"""Validate Graphics Advance 3 in the live alternate Program Deck screen."""

from __future__ import annotations

import argparse
import hashlib
import json
import shutil
import sys
from pathlib import Path

from PIL import Image, ImageChops


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import graphics_advance_3_header as asset  # noqa: E402
import mesen_core_validate_pet_deep_v0_10 as legacy  # noqa: E402


A2_ROM_SHA256 = "55616bc011c8439a693587c08dae9cf814801e61879ce280e253b0674e6004e5"
A3_ROM_SHA256 = "2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c"
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
CORE_SHA256 = "36be680c42d0cbc7980dbee6fe4289fd75d2ace26cd02d1da91a7c13005c29b9"
A2_SCREENSHOT_SHA256 = "0c0280c7adc11df8df847347e419c2467e02b86b790cfdffdf5bb39c6d39ce31"
TARGETS = {
    "PROGRAM DECK Y4": (8, 8, 64, 16),
    "CHIP FOLDER": (80, 0, 128, 16),
    "REMOVED RESIDUE": (128, 0, 136, 16),
}
RESIDUE_RECT = (128, 0, 136, 16)
REFERENCE_BLANK_RECT = (72, 0, 80, 16)
EXPECTED_CHANGED_PIXELS = 478
EXPECTED_CHANGED_BBOX = (8, 1, 136, 16)
EXPECTED_SCREENSHOT_SHA256 = "7ad998a2a27e225568f492aa011476a20675ec613512d51132704e4fd115080b"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def inside_target(x: int, y: int) -> bool:
    return any(left <= x < right and top <= y < bottom
               for left, top, right, bottom in TARGETS.values())


def bind_candidate(rom: bytes) -> None:
    legacy.EXPECTED_ROM_SHA256 = A3_ROM_SHA256
    for name, region in list(legacy.MAPS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.MAPS[name] = legacy.Region(region.offset, region.length, sha256(payload))
    for name, region in list(legacy.TILE_BANKS.items()):
        payload = rom[region.offset:region.offset + region.length]
        legacy.TILE_BANKS[name] = legacy.Region(region.offset, region.length, sha256(payload))


def components(mask: list[bool], width: int, height: int) -> int:
    unseen = {index for index, enabled in enumerate(mask) if enabled}
    count = 0
    while unseen:
        count += 1
        stack = [unseen.pop()]
        while stack:
            index = stack.pop()
            x, y = index % width, index // width
            for nx, ny in ((x - 1, y), (x + 1, y), (x, y - 1), (x, y + 1)):
                neighbour = ny * width + nx
                if 0 <= nx < width and 0 <= ny < height and neighbour in unseen:
                    unseen.remove(neighbour)
                    stack.append(neighbour)
    return count


def audit_canvas(crop: Image.Image, canvas: list[list[int]], face_indices: set[int]) -> dict[str, object]:
    if crop.size != (len(canvas[0]), len(canvas)):
        raise AssertionError("runtime crop and generated canvas differ in geometry")
    index_colours: dict[int, set[tuple[int, int, int]]] = {}
    for y, row in enumerate(canvas):
        for x, value in enumerate(row):
            index_colours.setdefault(value, set()).add(crop.getpixel((x, y)))
    if any(len(colours) != 1 for colours in index_colours.values()):
        raise AssertionError("a tile colour index maps to multiple runtime colours")
    palette = {index: next(iter(colours)) for index, colours in index_colours.items()}
    expected = Image.new("RGB", crop.size)
    for y, row in enumerate(canvas):
        for x, value in enumerate(row):
            expected.putpixel((x, y), palette[value])
    if expected.tobytes() != crop.tobytes():
        raise AssertionError("runtime crop differs from the generated internal mask")
    width, height = crop.size
    face_mask = [canvas[y][x] in face_indices for y in range(height) for x in range(width)]
    return {
        "runtime_matches_generated_canvas": True,
        "index_to_runtime_rgb": {str(index): list(colour) for index, colour in sorted(palette.items())},
        "palette_indices": sorted(index_colours),
        "foreground_components": components(face_mask, width, height),
    }


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--a2-rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--a2-screenshot", required=True, type=Path)
    parser.add_argument("--source-rom", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=180.0)
    args = parser.parse_args()
    rom = args.rom.read_bytes()
    a2 = args.a2_rom.read_bytes()
    source_rom = args.source_rom.read_bytes()
    if sha256(rom) != A3_ROM_SHA256 or sha256(a2) != A2_ROM_SHA256:
        raise ValueError("Advance 3 or its approved A2 base differs")
    if sha256(args.mesen_core.read_bytes()) != CORE_SHA256:
        raise ValueError("MesenCore differs from the validated 2.1.1 build")
    if sha256(args.a2_screenshot.read_bytes()) != A2_SCREENSHOT_SHA256:
        raise ValueError("A2 Program Deck baseline screenshot differs")
    if sha256(source_rom) != SOURCE_ROM_SHA256:
        raise ValueError("Japanese source ROM identity differs")
    route = legacy.route_by_name("program_alt")
    source_map = source_rom[asset.MAP_OFFSET:asset.MAP_OFFSET + asset.MAP_LENGTH]
    source_residue_words = [
        int.from_bytes(source_map[(y * 32 + x) * 2:(y * 32 + x) * 2 + 2], "little")
        for x, y in asset.RESIDUE_CELLS
    ]
    if source_residue_words != [0x240B, 0x241C]:
        raise AssertionError("Japanese source residue cells differ")
    bind_candidate(rom)
    route_dir = args.output_dir / "program_alt"
    result = legacy.run_route({
        "route": route.name,
        "rom": str(args.rom),
        "core": str(args.mesen_core),
        "output": str(route_dir),
        "timeout": args.timeout,
    })
    source = route_dir / "program_alt_button_27440.png"
    primary = args.output_dir / "program_alt_button_27440.png"
    shutil.copy2(source, primary)
    with Image.open(args.a2_screenshot) as before_source, Image.open(primary) as after_source:
        before = before_source.convert("RGB")
        after = after_source.convert("RGB")
    if before.size != (224, 144) or after.size != (224, 144):
        raise AssertionError("runtime screenshots are not native 224x144")
    difference = ImageChops.difference(before, after)
    bbox = difference.getbbox()
    changed = sum(before.getpixel((x, y)) != after.getpixel((x, y))
                  for y in range(144) for x in range(224))
    outside = sum(before.getpixel((x, y)) != after.getpixel((x, y))
                  for y in range(144) for x in range(224) if not inside_target(x, y))
    if outside:
        raise AssertionError(f"{outside} pixels changed outside the two headers")
    residue = after.crop(RESIDUE_RECT)
    if residue.tobytes() != after.crop(REFERENCE_BLANK_RECT).tobytes():
        raise AssertionError("pixels remain to the right of CHIP FOLDER")
    if len(set(residue.getdata())) != 1:
        raise AssertionError("removed residue rectangle is not uniform")
    if before.crop((136, 0, 224, 16)).tobytes() != after.crop((136, 0, 224, 16)).tobytes():
        raise AssertionError("right-side header neighbours changed")
    if before.crop((0, 16, 224, 144)).tobytes() != after.crop((0, 16, 224, 144)).tobytes():
        raise AssertionError("chip list, data panel or lower interface changed")
    bank = rom[asset.TILES_OFFSET:asset.TILES_OFFSET + asset.TILES_LENGTH]
    left_canvas = asset.read_canvas(bank, asset.LEFT_TILE_IDS, 7)
    right_canvas = asset.read_canvas(bank, asset.RIGHT_TILE_IDS, 6)
    left_audit = audit_canvas(after.crop(TARGETS["PROGRAM DECK Y4"]), left_canvas, {2, 6})
    right_audit = audit_canvas(after.crop(TARGETS["CHIP FOLDER"]), right_canvas, {15})
    if any(left_canvas[y][x] == 2 for y in range(8) for x in range(46, 56)):
        raise AssertionError("dark duplicate pixels remain in Y4")
    expected_y4 = [left_canvas[y][x] == 6 for y in range(8) for x in range(46, 56)]
    if components(expected_y4, 10, 8) != 4:
        raise AssertionError("Y4 component structure differs")
    generator = json.loads((ROOT / "translation/assets/graphics_advance_3_header_report.json").read_text())
    boxes = generator["labels"]["chip_folder"]["glyph_boxes"]
    for previous, current in zip(boxes, boxes[1:]):
        previous_end = previous[1] + previous[3]
        if current[1] - previous_end < 1:
            raise AssertionError("CHIP FOLDER glyph boxes overlap")
    word_gap = boxes[4][1] - (boxes[3][1] + boxes[3][3])
    if word_gap < 3:
        raise AssertionError("CHIP/FOLDER word boundary is not visually open")
    if EXPECTED_CHANGED_PIXELS is not None and changed != EXPECTED_CHANGED_PIXELS:
        raise AssertionError("pinned A3 visual delta count differs")
    if EXPECTED_CHANGED_BBOX is not None and bbox != EXPECTED_CHANGED_BBOX:
        raise AssertionError("pinned A3 visual bounds differ")
    screenshot_sha = sha256(primary.read_bytes())
    if EXPECTED_SCREENSHOT_SHA256 is not None and screenshot_sha != EXPECTED_SCREENSHOT_SHA256:
        raise AssertionError("pinned A3 screenshot identity differs")
    report = {
        "status": "PASS",
        "version": "0.10.7-graphics-a3",
        "advance": "3 of 6",
        "rom_sha256": A3_ROM_SHA256,
        "base_a2_rom_sha256": A2_ROM_SHA256,
        "mesen_core_sha256": CORE_SHA256,
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "native_resolution": [224, 144],
        "original_japanese_rom_sha256": SOURCE_ROM_SHA256,
        "original_japanese_residue_map_words": [f"0x{word:04X}" for word in source_residue_words],
        "semantic_original": {"left": "プログラムデッキ Y4", "right": "チップフォルダ"},
        "semantic_translation": {"left": "PROGRAM DECK Y4", "right": "CHIP FOLDER"},
        "auto_control_rejected_as_semantically_incorrect": True,
        "target_rectangles": {name: list(rect) for name, rect in TARGETS.items()},
        "removed_residue_rectangle": list(RESIDUE_RECT),
        "reference_blank_rectangle": list(REFERENCE_BLANK_RECT),
        "changed_pixels_vs_a2": changed,
        "changed_bbox_vs_a2": list(bbox) if bbox else None,
        "pixels_outside_target_rectangles": outside,
        "residue_pixels_remaining": 0,
        "residue_rectangle_uniform_background": True,
        "right_side_neighbours_pixel_exact_vs_a2": True,
        "interface_below_header_pixel_exact_vs_a2": True,
        "program_deck_y4_audit": left_audit,
        "chip_folder_audit": right_audit,
        "dark_duplicate_pixels_in_y4": 0,
        "y4_colour_zones_separated": True,
        "chip_folder_glyph_overlap_count": 0,
        "chip_folder_word_gap_pixels": word_gap,
        "runtime_map_matches_rom": result["captures"][0]["runtime_map"]["exact_match"],
        "runtime_tiles_match_rom": result["captures"][0]["runtime_tiles"]["exact_match"],
        "primary_screenshot": primary.name,
        "primary_screenshot_sha256": screenshot_sha,
        "route_report": "program_alt/route_report.json",
    }
    output = args.output_dir / "graphics_advance_3_runtime_validation.json"
    output.write_text(json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
