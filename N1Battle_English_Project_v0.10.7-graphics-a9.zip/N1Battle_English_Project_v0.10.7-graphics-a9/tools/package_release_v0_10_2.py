#!/usr/bin/env python3
"""Create the deterministic, ROM-free public N1 Battle v0.10.2 package."""

from __future__ import annotations

import argparse
import hashlib
import json
import zipfile
from pathlib import Path, PurePosixPath


PACKAGE_ROOT = "N1Battle_English_Project_v0.10.2"
FIXED_TIME = (2026, 8, 22, 0, 0, 0)
FINAL_ROM_SHA256 = "b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24"
INHERITED_V0101_ROM_SHA256 = "5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b"
INHERITED_V010_ROM_SHA256 = "0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69"
FORBIDDEN_SUFFIXES = {
    ".wsc", ".ws", ".gba", ".gb", ".gbc", ".nds", ".rom", ".binrom",
    ".sav", ".srm", ".mss", ".state", ".ieeprom", ".cdl", ".rgd", ".dmp",
    ".deb", ".so", ".dll", ".exe", ".tar", ".gz", ".7z", ".zip",
}
FORBIDDEN_DIRECTORIES = {
    "mesen_core_home", "mesen_home", "savestates", "saves", "memory",
}
FORBIDDEN_SIZES = {0x400000, 0x2000000, 0x8000}


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def require(root: Path, relative: str) -> Path:
    path = root / relative
    if not path.is_file():
        raise FileNotFoundError(path)
    return path


def load_json(root: Path, relative: str) -> dict[str, object]:
    return json.loads(require(root, relative).read_text(encoding="utf-8"))


def validate_release_evidence(root: Path) -> None:
    structural = load_json(root, "docs/STRUCTURAL_VALIDATION_v0_10_2.json")
    residual = load_json(root, "docs/RESIDUAL_TEXT_SCAN_v0_10_2.json")
    title = load_json(
        root,
        "docs/runtime_v0_10_2/title/title_runtime_validation_v0_10_2.json",
    )
    # The chip correction is byte-identical to v0.10.1; its native runtime
    # evidence is inherited and pinned to that exact build.
    chip = load_json(
        root,
        "docs/runtime_v0_10_1/chip/chip_effect_runtime_validation_v0_10_1.json",
    )

    # These three runtime suites cover unchanged v0.10 areas. Their original
    # ROM hash is pinned here; current-ROM structural validation proves that
    # subsequent releases do not escape their documented spans.
    shop = load_json(root, "docs/runtime_v0_10/shop_runtime_validation_v0_10.json")
    free_host = load_json(root, "docs/runtime_v0_10/free_host_runtime_validation_v0_10.json")
    pet = load_json(root, "docs/runtime_v0_10/pet_deep_runtime_validation_v0_10.json")

    checks = {
        "structural PASS": structural.get("overall_result") == "PASS",
        "structural final ROM": (
            structural.get("checks", {}).get("canonical_rebuild", {}).get("built_sha256")
            == FINAL_ROM_SHA256
        ),
        "residual PASS": residual.get("overall_result") == "PASS",
        "residual final ROM": (
            residual.get("checks", {}).get("build_size_and_optional_hash", {}).get("sha256")
            == FINAL_ROM_SHA256
        ),
        "title runtime PASS": title.get("status") == "PASS",
        "title runtime final ROM": title.get("rom_sha256") == FINAL_ROM_SHA256,
        "title clean boot": (
            title.get("clean_boot", {}).get("fresh_mesen_home") is True
            and title.get("clean_boot", {}).get("uses_sav_or_savestate") is False
        ),
        "title native display": title.get("native_display") == [224, 144],
        "title blink verified": (
            title.get("press_start_blink", {}).get("verified") is True
        ),
        "title menu transition verified": (
            title.get("start_transition", {}).get("verified") is True
            and title.get("start_transition", {}).get("new_game_selected_live_match") is True
            and title.get("start_transition", {}).get("continue_unselected_live_match") is True
        ),
        "chip runtime PASS": chip.get("status") == "PASS",
        "chip inherited runtime ROM pinned": (
            chip.get("rom_sha256") == INHERITED_V0101_ROM_SHA256
        ),
        "chip clean boot": chip.get("clean_boot") is True,
        "chip native display": chip.get("native_display") == [224, 144],
        "chip visual review PASS": (
            chip.get("manual_visual_review", {}).get("status") == "PASS"
        ),
        "chip information preserved": (
            chip.get("manual_visual_review", {}).get("information_preserved") is True
        ),
        "Shop inherited runtime PASS": shop.get("status") == "PASS",
        "Shop inherited ROM pinned": (
            shop.get("final_rom", {}).get("sha256") == INHERITED_V010_ROM_SHA256
        ),
        "Free/Host inherited runtime PASS": free_host.get("status") == "PASS",
        "Free/Host inherited ROM pinned": (
            free_host.get("rom", {}).get("sha256") == INHERITED_V010_ROM_SHA256
        ),
        "PET inherited runtime PASS": pet.get("status") == "PASS",
        "PET inherited ROM pinned": (
            pet.get("rom", {}).get("sha256_before") == INHERITED_V010_ROM_SHA256
        ),
        "PET runtime left ROM unchanged": (
            pet.get("rom", {}).get("unchanged_by_validation") is True
        ),
    }
    failed = [name for name, passed in checks.items() if not passed]
    if failed:
        raise ValueError("release evidence is not final: " + ", ".join(failed))


def collect(root: Path) -> list[Path]:
    manifest_path = require(root, "translation/en_v0_10_2.json")
    manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
    files: set[Path] = {manifest_path}

    for relative in (
        "APPLY_PATCH.bat",
        "BUILD_PATCH.bat",
        "CHANGELOG.md",
        "LICENSE.txt",
        "README_ES.md",
        "RELEASE_SHA256.txt",
        "patches/Rockman_EXE_N1_Battle_English_v0.10.2.ips",
        "references/bcc_en.tbl",
        "tables/n1battle_jp.tbl",
    ):
        files.add(require(root, relative))

    for entry in manifest.get("binary_entries", []):
        asset = PurePosixPath("translation") / str(entry["asset"])
        if asset.is_absolute() or ".." in asset.parts:
            raise ValueError(f"manifest asset escapes translation/: {asset}")
        files.add(require(root, asset.as_posix()))

    # Generators, validators and tests keep the patch reproducible.
    for directory, pattern in (("tools", "*.py"), ("tests", "*.py")):
        files.update(
            path for path in (root / directory).glob(pattern) if path.is_file()
        )

    # v0.10.2 evidence plus inherited v0.10.1/v0.10 runtime evidence for
    # untouched areas. Transient emulator homes are never selected.
    files.update(
        path for path in (root / "docs").rglob("*")
        if path.is_file()
        and path.suffix.lower() in {".md", ".json", ".png", ".tsv"}
        and (
            "v0_10" in path.relative_to(root / "docs").as_posix()
            or path.name in {
                "CREDITS_ENDING_AUDIT_v0_9.json",
                "deep_text_inventory_v0_9.json",
            }
        )
    )
    files.update(
        path for path in (root / "translation/assets").glob("*")
        if path.is_file()
        and "v0_10" in path.name
        and path.suffix.lower() in {".json", ".png", ".tsv", ".md"}
    )

    required_v0102 = {
        "docs/STRUCTURAL_VALIDATION_v0_10_2.json",
        "docs/RESIDUAL_TEXT_SCAN_v0_10_2.json",
        "docs/RESIDUAL_JAPANESE_AUDIT_v0_10_2.md",
        "docs/EMULATOR_VALIDATION_v0_10_2.md",
        "docs/PROGRESO_v0_10_2.md",
        "docs/progress_v0_10_2.json",
        "docs/runtime_v0_10_2/title/title_runtime_validation_v0_10_2.json",
        "tools/validate_release_v0_10_2.py",
        "tools/audit_residual_japanese_v0_10_2.py",
        "tools/package_release_v0_10_2.py",
        "tools/title_logo_assets_v0_10_2.py",
        "tools/mesen_core_validate_title_v0_10_2.py",
        "tests/test_title_logo_v0_10_2.py",
        "translation/assets/title_logo_master_v0_10_2.png",
        "translation/assets/title_logo_master_preview_v0_10_2.png",
        "translation/assets/title_logo_asset_report_v0_10_2.json",
    }
    inherited_v0101 = {
        "docs/STRUCTURAL_VALIDATION_v0_10_1.json",
        "docs/RESIDUAL_TEXT_SCAN_v0_10_1.json",
        "docs/RESIDUAL_JAPANESE_AUDIT_v0_10_1.md",
        "docs/EMULATOR_VALIDATION_v0_10_1.md",
        "docs/PROGRESO_v0_10_1.md",
        "docs/progress_v0_10_1.json",
        "docs/runtime_v0_10_1/title/title_runtime_validation_v0_10_1.json",
        "docs/runtime_v0_10_1/chip/chip_effect_runtime_validation_v0_10_1.json",
        "tools/validate_release_v0_10_1.py",
        "tools/audit_residual_japanese_v0_10_1.py",
        "tools/chip_effect_labels_v0_10_1.py",
        "tools/mesen_core_validate_title_v0_10_1.py",
    }
    inherited_v010 = {
        "docs/runtime_v0_10/shop_runtime_validation_v0_10.json",
        "docs/runtime_v0_10/free_host_runtime_validation_v0_10.json",
        "docs/runtime_v0_10/pet_deep_runtime_validation_v0_10.json",
        "tools/shop_purchase_assets_v0_10.py",
        "tools/pet_carousel_remaining_assets_v0_10.py",
        "tools/host_free_menu_assets_v0_10.py",
        "tools/pet_runtime_remaining_assets_v0_10.py",
    }
    for relative in required_v0102 | inherited_v0101 | inherited_v010:
        files.add(require(root, relative))

    return sorted(files, key=lambda path: path.relative_to(root).as_posix())


def validate_file(root: Path, path: Path) -> dict[str, object]:
    relative = path.relative_to(root).as_posix()
    if "candidate" in relative.lower():
        raise ValueError(f"candidate artifact in public package: {relative}")
    if path.is_symlink():
        raise ValueError(f"symlink not allowed in public package: {relative}")
    suffix = path.suffix.lower()
    size = path.stat().st_size
    lowered_parts = {part.lower() for part in path.relative_to(root).parts}
    if lowered_parts & FORBIDDEN_DIRECTORIES:
        raise ValueError(f"runtime-private directory in public package: {relative}")
    if relative.startswith("docs/") and suffix not in {".md", ".json", ".png", ".tsv"}:
        raise ValueError(f"unexpected document evidence type: {relative}")
    if suffix in FORBIDDEN_SUFFIXES:
        raise ValueError(f"forbidden extension in public package: {relative}")
    if size in FORBIDDEN_SIZES:
        raise ValueError(f"forbidden ROM/save-sized file: {relative} ({size})")
    payload = path.read_bytes()
    if relative.startswith("docs/") and "v0_10" in relative and suffix in {".md", ".json", ".tsv"}:
        text = payload.decode("utf-8")
        forbidden_markers = (
            "/workspace/", "/root/", "/tmp/",
            "bddeef28419bb9f7a0dabde5b46c3283e2f913f78af895601816e500e885f76d",
            "85545d5615",
        )
        found = [marker for marker in forbidden_markers if marker in text]
        if found:
            raise ValueError(f"stale/private marker in {relative}: {found}")
    if relative.endswith(".ips"):
        if not payload.startswith(b"PATCH") or b"EOF" not in payload[-11:]:
            raise ValueError(f"malformed IPS: {relative}")
    if relative.endswith(".json"):
        json.loads(payload.decode("utf-8"))
    return {"path": relative, "size": size, "sha256": sha256(payload)}


def private_file_reasons(root: Path, path: Path) -> list[str]:
    """Return calculated reasons why a selected file would be private."""
    relative = path.relative_to(root)
    lowered_parts = {part.lower() for part in relative.parts}
    reasons: list[str] = []
    if path.suffix.lower() in FORBIDDEN_SUFFIXES:
        reasons.append("extension")
    if path.stat().st_size in FORBIDDEN_SIZES:
        reasons.append("size")
    if lowered_parts & FORBIDDEN_DIRECTORIES:
        reasons.append("directory")
    return reasons


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--project-root", type=Path,
        default=Path(__file__).resolve().parents[1],
    )
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    validate_release_evidence(root)
    output = (
        args.output or root / "dist/N1Battle_English_Project_v0.10.2.zip"
    ).resolve()
    files = collect(root)
    private_files = {
        path.relative_to(root).as_posix(): private_file_reasons(root, path)
        for path in files
        if private_file_reasons(root, path)
    }
    if private_files:
        raise ValueError(f"private files selected for public package: {private_files}")
    inventory = [validate_file(root, path) for path in files]
    output.parent.mkdir(parents=True, exist_ok=True)

    with zipfile.ZipFile(
        output, "w", compression=zipfile.ZIP_DEFLATED, compresslevel=9
    ) as archive:
        for path in files:
            relative = path.relative_to(root).as_posix()
            info = zipfile.ZipInfo(f"{PACKAGE_ROOT}/{relative}", FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(
                info, path.read_bytes(),
                compress_type=zipfile.ZIP_DEFLATED, compresslevel=9,
            )

    payload = output.read_bytes()
    report = {
        "format": "n1battle-public-release-v1",
        "project_version": "0.10.2",
        "archive": output.name,
        "archive_size": len(payload),
        "archive_sha256": sha256(payload),
        "file_count": len(inventory),
        "rom_bios_save_emulator_files": len(private_files),
        "files": inventory,
    }
    report_path = output.with_suffix(".release.json")
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    output.with_suffix(output.suffix + ".sha256").write_text(
        f"{report['archive_sha256']}  {output.name}\n", encoding="ascii"
    )
    print(json.dumps({key: report[key] for key in (
        "archive", "archive_size", "archive_sha256", "file_count",
        "rom_bios_save_emulator_files",
    )}, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
