#!/usr/bin/env python3
"""Create isolated SRAM variants for locating the Backpack inventory array."""

from __future__ import annotations

import argparse
import hashlib
from pathlib import Path


BLOCK_LAYOUTS = {
    "auxiliary": (0x4800, 0x5800),
    "player": (0x1000, 0x2000),
}
BLOCK_SIZE = 0x1000
SIGNATURE = b"INTI"


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--layout", choices=tuple(BLOCK_LAYOUTS), default="auxiliary")
    parser.add_argument("--relative-start", required=True, type=lambda value: int(value, 0))
    parser.add_argument("--length", default=0x100, type=lambda value: int(value, 0))
    parser.add_argument("--value", default=1, type=lambda value: int(value, 0))
    args = parser.parse_args()

    source = args.input.read_bytes()
    if len(source) != 0x8000:
        raise ValueError("probe source must be a 32 KiB Mesen SRAM image")
    if not 0 <= args.value <= 0xFF:
        raise ValueError("probe byte must fit in one byte")
    if args.output.exists():
        raise FileExistsError(f"refusing to overwrite {args.output}")

    output = bytearray(source)
    blocks = BLOCK_LAYOUTS[args.layout]
    for block in blocks:
        if output[block:block + 4] != SIGNATURE:
            raise ValueError(f"missing INTI signature at 0x{block:04X}")
        payload_length = int.from_bytes(output[block + 6:block + 8], "little")
        start = block + args.relative_start
        end = start + args.length
        if not block + 0x0C <= start < end <= block + 0x0C + payload_length:
            raise ValueError("requested probe range lies outside the checksummed payload")
        output[start:end] = bytes([args.value]) * args.length
        checksum = sum(output[block + 0x0C:block + 0x0C + payload_length]) & 0xFFFF
        output[block + 4:block + 6] = checksum.to_bytes(2, "little")

    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_bytes(output)
    print(f"source_sha256={sha256(source)}")
    print(f"output_sha256={sha256(output)}")
    print(
        f"layout={args.layout} blocks={','.join(f'0x{block:04X}' for block in blocks)}\n"
        f"relative_range=0x{args.relative_start:04X}-"
        f"0x{args.relative_start + args.length - 1:04X} value=0x{args.value:02X}"
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
