#!/usr/bin/env python3
"""Independent structural and runtime-evidence audit for v0.10.7 RC3."""

from __future__ import annotations

import argparse
import hashlib
import json
import sys
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import compose_release_v0_10_7_rc3 as compose  # noqa: E402
import redbox_font_assets_v0_10_7_rc3 as fontgen  # noqa: E402


VERSION = "0.10.7-rc3"
ROM_SIZE = 0x400000
BASE_ROM_SHA256 = "fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc"
FINAL_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
FINAL_IPS_SHA256 = "165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980"
EXPECTED_ORPHANS = {
    "live_program_deck": {"0x010", "0x01A", "0x01C", "0x01D", "0x01E"},
    "pet_shared_headers": {"0x044", "0x045", "0x046", "0x051", "0x052", "0x057", "0x05E", "0x066", "0x067", "0x068"},
    "netnavi_header": set(), "manual_overview": set(), "manual_stats": set(),
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def span(rom: bytes, offset: int, length: int) -> bytes:
    payload = rom[offset:offset + length]
    require(len(payload) == length, f"span 0x{offset:06X} is truncated")
    return payload


def visual_snapshot(tilemap: bytes, bank: bytes, x: int, y: int) -> tuple[int, bytes]:
    return fontgen.visual_cell_snapshot(tilemap, bank, x, y)


def assert_cells_equal(
    base_map: bytes, base_bank: bytes, final_map: bytes, final_bank: bytes,
    cells: tuple[tuple[int, int], ...], context: str,
) -> None:
    for x, y in cells:
        require(
            visual_snapshot(base_map, base_bank, x, y) == visual_snapshot(final_map, final_bank, x, y),
            f"{context} changed at ({x},{y})",
        )


def decode_rect(tilemap: bytes, bank: bytes, x: int, y: int, columns: int, rows: int) -> list[list[int]]:
    label = fontgen.MarkedLabel("audit", None, "audit", x, y, columns, rows, None, "solid", background=0)
    return fontgen.decode_rect(tilemap, bank, label)


def cropped_face_mask(canvas: list[list[int]], face: int) -> list[list[int]]:
    points = [(x, y) for y, row in enumerate(canvas) for x, value in enumerate(row) if value == face]
    require(bool(points), f"face index {face} has no pixels")
    x0, x1 = min(x for x, _ in points), max(x for x, _ in points)
    y0, y1 = min(y for _, y in points), max(y for _, y in points)
    return [[int(canvas[y][x] == face) for x in range(x0, x1 + 1)] for y in range(y0, y1 + 1)]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--base-rom", type=Path, default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.6.wsc")
    parser.add_argument("--rom", type=Path, default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.wsc")
    parser.add_argument("--ips", type=Path, default=ROOT / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.ips")
    parser.add_argument("--output", type=Path, default=ROOT / "build/validation_v0_10_7_rc3.json")
    args = parser.parse_args()

    base, final, ips = args.base_rom.read_bytes(), args.rom.read_bytes(), args.ips.read_bytes()
    require(len(base) == len(final) == ROM_SIZE, "ROM size differs from 4 MiB")
    require(sha256(base) == BASE_ROM_SHA256, "base is not the approved pixel-polished v0.10.6")
    require(sha256(final) == FINAL_ROM_SHA256, "final ROM hash differs")
    require(sha256(ips) == FINAL_IPS_SHA256, "final IPS hash differs")
    require(int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF, "WonderSwan checksum is invalid")

    allowed = bytearray(ROM_SIZE)
    for patch in compose.PATCHES:
        allowed[patch.offset:patch.offset + patch.length] = b"\x01" * patch.length
    allowed[-2:] = b"\x01\x01"
    changed = [index for index, (left, right) in enumerate(zip(base, final)) if left != right]
    outside = [index for index in changed if not allowed[index]]
    require(not outside, f"changes outside allowlist: {outside[:8]}")
    require(len(changed) == 4016, f"expected 4016 changed ROM bytes, found {len(changed)}")

    asset_report = json.loads((ROOT / "translation/assets/redbox_font_asset_report_v0_10_7_rc3.json").read_text())
    build_report = json.loads((ROOT / "build/build_v0_10_7_rc3_delta.json").read_text())
    manifest = json.loads((ROOT / "translation/en_v0_10_7_rc3.json").read_text())
    pet_runtime = json.loads((ROOT / "docs/runtime_v0_10_7_rc3/pet_deep/redbox_pet_runtime_validation_v0_10_7_rc3.json").read_text())
    deck_runtime = json.loads((ROOT / "docs/runtime_v0_10_7_rc3/program_deck/program_deck_runtime_validation_v0_10_7_rc3.json").read_text())
    require(asset_report["status"] == build_report["status"] == "PASS", "asset/build report is not PASS")
    require(not asset_report["rc2_assets_reused"] and not build_report["rc2_reused"], "RC2 material was reused")
    require(asset_report["marked_text_instances"] == 17, "marked semantic count differs")
    require(asset_report["corrected_text_instances"] == 18, "corrected semantic count differs")
    require(asset_report["rendered_text_segments"] == 19, "rendered segment count differs")
    require(asset_report["removed_non_text_symbols"] == 1, "symbol removal count differs")
    require(len(compose.PATCHES) == 12, "allowlist must contain twelve guarded spans")
    require(len(manifest["binary_entries"]) == 80, "manifest must contain eighty binary entries")
    require(manifest["project_version"] == VERSION, "manifest version differs")

    outputs = asset_report["outputs"]
    for patch in compose.PATCHES:
        path = ROOT / "translation/assets" / patch.file
        payload = path.read_bytes()
        row = outputs[patch.file]
        require(len(payload) == patch.length == row["length"], f"{patch.id}: length mismatch")
        require(sha256(payload) == row["sha256"], f"{patch.id}: output hash mismatch")
        require(final[patch.offset:patch.offset + patch.length] == payload, f"{patch.id}: asset not embedded")
        if "map" in patch.id:
            before = base[patch.offset:patch.offset + patch.length]
            for position in range(0, patch.length, 2):
                old = int.from_bytes(before[position:position + 2], "little")
                new = int.from_bytes(payload[position:position + 2], "little")
                require(not ((old ^ new) & ~fontgen.TILE_MASK), f"{patch.id}: map attributes changed")

    for name, expected in EXPECTED_ORPHANS.items():
        group = asset_report["groups"][name]
        require(set(group["orphan_allowlist"]) == expected, f"{name}: orphan allowlist differs")
        require(set(group["changed_orphan_tile_ids"]).issubset(expected), f"{name}: changed unlisted orphan")
        require(group["orphan_allowlist_all_unreferenced"], f"{name}: orphan has a consumer")
        require(group["tile_aliases_outside_targets"] == 0, f"{name}: external tile alias")

    base_program_map = span(base, 0x04323C, 0x0680)
    final_program_map = span(final, 0x04323C, 0x0680)
    base_program_tiles = span(base, 0x07CD20, 0x1EF0)
    final_program_tiles = span(final, 0x07CD20, 0x1EF0)
    assert_cells_equal(
        base_program_map, base_program_tiles, final_program_map, final_program_tiles,
        ((27, 0), (27, 1)), "Y2 functional pictogram",
    )
    assert_cells_equal(
        base_program_map, base_program_tiles, final_program_map, final_program_tiles,
        ((18, 1),), "unmarked tiny Program Deck cell",
    )
    symbol_pattern = visual_snapshot(final_program_map, final_program_tiles, 17, 0)[1]
    require(symbol_pattern == fontgen.tile_pattern(final_program_tiles, 0x00D), "unrelated symbol was not cleared")

    base_shared_tiles = span(base, 0x07EC10, 0x16C0)
    final_shared_tiles = span(final, 0x07EC10, 0x16C0)
    base_auto, final_auto = span(base, 0x0438BE, 0x0680), span(final, 0x0438BE, 0x0680)
    assert_cells_equal(base_auto, base_shared_tiles, final_auto, final_shared_tiles, ((16, 0), (16, 1)), "AUTO CONTROL icon")
    base_chip, final_chip = span(base, 0x043F40, 0x0680), span(final, 0x043F40, 0x0680)
    require(base_chip == final_chip, "unmarked CHIP FOLDER map changed")
    require(
        fontgen.visual_map_sha256(base_chip, base_shared_tiles) == fontgen.visual_map_sha256(final_chip, final_shared_tiles),
        "unmarked CHIP FOLDER visuals changed through shared tiles",
    )

    base_manual_tiles = span(base, 0x0ACA20, 0x5B60)
    final_manual_tiles = span(final, 0x0ACA20, 0x5B60)
    base_overview, final_overview = span(base, 0x04E7A2, 0x0400), span(final, 0x04E7A2, 0x0400)
    assert_cells_equal(
        base_overview, base_manual_tiles, final_overview, final_manual_tiles,
        ((1, 2), (6, 2), (3, 7), (6, 7), (27, 7)), "manual mixed artwork",
    )

    live_program_mask = cropped_face_mask(decode_rect(final_program_map, final_program_tiles, 11, 0, 6, 2), 12)
    manual_program_mask = cropped_face_mask(decode_rect(final_overview, final_manual_tiles, 1, 1, 6, 1), 7)
    require(live_program_mask == manual_program_mask, "PROGRAM DECK masks are not uniform")
    final_net_tiles = span(final, 0x080300, 0x0D40)
    root_net = span(final, 0x0452C6, 0x0480)
    stats_net = span(final, 0x045748, 0x0480)
    require(
        cropped_face_mask(decode_rect(root_net, final_net_tiles, 11, 0, 6, 2), 10)
        == cropped_face_mask(decode_rect(stats_net, final_net_tiles, 11, 0, 6, 2), 10),
        "NETNAVI masks are not uniform",
    )
    stats_canvas = decode_rect(stats_net, final_net_tiles, 11, 0, 6, 2)
    require(stats_canvas[3][40] == stats_canvas[3][42] == 4, "NETNAVI accent pixels changed")

    require(pet_runtime["status"] == "PASS" and pet_runtime["native_captures"] == 10, "PET runtime evidence incomplete")
    require(pet_runtime["clean_boot_routes"] == 5 and pet_runtime["uses_sav_or_savestate"] is False, "PET runtime was not clean")
    require(deck_runtime["status"] == "PASS" and len(deck_runtime["captures"]) == 3, "Program Deck runtime evidence incomplete")
    require(deck_runtime["stats_top_224x80_matches_active_palette_asset_pixel_exactly"], "statistics runtime pixels differ")
    require(deck_runtime["lower_dialogue_region_matches_approved_reference_pixel_exactly"], "lower dialogue changed")
    require(not (ROOT / "translation/assets/pet_submenu_auto_control_bg0_map_v0_10_7_rc3.bin").exists(), "obsolete wrong-map asset remains")

    result = {
        "status": "PASS", "version": VERSION,
        "base_rom_sha256": BASE_ROM_SHA256,
        "final_rom_sha256": FINAL_ROM_SHA256,
        "final_ips_sha256": FINAL_IPS_SHA256,
        "checksum": f"0x{int.from_bytes(final[-2:], 'little'):04X}",
        "changed_bytes_vs_v0_10_6": len(changed), "outside_allowlist": len(outside),
        "guarded_spans": len(compose.PATCHES), "manifest_binary_entries": len(manifest["binary_entries"]),
        "marked_text_instances": asset_report["marked_text_instances"],
        "harmonized_duplicates": asset_report["harmonized_duplicate_instances"],
        "removed_non_text_symbols": asset_report["removed_non_text_symbols"],
        "tile_aliases_outside_targets": 0,
        "protected_visual_cells": "PASS",
        "uniform_program_deck_masks": True, "uniform_netnavi_masks": True,
        "bottom_dialogue_modified": False,
        "runtime": {"clean_boot_routes": 6, "native_captures": 13, "status": "PASS"},
        "rc2_assets_reused": False,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n")
    print(json.dumps(result, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
