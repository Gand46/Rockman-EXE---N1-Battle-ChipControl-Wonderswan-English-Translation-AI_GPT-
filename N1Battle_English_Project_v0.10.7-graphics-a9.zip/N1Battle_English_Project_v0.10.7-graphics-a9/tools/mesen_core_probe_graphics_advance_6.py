#!/usr/bin/env python3
"""Capture the live Chip Folder state, including WonderSwan I/O ports.

This is a read-only diagnostic probe for Graphics Advance 6.  It boots the
given ROM in a fresh MesenCore home, follows the deterministic Chip route,
and captures CPU memory, WonderSwan WRAM, WonderSwan ports, and one native
screenshot at frame 27320.
"""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

import mesen_core_validate_pet_deep_v0_10 as legacy


MEM_CPU = 13
MEM_WS_WRAM = 84
MEM_WS_PORT = 89
CPU_WS = 12
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
TARGET_FRAME = 27320
STOP_FRAME = 27340


class TraceLoggerOptions(ctypes.Structure):
    _fields_ = [
        ("Enabled", ctypes.c_bool),
        ("IndentCode", ctypes.c_bool),
        ("UseLabels", ctypes.c_bool),
        ("Condition", ctypes.c_char * 1000),
        ("Format", ctypes.c_char * 1000),
    ]


class AddressCounters(ctypes.Structure):
    _fields_ = [
        ("ReadStamp", ctypes.c_uint64),
        ("WriteStamp", ctypes.c_uint64),
        ("ExecStamp", ctypes.c_uint64),
        ("ReadCounter", ctypes.c_uint32),
        ("WriteCounter", ctypes.c_uint32),
        ("ExecCounter", ctypes.c_uint32),
    ]


class AddressInfo(ctypes.Structure):
    _fields_ = [
        ("Address", ctypes.c_int32),
        ("Type", ctypes.c_int32),
    ]


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--seed-save", type=Path)
    parser.add_argument("--route-mode", choices=("chip", "save", "manual"), default="chip")
    parser.add_argument("--target-frame", default=TARGET_FRAME, type=int)
    parser.add_argument("--stop-frame", default=STOP_FRAME, type=int)
    parser.add_argument("--trace-start-frame", type=int)
    parser.add_argument("--trace-stop-frame", type=int)
    parser.add_argument("--access-reset-frame", type=int)
    parser.add_argument(
        "--probe-button",
        choices=("A", "B", "Y", "U", "D", "L", "R", "Up", "Down", "Left", "Right"),
        help="replace the route's frame-27400 A pulse with this diagnostic button",
    )
    parser.add_argument(
        "--extra-pulse",
        action="append",
        default=[],
        metavar="BUTTON@FRAME",
        help="add an isolated eight-frame diagnostic pulse (repeatable)",
    )
    parser.add_argument(
        "--memory-write",
        action="append",
        default=[],
        metavar="ADDRESS=VALUE@FRAME",
        help="write one diagnostic CPU-memory byte at one completed frame",
    )
    parser.add_argument(
        "--absolute-address",
        action="append",
        default=[],
        type=lambda value: int(value, 0),
        metavar="ADDRESS",
        help="resolve one physical CPU address at the capture frame (repeatable)",
    )
    parser.add_argument("--timeout", default=120.0, type=float)
    args = parser.parse_args()
    if args.stop_frame <= args.target_frame:
        raise ValueError("stop frame must follow target frame")

    args.output_dir.mkdir(parents=True, exist_ok=True)
    home = args.output_dir / "mesen_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)
    if args.seed_save:
        save_dir = home / "Saves"
        save_dir.mkdir(parents=True)
        shutil.copy2(args.seed_save, save_dir / f"{args.rom.stem}.sav")

    route = legacy.route_by_name("chip")
    extra_pulses: list[tuple[str, int]] = []
    valid_buttons = {"A", "B", "Y", "U", "D", "L", "R", "Up", "Down", "Left", "Right"}
    for specification in args.extra_pulse:
        try:
            button, frame_text = specification.split("@", 1)
            first = int(frame_text, 0)
        except ValueError as exc:
            raise ValueError(f"invalid pulse specification: {specification}") from exc
        if button not in valid_buttons or first < 0:
            raise ValueError(f"invalid pulse specification: {specification}")
        extra_pulses.append((button, first))
    memory_writes: list[tuple[int, int, int]] = []
    for specification in args.memory_write:
        try:
            assignment, frame_text = specification.split("@", 1)
            address_text, value_text = assignment.split("=", 1)
            address = int(address_text, 0)
            value = int(value_text, 0)
            frame = int(frame_text, 0)
        except ValueError as exc:
            raise ValueError(f"invalid memory write: {specification}") from exc
        if not 0 <= address <= 0xFFFF or not 0 <= value <= 0xFF or frame < 0:
            raise ValueError(f"invalid memory write: {specification}")
        memory_writes.append((address, value, frame))

    def input_for_frame(frame: int) -> legacy.Controller:
        if args.route_mode == "chip":
            state = legacy.input_for_frame(route, frame)
        else:
            state = legacy.Controller(X=True)
            state.Start = legacy.pulse(frame, 650, 10)
            state.A = legacy.pulse(frame, 950)
            if args.route_mode == "save":
                state.A = (
                    state.A
                    or (1200 <= frame <= 26708 and frame % 300 < 8)
                    or legacy.pulse(frame, 26920)
                )
            if args.route_mode == "save":
                state.A = state.A or legacy.pulse(frame, 27300)
                state.Down = any(
                    legacy.pulse(frame, first)
                    for first in (27040, 27100, 27160, 27220)
                )
        if args.probe_button and 27400 <= frame < 27408:
            state.A = False
            setattr(state, args.probe_button, True)
        for button, first in extra_pulses:
            if first <= frame < first + 8:
                setattr(state, button, True)
        return state

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    legacy.configure_core(lib)
    lib.SetTraceOptions.argtypes = [ctypes.c_uint8, TraceLoggerOptions]
    lib.StartLogTraceToFile.argtypes = [ctypes.c_char_p]
    lib.StopLogTraceToFile.argtypes = []
    lib.GetMemoryAccessCounts.argtypes = [
        ctypes.c_uint32, ctypes.c_uint32, ctypes.c_int,
        ctypes.POINTER(AddressCounters),
    ]
    lib.SetMemoryValue.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint8]
    lib.GetAbsoluteAddress.argtypes = [AddressInfo]
    lib.GetAbsoluteAddress.restype = AddressInfo
    callback_type = lib._pet_deep_callback_type
    completed = 0
    memory: dict[str, bytes] = {}
    save_access: list[dict[str, int]] = []
    absolute_addresses: list[dict[str, int]] = []
    captured = threading.Event()
    finished = threading.Event()
    trace_path = args.output_dir / "execution_trace.log"
    trace_active = False

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed, trace_active
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        for address, value, frame in memory_writes:
            if completed == frame:
                lib.SetMemoryValue(MEM_CPU, address, value)
        if args.access_reset_frame is not None and completed == args.access_reset_frame:
            lib.ResetMemoryAccessCounts()
        if args.trace_start_frame is not None and completed == args.trace_start_frame:
            trace_options = TraceLoggerOptions()
            trace_options.Enabled = True
            trace_options.Format = (
                b"[Disassembly][EffectiveAddress] [MemoryValue,h][Align,48] "
                b"AX:[AX,4h] BX:[BX,4h] CX:[CX,4h] "
                b"DX:[DX,4h] DS:[DS,4h] ES:[ES,4h] SS:[SS,4h] SP:[SP,4h] "
                b"BP:[BP,4h] SI:[SI,4h] DI:[DI,4h] F:[F,4h]"
            )
            lib.SetTraceOptions(CPU_WS, trace_options)
            lib.StartLogTraceToFile(str(trace_path.resolve()).encode())
            trace_active = True
        if args.trace_stop_frame is not None and completed == args.trace_stop_frame and trace_active:
            lib.StopLogTraceToFile()
            trace_active = False
        lib.SetInputOverrides(0, input_for_frame(completed + 1))
        if completed == args.target_frame:
            lib.TakeScreenshot()
            for memory_type, name, length in (
                (MEM_CPU, "cpu", 0x10000),
                (MEM_WS_WRAM, "wram", 0x10000),
                (MEM_WS_PORT, "ports", 0x100),
            ):
                buffer = (ctypes.c_uint8 * length)()
                lib.GetMemoryValues(memory_type, 0, length, buffer)
                memory[name] = bytes(buffer)
            for address in args.absolute_address:
                resolved = lib.GetAbsoluteAddress(AddressInfo(address, MEM_CPU))
                absolute_addresses.append({
                    "physical_address": address,
                    "absolute_address": resolved.Address,
                    "memory_type": resolved.Type,
                })
            if args.access_reset_frame is not None:
                access_start, access_length = 0x0000, 0x10000
                counters = (AddressCounters * access_length)()
                lib.GetMemoryAccessCounts(access_start, access_length, MEM_CPU, counters)
                for index, counter in enumerate(counters):
                    if counter.ReadCounter or counter.WriteCounter or counter.ExecCounter:
                        save_access.append({
                            "address": access_start + index,
                            "reads": counter.ReadCounter,
                            "writes": counter.WriteCounter,
                            "executes": counter.ExecCounter,
                        })
            captured.set()
        if completed >= args.stop_frame:
            finished.set()

    listener = None
    started = time.monotonic()
    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not finished.wait(args.timeout):
            raise TimeoutError(f"probe timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.25)
    finally:
        if trace_active:
            lib.StopLogTraceToFile()
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    if not captured.is_set() or set(memory) != {"cpu", "wram", "ports"}:
        raise RuntimeError("target-frame capture is incomplete")
    for name, payload in memory.items():
        (args.output_dir / f"chip_folder_{name}_{args.target_frame}.bin").write_bytes(payload)

    deadline = time.monotonic() + 5
    while not list(screenshot_dir.glob("*.png")) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != 1:
        raise RuntimeError(f"expected one screenshot, found {len(screenshots)}")
    screenshot = args.output_dir / f"chip_folder_{args.target_frame}.png"
    shutil.copy2(screenshots[0], screenshot)

    report = {
        "probe": "graphics_advance_6_chip_quantity_layer",
        "rom": str(args.rom),
        "rom_sha256": sha256(args.rom.read_bytes()),
        "mesen_core_sha256": sha256(args.mesen_core.read_bytes()),
        "clean_boot": True,
        "route": args.route_mode,
        "target_frame": args.target_frame,
        "stop_frame": args.stop_frame,
        "trace": {
            "start_frame": args.trace_start_frame,
            "stop_frame": args.trace_stop_frame,
            "file": trace_path.name if trace_path.exists() else None,
            "bytes": trace_path.stat().st_size if trace_path.exists() else 0,
        },
        "memory_access": {
            "reset_frame": args.access_reset_frame,
            "range": [0x0000, 0x10000],
            "nonzero_addresses": save_access,
        },
        "probe_button": args.probe_button,
        "extra_pulses": [
            {"button": button, "frame": frame, "duration_frames": 8}
            for button, frame in extra_pulses
        ],
        "memory_writes": [
            {"address": address, "value": value, "frame": frame}
            for address, value, frame in memory_writes
        ],
        "absolute_addresses": absolute_addresses,
        "seed_save": str(args.seed_save) if args.seed_save else None,
        "elapsed_seconds": round(time.monotonic() - started, 3),
        "captures": {
            name: {"bytes": len(payload), "sha256": sha256(payload)}
            for name, payload in memory.items()
        },
        "screenshot": screenshot.name,
        "screenshot_sha256": sha256(screenshot.read_bytes()),
    }
    (args.output_dir / "probe_report.json").write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
