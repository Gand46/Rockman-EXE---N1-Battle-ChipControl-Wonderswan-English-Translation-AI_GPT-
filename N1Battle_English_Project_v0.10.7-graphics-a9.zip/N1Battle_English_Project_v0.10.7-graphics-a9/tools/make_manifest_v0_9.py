#!/usr/bin/env python3
"""Create the expanded v0.9 manifest from the audited v0.8 baseline."""

from __future__ import annotations

import argparse
import copy
import hashlib
import json
from pathlib import Path
from typing import Any


SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_MANIFEST_SHA256 = "82183ee3ebb91376d95b367bceca97b87aab22b4cf6d9fac07d26fec6ad3eef8"


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def number(value: int | str) -> int:
    return value if isinstance(value, int) else int(value, 0)


def binary_entry(
    entry_id: str, offset: int, length: int, expected: str, asset: str
) -> dict[str, Any]:
    return {
        "id": entry_id,
        "offset": f"0x{offset:06X}",
        "length": length,
        "expected_sha256": expected,
        "asset": f"assets/{asset}",
    }


NEW_BINARY_ENTRIES = [
    binary_entry(
        "location_shop_bg0_map", 0x041BB2, 0x0480,
        "c865ab0fed96a66bc02494d72411bd965b38168a010a6fa118696ec7970bbe36",
        "location_shop_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "location_battlechip_gp_bg0_map", 0x042034, 0x0480,
        "b5f0188ed5f4671193e892107d5799683ed3788604f228199ed293bbefa79cb1",
        "location_battlechip_gp_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_chip_folder_bg0_map", 0x043F40, 0x680,
        "20f8cc49ceec3ca227a9f3d7f1b1882b05fb51458afdab5fa0c5abe6fa4ee2c4",
        "pet_submenu_chip_folder_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_data_library_bg0_map", 0x044C44, 0x680,
        "07ebe88de45c645949f644ff211d3b2333e02d332122d493abe0bd129d50699e",
        "pet_submenu_data_library_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_netnavi_bg0_map", 0x0452C6, 0x480,
        "a9c6a387067b6b0f062e03e22f78aeb7f75f3939534b4bb0119045ddcc4278b2",
        "pet_submenu_netnavi_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_save_bg0_map", 0x045BCA, 0x480,
        "3af1dc0c58926b8947e67f789145694fafc2d2c8adc0c86415e4c78264dbda17",
        "pet_submenu_save_bg0_map_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_chip_library_tiles", 0x07EC10, 0x16C0,
        "848239b8a63279baf5f7e2c243d97f677fa810fc6f1699f8b5aa3920fb1a707c",
        "pet_submenu_chip_library_tiles_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_netnavi_tiles", 0x080300, 0x0D40,
        "48d4c0245741ce07669fc476817f6d440dbde161c0b5ce1788ce030942c2a539",
        "pet_submenu_netnavi_tiles_v0_9.bin",
    ),
    binary_entry(
        "pet_submenu_save_tiles", 0x081070, 0x0800,
        "80911b2f494f5671a1ca1d701e7e84af47533194cceffa7cba5fe2fa1e7b1863",
        "pet_submenu_save_tiles_v0_9.bin",
    ),
    binary_entry(
        "location_shop_bg0_tiles", 0x0768F0, 0x1740,
        "d40c25251dd92512fb4fd47b6d10be9acbfff0a7031f69aa3ed0dea0b376a611",
        "location_shop_bg0_tiles_v0_9.bin",
    ),
    binary_entry(
        "location_battlechip_gp_bg0_tiles", 0x078100, 0x1480,
        "1c100a2e11fb98b8fc046557e3dbeb1a23677537219d31d02fcfa98338b6cce8",
        "location_battlechip_gp_bg0_tiles_v0_9.bin",
    ),
    binary_entry(
        "tournament_header_top", 0x08C2F0, 0x00E0,
        "94392a0f57f43ba1c722451cd873d126dd7ef18dbd441c7d74a09d115ae95dd1",
        "tournament_header_top_tiles_v0_9.bin",
    ),
    binary_entry(
        "tournament_header_bottom", 0x08C430, 0x00E0,
        "188d7ef4dee5d29e08fe7e82c69f2fdf6bb38f02422de560f2f05446d3e44a26",
        "tournament_header_bottom_tiles_v0_9.bin",
    ),
    binary_entry(
        "lan_room_poster_bg0_tiles", 0x0A7900, 0x3000,
        "f028469173d41f02e635fd8544a5c4d14c9622fed33378ee58e2a47c1d991c1a",
        "lan_room_poster_bg0_tiles_v0_9.bin",
    ),
    binary_entry(
        "program_deck_transfer_text", 0x2E9EE0, 0x0300,
        "526049c4368e60a6be09130afcab7a536fcb5a758184883e80bb2b77a0ab6f19",
        "program_deck_transfer_text_tiles_v0_9.bin",
    ),
    binary_entry(
        "tournament_phase_renderer", 0x328F10, 0x0070,
        "d2d2414673d9a6348792821130a41277baed4a156cdc4f4308b6d61fc7151179",
        "tournament_phase_renderer_v0_9.bin",
    ),
    binary_entry(
        "tournament_phase_text_pool", 0x344688, 0x0034,
        "7955cb2de90dd9efc6df9fdbf5f5d10c114f4135a9a6b52db1003be749e32f7a",
        "tournament_phase_text_pool_v0_9.bin",
    ),
    binary_entry(
        "auxiliary_text_pointers", 0x34AB10, 0x01A0,
        "2ecc503144cc5245736e8b49b7d69ebf7b32a025ec7cf46a2bafca713d84f70f",
        "aux_text_pointers_v0_9.bin",
    ),
    binary_entry(
        "auxiliary_text_pool", 0x34ACB0, 0x0AAE,
        "600926c8e902301f668b2b376a90220dda678700a7e5a32745b0643f01228f0d",
        "aux_text_pool_v0_9.bin",
    ),
    binary_entry(
        "database_participant_names", 0x367660, 0x048A,
        "a611660b821386a2a38ae5b659432e588ed938bc541c9700d0dde9b1a2752a99",
        "participant_names_data_v0_9.bin",
    ),
    binary_entry(
        "database_participant_name_pointers", 0x367AEA, 0x0124,
        "2f9e390400a38020a528f5e687a2eb310cf10259ade1d96be7f9c19a85b3544c",
        "participant_names_pointers_v0_9.bin",
    ),
    binary_entry(
        "battle_messages_b1_data", 0x37CC30, 0x0BC4,
        "a3e586701f5ccb8f165dff1e0a4ca7e8e322301d14692deff7d4ae70adc8c578",
        "battle_messages_b1_data_v0_9.bin",
    ),
    binary_entry(
        "battle_messages_b1_pointers", 0x37D7F4, 0x02EC,
        "ba5c8533a43908ce23fd552f3962a6ab0c5313569d21f0c2291eb2f450d43c12",
        "battle_messages_b1_pointers_v0_9.bin",
    ),
    binary_entry(
        "battle_messages_b2_data", 0x37DAE0, 0x05EC,
        "f92001a5d80e860ddbd261742198a7d1ee883f54397bf16df8b46f4696feb1aa",
        "battle_messages_b2_data_v0_9.bin",
    ),
    binary_entry(
        "battle_messages_b2_pointers", 0x37E0CC, 0x0170,
        "499067c64f7bb216b6b609f670a21866db28631f16b18854dd958198aad27f60",
        "battle_messages_b2_pointers_v0_9.bin",
    ),
]


REPLACEMENTS = {
    "name_keyboard_bg0_map": {
        "asset": "assets/name_keyboard_bg0_map_v0_9.bin",
    },
    "name_keyboard_tiles": {
        "asset": "assets/name_keyboard_tiles_v0_9.bin",
    },
    "program_deck_live_ui_tiles": {
        "length": 0x1EF0,
        "expected_sha256": "ef6d011c4d289338ecbd8c3bdf93da37b271295b442c066e3963ea0d1421bd97",
        "asset": "assets/program_deck_live_ui_tiles_v0_9.bin",
    },
    "program_deck_manual_internal_tiles": {
        "asset": "assets/program_deck_manual_internal_tiles_v0_9.bin",
    },
}


OVERWRITE_ENTRY = {
    "id": "ui_overwrite_data_direct",
    "offset": "0x3578AE",
    "length": 58,
    "expected_sha256": "5cad769b64454e5ce4f5455ba8c80b8f8c7aaf2f0f4cd7ad09102a0936a78d65",
    "source_summary": "Direct/alternate existing-save overwrite confirmation",
    "translation": "[PORTRAIT:04][RAW:0C00]Overwrite data?[LINE]  Yes[LINE]  No",
    "terminator": "END",
    "pad_after_terminator": True,
}


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=Path(__file__).resolve().parents[1])
    parser.add_argument("--source-rom", type=Path, required=True)
    parser.add_argument("--output", type=Path)
    args = parser.parse_args()

    root = args.project_root.resolve()
    source = args.source_rom.read_bytes()
    if len(source) != 0x400000 or sha256(source) != SOURCE_SHA256:
        raise ValueError("unexpected source ROM; expected verified Japanese Rev 1")
    base_path = root / "translation" / "en_v0_8.json"
    base_bytes = base_path.read_bytes()
    if sha256(base_bytes) != BASE_MANIFEST_SHA256:
        raise ValueError("v0.8 baseline manifest hash changed")
    manifest = copy.deepcopy(json.loads(base_bytes.decode("utf-8")))
    manifest["project_version"] = "0.9.0"
    manifest["scope"] = (
        "Expanded deep-audit English release: all v0.8 content plus the auxiliary UI/credits "
        "pool, all battle/result messages, preset participant names, overwrite prompt, fully "
        "English keyboard pages, PET submenu labels, NORMAL30, tournament header and phase "
        "labels, Program Deck transfer status, Shop/BattleChip GP location graphics, and the "
        "Mega Man Legends 2 poster in Lan's room (abbreviated MM/L2 at native resolution)."
    )
    manifest["expanded_inventory"] = {
        "text_units": {"translated": 1552, "denominator": 1552},
        "newly_recovered_text_units": 347,
        "graphical_occurrences": {"translated": 75, "denominator": 75},
        "known_residual_japanese_targets": 0,
    }

    entries = manifest["entries"]
    if any(entry.get("id") == OVERWRITE_ENTRY["id"] for entry in entries):
        raise ValueError("overwrite entry already exists in baseline")
    entries.append(OVERWRITE_ENTRY)

    binary_entries = manifest["binary_entries"]
    seen_replacements: set[str] = set()
    for entry in binary_entries:
        entry_id = str(entry.get("id"))
        if entry_id in REPLACEMENTS:
            entry.update(REPLACEMENTS[entry_id])
            seen_replacements.add(entry_id)
    if seen_replacements != set(REPLACEMENTS):
        raise ValueError(f"missing baseline binary entries: {sorted(set(REPLACEMENTS) - seen_replacements)}")
    binary_entries.extend(copy.deepcopy(NEW_BINARY_ENTRIES))
    binary_entries.sort(key=lambda item: (number(item["offset"]), str(item["id"])))

    spans: list[tuple[int, int, str]] = []
    for entry in [*entries, *binary_entries]:
        start, length = number(entry["offset"]), number(entry["length"])
        end = start + length
        if not (0 <= start < end <= len(source) - 2):
            raise ValueError(f"{entry['id']}: span outside ROM")
        expected = str(entry.get("expected_sha256", ""))
        expected_hex = str(entry.get("expected_hex", "")).replace(" ", "")
        if expected and sha256(source[start:end]) != expected:
            raise ValueError(f"{entry['id']}: source hash mismatch")
        if expected_hex and source[start:end] != bytes.fromhex(expected_hex):
            raise ValueError(f"{entry['id']}: source bytes mismatch")
        for old_start, old_end, old_id in spans:
            if max(start, old_start) < min(end, old_end):
                raise ValueError(f"{entry['id']}: overlaps {old_id}")
        spans.append((start, end, str(entry["id"])))

    for entry in binary_entries:
        asset_path = root / "translation" / str(entry["asset"])
        asset = asset_path.read_bytes()
        if len(asset) != number(entry["length"]):
            raise ValueError(f"{entry['id']}: asset length mismatch")
        entry["asset_sha256"] = sha256(asset)

    output = (args.output or root / "translation" / "en_v0_9.json").resolve()
    output.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(manifest, ensure_ascii=False, indent=2) + "\n"
    output.write_text(rendered, encoding="utf-8")
    print(json.dumps({
        "output": output.name,
        "sha256": sha256(rendered.encode("utf-8")),
        "text_entries": len(entries),
        "binary_entries": len(binary_entries),
        "overlap_free": True,
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
