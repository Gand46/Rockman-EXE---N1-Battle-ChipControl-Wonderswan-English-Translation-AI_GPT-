#!/usr/bin/env python3
"""Validate the effect-label-only N1 Battle English v0.10.5 release."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from collections import defaultdict
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
import bcc_reference as bcc  # noqa: E402
import chip_effect_labels_v0_10_5 as effects  # noqa: E402
import compose_release_v0_10_4 as ips_tools  # noqa: E402


VERSION = "0.10.5"
ROM_SIZE = 0x400000
SOURCE_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
FINAL_ROM_SHA256 = "e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf"
BASE_IPS_SHA256 = "025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b"
FINAL_IPS_SHA256 = "06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae"
ASSET_SHA256 = "9973bd4e3042d71189c26ea6ab852c5b86472aba0b35396e08be2cc048aea52f"
POINTER_SHA256 = "baf060ade9e8198c881aed504201809ea369796001993fb4a23b48086fe28460"
EFFECT_OFFSET = 0x369550
EFFECT_LENGTH = 0x0F90
POINTER_OFFSET = 0x369160
POINTER_LENGTH = 0x03E4


def sha256(payload: bytes | bytearray) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_json(path: Path) -> dict[str, Any]:
    payload = json.loads(path.read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError(f"expected JSON object: {path}")
    return payload


def check(ok: bool, **details: Any) -> dict[str, Any]:
    return {"result": "PASS" if ok else "FAIL", **details}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def decoded_table_rows(
    rom: bytes, pointer_start: int, count: int, label: str,
    decode: dict[int, str],
) -> list[dict[str, Any]]:
    rows = []
    for index in range(count):
        pointer = bcc.wsc_pointer(rom, pointer_start, index, label)
        words = bcc.read_words(rom, pointer, f"{label}[{index}]")
        rows.append({
            "index": index,
            "pointer": pointer,
            "text": bcc.decode_gba_words(words, decode),
            "record_bytes": len(words) * 2,
        })
    return rows


def manifest_delta(old: dict[str, Any], new: dict[str, Any]) -> list[str]:
    failures: list[str] = []
    if old.get("entries") != new.get("entries"):
        failures.append("text entries changed")
    if old.get("official_reference") != new.get("official_reference"):
        failures.append("official reference changed")
    old_rows = {row.get("id"): row for row in old.get("binary_entries", [])}
    new_rows = {row.get("id"): row for row in new.get("binary_entries", [])}
    if old_rows.keys() != new_rows.keys():
        failures.append("binary entry IDs changed")
    for entry_id in old_rows.keys() & new_rows.keys():
        before = dict(old_rows[entry_id])
        after = dict(new_rows[entry_id])
        if entry_id == "database_effect_labels":
            before.pop("asset", None)
            before.pop("asset_sha256", None)
            after.pop("asset", None)
            after.pop("asset_sha256", None)
        if before != after:
            failures.append(f"unexpected binary delta: {entry_id}")
    return failures


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--project-root", type=Path, default=ROOT)
    parser.add_argument("--base-rom", type=Path)
    parser.add_argument("--rom", type=Path)
    parser.add_argument("--report", type=Path)
    args = parser.parse_args()
    root = args.project_root.resolve()
    base_path = args.base_rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.4.wsc"
    rom_path = args.rom or root / "build/Rockman_EXE_N1_Battle_English_v0.10.5.wsc"
    report_path = args.report or root / "docs/STRUCTURAL_VALIDATION_v0_10_5.json"

    report: dict[str, Any] = {
        "format": "n1battle-structural-validation-v0.10.5",
        "project_version": VERSION,
        "overall_result": "FAIL",
        "checks": {},
        "failures": [],
    }
    try:
        base = base_path.read_bytes()
        final = rom_path.read_bytes()
        base_ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.4.ips").read_bytes()
        final_ips = (root / "patches/Rockman_EXE_N1_Battle_English_v0.10.5.ips").read_bytes()
        old_manifest = load_json(root / "translation/en_v0_10_4.json")
        manifest = load_json(root / "translation/en_v0_10_5.json")

        identity_ok = (
            len(base) == len(final) == ROM_SIZE
            and sha256(base) == BASE_ROM_SHA256
            and sha256(final) == FINAL_ROM_SHA256
        )
        report["checks"]["rom_identity"] = check(
            identity_ok, size=len(final), base_sha256=sha256(base),
            final_sha256=sha256(final), expected_final_sha256=FINAL_ROM_SHA256,
        )

        stored = int.from_bytes(final[-2:], "little")
        calculated = sum(final[:-2]) & 0xFFFF
        report["checks"]["wonderswan_checksum"] = check(
            stored == calculated, stored=f"0x{stored:04X}", calculated=f"0x{calculated:04X}",
        )

        changed = [index for index, (a, b) in enumerate(zip(base, final)) if a != b]
        allowed = bytearray(ROM_SIZE)
        allowed[EFFECT_OFFSET:EFFECT_OFFSET + EFFECT_LENGTH] = b"\x01" * EFFECT_LENGTH
        allowed[-2:] = b"\x01\x01"
        outside = [index for index in changed if not allowed[index]]
        effect_changed = [index for index in changed if EFFECT_OFFSET <= index < EFFECT_OFFSET + EFFECT_LENGTH]
        report["checks"]["v0_10_4_to_v0_10_5_allowlist"] = check(
            not outside and len(changed) == 187 and len(effect_changed) == 185,
            changed_bytes=len(changed), effect_label_bytes=len(effect_changed),
            checksum_bytes=len(changed) - len(effect_changed), outside_count=len(outside),
            allowed_spans=[
                {"id": "database_effect_labels", "offset": "0x369550", "length": EFFECT_LENGTH},
                {"id": "wonderswan_checksum", "offset": "0x3FFFFE", "length": 2},
            ],
        )

        pointer_base = base[POINTER_OFFSET:POINTER_OFFSET + POINTER_LENGTH]
        pointer_final = final[POINTER_OFFSET:POINTER_OFFSET + POINTER_LENGTH]
        pointer_asset = (root / "translation/assets/effect_labels_pointers.bin").read_bytes()
        report["checks"]["pointer_stability"] = check(
            pointer_base == pointer_final == pointer_asset
            and sha256(pointer_asset) == POINTER_SHA256,
            pointer_rows=bcc.WSC_CHIP_COUNT, pointer_bytes=POINTER_LENGTH,
            pointer_sha256=sha256(pointer_final), changed_pointers=0,
        )

        decode = bcc.load_decode_table(root / "tables/n1battle_jp.tbl")
        base_rows = decoded_table_rows(
            base, bcc.EFFECT_LABELS.pointer_start, bcc.WSC_CHIP_COUNT,
            "effect_labels", decode,
        )
        final_rows = decoded_table_rows(
            final, bcc.EFFECT_LABELS.pointer_start, bcc.WSC_CHIP_COUNT,
            "effect_labels", decode,
        )
        if [row["pointer"] for row in base_rows] != [row["pointer"] for row in final_rows]:
            raise AssertionError("decoded effect pointers changed")
        exact_policy = all(
            after["text"] == effects.shorten_effect(str(before["text"]))
            for before, after in zip(base_rows, final_rows, strict=True)
        )
        changed_rows = [
            after["index"] for before, after in zip(base_rows, final_rows, strict=True)
            if before["text"] != after["text"]
        ]
        unique_before: dict[int, str] = {}
        unique_after: dict[int, str] = {}
        for before, after in zip(base_rows, final_rows, strict=True):
            unique_before[int(before["pointer"])] = str(before["text"])
            unique_after[int(after["pointer"])] = str(after["text"])
        changed_targets = [
            pointer for pointer in unique_before
            if unique_before[pointer] != unique_after[pointer]
        ]
        output_sources: dict[str, set[str]] = defaultdict(set)
        for pointer in unique_before:
            output_sources[unique_after[pointer]].add(unique_before[pointer])
        collisions = {
            text: sorted(sources) for text, sources in output_sources.items()
            if len(sources) > 1
        }
        final_texts = [str(row["text"]) for row in final_rows]

        chip_names = decoded_table_rows(
            final, bcc.CHIP_NAMES.pointer_start, bcc.WSC_CHIP_COUNT,
            "chip_names", decode,
        )
        available = [
            row["index"] > 0 and row["text"] != "NO DATA"
            for row in chip_names
        ]
        populated_effects = [
            final_texts[index] for index, present in enumerate(available) if present
        ]
        label_ok = (
            exact_policy
            and len(changed_rows) == 194
            and len(changed_targets) == 43
            and len(unique_after) == 70
            and all(len(text) <= 6 for text in final_texts)
            and final_texts.count("NODATA") == 136
            and "NO DATA" not in final_texts
            and not collisions
            and sum(available) == 113
            and len([text for text in populated_effects if text]) == 108
            and len([text for text in populated_effects if not text]) == 5
        )
        report["checks"]["six_glyph_effect_policy"] = check(
            label_ok, pointer_rows=len(final_rows), unique_targets=len(unique_after),
            changed_pointer_rows=len(changed_rows), changed_unique_targets=len(changed_targets),
            maximum_visible_glyphs=max(map(len, final_texts)),
            no_data_rows=final_texts.count("NODATA"), old_no_data_rows=final_texts.count("NO DATA"),
            populated_chips=sum(available), nonempty_populated_effects=sum(bool(x) for x in populated_effects),
            empty_special_effects=sum(not x for x in populated_effects),
            abbreviation_collisions=collisions,
            sample_mappings={
                "NORMAL60": "NORM60", "NORMA120": "NOR120",
                "PIERC90+": "PIE90+", "~ADD50+": "~AD50+",
                "NO DATA": "NODATA",
            },
        )

        asset = (root / "translation/assets/effect_labels_data_v0_10_5.bin").read_bytes()
        asset_report = load_json(
            root / "translation/assets/chip_effect_label_asset_report_v0_10_5.json"
        )
        asset_ok = (
            len(asset) == EFFECT_LENGTH and sha256(asset) == ASSET_SHA256
            and final[EFFECT_OFFSET:EFFECT_OFFSET + EFFECT_LENGTH] == asset
            and asset_report.get("status") == "PASS"
            and asset_report.get("inventory", {}).get("changed_unique_targets") == 43
            and asset_report.get("inventory", {}).get("changed_pointer_rows") == 194
            and asset_report.get("inventory", {}).get("maximum_effect_length") == 6
            and asset_report.get("integrity", {}).get("pointers_changed") == 0
            and asset_report.get("integrity", {}).get("outside_affected_live_records") == 0
            and asset_report.get("integrity", {}).get("unreferenced_bank_tail_preserved") is True
        )
        report["checks"]["effect_asset_report"] = check(
            asset_ok, asset_sha256=sha256(asset), asset_length=len(asset),
            changed_asset_bytes=asset_report.get("integrity", {}).get("changed_asset_bytes"),
            unreferenced_bank_tail_preserved=asset_report.get("integrity", {}).get("unreferenced_bank_tail_preserved"),
        )

        delta_failures = manifest_delta(old_manifest, manifest)
        binary_failures = []
        effect_seen = False
        for entry in manifest.get("binary_entries", []):
            relative = root / "translation" / str(entry.get("asset"))
            payload = relative.read_bytes() if relative.is_file() else b""
            offset = int(str(entry.get("offset")), 0)
            length = int(entry.get("length"))
            ok = (
                len(payload) == length
                and sha256(payload) == str(entry.get("asset_sha256", "")).lower()
                and final[offset:offset + length] == payload
            )
            if entry.get("id") == "database_effect_labels":
                effect_seen = True
                ok &= entry.get("asset") == "assets/effect_labels_data_v0_10_5.bin"
                ok &= entry.get("asset_sha256") == ASSET_SHA256
            if not ok:
                binary_failures.append(str(entry.get("id")))
        manifest_ok = (
            manifest.get("format") == "n1battle-inplace-translation-v1"
            and manifest.get("project_version") == VERSION
            and manifest.get("source_sha256") == SOURCE_SHA256
            and len(manifest.get("entries", [])) == 271
            and len(manifest.get("binary_entries", [])) == 77
            and not delta_failures and not binary_failures and effect_seen
        )
        report["checks"]["manifest_and_binary_assets"] = check(
            manifest_ok, text_entries=len(manifest.get("entries", [])),
            binary_entries=len(manifest.get("binary_entries", [])),
            delta_failures=delta_failures, binary_failures=binary_failures,
        )

        old_covered, old_values = ips_tools.parse_ips(base_ips, ROM_SIZE)
        new_covered, new_values = ips_tools.parse_ips(final_ips, ROM_SIZE)
        synthetic = bytearray(base)
        for index, present in enumerate(old_covered):
            if present:
                synthetic[index] = 0
        old_roundtrip = ips_tools.apply_normalized(
            bytes(synthetic), old_covered, old_values
        ) == base
        new_roundtrip = ips_tools.apply_normalized(
            bytes(synthetic), new_covered, new_values
        ) == final
        v104_validator = load_module(
            "validate_v0104_for_v0105", root / "tools/validate_release_v0_10_4.py"
        )
        records = v104_validator.raw_ips_records(final_ips)
        build_report = load_json(root / "build/build_v0_10_5_delta.json")
        ips_ok = (
            sha256(base_ips) == BASE_IPS_SHA256
            and sha256(final_ips) == FINAL_IPS_SHA256
            and old_roundtrip and new_roundtrip
            and build_report.get("status") == "PASS"
            and build_report.get("final_rom_sha256") == FINAL_ROM_SHA256
            and build_report.get("final_ips_sha256") == FINAL_IPS_SHA256
            and build_report.get("outside_allowlist") == 0
            and build_report.get("ips", {}).get("composition_proof") == "PASS"
        )
        report["checks"]["source_compatible_ips_composition"] = check(
            ips_ok, base_ips_sha256=sha256(base_ips), final_ips_sha256=sha256(final_ips),
            record_count=len(records), records_non_overlapping=True,
            inherited_v0_10_4_roundtrip=old_roundtrip,
            composed_v0_10_5_roundtrip=new_roundtrip,
        )

        runtime = load_json(
            root / "docs/runtime_v0_10_5/chip_effect/chip_effect_runtime_validation_v0_10_5.json"
        )
        runtime_ok = (
            runtime.get("status") == "PASS"
            and runtime.get("project_version") == VERSION
            and runtime.get("rom_sha256") == FINAL_ROM_SHA256
            and runtime.get("native_display") == [224, 144]
            and runtime.get("clean_boot", {}).get("fresh_mesen_home") is True
            and runtime.get("clean_boot", {}).get("uses_sav_or_savestate") is False
            and runtime.get("runtime", {}).get("visible_effects") == ["NORM60", "NODATA"]
            and runtime.get("runtime", {}).get("all_live_maps_and_tiles_match_final_rom") is True
            and runtime.get("rom_unchanged_by_validation") is True
            and runtime.get("manual_visual_review", {}).get("status") == "PASS"
        )
        report["checks"]["clean_boot_runtime"] = check(
            runtime_ok, visible_effects=runtime.get("runtime", {}).get("visible_effects"),
            native_display=runtime.get("native_display"),
            uses_sav_or_savestate=runtime.get("clean_boot", {}).get("uses_sav_or_savestate"),
            live_resources_match=runtime.get("runtime", {}).get("all_live_maps_and_tiles_match_final_rom"),
        )

        inherited_structural = load_json(root / "docs/STRUCTURAL_VALIDATION_v0_10_4.json")
        inherited_progress = load_json(root / "docs/progress_v0_10_4.json")
        inherited_title = load_json(
            root / "docs/runtime_v0_10_4/title/title_runtime_validation_v0_10_4.json"
        )
        inherited_pet = load_json(
            root / "docs/runtime_v0_10_4/pet_root/pet_root_runtime_validation_v0_10_4.json"
        )
        inherited_ok = (
            inherited_structural.get("overall_result") == "PASS"
            and inherited_progress.get("status") == "PASS"
            and inherited_progress.get("text_units") == {
                "translated": 1552, "denominator": 1552,
                "inherited_unchanged_from": "0.10.3",
            }
            and inherited_progress.get("localizable_graphics") == {
                "translated": 129, "denominator": 129,
            }
            and inherited_progress.get("known_residual_japanese_targets") == 0
            and inherited_title.get("status") == "PASS"
            and inherited_title.get("rom_sha256") == BASE_ROM_SHA256
            and inherited_pet.get("status") == "PASS"
            and old_manifest.get("entries") == manifest.get("entries")
            and not outside
        )
        report["checks"]["inherited_v0_10_4_coverage"] = check(
            inherited_ok, translated_text=1552, text_denominator=1552,
            graphics_localized=129, graphics_denominator=129,
            remaining_japanese_targets=0,
            title_and_pet_assets_unchanged_outside_effect_bank=True,
        )
    except BaseException as exc:
        report["failures"].append(f"{type(exc).__name__}: {exc}")

    failed = [
        name for name, row in report["checks"].items()
        if isinstance(row, dict) and row.get("result") != "PASS"
    ]
    report["failed_checks"] = failed
    report["overall_result"] = "PASS" if not failed and not report["failures"] else "FAIL"
    report_path.parent.mkdir(parents=True, exist_ok=True)
    rendered = json.dumps(report, ensure_ascii=False, indent=2) + "\n"
    report_path.write_text(rendered, encoding="utf-8")
    print(json.dumps({
        "overall_result": report["overall_result"],
        "failed_checks": failed,
        "failures": report["failures"],
        "final_rom_sha256": FINAL_ROM_SHA256,
        "ips_sha256": FINAL_IPS_SHA256,
        "report": str(report_path),
        "report_sha256": sha256(rendered.encode("utf-8")),
    }, indent=2))
    return 0 if report["overall_result"] == "PASS" else 1


if __name__ == "__main__":
    raise SystemExit(main())
