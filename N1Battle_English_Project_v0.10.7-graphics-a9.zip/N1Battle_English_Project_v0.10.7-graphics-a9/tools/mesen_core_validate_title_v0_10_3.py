#!/usr/bin/env python3
"""Clean-boot runtime and alpha-composition QA for the v0.10.3 title."""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import sys
from pathlib import Path

from PIL import Image


ROM_SHA256 = "eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc"
TITLE_TILE_SHA256 = "df551f0e32d0d5954773568063945547bf8361b2fd47cff3c1e024ce435d8915"
TITLE_MAP_SHA256 = "3e8911f5e96aec73a93cab9b1a5923aab5f03b56f0ddfb279be685afd8245236"
MASTER_SHA256 = "bd0240a61f4ed9febefd422200920e99afaabb8d80ffa8540c333ceeb4199569"
OLD_MASTER_SHA256 = "9f6a15918f5a8016aae4ddef21e71621af3dc0ec137f1adb0f1b21d88cebf83f"
CLEANUP_MASK_SHA256 = "920f9a34234f5d02f28a5ba1cca8ffadfce6bd0b714527d2a87d1ce21f44e5d9"

SCREEN_SIZE = (224, 144)
LOGO_SIZE = (224, 112)
EXPECTED_ALPHA_BBOX = (14, 2, 209, 103)  # right/bottom exclusive
EXPECTED_MAXIMUM_OPAQUE_Y = 102
EXPECTED_OPAQUE_PIXELS = 10680
EXPECTED_REMOVED_PIXELS = 384
EXPECTED_BACKGROUND_REMNANTS = 340
EXPECTED_CLEARANCE_PIXELS = 44
EXPECTED_PROMPT_BBOX = [69, 103, 150, 113]

# These exact runtime counts are part of the reviewed frame-450/frame-550
# composition.  Some removed pixels naturally show the same background colour
# in both phases; the important invariants are that most are dynamic and only
# three coincidentally equal their old, erroneously opaque RGB in both frames.
EXPECTED_REMOVED_CHANGED = 222
EXPECTED_REMNANT_CHANGED = 184
EXPECTED_CLEARANCE_CHANGED = 38
EXPECTED_OLD_STATIC_COINCIDENCES = 3


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_base_validator(root: Path):
    path = root / "tools" / "mesen_core_validate_title_v0_10_2.py"
    spec = importlib.util.spec_from_file_location("n1_title_runtime_v0102", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def load_image(
    path: Path,
    expected_sha256: str,
    expected_mode: str,
    expected_size: tuple[int, int],
) -> Image.Image:
    payload = path.read_bytes()
    actual_sha256 = digest(payload)
    if actual_sha256 != expected_sha256:
        raise ValueError(
            f"unexpected {path.name} SHA-256: {actual_sha256} != {expected_sha256}"
        )
    with Image.open(path) as source:
        if source.format != "PNG":
            raise ValueError(f"{path.name} is not a PNG")
        if source.mode != expected_mode or source.size != expected_size:
            raise ValueError(
                f"unexpected {path.name} geometry: {source.mode} {source.size}"
            )
        return source.copy()


def selected_rgb_digest(
    pixels: list[tuple[int, int, int]],
    indices: list[int],
) -> str:
    return digest(b"".join(bytes(pixels[index]) for index in indices))


def alpha_runtime_qa(root: Path, report: dict, output_dir: Path) -> dict:
    assets = root / "translation" / "assets"
    master_path = assets / "title_logo_master_v0_10_3.png"
    old_master_path = assets / "title_logo_master_v0_10_2.png"
    cleanup_mask_path = assets / "title_logo_cleanup_mask_v0_10_3.png"
    master = load_image(master_path, MASTER_SHA256, "RGBA", LOGO_SIZE)
    old_master = load_image(old_master_path, OLD_MASTER_SHA256, "RGBA", LOGO_SIZE)
    cleanup_mask = load_image(
        cleanup_mask_path, CLEANUP_MASK_SHA256, "L", LOGO_SIZE
    )

    captures = {capture["name"]: capture for capture in report["captures"]}
    visible_capture = captures["press_start_visible"]
    hidden_capture = captures["press_start_hidden"]
    visible_path = output_dir / visible_capture["screenshot"]
    hidden_path = output_dir / hidden_capture["screenshot"]
    with Image.open(visible_path) as source:
        if source.size != SCREEN_SIZE:
            raise ValueError("visible title capture is not native 224x144")
        visible = source.convert("RGB").crop((0, 0, *LOGO_SIZE))
    with Image.open(hidden_path) as source:
        if source.size != SCREEN_SIZE:
            raise ValueError("hidden title capture is not native 224x144")
        hidden = source.convert("RGB").crop((0, 0, *LOGO_SIZE))

    master_pixels = list(master.get_flattened_data())
    old_pixels = list(old_master.get_flattened_data())
    mask_pixels = list(cleanup_mask.get_flattened_data())
    visible_pixels = list(visible.get_flattened_data())
    hidden_pixels = list(hidden.get_flattened_data())

    alpha_values = sorted({pixel[3] for pixel in master_pixels})
    transparent_rgb_zero = all(
        pixel[:3] == (0, 0, 0) for pixel in master_pixels if pixel[3] == 0
    )
    rgb444_only = all(
        channel % 17 == 0
        for pixel in master_pixels
        if pixel[3] == 255
        for channel in pixel[:3]
    )
    opaque_indices = [
        index for index, pixel in enumerate(master_pixels) if pixel[3] == 255
    ]
    opaque_coordinates = [
        (index % LOGO_SIZE[0], index // LOGO_SIZE[0]) for index in opaque_indices
    ]
    maximum_opaque_y = max(y for _x, y in opaque_coordinates)
    mask_indices = [index for index, value in enumerate(mask_pixels) if value == 255]
    mask_values_binary = set(mask_pixels) <= {0, 255}
    remnants = [index for index in mask_indices if index // LOGO_SIZE[0] < 103]
    clearance = [index for index in mask_indices if index // LOGO_SIZE[0] >= 103]
    mask_exactly_describes_cleanup = all(
        (
            old_pixels[index][3] == 255
            and master_pixels[index] == (0, 0, 0, 0)
        )
        if mask_pixels[index] == 255
        else master_pixels[index] == old_pixels[index]
        for index in range(len(master_pixels))
    )
    asset_guards_verified = all((
        alpha_values == [0, 255],
        transparent_rgb_zero,
        rgb444_only,
        master.getchannel("A").getbbox() == EXPECTED_ALPHA_BBOX,
        len(opaque_indices) == EXPECTED_OPAQUE_PIXELS,
        maximum_opaque_y == EXPECTED_MAXIMUM_OPAQUE_Y,
        mask_values_binary,
        cleanup_mask.getbbox() == (14, 16, 211, 108),
        len(mask_indices) == EXPECTED_REMOVED_PIXELS,
        len(remnants) == EXPECTED_BACKGROUND_REMNANTS,
        len(clearance) == EXPECTED_CLEARANCE_PIXELS,
        mask_exactly_describes_cleanup,
    ))

    changed_opaque = [
        index
        for index in opaque_indices
        if visible_pixels[index] != hidden_pixels[index]
    ]
    stable_core = [
        index for index in opaque_indices if index // LOGO_SIZE[0] < 102
    ]
    changed_core = [
        index
        for index in stable_core
        if visible_pixels[index] != hidden_pixels[index]
    ]
    hidden_master_mismatches = [
        index
        for index in opaque_indices
        if hidden_pixels[index] != master_pixels[index][:3]
    ]
    visible_master_mismatches = [
        index
        for index in opaque_indices
        if visible_pixels[index] != master_pixels[index][:3]
    ]
    changed_opaque_confined_to_shadow_row = all(
        index // LOGO_SIZE[0] == 102 for index in changed_opaque
    )
    opaque_stability_verified = all((
        not changed_core,
        not hidden_master_mismatches,
        changed_opaque_confined_to_shadow_row,
        set(changed_opaque) == set(visible_master_mismatches),
    ))

    changed_removed = [
        index
        for index in mask_indices
        if visible_pixels[index] != hidden_pixels[index]
    ]
    changed_remnants = [
        index
        for index in remnants
        if visible_pixels[index] != hidden_pixels[index]
    ]
    changed_clearance = [
        index
        for index in clearance
        if visible_pixels[index] != hidden_pixels[index]
    ]
    old_static_coincidences = [
        index
        for index in mask_indices
        if visible_pixels[index] == old_pixels[index][:3]
        and hidden_pixels[index] == old_pixels[index][:3]
    ]
    removed_mask_verified = all((
        len(changed_removed) == EXPECTED_REMOVED_CHANGED,
        len(changed_remnants) == EXPECTED_REMNANT_CHANGED,
        len(changed_clearance) == EXPECTED_CLEARANCE_CHANGED,
        len(old_static_coincidences) == EXPECTED_OLD_STATIC_COINCIDENCES,
    ))

    prompt_bbox = visible_capture["prompt_metrics"]["neutral_white_bbox"]
    overlap_pixels = []
    if prompt_bbox is not None:
        left, top, right, bottom = prompt_bbox
        overlap_pixels = [
            (x, y)
            for x, y in opaque_coordinates
            if left <= x <= right and top <= y <= bottom
        ]
    clearance_verified = all((
        prompt_bbox == EXPECTED_PROMPT_BBOX,
        maximum_opaque_y == EXPECTED_MAXIMUM_OPAQUE_Y,
        not overlap_pixels,
        prompt_bbox is not None and prompt_bbox[1] > maximum_opaque_y,
    ))

    return {
        "asset_guards": {
            "master": master_path.relative_to(root).as_posix(),
            "master_sha256": MASTER_SHA256,
            "old_master_sha256": OLD_MASTER_SHA256,
            "cleanup_mask": cleanup_mask_path.relative_to(root).as_posix(),
            "cleanup_mask_sha256": CLEANUP_MASK_SHA256,
            "alpha_values": alpha_values,
            "transparent_rgb_zero": transparent_rgb_zero,
            "rgb444_only": rgb444_only,
            "alpha_bbox_exclusive": list(master.getchannel("A").getbbox() or ()),
            "maximum_opaque_y": maximum_opaque_y,
            "opaque_pixels": len(opaque_indices),
            "cleanup_mask_pixels": len(mask_indices),
            "background_remnant_pixels": len(remnants),
            "press_start_clearance_pixels": len(clearance),
            "mask_exactly_describes_cleanup": mask_exactly_describes_cleanup,
            "verified": asset_guards_verified,
        },
        "opaque_logo_stability": {
            "comparison_frames": [
                visible_capture["frame"], hidden_capture["frame"]
            ],
            "opaque_pixels_total": len(opaque_indices),
            "unobscured_core_pixels_y_0_101": len(stable_core),
            "changed_unobscured_core_pixels": len(changed_core),
            "changed_opaque_pixels_total": len(changed_opaque),
            "changed_opaque_coordinates": [
                [index % LOGO_SIZE[0], index // LOGO_SIZE[0]]
                for index in changed_opaque
            ],
            "changed_pixels_confined_to_press_shadow_row_y102": (
                changed_opaque_confined_to_shadow_row
            ),
            "hidden_frame_master_mismatches": len(hidden_master_mismatches),
            "visible_frame_master_mismatches": len(visible_master_mismatches),
            "visible_core_rgb_sha256": selected_rgb_digest(
                visible_pixels, stable_core
            ),
            "hidden_core_rgb_sha256": selected_rgb_digest(hidden_pixels, stable_core),
            "verified": opaque_stability_verified,
        },
        "removed_mask_runtime": {
            "removed_pixels": len(mask_indices),
            "pixels_changed_between_frames": len(changed_removed),
            "changed_ratio": len(changed_removed) / len(mask_indices),
            "background_remnants_changed": len(changed_remnants),
            "press_clearance_pixels_changed": len(changed_clearance),
            "old_opaque_rgb_static_coincidences": len(old_static_coincidences),
            "old_static_coincidence_coordinates": [
                [index % LOGO_SIZE[0], index // LOGO_SIZE[0]]
                for index in old_static_coincidences
            ],
            "visible_removed_pixels_rgb_sha256": selected_rgb_digest(
                visible_pixels, mask_indices
            ),
            "hidden_removed_pixels_rgb_sha256": selected_rgb_digest(
                hidden_pixels, mask_indices
            ),
            "verified": removed_mask_verified,
        },
        "press_start_clearance": {
            "logo_maximum_opaque_y": maximum_opaque_y,
            "prompt_neutral_white_bbox": prompt_bbox,
            "overlap_pixels": len(overlap_pixels),
            "first_prompt_glyph_y": prompt_bbox[1] if prompt_bbox else None,
            "verified": clearance_verified,
        },
        "verified": all((
            asset_guards_verified,
            opaque_stability_verified,
            removed_mask_verified,
            clearance_verified,
        )),
    }


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--output-dir", required=True, type=Path)
    known, _unknown = parser.parse_known_args()
    output_dir = known.output_dir.resolve()

    base = load_base_validator(root)
    base.ROM_SHA256 = ROM_SHA256
    base.REGIONS["title_tiles"] = base.Region(
        0x071BC0, 0x1A00, TITLE_TILE_SHA256
    )
    base.REGIONS["title_map"] = base.Region(
        0x0409A6, 0x0480, TITLE_MAP_SHA256
    )
    captured_stdout = io.StringIO()
    with contextlib.redirect_stdout(captured_stdout):
        base_result = base.main()

    base_report_path = output_dir / "title_runtime_validation_v0_10_2.json"
    if not base_report_path.is_file():
        raise RuntimeError("base title validator did not emit its report")
    report = json.loads(base_report_path.read_text(encoding="utf-8"))
    alpha_qa = alpha_runtime_qa(root, report, output_dir)
    base_passed = base_result == 0 and report.get("status") == "PASS"
    passed = base_passed and alpha_qa["verified"]
    report["validation"] = (
        "title_screen_v0_10_3_clean_boot_start_transition_and_alpha_composition"
    )
    report["status"] = "PASS" if passed else "FAIL"
    report["title_alpha_qa"] = alpha_qa
    report["summary_checks"].update({
        "cleaned_title_asset_guards": alpha_qa["asset_guards"]["verified"],
        "opaque_logo_stable_across_blink_frames": (
            alpha_qa["opaque_logo_stability"]["verified"]
        ),
        "removed_mask_pixels_are_not_static_logo": (
            alpha_qa["removed_mask_runtime"]["verified"]
        ),
        "logo_bbox_does_not_overlap_press_start": (
            alpha_qa["press_start_clearance"]["verified"]
        ),
    })
    report["base_validator"] = {
        "source": "tools/mesen_core_validate_title_v0_10_2.py",
        "passed": base_passed,
    }
    final_report_path = output_dir / "title_runtime_validation_v0_10_3.json"
    final_report_path.write_text(
        json.dumps(report, indent=2) + "\n", encoding="utf-8"
    )
    base_report_path.unlink()
    print(json.dumps(report, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
