#!/usr/bin/env python3
"""Validate the final Lan-room MM/L2 poster from a clean MesenCore boot."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path


ROM_SIZE = 0x400000
MAP_OFFSET = 0x04DE98
MAP_LENGTH = 0x0480
MAP_SHA256 = "10b9f999ccf7c2271e91d972003f82a3d82174346975bb091addb398a8c5b5a9"
TILES_LENGTH = 0x3000
TILES_SHA256 = "8fb47340c2b01edc5f5608d9aeec172314adeca1ace60d82ec11ef97749440f3"
TARGET_FRAME = 24924

MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def input_for(frame: int) -> Controller:
    state = Controller()
    state.Start = 650 <= frame < 660
    state.A = (
        950 <= frame < 958
        or (1200 <= frame <= 25500 and frame % 300 < 8)
    )
    return state


def run(
    rom_path: Path,
    core_path: Path,
    assets_dir: Path,
    output_dir: Path,
    evidence_dir: Path | None,
    timeout: float,
) -> dict[str, object]:
    rom = rom_path.read_bytes()
    if len(rom) != ROM_SIZE:
        raise ValueError(f"unexpected ROM size: {len(rom)}")
    stored = int.from_bytes(rom[-2:], "little")
    calculated = sum(rom[:-2]) & 0xFFFF
    if stored != calculated:
        raise ValueError("WonderSwan checksum mismatch")
    expected_map = rom[MAP_OFFSET:MAP_OFFSET + MAP_LENGTH]
    if sha256(expected_map) != MAP_SHA256:
        raise ValueError("Lan-room map hash mismatch")
    expected_tiles = (assets_dir / "lan_room_poster_bg0_tiles_v0_9.bin").read_bytes()
    if len(expected_tiles) != TILES_LENGTH or sha256(expected_tiles) != TILES_SHA256:
        raise ValueError("final Lan-room poster asset hash mismatch")

    if output_dir.exists():
        shutil.rmtree(output_dir)
    screenshots = output_dir / "mesen_core_home" / "Screenshots"
    screenshots.mkdir(parents=True)
    home = screenshots.parent

    lib = ctypes.CDLL(str(core_path.resolve()))
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause",
        "Resume", "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    reached = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: object) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for(completed + 1))
        if completed == TARGET_FRAME:
            lib.TakeScreenshot()
            reached.set()

    listener = None
    map_live = b""
    tiles_live = b""
    try:
        lib.InitDll()
        lib.InitializeEmu(str(home.resolve()).encode(), None, None, True, True, True, True)
        if not lib.LoadRom(str(rom_path.resolve()).encode(), b""):
            raise RuntimeError("MesenCore LoadRom failed")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("MesenCore notification callback failed")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not reached.wait(timeout):
            raise TimeoutError(f"target frame not reached; last={completed}")
        lib.Pause()
        time.sleep(0.2)
        map_buffer = (ctypes.c_uint8 * MAP_LENGTH)()
        lib.GetMemoryValues(MEM_CPU, 0x2000, 0x2000 + MAP_LENGTH, map_buffer)
        map_live = bytes(map_buffer)
        tiles_buffer = (ctypes.c_uint8 * TILES_LENGTH)()
        lib.GetMemoryValues(MEM_CPU, 0x8000, 0x8000 + TILES_LENGTH, tiles_buffer)
        tiles_live = bytes(tiles_buffer)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        try:
            lib.Stop()
            lib.Release()
        except BaseException:
            pass

    screenshot_source = None
    for _ in range(100):
        candidates = list(screenshots.glob("*.png"))
        if candidates:
            screenshot_source = candidates[0]
            break
        time.sleep(0.05)
    if screenshot_source is None:
        raise RuntimeError("MesenCore did not emit the target screenshot")

    screenshot = output_dir / "lan_room_poster_mesen_v0_9.png"
    shutil.copy2(screenshot_source, screenshot)
    # MesenCore's unified CPU memory domain exposes both the live BG0 map and
    # WonderSwan tile RAM.  Exact live map/tile equality identifies the target
    # room without relying on visual inference alone.  Read only those spans:
    # dumping the entire 64 KiB CPU domain also probes intentionally
    # uninitialized game RAM and produces thousands of irrelevant warnings.
    persistence = sorted(
        path.relative_to(home).as_posix()
        for path in home.rglob("*")
        if path.is_file() and path.suffix.lower() in {".sav", ".mss", ".ieeprom"}
    )
    map_match = map_live == expected_map
    tiles_match = tiles_live == expected_tiles
    result = "PASS" if map_match and tiles_match else "FAIL"
    report: dict[str, object] = {
        "validation": "lan_room_poster_v0_9_clean_boot_headless_mesen_core",
        "result": result,
        "rom": {"path": rom_path.as_posix(), "sha256": sha256(rom)},
        "mesen_core": {"path": core_path.as_posix(), "sha256": sha256(core_path.read_bytes())},
        "route": {
            "clean_boot": True,
            "uses_input_sav_or_savestate": False,
            "target_frame": TARGET_FRAME,
            "last_callback_frame": completed,
            "runtime_generated_persistence_files_removed": persistence,
        },
        "screenshot": {
            "file": screenshot.name,
            "sha256": sha256(screenshot.read_bytes()),
            "dimensions": [224, 144],
        },
        "runtime": {
            "map": {
                "cpu_span": ["0x2000", "0x2480"],
                "sha256": sha256(map_live),
                "matches_expected": map_match,
            },
            "tiles": {
                "cpu_span": ["0x8000", "0xB000"],
                "sha256": sha256(tiles_live),
                "matches_asset": tiles_match,
            },
            "ports": {
                "status": "not_queried",
                "reason": "exact live map and tile equality is the scene criterion",
                "used_as_pass_criterion": False,
            },
        },
        "expected_visible_label": "MM / L2 (Mega Man Legends 2)",
        "manual_visual_review_required": True,
    }
    report_path = output_dir / "lan_room_poster_mesen_validation_v0_9.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")

    if evidence_dir is not None:
        evidence_dir.mkdir(parents=True, exist_ok=True)
        shutil.copy2(screenshot, evidence_dir / screenshot.name)
        shutil.copy2(report_path, evidence_dir / report_path.name)
    shutil.rmtree(home)
    if result != "PASS":
        raise RuntimeError(json.dumps(report, indent=2))
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", type=Path, required=True)
    parser.add_argument("--mesen-core", type=Path, required=True)
    parser.add_argument("--assets", type=Path, required=True)
    parser.add_argument("--output-dir", type=Path, required=True)
    parser.add_argument("--evidence-dir", type=Path)
    parser.add_argument("--timeout", type=float, default=180)
    args = parser.parse_args()
    report = run(
        args.rom, args.mesen_core, args.assets, args.output_dir,
        args.evidence_dir, args.timeout,
    )
    print(json.dumps(report, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
