#!/usr/bin/env python3
"""Clean-boot validation of the restored native WonderSwan title logo."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


MEM_CPU = 13
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
ROM_SHA256 = "5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b"
TITLE_OFFSET, TITLE_LENGTH = 0x071BC0, 0x1A00
TITLE_SHA256 = "a0d931ca05357275d2410dba82a61ee90dd7e673437e89e4f0b506945829c95c"
MAP_OFFSET, MAP_LENGTH = 0x0409A6, 0x0480
MAP_SHA256 = "d873b618f601aad1430fe2bb99b68966808d0aeac0f52223f8c58d245391ff56"
PALETTE_OFFSET, PALETTE_LENGTH = 0x074C68, 0x00A0
PALETTE_SHA256 = "5bbabe397d4dec9fda37d9f6a2e0e5b871118eace3fb1790d8718ce9f7359602"


class Controller(ctypes.Structure):
    _fields_ = [
        (name, ctypes.c_bool)
        for name in (
            "A", "B", "X", "Y", "L", "R", "U", "D",
            "Up", "Down", "Left", "Right", "Select", "Start",
        )
    ]


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def configure(lib: ctypes.CDLL) -> None:
    lib.InitializeEmu.argtypes = [
        ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
        ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool,
    ]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [
        ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
        ctypes.POINTER(ctypes.c_uint8),
    ]
    for name in (
        "InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
        "TakeScreenshot", "Stop", "Release",
    ):
        getattr(lib, name).argtypes = []
    callback = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib._title_callback = callback
    lib.RegisterNotificationCallback.argtypes = [callback]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", type=float, default=45.0)
    args = parser.parse_args()

    rom = args.rom.read_bytes()
    if digest(rom) != ROM_SHA256:
        raise ValueError("unexpected v0.10.1 ROM")
    guards = {
        "title_tiles": digest(rom[TITLE_OFFSET:TITLE_OFFSET + TITLE_LENGTH]) == TITLE_SHA256,
        "title_map": digest(rom[MAP_OFFSET:MAP_OFFSET + MAP_LENGTH]) == MAP_SHA256,
        "title_palettes": digest(rom[PALETTE_OFFSET:PALETTE_OFFSET + PALETTE_LENGTH]) == PALETTE_SHA256,
    }
    if not all(guards.values()):
        raise ValueError(f"title ROM guards failed: {guards}")

    if args.output_dir.exists():
        shutil.rmtree(args.output_dir)
    home = args.output_dir / "mesen_home"
    shots_dir = home / "Screenshots"
    shots_dir.mkdir(parents=True)
    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    configure(lib)
    frame = 0
    frames = (450, 550)
    dumps: dict[int, bytes] = {}
    done = threading.Event()
    cb_type = lib._title_callback

    @cb_type
    def notification(kind: int, _param: ctypes.c_void_p) -> None:
        nonlocal frame
        if kind != PPU_FRAME_DONE:
            return
        frame += 1
        lib.SetInputOverrides(0, Controller(X=True))
        if frame in frames:
            lib.TakeScreenshot()
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
            dumps[frame] = bytes(buffer)
        if frame >= 575:
            done.set()

    listener = None
    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load ROM")
        lib.InitializeDebugger()
        listener = lib.RegisterNotificationCallback(notification)
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not done.wait(args.timeout):
            raise TimeoutError(f"title route timed out at frame {frame}")
        lib.Pause()
        time.sleep(0.2)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5
    while len(list(shots_dir.glob("*.png"))) < 2 and time.monotonic() < deadline:
        time.sleep(0.05)
    sources = sorted(shots_dir.glob("*.png"))
    if len(sources) != 2 or set(dumps) != set(frames):
        raise RuntimeError("title captures are incomplete")

    captures = []
    for capture_frame, source in zip(frames, sources, strict=True):
        output = args.output_dir / f"title_{capture_frame}.png"
        shutil.copy2(source, output)
        with Image.open(output) as image:
            dimensions = list(image.size)
        cpu = dumps[capture_frame]
        live_tiles = cpu[0x8020:0x8020 + TITLE_LENGTH]
        live_map_a = cpu[0x2800:0x2800 + MAP_LENGTH]
        live_map_b = cpu[0x3000:0x3000 + MAP_LENGTH]
        captures.append({
            "frame": capture_frame,
            "screenshot": output.name,
            "screenshot_sha256": digest(output.read_bytes()),
            "dimensions": dimensions,
            "native_224x144": dimensions == [224, 144],
            "live_title_tiles_sha256": digest(live_tiles),
            "live_title_tiles_match_source": digest(live_tiles) == TITLE_SHA256,
            "live_map_match": digest(live_map_a) == MAP_SHA256 or digest(live_map_b) == MAP_SHA256,
        })
    shutil.rmtree(home)
    passed = all(
        item["native_224x144"]
        and item["live_title_tiles_match_source"]
        and item["live_map_match"]
        for item in captures
    )
    report = {
        "validation": "title_screen_v0_10_1_clean_boot",
        "status": "PASS" if passed else "FAIL",
        "rom_sha256": digest(rom),
        "native_display": [224, 144],
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "rom_guards": guards,
        "policy": "native WonderSwan logo restored; English NEW GAME/CONTINUE assets remain separate",
        "captures": captures,
    }
    report_path = args.output_dir / "title_runtime_validation_v0_10_1.json"
    report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    print(json.dumps(report, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
