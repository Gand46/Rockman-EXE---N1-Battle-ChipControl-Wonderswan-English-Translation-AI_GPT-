#!/usr/bin/env python3
"""Capture v0.8 Program Deck labels through a clean headless MesenCore route."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
CAPTURE_FRAMES = (15900, 17400, 21600, 23400, 27200)
STOP_FRAME = 27300
MEM_CPU = 13


class Controller(ctypes.Structure):
    _fields_ = [(name, ctypes.c_bool) for name in (
        "A", "B", "X", "Y", "L", "R", "U", "D",
        "Up", "Down", "Left", "Right", "Select", "Start",
    )]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def pulse(frame: int, first: int, last: int) -> bool:
    return first <= frame < last


def input_for_frame(frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = pulse(frame, 650, 660)
    state.A = (
        pulse(frame, 950, 958)
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or pulse(frame, 26920, 26928)
        or pulse(frame, 27020, 27028)
    )
    return state


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=120.0, type=float)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    home = args.output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    lib.InitializeEmu.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
                                    ctypes.POINTER(ctypes.c_uint8)]
    for name in ("InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
                 "TakeScreenshot", "Stop", "Release"):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    captured: list[int] = []
    memory_captures: dict[int, bytes] = {}
    route_done = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(completed + 1))
        if completed in CAPTURE_FRAMES:
            lib.TakeScreenshot()
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(MEM_CPU, 0, 0x10000, buffer)
            memory_captures[completed] = bytes(buffer)
            captured.append(completed)
        if completed >= STOP_FRAME:
            route_done.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    start_time = time.monotonic()
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not route_done.wait(args.timeout):
            raise TimeoutError(f"Program Deck route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.2)
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5
    while len(list(screenshot_dir.glob("*.png"))) < len(CAPTURE_FRAMES) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != len(CAPTURE_FRAMES):
        raise RuntimeError(f"expected {len(CAPTURE_FRAMES)} captures, found {len(screenshots)}")

    evidence = []
    for frame, source in zip(CAPTURE_FRAMES, screenshots):
        destination = args.output_dir / f"program_deck_frame_{frame:05d}.png"
        shutil.copy2(source, destination)
        with Image.open(destination) as image:
            dimensions = list(image.size)
        memory_path = args.output_dir / f"program_deck_cpu_{frame:05d}.bin"
        memory_path.write_bytes(memory_captures[frame])
        evidence.append({"frame": frame, "file": destination.name,
                         "sha256": sha256(destination), "dimensions": dimensions,
                         "cpu_dump": memory_path.name, "cpu_dump_sha256": sha256(memory_path)})

    report = {
        "validation": "program_deck_labels_v0_8_clean_boot_headless_mesen_core",
        "rom_sha256": sha256(args.rom),
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "last_callback_frame": completed,
        "elapsed_seconds": round(time.monotonic() - start_time, 3),
        "captures": evidence,
    }
    (args.output_dir / "program_deck_mesen_validation_v0_8.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
