#!/usr/bin/env python3
"""Clean-boot runtime and transparency QA for the v0.10.4 title screen.

This validator reuses the proven v0.10.2 clean-boot route, live-resource
checks, PRESS START blink test and real START transition.  Its visual audit is
based directly on the canonical v0.10.4 RGBA master and never imports or uses
the subtractive cleanup mask from v0.10.3.
"""

from __future__ import annotations

import argparse
import contextlib
import hashlib
import importlib.util
import io
import json
import shutil
import sys
import tempfile
from collections import Counter
from pathlib import Path

from PIL import Image


ROM_SHA256 = "ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2"
TITLE_TILE_SHA256 = "7a4556ddef397cf1a20d0cd8ab6552efa589b23a7b561c6145a12bcc5cb214a8"
TITLE_MAP_SHA256 = "be3a4b84dfed1ff9d51585d4aa71f0148b60f6bea15a96829def8a30294bebf3"
MASTER_SHA256 = "7773d34d168c7206b7aafa2e12ed03060392af77fe783e5511d6298f9545754d"
ASSET_REPORT_SHA256 = ""

SCREEN_SIZE = (224, 144)
LOGO_SIZE = (224, 112)
EXPECTED_ALPHA_BBOX = (14, 4, 210, 103)
EXPECTED_MAXIMUM_OPAQUE_Y = 102
EXPECTED_OPAQUE_PIXELS = 10680
EXPECTED_UNIQUE_TILES = 194
EXPECTED_SPARE_TILES = 14
EXPECTED_PROMPT_BBOX = [69, 103, 150, 113]

# The animated layer must visibly pass through a substantial part of the
# transparent logo canvas between the two established blink-phase captures.
# These are deliberately lower-bound invariants rather than screenshot hashes:
# they detect a frozen/opaque tile backing while remaining tolerant of capture
# container metadata.
MIN_DYNAMIC_TRANSPARENT_CORE_PIXELS = 1000
MIN_DYNAMIC_TRANSPARENT_CORE_RATIO = 0.08
MIN_MIXED_CELLS_WITH_DYNAMIC_BACKGROUND_RATIO = 0.70
MIN_TRANSPARENT_PIXELS_PER_MIXED_CELL = 16


def digest(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[name] = module
    spec.loader.exec_module(module)
    return module


def load_master(path: Path) -> Image.Image:
    payload = path.read_bytes()
    if digest(payload) != MASTER_SHA256:
        raise ValueError(f"unexpected v0.10.4 title master SHA-256: {digest(payload)}")
    with Image.open(path) as source:
        if source.format != "PNG" or source.mode != "RGBA" or source.size != LOGO_SIZE:
            raise ValueError("v0.10.4 title master must be a 224x112 RGBA PNG")
        master = source.copy()
    pixels = list(master.get_flattened_data())
    if {pixel[3] for pixel in pixels} != {0, 255}:
        raise ValueError("v0.10.4 title master alpha is not binary")
    if any(pixel[:3] != (0, 0, 0) for pixel in pixels if pixel[3] == 0):
        raise ValueError("transparent master pixels contain hidden RGB")
    if any(
        channel % 17
        for pixel in pixels
        if pixel[3] == 255
        for channel in pixel[:3]
    ):
        raise ValueError("v0.10.4 title master contains colours outside RGB444")
    return master


def load_rgb(path: Path) -> Image.Image:
    with Image.open(path) as source:
        if source.size != SCREEN_SIZE:
            raise ValueError(f"runtime capture is not native 224x144: {path}")
        return source.convert("RGB")


def selected_rgb_digest(
    pixels: list[tuple[int, int, int]], indices: list[int]
) -> str:
    return digest(b"".join(bytes(pixels[index]) for index in indices))


def visual_transparency_qa(root: Path, report: dict, output_dir: Path) -> dict:
    assets = root / "translation/assets"
    master_path = assets / "title_logo_master_v0_10_4.png"
    asset_report_path = assets / "title_logo_asset_report_v0_10_4.json"
    master = load_master(master_path)
    asset_report_payload = asset_report_path.read_bytes()
    asset_report = json.loads(asset_report_payload.decode("utf-8"))

    captures = {capture["name"]: capture for capture in report["captures"]}
    visible_capture = captures["press_start_visible"]
    hidden_capture = captures["press_start_hidden"]
    visible = load_rgb(output_dir / visible_capture["screenshot"]).crop((0, 0, *LOGO_SIZE))
    hidden = load_rgb(output_dir / hidden_capture["screenshot"]).crop((0, 0, *LOGO_SIZE))

    master_pixels = list(master.get_flattened_data())
    visible_pixels = list(visible.get_flattened_data())
    hidden_pixels = list(hidden.get_flattened_data())
    width = LOGO_SIZE[0]

    opaque_indices = [
        index for index, pixel in enumerate(master_pixels) if pixel[3] == 255
    ]
    transparent_indices = [
        index for index, pixel in enumerate(master_pixels) if pixel[3] == 0
    ]
    stable_opaque_core = [index for index in opaque_indices if index // width < 102]
    shadow_edge_opaque = [index for index in opaque_indices if index // width == 102]
    transparent_core = [index for index in transparent_indices if index // width < 102]

    hidden_opaque_mismatches = [
        index
        for index in opaque_indices
        if hidden_pixels[index] != master_pixels[index][:3]
    ]
    visible_opaque_mismatches = [
        index
        for index in opaque_indices
        if visible_pixels[index] != master_pixels[index][:3]
    ]
    changed_stable_opaque = [
        index
        for index in stable_opaque_core
        if visible_pixels[index] != hidden_pixels[index]
    ]
    changed_shadow_edge = [
        index
        for index in shadow_edge_opaque
        if visible_pixels[index] != hidden_pixels[index]
    ]
    opaque_layer_verified = (
        not hidden_opaque_mismatches
        and not changed_stable_opaque
        and all(index // width == 102 for index in visible_opaque_mismatches)
        and set(visible_opaque_mismatches) == set(changed_shadow_edge)
    )

    changed_transparent_core = [
        index
        for index in transparent_core
        if visible_pixels[index] != hidden_pixels[index]
    ]
    dynamic_ratio = (
        len(changed_transparent_core) / len(transparent_core)
        if transparent_core
        else 0.0
    )

    mixed_cells: list[dict[str, object]] = []
    suspicious_static_fill_cells: list[dict[str, object]] = []
    mixed_cells_with_dynamic_background = 0
    for cell_y in range(13):
        for cell_x in range(28):
            cell_indices = [
                (cell_y * 8 + y) * width + cell_x * 8 + x
                for y in range(8)
                for x in range(8)
            ]
            cell_opaque = [index for index in cell_indices if master_pixels[index][3] == 255]
            cell_transparent = [
                index for index in cell_indices if master_pixels[index][3] == 0
            ]
            if (
                not cell_opaque
                or len(cell_transparent) < MIN_TRANSPARENT_PIXELS_PER_MIXED_CELL
            ):
                continue
            changed = sum(
                visible_pixels[index] != hidden_pixels[index]
                for index in cell_transparent
            )
            if changed:
                mixed_cells_with_dynamic_background += 1
            visible_colours = Counter(visible_pixels[index] for index in cell_transparent)
            hidden_colours = Counter(hidden_pixels[index] for index in cell_transparent)
            dominant_visible, dominant_visible_count = visible_colours.most_common(1)[0]
            dominant_hidden, dominant_hidden_count = hidden_colours.most_common(1)[0]
            static_uniform_fill = (
                changed == 0
                and dominant_visible == dominant_hidden
                and dominant_visible_count == len(cell_transparent)
                and dominant_hidden_count == len(cell_transparent)
            )
            record = {
                "cell": [cell_x, cell_y],
                "opaque_pixels": len(cell_opaque),
                "transparent_pixels": len(cell_transparent),
                "changed_transparent_pixels": changed,
                "static_uniform_fill": static_uniform_fill,
            }
            mixed_cells.append(record)
            if static_uniform_fill:
                suspicious_static_fill_cells.append({
                    **record,
                    "uniform_rgb": list(dominant_visible),
                })

    mixed_dynamic_ratio = (
        mixed_cells_with_dynamic_background / len(mixed_cells)
        if mixed_cells
        else 0.0
    )
    transparent_background_verified = (
        len(changed_transparent_core) >= MIN_DYNAMIC_TRANSPARENT_CORE_PIXELS
        and dynamic_ratio >= MIN_DYNAMIC_TRANSPARENT_CORE_RATIO
        and mixed_dynamic_ratio >= MIN_MIXED_CELLS_WITH_DYNAMIC_BACKGROUND_RATIO
        and not suspicious_static_fill_cells
    )

    prompt_bbox = visible_capture["prompt_metrics"]["neutral_white_bbox"]
    prompt_overlap = []
    if prompt_bbox is not None:
        left, top, right, bottom = prompt_bbox
        prompt_overlap = [
            [index % width, index // width]
            for index in opaque_indices
            if left <= index % width <= right and top <= index // width <= bottom
        ]
    prompt_verified = (
        prompt_bbox == EXPECTED_PROMPT_BBOX
        and not prompt_overlap
        and EXPECTED_MAXIMUM_OPAQUE_Y < EXPECTED_PROMPT_BBOX[1]
    )

    asset_guards_verified = (
        master.getchannel("A").getbbox() == EXPECTED_ALPHA_BBOX
        and len(opaque_indices) == EXPECTED_OPAQUE_PIXELS
        and max(index // width for index in opaque_indices) == EXPECTED_MAXIMUM_OPAQUE_Y
        and asset_report.get("status") == "PASS"
        and asset_report.get("reference", {}).get("sole_art_reference") is True
        and asset_report.get("master", {}).get("opaque_black_canvas_introduced") is False
        and asset_report.get("capacity", {}).get("unique_tiles_used") == EXPECTED_UNIQUE_TILES
        and asset_report.get("capacity", {}).get("spare_tiles") == EXPECTED_SPARE_TILES
        and asset_report.get("protected", {}).get("palettes_byte_identical") is True
        and asset_report.get("protected", {}).get("map_rows_14_17_byte_identical") is True
        and asset_report.get("protected", {}).get("press_start_sprite_not_emitted") is True
    )

    return {
        "canonical_assets": {
            "master": master_path.relative_to(root).as_posix(),
            "master_sha256": digest(master_path.read_bytes()),
            "asset_report": asset_report_path.relative_to(root).as_posix(),
            "asset_report_sha256": digest(asset_report_payload),
            "alpha_values": sorted({pixel[3] for pixel in master_pixels}),
            "alpha_bbox_exclusive": list(master.getchannel("A").getbbox() or ()),
            "opaque_pixels": len(opaque_indices),
            "transparent_pixels": len(transparent_indices),
            "maximum_opaque_y": max(index // width for index in opaque_indices),
            "rgb444_only": all(
                channel % 17 == 0
                for pixel in master_pixels
                if pixel[3] == 255
                for channel in pixel[:3]
            ),
            "sole_user_png_reference": asset_report.get("reference", {}).get(
                "sole_art_reference"
            ),
            "opaque_black_canvas_introduced": asset_report.get("master", {}).get(
                "opaque_black_canvas_introduced"
            ),
            "unique_tiles": asset_report.get("capacity", {}).get("unique_tiles_used"),
            "spare_tiles": asset_report.get("capacity", {}).get("spare_tiles"),
            "verified": asset_guards_verified,
        },
        "opaque_logo_runtime": {
            "hidden_frame_master_mismatches": len(hidden_opaque_mismatches),
            "visible_frame_master_mismatches": len(visible_opaque_mismatches),
            "changed_opaque_core_y_0_101": len(changed_stable_opaque),
            "changed_opaque_shadow_edge_y_102": len(changed_shadow_edge),
            "hidden_opaque_rgb_sha256": selected_rgb_digest(
                hidden_pixels, opaque_indices
            ),
            "master_opaque_rgb_sha256": selected_rgb_digest(
                [pixel[:3] for pixel in master_pixels], opaque_indices
            ),
            "verified": opaque_layer_verified,
        },
        "transparent_animated_background": {
            "transparent_core_pixels_y_0_101": len(transparent_core),
            "changed_between_blink_phases": len(changed_transparent_core),
            "dynamic_ratio": dynamic_ratio,
            "minimum_changed_pixels": MIN_DYNAMIC_TRANSPARENT_CORE_PIXELS,
            "minimum_dynamic_ratio": MIN_DYNAMIC_TRANSPARENT_CORE_RATIO,
            "mixed_logo_edge_cells_checked": len(mixed_cells),
            "minimum_transparent_pixels_per_mixed_cell": (
                MIN_TRANSPARENT_PIXELS_PER_MIXED_CELL
            ),
            "mixed_cells_with_dynamic_background": (
                mixed_cells_with_dynamic_background
            ),
            "mixed_cells_dynamic_ratio": mixed_dynamic_ratio,
            "minimum_mixed_cells_dynamic_ratio": (
                MIN_MIXED_CELLS_WITH_DYNAMIC_BACKGROUND_RATIO
            ),
            "suspicious_static_uniform_fill_cells": suspicious_static_fill_cells,
            "visible_transparent_core_rgb_sha256": selected_rgb_digest(
                visible_pixels, transparent_core
            ),
            "hidden_transparent_core_rgb_sha256": selected_rgb_digest(
                hidden_pixels, transparent_core
            ),
            "verified": transparent_background_verified,
        },
        "press_start_clearance": {
            "logo_maximum_opaque_y": EXPECTED_MAXIMUM_OPAQUE_Y,
            "prompt_neutral_white_bbox": prompt_bbox,
            "overlap_pixels": len(prompt_overlap),
            "verified": prompt_verified,
        },
        "verified": all((
            asset_guards_verified,
            opaque_layer_verified,
            transparent_background_verified,
            prompt_verified,
        )),
    }


def remove_private_cpu_dumps(report: dict, output_dir: Path) -> None:
    """Keep hashes in the report while removing transient raw memory dumps."""
    for capture in report.get("captures", []):
        dump_name = capture.pop("cpu_dump", None)
        dump_hash = capture.pop("cpu_dump_sha256", None)
        if dump_hash is not None:
            capture["cpu_capture_sha256"] = dump_hash
            capture["cpu_capture_distributed"] = False
        if dump_name:
            dump_path = output_dir / str(dump_name)
            if dump_path.is_file():
                dump_path.unlink()


def main() -> int:
    root = Path(__file__).resolve().parents[1]
    parser = argparse.ArgumentParser(add_help=False)
    parser.add_argument("--output-dir", required=True, type=Path)
    known, _unknown = parser.parse_known_args()
    output_dir = known.output_dir.resolve()
    if output_dir == Path(output_dir.anchor) or output_dir == Path.cwd().resolve():
        raise ValueError(f"unsafe output directory: {output_dir}")
    runtime_work = Path(tempfile.mkdtemp(prefix="n1-title-v0104-"))

    base = load_module(
        "n1_title_runtime_v0102_for_v0104",
        root / "tools/mesen_core_validate_title_v0_10_2.py",
    )
    base.ROM_SHA256 = ROM_SHA256
    base.REGIONS["title_tiles"] = base.Region(
        0x071BC0, 0x1A00, TITLE_TILE_SHA256
    )
    base.REGIONS["title_map"] = base.Region(
        0x0409A6, 0x0480, TITLE_MAP_SHA256
    )

    original_argv = sys.argv[:]
    delegated_argv = original_argv[:]
    output_index = delegated_argv.index("--output-dir") + 1
    delegated_argv[output_index] = str(runtime_work)
    captured_stdout = io.StringIO()
    try:
        sys.argv = delegated_argv
        with contextlib.redirect_stdout(captured_stdout):
            base_result = base.main()
    finally:
        sys.argv = original_argv

    inherited_report_path = runtime_work / "title_runtime_validation_v0_10_2.json"
    if not inherited_report_path.is_file():
        raise RuntimeError("base title validator did not emit its report")
    report = json.loads(inherited_report_path.read_text(encoding="utf-8"))
    visual_qa = visual_transparency_qa(root, report, runtime_work)
    base_passed = base_result == 0 and report.get("status") == "PASS"
    passed = base_passed and visual_qa["verified"]

    report["validation"] = (
        "title_screen_v0_10_4_clean_boot_start_transition_and_transparency"
    )
    report["status"] = "PASS" if passed else "FAIL"
    report["expected_rom_sha256"] = ROM_SHA256
    report["title_visual_qa"] = visual_qa
    report["base_validator"] = {
        "source": "tools/mesen_core_validate_title_v0_10_2.py",
        "mask_dependency": False,
        "v0_10_3_cleanup_mask_loaded": False,
        "passed": base_passed,
    }
    report["summary_checks"].update({
        "canonical_v0_10_4_master_and_asset_guards": (
            visual_qa["canonical_assets"]["verified"]
        ),
        "opaque_logo_matches_master_across_blink_phases": (
            visual_qa["opaque_logo_runtime"]["verified"]
        ),
        "transparent_pixels_reveal_animated_background": (
            visual_qa["transparent_animated_background"]["verified"]
        ),
        "no_static_uniform_tile_backing_detected": not visual_qa[
            "transparent_animated_background"
        ]["suspicious_static_uniform_fill_cells"],
        "press_start_protected_and_clear": (
            visual_qa["press_start_clearance"]["verified"]
        ),
    })
    remove_private_cpu_dumps(report, runtime_work)
    output_dir.mkdir(parents=True, exist_ok=True)
    stale_home = output_dir / "mesen_home"
    shutil.rmtree(stale_home, ignore_errors=True)
    for capture in report["captures"]:
        screenshot_name = str(capture["screenshot"])
        shutil.copy2(runtime_work / screenshot_name, output_dir / screenshot_name)

    final_report_path = output_dir / "title_runtime_validation_v0_10_4.json"
    final_report_path.write_text(json.dumps(report, indent=2) + "\n", encoding="utf-8")
    inherited_report_path.unlink()
    shutil.rmtree(runtime_work, ignore_errors=True)
    print(json.dumps({
        "status": report["status"],
        "rom_sha256": report["rom_sha256"],
        "native_display": report["native_display"],
        "press_start_blink": report["press_start_blink"]["verified"],
        "start_transition": report["start_transition"]["verified"],
        "visual_qa": visual_qa["verified"],
        "transparent_dynamic_pixels": visual_qa[
            "transparent_animated_background"
        ]["changed_between_blink_phases"],
        "suspicious_static_fill_cells": len(visual_qa[
            "transparent_animated_background"
        ]["suspicious_static_uniform_fill_cells"]),
        "report": final_report_path.relative_to(root).as_posix(),
        "report_sha256": digest(final_report_path.read_bytes()),
    }, indent=2))
    return 0 if passed else 1


if __name__ == "__main__":
    raise SystemExit(main())
