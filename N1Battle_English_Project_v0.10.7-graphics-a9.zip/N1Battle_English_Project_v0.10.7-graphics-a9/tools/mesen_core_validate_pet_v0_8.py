#!/usr/bin/env python3
"""Validate the v0.8 English PET root from a clean MesenCore boot."""

from __future__ import annotations

import argparse
import ctypes
import hashlib
import json
import shutil
import threading
import time
from pathlib import Path

from PIL import Image


CPU_WS = 12
MEM_CPU = 13
MEM_WS_WRAM = 85
MEM_WS_PORT = 90
MAXIMUM_SPEED = 0x04
PPU_FRAME_DONE = 7
TARGET_FRAME = 27000


class TimingInfo(ctypes.Structure):
    _fields_ = [
        ("fps", ctypes.c_double), ("master_clock", ctypes.c_uint64),
        ("master_clock_rate", ctypes.c_uint32), ("frame_count", ctypes.c_uint32),
        ("scanline_count", ctypes.c_uint32), ("first_scanline", ctypes.c_int32),
        ("cycle_count", ctypes.c_uint32),
    ]


class Controller(ctypes.Structure):
    _fields_ = [(name, ctypes.c_bool) for name in (
        "A", "B", "X", "Y", "L", "R", "U", "D",
        "Up", "Down", "Left", "Right", "Select", "Start",
    )]


def sha256(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def input_for_frame(frame: int) -> Controller:
    state = Controller(X=True)
    state.Start = 650 <= frame < 660
    state.A = (
        950 <= frame < 958
        or (1200 <= frame <= 26708 and frame % 300 < 8)
        or 26920 <= frame < 26928
    )
    return state


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--rom", required=True, type=Path)
    parser.add_argument("--mesen-core", required=True, type=Path)
    parser.add_argument("--tiles", required=True, type=Path)
    parser.add_argument("--tilemap", required=True, type=Path)
    parser.add_argument("--output-dir", required=True, type=Path)
    parser.add_argument("--timeout", default=120.0, type=float)
    args = parser.parse_args()

    args.output_dir.mkdir(parents=True, exist_ok=True)
    home = args.output_dir / "mesen_core_home"
    if home.exists():
        shutil.rmtree(home)
    screenshot_dir = home / "Screenshots"
    screenshot_dir.mkdir(parents=True)

    lib = ctypes.CDLL(str(args.mesen_core.resolve()))
    lib.InitializeEmu.argtypes = [ctypes.c_char_p, ctypes.c_void_p, ctypes.c_void_p,
                                  ctypes.c_bool, ctypes.c_bool, ctypes.c_bool, ctypes.c_bool]
    lib.LoadRom.argtypes = [ctypes.c_char_p, ctypes.c_char_p]
    lib.LoadRom.restype = ctypes.c_bool
    lib.SetEmulationFlag.argtypes = [ctypes.c_int, ctypes.c_bool]
    lib.SetInputOverrides.argtypes = [ctypes.c_uint32, Controller]
    lib.GetMemoryValues.argtypes = [ctypes.c_int, ctypes.c_uint32, ctypes.c_uint32,
                                    ctypes.POINTER(ctypes.c_uint8)]
    for name in ("InitDll", "InitializeDebugger", "ReleaseDebugger", "Pause", "Resume",
                 "TakeScreenshot", "Stop", "Release"):
        getattr(lib, name).argtypes = []
    callback_type = ctypes.CFUNCTYPE(None, ctypes.c_int, ctypes.c_void_p)
    lib.RegisterNotificationCallback.argtypes = [callback_type]
    lib.RegisterNotificationCallback.restype = ctypes.c_void_p
    lib.UnregisterNotificationCallback.argtypes = [ctypes.c_void_p]

    completed = 0
    target_reached = threading.Event()

    @callback_type
    def notification(notification_type: int, _parameter: ctypes.c_void_p) -> None:
        nonlocal completed
        if notification_type != PPU_FRAME_DONE:
            return
        completed += 1
        lib.SetInputOverrides(0, input_for_frame(completed + 1))
        if completed == TARGET_FRAME:
            lib.TakeScreenshot()
            target_reached.set()

    lib.InitDll()
    lib.InitializeEmu(str(home).encode(), None, None, True, True, True, True)
    listener = None
    start_time = time.monotonic()
    try:
        if not lib.LoadRom(str(args.rom.resolve()).encode(), b""):
            raise RuntimeError("MesenCore could not load the ROM")
        lib.InitializeDebugger()
        lib.SetInputOverrides(0, input_for_frame(0))
        listener = lib.RegisterNotificationCallback(notification)
        if not listener:
            raise RuntimeError("could not register MesenCore callback")
        lib.SetEmulationFlag(MAXIMUM_SPEED, True)
        lib.Resume()
        if not target_reached.wait(args.timeout):
            raise TimeoutError(f"clean PET route timed out at frame {completed}")
        lib.Pause()
        time.sleep(0.2)

        memory = {}
        for memory_type, name in ((MEM_CPU, "cpu"), (MEM_WS_WRAM, "wram"), (MEM_WS_PORT, "ports")):
            buffer = (ctypes.c_uint8 * 0x10000)()
            lib.GetMemoryValues(memory_type, 0, 0x10000, buffer)
            payload = bytes(buffer)
            (args.output_dir / f"{name}_{TARGET_FRAME}.bin").write_bytes(payload)
            memory[name] = payload
    finally:
        if listener:
            lib.UnregisterNotificationCallback(listener)
        try:
            lib.ReleaseDebugger()
        except BaseException:
            pass
        lib.Stop()
        lib.Release()

    deadline = time.monotonic() + 5
    while not list(screenshot_dir.glob("*.png")) and time.monotonic() < deadline:
        time.sleep(0.05)
    screenshots = sorted(screenshot_dir.glob("*.png"))
    if len(screenshots) != 1:
        raise RuntimeError(f"expected one PET screenshot, found {len(screenshots)}")
    screenshot = args.output_dir / "pet_root_clean_v0_8.png"
    shutil.copy2(screenshots[0], screenshot)

    expected_tiles = args.tiles.read_bytes()
    expected_map = args.tilemap.read_bytes()
    live_tiles = memory["cpu"][0x8020:0x8020 + len(expected_tiles)]
    live_map = memory["cpu"][0x2000:0x2000 + len(expected_map)]
    tile_match = live_tiles == expected_tiles
    map_match = live_map == expected_map
    if not tile_match or not map_match:
        raise RuntimeError(f"PET live-memory mismatch: tiles={tile_match}, map={map_match}")
    with Image.open(screenshot) as image:
        dimensions = list(image.size)

    report = {
        "validation": "pet_labels_v0_8_clean_boot_headless_mesen_core",
        "rom_sha256": sha256(args.rom.read_bytes()),
        "clean_boot": True,
        "uses_sav_or_savestate": False,
        "target_frame": TARGET_FRAME,
        "last_callback_frame": completed,
        "elapsed_seconds": round(time.monotonic() - start_time, 3),
        "runtime": {
            "tiles": {"address": "CPU:0x8020", "length": len(expected_tiles),
                      "sha256": sha256(live_tiles), "matches_asset": tile_match},
            "bg0_map": {"address": "CPU:0x2000", "length": len(expected_map),
                        "sha256": sha256(live_map), "matches_asset": map_match},
        },
        "screenshot": {"file": screenshot.name, "sha256": sha256(screenshot.read_bytes()),
                       "dimensions": dimensions},
    }
    (args.output_dir / "pet_mesen_validation_v0_8.json").write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n", encoding="utf-8"
    )
    print(json.dumps(report, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
