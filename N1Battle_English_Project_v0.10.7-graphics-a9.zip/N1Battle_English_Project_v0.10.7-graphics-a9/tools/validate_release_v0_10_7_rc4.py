#!/usr/bin/env python3
"""Audit the complete v0.10.7 RC4 ROM delta and release inputs."""

from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any


ROOT = Path(__file__).resolve().parents[1]
VERSION = "0.10.7-rc4"
ROM_SIZE = 0x400000
SOURCE_ROM_SHA256 = "4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed"
BASE_ROM_SHA256 = "6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c"
FINAL_ROM_SHA256 = "129ef89f09e2fef3a6c7f1acce11f62ff0c615ca583317e5e5b106f029bbe1b8"
FINAL_IPS_SHA256 = "1f4270eab41a0401381c8ba53087faa337436337933932dc3623d1cf4321d2e9"
FINAL_MANIFEST_SHA256 = "d82f74ca02760c4e1f5cf01303b094f3f2f83fab890aabc239bca342b3ff9a0d"
EXPECTED_CHANGED_BYTES = 3355
EXPECTED_TEXT_ENTRIES = 52
EXPECTED_BATTLE_ENTRIES = 4

BATTLE_IDS = {
    "battle_messages_b1_data",
    "battle_messages_b1_pointers",
    "battle_messages_b2_data",
    "battle_messages_b2_pointers",
}


def sha256(payload: bytes) -> str:
    return hashlib.sha256(payload).hexdigest()


def require(condition: bool, message: str) -> None:
    if not condition:
        raise AssertionError(message)


def parse_number(value: Any) -> int:
    return int(str(value), 0) if isinstance(value, str) else int(value)


def load_json(path: Path) -> dict[str, Any]:
    value = json.loads(path.read_text(encoding="utf-8"))
    require(isinstance(value, dict), f"expected JSON object: {path}")
    return value


def load_n1tool() -> Any:
    path = ROOT / "tools/n1tool.py"
    spec = importlib.util.spec_from_file_location("n1tool_validate_rc4", path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"cannot import {path}")
    module = importlib.util.module_from_spec(spec)
    sys.modules[spec.name] = module
    spec.loader.exec_module(module)
    return module


def main() -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument(
        "--base-rom", type=Path,
        default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc3.wsc",
    )
    parser.add_argument(
        "--rom", type=Path,
        default=ROOT / "build/Rockman_EXE_N1_Battle_English_v0.10.7-rc4.wsc",
    )
    parser.add_argument(
        "--ips", type=Path,
        default=ROOT / "patches/Rockman_EXE_N1_Battle_English_v0.10.7-rc4.ips",
    )
    parser.add_argument(
        "--source-rom", type=Path,
        help="optional verified Japanese Rev 1 ROM for an independent IPS proof",
    )
    parser.add_argument(
        "--output", type=Path,
        default=ROOT / "build/validation_v0_10_7_rc4.json",
    )
    args = parser.parse_args()

    base = args.base_rom.read_bytes()
    final = args.rom.read_bytes()
    ips = args.ips.read_bytes()
    require(len(base) == len(final) == ROM_SIZE, "ROM size is not 4 MiB")
    require(sha256(base) == BASE_ROM_SHA256, "base is not the approved RC3 ROM")
    require(sha256(final) == FINAL_ROM_SHA256, "final RC4 ROM hash differs")
    require(sha256(ips) == FINAL_IPS_SHA256, "final RC4 IPS hash differs")
    require(
        int.from_bytes(final[-2:], "little") == sum(final[:-2]) & 0xFFFF,
        "WonderSwan checksum is invalid",
    )

    manifest3_path = ROOT / "translation/en_v0_10_7_rc3.json"
    manifest4_path = ROOT / "translation/en_v0_10_7_rc4.json"
    manifest3 = load_json(manifest3_path)
    manifest4 = load_json(manifest4_path)
    require(sha256(manifest4_path.read_bytes()) == FINAL_MANIFEST_SHA256, "RC4 manifest hash differs")
    require(manifest4.get("project_version") == VERSION, "RC4 manifest identity differs")

    entries3 = {str(row["id"]): row for row in manifest3["entries"]}
    entries4 = {str(row["id"]): row for row in manifest4["entries"]}
    require(set(entries3) == set(entries4), "text entry inventory changed")
    changed_text = [
        entry_id for entry_id in entries3
        if entries3[entry_id]["translation"] != entries4[entry_id]["translation"]
    ]
    require(len(changed_text) == EXPECTED_TEXT_ENTRIES, "unexpected changed text-entry count")

    binaries3 = {str(row["id"]): row for row in manifest3["binary_entries"]}
    binaries4 = {str(row["id"]): row for row in manifest4["binary_entries"]}
    require(set(binaries3) == set(binaries4), "binary entry inventory changed")
    changed_binary = {
        entry_id for entry_id in binaries3
        if (
            binaries3[entry_id]["asset"] != binaries4[entry_id]["asset"]
            or binaries3[entry_id]["asset_sha256"] != binaries4[entry_id]["asset_sha256"]
        )
    }
    require(changed_binary == BATTLE_IDS, "binary manifest changed outside B1/B2")

    allowed = bytearray(ROM_SIZE)
    allowed_spans: list[dict[str, Any]] = []
    for entry_id in changed_text:
        row = entries4[entry_id]
        start, length = parse_number(row["offset"]), parse_number(row["length"])
        allowed[start:start + length] = b"\x01" * length
        allowed_spans.append({"id": entry_id, "offset": row["offset"], "length": length, "kind": "dialogue"})
    for entry_id in sorted(BATTLE_IDS):
        row = binaries4[entry_id]
        start, length = parse_number(row["offset"]), parse_number(row["length"])
        allowed[start:start + length] = b"\x01" * length
        asset = ROOT / "translation" / str(row["asset"])
        payload = asset.read_bytes()
        require(len(payload) == length, f"{entry_id}: asset length differs")
        require(sha256(payload) == str(row["asset_sha256"]), f"{entry_id}: asset hash differs")
        require(final[start:start + length] == payload, f"{entry_id}: final ROM does not contain asset")
        allowed_spans.append({"id": entry_id, "offset": row["offset"], "length": length, "kind": "battle_bank"})
    allowed[-2:] = b"\x01\x01"

    changed = [index for index, (left, right) in enumerate(zip(base, final)) if left != right]
    outside = [index for index in changed if not allowed[index]]
    require(not outside, f"RC4 changed outside allowlist: {outside[:8]}")
    require(len(changed) == EXPECTED_CHANGED_BYTES, f"changed-byte count is {len(changed)}")

    # Every static graphical/data binary span is exactly the approved RC3 span.
    for entry_id, row in binaries4.items():
        if entry_id in BATTLE_IDS:
            continue
        start, length = parse_number(row["offset"]), parse_number(row["length"])
        require(
            base[start:start + length] == final[start:start + length],
            f"static RC3 binary span changed: {entry_id}",
        )

    lower = load_json(ROOT / "translation/assets/lower_dialogue_layout_report_v0_10_7_rc4.json")
    battle = load_json(ROOT / "translation/assets/battle_message_asset_report_v0_10_7_rc4.json")
    combined = load_json(ROOT / "translation/assets/manifest_report_v0_10_7_rc4.json")
    require(lower.get("status") == battle.get("status") == combined.get("status") == "PASS", "RC4 reports are not PASS")
    require(lower.get("remaining_literal_overflow_lines") == 0, "normal dialogue overflow remains")
    require(lower.get("remaining_vertical_overflow_pages") == 0, "normal dialogue vertical overflow remains")
    require(battle.get("dispatch_safety", {}).get("null_pointer_topology_preserved") is True, "battle NULL topology changed")
    require(battle.get("dispatch_safety", {}).get("line_control_words_added") == 13, "battle LINE inventory differs")

    ips_proof = "not requested"
    if args.source_rom is not None:
        source = args.source_rom.read_bytes()
        require(sha256(source) == SOURCE_ROM_SHA256, "source ROM hash differs")
        require(load_n1tool().apply_ips(source, ips) == final, "IPS does not reconstruct RC4")
        ips_proof = "PASS"

    result = {
        "status": "PASS",
        "project_version": VERSION,
        "base_version": "0.10.7-rc3",
        "base_rom_sha256": sha256(base),
        "final_rom_sha256": sha256(final),
        "final_ips_sha256": sha256(ips),
        "final_manifest_sha256": sha256(manifest4_path.read_bytes()),
        "checksum": f"0x{int.from_bytes(final[-2:], 'little'):04X}",
        "checksum_valid": True,
        "changed_bytes_vs_rc3": len(changed),
        "outside_allowlist": len(outside),
        "changed_dialogue_entries": len(changed_text),
        "changed_battle_binary_entries": len(changed_binary),
        "guarded_spans": len(allowed_spans),
        "static_rc3_binary_spans_changed": 0,
        "normal_dialogue": {
            "source_overflow_lines": lower["source_overflow_lines"],
            "affected_pages": lower["affected_pages"],
            "affected_entries": lower["affected_entries"],
            "remaining_overflow_lines": 0,
        },
        "battle_dialogue": {
            "changed_targets": battle["changed_targets"],
            "line_controls_added": battle["dispatch_safety"]["line_control_words_added"],
            "null_topology_preserved": True,
            "pause_option": "DECK",
        },
        "ips_reconstruction": ips_proof,
        "allowlist": allowed_spans,
    }
    args.output.parent.mkdir(parents=True, exist_ok=True)
    args.output.write_text(json.dumps(result, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")
    print(json.dumps({
        "status": result["status"],
        "changed_bytes_vs_rc3": result["changed_bytes_vs_rc3"],
        "outside_allowlist": result["outside_allowlist"],
        "changed_dialogue_entries": result["changed_dialogue_entries"],
        "changed_battle_binary_entries": result["changed_battle_binary_entries"],
        "ips_reconstruction": result["ips_reconstruction"],
    }, indent=2))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
