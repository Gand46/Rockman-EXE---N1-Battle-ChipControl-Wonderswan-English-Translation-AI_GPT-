# Changelog

## 0.10.7 Graphics Advance 9 — 2026-08-26

- Restaurado únicamente el cuadrante inferior izquierdo de 8×8 píxeles del
  primer chip de MegaMan situado junto a `OK` en Program Deck.
- Corregida la causa raíz: el tile vivo `0x0E9` consume el activo físico
  `0x0E8` por la fase `tile N → activo N−1`. La celda `(14,7)` es su único
  consumidor en el mapa completo.
- Recuperados desde la ROM japonesa los 29 bytes distintos del patrón original;
  la ROM cambia 31 bytes frente a A8 al incluir el checksum.
- Mapas, paletas, código, punteros, textos, demás tiles y barra inglesa
  `DECK FILE` permanecen intactos.
- Dos arranques limpios de MesenCore confirman 53 píxeles distintos dentro de
  `[112,56,120,64]`, cero fuera y cero cambios al activar la barra.
- Añadida R29 para medir la fase viva entre tile y activo y proteger iconos
  dinámicos exclusivos frente a ediciones gráficas adyacentes.
- ROM privada SHA-256 `27c189a8303ff1ba75a624ea686380c3d9bff618da2a06d8e3e1b0d8ceda53f6`,
  IPS acumulativo SHA-256 `9a1bf3430a4e213eb10d3a1f340532dc43f4a7554fad83821263c21bef9e9cb5`
  y checksum WonderSwan `0xB86D`.

## 0.10.7 Graphics Advance 8 — 2026-08-25

- Eliminados únicamente los restos japoneses situados debajo de la tarjeta
  compartida `NO CHIP / IS / SELECTED`.
- La limpieza se limita al interior `[2,24,62,28]` del activo 64×32. Las filas
  de fondo usan el índice 1 y la fila compartida con el marco se reconstruye
  de forma uniforme con el índice 14.
- Conservados byte a byte los tres renglones ingleses, laterales, filas
  inferiores del marco, mapas, paletas, código, punteros y datos dinámicos.
- El banco cambia 37 bytes en los tiles `0x032`–`0x035`; la ROM cambia 39 bytes
  frente a A7 al incluir el checksum, con cero fuera de la lista blanca.
- Cuatro arranques limpios de MesenCore comparan A7/A8 en Backpack y Data
  Library: 43 píxeles por consumidor, todos dentro de la franja autorizada.
  `chip_folder`, `chip_sort` y `data_library` permanecen píxel a píxel iguales.
- Añadida R28 de auditoría de filas residuales y conservación de marco en
  tarjetas compartidas.
- ROM privada SHA-256 `aafa083e8781d58858c35cf729ed18c9269126cba70c789e1e631844071e3749`,
  IPS acumulativo SHA-256 `d4f05841889955bd0818994f05637203bbea376b31ef90edf08cd2ba8e1c3165`
  y checksum WonderSwan `0xB6E7`.

## 0.10.7 Graphics Advance 7 — 2026-08-25

- Centrado únicamente el intertítulo auxiliar `1 MONTH LATER...`: sus 16
  celdas de 8 píxeles pasan de `x=88` a `x=48`, con tramo lógico `[48,176)`
  centrado exactamente en la pantalla de 224 píxeles.
- La traza identifica la llamada exclusiva del estado `0x0D` en PC físico
  `0x2A6F7`, offset ROM `0x32A6F7`; solo cambia `PUSH 0x0B` por `PUSH 0x06`.
- Conservados byte a byte texto auxiliar `0x10`, puntero, argumento vertical,
  renderizador compartido, fuente, tiles, paletas, mapas persistentes y fondo.
- La máscara ejecutada conserva sus 269 píxeles y se traslada rígidamente
  `(-40,0)`; los fotogramas 2300, 2960 y 3200 coinciden exactamente con A6.
- Añadida R27 de centrado métrico y aislamiento de llamada de escena.
- ROM privada SHA-256 `e049ce549ddbbe695995cc7c76863a201e22199e064daaa24f2e542dcedaf9fa`,
  IPS acumulativo SHA-256 `26f612898f1bc8755324c5e6335c4581d3e8b19cd58fee46e9817eeff1d7ef86`
  y checksum WonderSwan `0xB4F6`.

## 0.10.7 Graphics Advance 6 — 2026-08-25

- Reducido únicamente el número de existencias situado a la derecha de `MB`
  en Backpack: usa glifos 3×5 de pixel art, alineados como superíndice dentro
  de la celda original de 8×16.
- Aislada la intervención en la llamada ROM `0x33835C`. El envoltorio de 282
  bytes vive en el tramo B1 vacío `[0x37D6D8,0x37D7F2)` y conserva primero la
  ejecución del renderizador original y su caché.
- Reservados siete pares de tiles sin consumidores en mapas ROM relacionados,
  ninguna de las dos capas vivas ni OBJ. El grafo final tiene exactamente un
  consumidor por tile y cero consumidores externos.
- Protegidos píxel a píxel los números de `Quake1` y `Meteor3`, capacidades,
  `MB`, nombres, iconos, tarjeta, estadísticas, encabezado, marcos y paletas.
- Verificados `0–9`, `10`, `11`, `12`, `255`, una lista desplazada de diez
  chips, Backpack vacío y la pantalla principal Chip Folder. Los valores de
  más de una cifra conservan el comportamiento de una columna y muestran la
  última cifra.
- En la captura aportada cambian 195 píxeles, todos dentro de las siete celdas
  de cantidad; tras desplazar la lista cambian 210 y siguen siendo cero fuera.
- Añadida R26, que prohíbe modificar una fuente numérica compartida para
  resolver un solo campo dinámico y exige aislamiento de llamada, almacenamiento
  gráfico y consumidores.
- ROM privada SHA-256 `9b135e34db6b20d8135c79476bd72a7118500e176ee8f5eee3c0c99fe3bb333b`,
  IPS acumulativo SHA-256 `05e449483f5ee665688e60548b1d06d458c689e572e5e5801bd259cc8925cb0a`
  y checksum WonderSwan `0xB4FB`.

## 0.10.7 Graphics Advance 5 — 2026-08-25

- Armonizada la segunda instancia principal de `CHIP FOLDER` con el patrón
  nativo aprobado en el Avance 3; se conserva la traducción literal de
  `チップフォルダ` y no se recrea ni modifica ningún tile.
- Reasignadas únicamente doce palabras BG0 en las celdas `(11,0)`–`(16,1)`
  para reutilizar los IDs `0x02A`–`0x030` y `0x037`–`0x03B`; atributos,
  paletas, banco gráfico, código, diálogo y datos dinámicos quedan intactos.
- El grafo de consumidores queda cerrado con exactamente dos consumidores
  previstos por patrón: la cabecera alterna de A3 y la pantalla principal.
- Frente a A4 cambian 14 bytes: doce bytes bajos del mapa y dos del checksum.
  El checksum WonderSwan almacenado/calculado es `0x5286`.
- Dos arranques limpios de MesenCore confirman 524 píxeles distintos dentro de
  `[88,0,136,16]`, cero fuera y coincidencia exacta de mapa/tiles entre ROM y
  RAM. Las pantallas de ordenación y mochila coinciden píxel a píxel con A4.
- Añadida la regla R25 de reutilización canónica: una instancia equivalente
  debe enlazarse al patrón aprobado antes de reservar o redibujar nuevos tiles.
- ROM privada SHA-256 `254bebaca20411516471e0cd5664f3d4234df5816d3e7f4087e7f6ecaa706522`
  e IPS acumulativo SHA-256 `2beb302099fc4b6c661c1db39722978cf83f6705b8edf7856d21e812e0627faf`.

## 0.10.7 Graphics Advance 4 — 2026-08-25

- Recompuestos los ocho campos de estadísticas de Program Deck con el glosario
  aprobado: `Normal30`, `Attack Power`, `Chip Heal Points`, `Speed Process`,
  `Capacity`, `Normal Navi`, `Normal Buster` y las dos capacidades inferiores.
- Los términos largos se distribuyen solo en límites de palabra y hasta dos
  filas; no se abrevia, filtra, escala ni aplica antialiasing.
- Los campos principales usan máscaras proporcionales BN5 de 7 píxeles; los
  descriptores y la leyenda usan la cara compacta nativa de 5 píxeles derivada
  del Avance 3 para no invadir valores ni conectores.
- El asignador reserva en una primera pasada todos los patrones fuente que aún
  necesita la composición final y asigna patrones nuevos en una segunda. Esto
  elimina las colisiones que podían degradar un rótulo procesado después.
- Se descartó una variante que usaba cinco tiles no referenciados por BG0:
  esos slots eran consumidos dinámicamente por el diálogo inferior. La versión
  final modifica cero tiles externos o no mapeados.
- Protegidos píxel a píxel `HP/SP/CS`, conectores, `140/210 MB`, `START`,
  iconos, diálogo inferior y las demás páginas del manual.
- La captura limpia a 224×144 registra 1.175 píxeles modificados dentro de los
  ocho campos y cero fuera; las ocho máscaras, el mapa y 5.824 bytes de tiles
  activos coinciden entre ROM y RAM.
- Añadidas las reglas R22–R24: glosario literal y propiedad semántica del
  conector, reserva de patrones en dos pasadas y auditoría entre capas/datos
  dinámicos.
- ROM privada SHA-256 `e640da75a810a3cc7699c93333d164dfbf444baef006c5d26bbec176d84d62c8`,
  IPS acumulativo SHA-256 `8c5dc76eb9a5841453f613d4babb3d1eb83e7fa114729b66c6f233b96e3302f9`
  y checksum WonderSwan `0x50F4`.

## 0.10.7 Graphics Advance 3 — 2026-08-25

- Reconstruidos `PROGRAM DECK Y4` y `CHIP FOLDER` en la cabecera alterna,
  conservando la fuente de pixel art seleccionada y la resolución nativa.
- Verificada la semántica contra la ROM japonesa: `チップフォルダ` corresponde
  a `CHIP FOLDER`; se descarta el rótulo previo `AUTO CONTROL`.
- Eliminado el segundo `Y4` oscuro que se dibujaba sobre el indicador naranja;
  cada parte usa ahora la zona de contraste y el color correctos.
- `CHIP FOLDER` mantiene un píxel mínimo entre letras, tres entre palabras,
  márgenes laterales de 4/5 píxeles y cero solapamientos.
- Eliminado el residuo de 8×16 a la derecha de `CHIP FOLDER`. Sus dos celdas
  usan ahora el fondo `0x2404`; el tile inferior `0x01C` está compartido y se
  conserva intacto para no dañar la otra pantalla que lo consume.
- Los 19 tiles objetivo son exclusivos; mapa, icono funcional, lista, paneles
  y toda la interfaz desde la fila 16 permanecen intactos.
- Captura limpia a 224×144: 478 píxeles modificados dentro de los tres
  rectángulos autorizados y cero fuera. Mapas y tiles activos coinciden con la ROM.
- Añadida la regla 20: fidelidad semántica, límites de palabra, contraste por
  campo y validación de coordenadas reales de pantalla con scroll.
- Añadida la regla 21: ningún gráfico adyacente ambiguo se considera funcional
  sin prueba de estado; los residuos con tiles compartidos se aíslan por mapa.
- ROM privada SHA-256 `2080294b6ad76580c8eb3060ecc49f8d8bde59291a21224f7b5337739f2cfe1c`,
  IPS acumulativo SHA-256 `0d7d2ca8d516489b8452f55438dda497fc39ecff363ed5fd6b299facf274b316`
  y checksum WonderSwan `0x33C6`.

## 0.10.7 Graphics Advance 2 — 2026-08-24

- Reconstruidos `PROGRAM DECK`, `NAVICHIP` y `BATTLECHIP` en la vista general
  del manual con máscaras de pixel art de 9 píxeles derivadas del rol de
  `BN5DSEU Font Thin` y retoque manual a resolución nativa.
- Corregida la geometría de `BATTLECHIP` contra la ROM japonesa: el cartel
  ocupa filas 6–7. La implementación descartada escribía en 7–8, duplicaba el
  texto y dañaba la cuadrícula púrpura inferior; esa franja quedó restaurada.
- Eliminados todos los restos de la fuente anterior; cada glifo conserva un
  píxel mínimo de separación, línea base y márgenes uniformes, sin filtros,
  escalado ni antialiasing.
- Asignados 32 tiles objetivo. Solo cuatro celdas internas de `PROGRAM DECK`
  se enlazan a IDs libres; los otros dos carteles conservan el mapa original.
- Cinco estados consecutivos a 224×144 verifican 832 píxeles modificados
  dentro de los tres carteles y cero fuera; diálogo inferior, diagrama,
  encabezado y bordes permanecen idénticos al Avance 1.
- La regresión acumulativa del Avance 1 vuelve a pasar sobre esta ROM: símbolo
  ausente, franja izquierda limpia y encabezados vecinos intactos.
- Añadida la regla 19: geometría tomada de la ROM original, máscara interna,
  paleta, componentes conectados y restauración de derrames previos.
- ROM privada SHA-256 `55616bc011c8439a693587c08dae9cf814801e61879ce280e253b0674e6004e5`,
  IPS acumulativo SHA-256 `2b54f43f19187feb59714d48be502d63b9bbdfbda1e1118de29619d13e55ba8c`
  y checksum WonderSwan `0xF4E1`.

## 0.10.7 Graphics Advance 1 corregido — 2026-08-24

- Reprocesada la eliminación del símbolo de 8×16 entre `PROGRAM DECK` y
  `Y2 CHIP FOLDER`; las dos celdas objetivo usan el fondo `0x240C`.
- Corregida la relación real del recurso: los tiles se cargan desde `0x8020`
  y el ID `N` del mapa consume el slot `N-1` del atlas.
- Restaurados `PROGRAM DECK`, `Y2 CHIP FOLDER`, el pictograma Y2 y el slot
  compartido `0x010`, cuyos 15 consumidores formaban la franja corrupta del
  borde izquierdo.
- Cerrado el grafo de consumidores: cero alias externos sin resolver y cero
  consumidores ajenos modificados.
- Delta frente a RC4: 310 bytes, todos dentro de mapa, tiles autorizados y
  checksum; cero escrituras fuera de allowlist.
- Validación limpia a 224×144 en pantalla raíz y barra de herramientas; mapas
  y tiles activos coinciden con la ROM, y no se usaron partidas ni savestates.
- Incorporadas 15 reglas acumulativas, con protección semántica de vecinos,
  auditoría de los cuatro bordes, allowlist visual global y reconstrucción
  independiente del IPS.
- ROM privada SHA-256 `63ce8069d89106fdc96167a14d139641db202d23e0a2cd539347e19f8fcd8575`,
  IPS acumulativo SHA-256 `874bb8a02d3f21e45883d1c051159c6721b1c9472f04458594b646c31f2f1fb0`
  y checksum WonderSwan `0xD36B`.

## 0.10.7 RC4 — 2026-08-24

- Preservada RC3 como base independiente; RC4 limita su alcance funcional a
  los desbordes de los cuadros inferiores, batalla/resultados y menú de pausa.
- Formalizada la geometría de la fuente dinámica 8×16: 19 columnas y tres
  filas cuando el retrato reserva 64 píxeles; 26 columnas sin retrato y ocho
  columnas por opción en la pausa.
- Corregidas 71 líneas normales de 20 columnas en 67 páginas y 52 entradas:
  56 páginas conservan el texto exacto mediante redistribución de `[LINE]` y
  11 usan condensaciones mínimas revisadas. Cero páginas exceden 19×3 y todas
  permanecen dentro de sus spans in-place.
- Regenerados los bancos B1/B2 conservando la topología de punteros nulos, los
  flags `0x80LL`/`0xC0LL` y la capacidad fija. Trece grupos B1 usan `0x0800`
  en su último registro y ninguno supera tres filas.
- Incluidos en la auditoría los casos aportados de parálisis, entumecimiento y
  bonificación de ataque por coincidencia Navi/chip.
- `VIEW DECK` pasa a `DECK` dentro del slot de ocho columnas, evitando que el
  texto cubra la opción `RETRY`.
- Cerrados generadores, manifiesto acumulativo y validación estructural: 3.355
  bytes distintos frente a RC3, cero fuera de 56 spans autorizados y cero
  recursos gráficos estáticos alterados.
- Cinco arranques limpios de MesenCore confirman el diálogo normal, la pausa y
  los tres casos aportados a 224×144. El grupo posterior permanece limpio y
  no se usaron SAV ni savestates.
- ROM privada SHA-256 `129ef89f09e2fef3a6c7f1acce11f62ff0c615ca583317e5e5b106f029bbe1b8`,
  IPS SHA-256 `1f4270eab41a0401381c8ba53087faa337436337933932dc3623d1cf4321d2e9`
  y checksum WonderSwan `0xCB1C`.
- El empaquetador determinista mantiene la
  exclusión de ROM, BIOS, TTF, partidas, savestates y emulador; dos
  generaciones consecutivas producen la misma huella.

## 0.10.7 RC3 — 2026-08-24

- Descartada completamente la RC2; la revisión se recompone directamente
  sobre la v0.10.6 con retoque manual de pixel art aprobada.
- Corregidas 17 incidencias tipográficas marcadas en rojo y armonizada una
  segunda instancia compartida de `NETNAVI`, para 18 rótulos semánticos y 19
  segmentos gráficos efectivos.
- Redibujadas a 1:1 las formas problemáticas de `M`, `N`, `W` y `G`, con
  contraformas abiertas, diagonales escalonadas, línea base uniforme y al
  menos una columna limpia entre glifos; sin filtros, antialiasing ni escalado.
- Reconstruidos `PROGRAM DECK`, `Y2 CHIP FOLDER`, `AUTO CONTROL`,
  `DATA LIBRARY`, `BACKPACK`, `NETNAVI`, `NAVICHIP`, `BATTLECHIP` y los ocho
  rótulos de estadísticas del manual.
- Limpiado el fondo nativo de `Y2 CHIP FOLDER` antes de dibujar para impedir
  contaminación del índice de color; márgenes 4/5 píxeles dentro de 56.
- Eliminado exclusivamente el símbolo blanco ajeno de la celda `(17,0)` del
  mapa de Program Deck. Se conservan la celda diminuta `(18,1)`, flecha Y2,
  icono de `AUTO CONTROL`, pantalla no marcada de `CHIP FOLDER` y cinco celdas
  mixtas de arte del manual.
- Tiles libres limitados a dos allowlists explícitas y comprobados sin
  referencias: cinco patrones del banco Program y diez del banco compartido;
  cero huérfanos en NetNavi o el manual y cero alias externos.
- Seis arranques limpios de MesenCore, 13 capturas a 224×144, mapas y tiles
  vivos exactos. La página de estadísticas coincide píxel por píxel con la
  paleta activa y el cuadro inferior permanece idéntico.
- Suite completa: 67 pruebas correctas, cero fallos y una prueba opcional
  omitida por ausencia de una partida privada.
- Delta frente a v0.10.6: 4.016 bytes —incluido checksum— dentro de 12 rangos
  guardados; cero cambios fuera de la allowlist y cero spans de diálogo.
- Reconstrucción final: ROM privada SHA-256
  `6b09ab76ef1608a94e014609d9b1e2fd350a3190c9e5866b885a190c3f98625c`,
  IPS SHA-256
  `165378b19042342d0f2cfd15b42edb2b003dadda0aa3d6df097fb2f80ec3f980`
  y checksum WonderSwan `0xE8FF`.

## 0.10.6 — 2026-08-23

- Reconstruidos 25 rótulos gráficos desde los TTF `BN5DSEU Font Thin` y
  `SF3FontSmall`; 70 variantes de glifo reciben retoque manual determinista a
  resolución nativa para reparar trazos, diagonales y contraformas. No se
  escala un atlas PNG, no se condensa la línea y no se aplican filtros ni
  antialiasing.
- `BN5DSEU Font Thin` se asigna a PET, SHOP, SAVE y banners largos;
  `SF3FontSmall` a encabezados/controles del teclado, `BACK` y `STREAK`.
- Corregido el solapamiento mediante avance por glifo, sombras solo inferiores
  y una separación mínima de un píxel entre compuestos. PET utiliza 63/63
  patrones seguros y SHOP 22/23.
- Actualizados `ENTRY NAME` y sus selectores, `SHOP`, `BATTLE CHIP GP`,
  `FREE BATTLE`, `HOST TOURNEY`, SAVE, las opciones de tienda y el rótulo
  dinámico `STREAK [n]`; los cuadros de diálogo inferiores quedan excluidos.
- `CLASS` pasa a la misma familia que el menú PET y conserva mayúsculas; `E`,
  `3000Z`, cursor, marco y créditos permanecen intactos.
- Actualizada la validación de `ABC` con los IDs de tiles vivos del nuevo mapa
  TTF; las máscaras `LOW/CAP/ABC` coinciden con sus recursos cargados.
- Corregida la pérdida del icono verde en la selección BATTLE CHIP GP mediante
  `A CLASS`–`E CLASS` → `A CLS`–`E CLS` dentro de los mismos slots; cero
  punteros movidos y cursor/iconos OBJ intactos.
- MesenCore validó nueve arranques limpios y 45 capturas nativas. Los activos
  vivos coinciden con la ROM final en PET, teclado, SAVE, SHOP y las rutas
  Free/Host.
- Conservados byte a byte los 249 efectos de chip de v0.10.5, incluidos el
  máximo de seis caracteres y `NODATA`; 1.552/1.552 textos y 129/129 gráficos
  continúan cubiertos.
- Delta frente a v0.10.5: 4.918 bytes dentro de 21 spans guardados y
  checksum; cero cambios fuera de allowlist y cero spans de diálogo.
- Reconstrucción final: ROM privada SHA-256
  `fb78269238806807616cfe622a3be9239dc5b95bbd454ee02127919dd463e3cc`,
  IPS SHA-256
  `d7df4954bd3509865abf3fabf99a3ba6bc8b17bb22b2855d52cd85907e7a56f6`
  y checksum WonderSwan `0x937D`.

## 0.10.5 — 2026-08-22

- Limitados a seis caracteres todos los rótulos de efecto de las fichas
  grandes, conservando completos números y modificadores `~`/`+`.
- Aplicada una regla determinista sin colisiones: 43 efectos únicos y 194
  apariciones actualizadas; ejemplos `NORMAL60` → `NORM60`, `NORMA120` →
  `NOR120`, `PIERC90+` → `PIE90+` y `~ADD50+` → `~AD50+`.
- El rótulo compartido de reservas cambia de `NO DATA` a `NODATA` en sus 136
  apariciones. Las capas informativas independientes `NO DATA` no se alteran.
- Conservados los 249 punteros, los cinco efectos especiales vacíos y los 70
  destinos únicos sin colisiones ni repacado del banco.
- Delta frente a v0.10.4 limitado a 185 bytes del banco
  `0x369550–0x36A4DF` y dos bytes de checksum; cero cambios fuera de la
  allowlist.
- MesenCore validó `NORM60` y `NODATA` a 224×144 mediante una ruta limpia a
  CHIP FOLDER, sin SAV ni savestate; mapas y tiles vivos coinciden con la ROM.
- Reconstrucción final: ROM privada SHA-256
  `e51d45b3a02161d20c9de136d610f9b1fc268752ca6ce29a16f308568bc082bf`,
  IPS SHA-256
  `06823e482d4ae7f94fe2dc3cd75201e5d980243b54b6462714f6061bc023cdae`
  y checksum WonderSwan `0x71B2`.
- Suite automatizada: 47 pruebas correctas, cero fallos y una prueba opcional
  omitida.

## 0.10.4 — 2026-08-22

- Reconstruido el título usando exclusivamente el PNG indexado 224×144
  suministrado, con su transparencia `tRNS` real; se elimina la interpretación
  errónea del negro transparente como fondo opaco.
- El logo se adapta por recorte alfa y nearest-neighbour a 196×99 píxeles en
  `(14,4)`, usa 194/208 tiles, deja 14 libres y termina en `y=102` antes de
  `PRESS START`.
- Conservados byte a byte el fondo animado, las cinco paletas, créditos,
  filas 14–17 y columnas ocultas del mapa.
- Rediseñadas `PROGRAM DECK`, `CHIP FOLDER`, `DATA LIBRARY`, `NETNAVI` y
  `SAVE` con fuente de bloque nativa de 7 píxeles de alto y ancho variable,
  contorno de un píxel y sin antialiasing; 57/57 patrones disponibles.
- La prueba runtime descubrió y corrigió una colisión que la vista estática no
  mostraba: el tile `0x45` pertenece a la esquina inferior del marco en la fila
  dinámica 16. Ahora queda protegido y el recuadro coincide con el original.
- MesenCore validó la portada en frames 450/550, la transición START en el
  frame 900 y el menú PET en el frame 27000, siempre a 224×144 y desde
  arranques limpios sin SAV, savestate ni inyección.
- Captura PET idéntica píxel a píxel a la referencia construida; tiles y mapa
  vivos coinciden con los activos, y `CLASS`, cursor, panel, `Z`, rango,
  créditos y marco permanecen intactos.
- Delta frente a v0.10.3 limitado a cuatro spans gráficos más checksum:
  7.467 bytes distintos, cero fuera de allowlist y cero dentro de pools de
  texto.
- Reconstrucción final: ROM privada SHA-256
  `ba315859105dbb2acbc5c775f00ec8c9b09f612fd9d3cd00e5a49e4670c4cbb2`,
  IPS SHA-256
  `025c2012a3e29183d81d75958175b36a19a81058275e259452e8efd89ebc3f1b`
  y checksum WonderSwan `0x7684`.
- Suite automatizada: 45 pruebas correctas, cero fallos y una prueba opcional
  omitida.

## 0.10.3 — 2026-08-22

- Cerrada la auditoría de los siete pantallazos señalados: todos los hallazgos
  quedan corregidos o clasificados como arte funcional original.
- Corregida la portada de v0.10.2 mediante una máscara sustractiva explícita:
  se eliminan 384 píxeles opacos ajenos al logo, 340 del fondo animado y 44 de
  separación respecto a `PRESS START`.
- El logo final ocupa 191/208 tiles, deja 17 libres y termina en la fila 102;
  `PRESS START` empieza en la 103, con cero píxeles de solapamiento.
- Reconstruidas las tres máscaras OBJ dinámicas del teclado `LOW`, `CAP` y
  `ABC`. El mapa y los tiles ingleses permanecen intactos y `LOW` queda como
  página inicial coherente.
- Corregidas seis celdas de paleta del bloque `CAPACITY`, eliminando el
  rectángulo violeta observado en Program Deck.
- Rediseñados en fuente nativa 5×7 y píxel entero los rótulos
  `LIKELY / CHIPS`, `2 CHIPS / LEFT`, `MIDDLE / 1 CHIP` y
  `PRESS START / DECK INFO`.
- La flecha superior y el pictograma de tipo/ranura se verificaron como
  elementos funcionales originales; sus tiles permanecen byte a byte iguales
  a la ROM japonesa.
- MesenCore validó en arranques limpios la portada, sus dos estados de
  parpadeo, la transición a `NEW GAME / CONTINUE`, las tres páginas del
  teclado y las vistas `stats`, `order` y `tool` de Program Deck a 224×144.
- Reconstrucción final: ROM privada SHA-256
  `eb53372aa5e7e3b202dab7959669d6787c4776c487f9860951012ffb6d8f08dc`,
  IPS SHA-256
  `db366d9d14b30f72185ef91b3c3e47c5d034281b4dc7f8b913a1279838e31dc7`
  y checksum WonderSwan `0xAFC4`.
- Validación estructural en `PASS`, informe SHA-256
  `f8d64503aab0f9381ab0fbbf8bec18d2445fc650e12a4395aea2ad7beb3d57a6`;
  barrido residual en `PASS`, informe SHA-256
  `e0f7756f2d2815e9a12cce2dc6faa68426ec679725a25c393a2c502a47ea819a`.
- Suite automatizada: 32 pruebas correctas, cero fallos y una prueba opcional
  omitida.

## 0.10.2 — 2026-08-22

- Sustituido el logotipo japonés por `MEGA MAN / BATTLE NETWORK / N1 BATTLE`,
  reconstruido como capa nativa transparente en lugar de importar una captura
  completa.
- Maestro RGBA real de 224×112, alfa binario, 50 colores opacos RGB444 y
  round-trip exacto a tiles 8×8 packed 4-bpp, sin dithering.
- El título usa 194/208 tiles y deja 14 libres. El mapa cambia en 216 celdas:
  nueve añadidas, 26 limpiadas y 181 remapeadas.
- Solo se modifican el banco aislado de tiles del logo y las filas 0–13 de su
  mapa. Fila 14, créditos de filas 15–17, columnas ocultas 28–31 y las cinco
  paletas permanecen byte a byte intactos.
- Reconstrucción final: ROM privada SHA-256
  `b6bdab3a957eac00fb9bac9aadd681d1c9495a9487cde0bef50b4eecc0125f24`,
  IPS SHA-256
  `a163fc6bef9932eab9d408afbc182d2afb7e5c8f46e514d11229e9821e18d608`
  y checksum WonderSwan `0x383A`.
- Inventario actualizado a 1.552/1.552 textos y 129/129 gráficos
  localizables. El logotipo ya no se registra como excepción de marca.
- Validación estructural en `PASS`, informe SHA-256
  `863abca9af78a801b2219a6c7072db1f92676448e574a82e5c193a72fcf2b561`;
  barrido residual en `PASS`, informe SHA-256
  `f5a19dcc70633669298e69150e9040b0473dbc5da52a419c35b4ae9d3714ed27`.
- MesenCore confirmó en arranque limpio los frames 450 y 550 del parpadeo de
  `PRESS START` y el frame 900 de `NEW GAME / CONTINUE`; tiles, mapas,
  paletas y recursos vivos coinciden con los activos esperados.
- Suite automatizada: 24 pruebas correctas, cero fallos y una prueba opcional
  omitida.

## 0.10.1 — 2026-08-22

- Restaurado el logotipo original de la edición WonderSwan, conservando su
  banco de 208 tiles, mapa, cinco paletas, animación y composición 224×144.
- Eliminado del manifiesto el reemplazo `MEGA MAN / 1 BATTLE`; no se distribuye
  una copia del activo japonés porque el parche deja intacta la ROM fuente.
- Corregidos los efectos de las tarjetas grandes: las 108 cadenas no vacías se
  normalizan a mayúsculas para la fuente nativa 8×16 (`Normal60` → `NORMAL60`).
- Solo cambian 251 bytes del banco de efectos `0x369550–0x36A4DF`; punteros,
  daño, código, descripciones, mapas, tiles e ilustraciones permanecen iguales.
- Validación estructural y residual en PASS: 1.552/1.552 textos, 128/128
  gráficos localizables y un logotipo de marca preservado por decisión
  artística. ROM privada SHA-256 `5affee17034c24a17fbc50096ae534b463f6879896c6dd320a54fe0db53bf64b`.

## 0.10.0 — 2026-08-22

- Reapertura de la cobertura gráfica tras comprobar que el 75/75 de v0.9 no
  incluía estados internos de Shop, mapas PET desplazables ni menús Host/Free.
- Inventario ampliado en 54 ocurrencias: Shop (3), carrusel Free/Host (2),
  Host/Free profundo (31) y estados PET profundos (18); cierre en 129/129.
- Shop muestra `1 CHIP`, `10 CHIPS` e `INFO` sin modificar precios, Zenny,
  cursor, marco o diálogos.
- Free Battle muestra `STREAK:` y conserva el contador dinámico BG1; las
  tarjetas del carrusel muestran `FREE BATTLE` y `HOST TOURNEY`.
- Traducción de gestión Host: roster, registro NaviCode, brackets, cantidad de
  participantes, selección/borrado de entradas y tablas de resultado.
- Traducción de barras START/Y4 de Program Deck, ordenación y mochila
  `BACKPACK` de Chip Folder, estadísticas NetNavi y tarjeta compartida
  `NO CHIP / IS / SELECTED`.
- Revisión contextual final de `Pack: 10 chips?`, `Fix the Chip Folder` y
  `Host your own tournament.`, conservando capacidades y punteros internos.
- Ajuste contextual de dos líneas dinámicas a `Cls … Tour` y `Host Tour # …`
  para impedir concatenaciones en el ancho real del cuadro de diálogo.
- Todos los activos nuevos se renderizan a 224×144, con tiles 8×8 4-bpp,
  paletas BGR444, píxel entero y sin antialias; no se redimensionan marcos ni
  fondos.
- Validación MesenCore sobre la ROM final: 10 arranques limpios y 46 capturas
  nativas; una sonda controlada adicional abre la confirmación de 10 chips sin
  alterar ni distribuir la ROM final.
- El barrido de 1.552 destinos textuales continúa en PASS y la reconstrucción
  canónica produce ROM privada SHA-256
  `0c244f227032e771ca542447e092ffd47763ae88d9ed88152e83a6ad45e7cb69`,
  IPS `eb59d8fed207c53d84843dba024f81a706bcfebedacaaaebd0383e5d50e0e5ed`
  y checksum WonderSwan `0x71ED`.
- Se conserva intencionalmente el logotipo legal japonés de Inti Creates del
  arranque. El paquete público continúa excluyendo ROM, BIOS, firmware, SAV,
  savestate y emuladores.

## 0.9.0 — 2026-08-22

- Auditoría profunda de las seis tablas de texto, bases far-pointer, registros
  directos, bancos de batalla y ROM completa; el denominador textual verificable
  pasa a 1.552 unidades.
- Traducción de 347 unidades omitidas por el inventario de v0.8: 88 destinos
  auxiliares, confirmación de sobrescritura, 73 participantes y 185 mensajes de
  batalla/resultado.
- La métrica heredada se retira: con el nuevo denominador, v0.8 representaba
  1.205/1.552 (77,64 %). v0.9 alcanza 1.552/1.552 (100,00 %) y cero destinos
  referenciados con japonés.
- Auditoría gráfica ampliada a 75 ocurrencias: teclado, PET y Program Deck
  completos, `NORMAL30`, transferencia, cabecera y 15 fases de torneo, rótulos
  de tienda/GP/sede, y el póster de `Rockman DASH 2` adaptado como `MM/L2`.
- El póster se identificó contra una publicación oficial de Capcom y el contexto
  compartido con EXE1; solo seis tiles exclusivos del logotipo se modifican.
- La QA dinámica detectó que una primera implementación mostraba `ROUND3` para
  la ronda 13; el renderizador se reabrió y se validaron rondas de uno y dos
  dígitos, semifinal y final en arranques limpios.
- Auditoría estática específica de la máquina de créditos: 58/58 slots y los
  dos bloques del epílogo en inglés, sin loader gráfico japonés dedicado; la
  ausencia de un recorrido orgánico hasta créditos queda documentada.
- Manifiesto sin solapamientos, reconstrucción canónica, IPS, checksum WSC,
  allowlist de cambios, escáner residual y 19/19 pruebas automatizadas.
- El paquete público continúa excluyendo ROM, BIOS, firmware, SAV, savestate y
  emuladores.

## 0.8.0 — 2026-08-22

- Cierre de las cuatro familias gráficas pendientes: logotipo principal,
  teclado de nombre, etiquetas PET y cinco vistas internas de Program Deck.
- El registro arranca en la página latina sin pulsación manual y muestra
  `ENTRY NAME`, `REGISTER`, `JP1`, `JP2`, `ABC`, `BACK` y `OK!`.
- El menú PET muestra `PROGRAM DECK`, `CHIP FOLDER`, `DATA LIBRARY`,
  `NETNAVI`, `SAVE` y `CLASS`.
- Program Deck integra dos atlas y cinco mapas BG0 verificados. La auditoría
  final cotejó 221/221 tiles objetivo con VRAM y cero divergencias.
- Un primer activo Program Deck fue rechazado por truncamientos; una segunda
  auditoría detectó que se cubría parte de un `PROGRAM DECK` ya inglés. El
  mapa final preserva ese rótulo y repitió las cinco capturas limpias.
- Manifiesto final: 270 entradas textuales y 28 binarias, sin solapamientos ni
  cambios fuera de spans autorizados.
- Build directo, reconstrucción canónica e IPS aplicado idénticos; ROM privada
  SHA-256 `963ffd2830b23390dabb2cafa5c7b58afea93005525591643fa0a6e1714331f0`,
  IPS SHA-256 `8274e3bead5ee21ee6a4d64a1f2a88e07aa4f32d67eb5417dfc26a340cf61a47`
  y checksum WSC `0x487C`.
- Regresiones limpias de MesenCore para logo, teclado, PET y Program Deck;
  MAME 0.289 completó `wscolor -bench 10` con código 0; 19/19 pruebas.
- Avance global reproducible: **100,00 % del alcance inventariado**, diez
  puntos porcentuales más que v0.7.

## 0.7.0 — 2026-08-22

- Traducción in-place completada para los **274/274 destinos únicos de
  diálogo** inventariados: 270 entradas físicas conservan 289 punteros
  válidos, aliases y cinco entrypoints interiores sin relocalización.
- Incorporación del resto de torneos, presentaciones y resultados, Free
  Battle, Open Battle, tienda, progresión, consejos, recompensas y final.
- Segunda familia gráfica terminada: las dos portadas recurrentes del manual
  muestran `PROGRAM DECK MANUAL` mediante un activo packed 4-bpp reproducible.
- Validación limpia en MesenCE de combate → resultado → regreso y de guardado
  real → cierre → `CONTINUE`; flujo pasa a 10/10.
- Firmware privado `wswan`/`wscolor` aceptado por MAME 0.289; el build final
  completó un bench de 10 segundos con código 0.
- Manifiesto final: 270 entradas textuales y 15 binarias, 0 solapamientos,
  270/270 capacidades válidas y 0 cambios fuera de la allowlist.
- Build directo, reconstrucción canónica e IPS aplicado idénticos; ROM privada
  SHA-256 `61ed73b6ec0dab709550f3ce7a2124ead24d9e296dc03b0e5ab6f2ec7af7dba0`,
  IPS SHA-256 `8caf531e224cf26889a181e3fb7b364a049c155877ffc28ec01b8fa30565956d`
  y checksum WSC `0xDA67`.
- Validación estructural y auditoría independiente en PASS; 19/19 pruebas.
- Avance global reproducible: **90,00 %** (+46,54 puntos frente a v0.6). Solo
  quedan cuatro familias gráficas: logotipo, teclado, PET y Program Deck.

## 0.6.0 — 2026-08-21

- Traducción in-place de 16 presentaciones `01:1D–01:2C`: semifinal y final
  de Sapling, los torneos Droplet y Battery completos y las seis rondas de
  Quick.
- Revisión contra la localización oficial USA, incluidos `M-Cannon` para la
  semifinal de Sapling y los nombres propios de chips de cada encuentro WSC.
- Traducción de los 49 ataques Navi mediante 40 cadenas inglesas únicas,
  repacadas en los 31 spans originales con 90 bytes libres y sin ocupar sus
  huecos intermedios.
- Corrección del remapeo por identidad de los operadores genéricos Navi-A,
  Navi-F, Navi-E y Navi-W, que en 0.5 seguían un orden de índices incorrecto.
- 83 bloques textuales y 13 binarios totales; los 16 spans nuevos suman 3.508
  bytes, conservan las tablas de punteros de diálogo y respetan 20 caracteres
  por línea y tres líneas por página.
- Avance global medido en 43,46 %; diálogo identificado en 82/274 (29,93 %)
  y cobertura por spans en 19.130/52.346 bytes (36,55 %).
- Build directo e IPS aplicado idénticos; ROM final SHA-256
  `b416180a5796a56300c5421b583a772b05535c8282b2cf9708b9291b6a4d3e29`
  y checksum WSC `0x7143`.
- MesenCE aprobó smoke, observación de punteros y el render completo de cuatro
  páginas en `01:1F` y `01:28`; Mednafen 1.29.0 confirmó arranque, SRAM y
  checksum en una segunda implementación.
- El observador reescribe y coteja el manifiesto de capturas al finalizar para
  impedir que una sesión se acepte con filas faltantes.
- Auditoría del set MAME: `wswan.zip` coincide con el firmware padre
  monocromo, pero el arranque `wscolor` aún requiere sus dos recursos Color.

## 0.5.0 — 2026-08-21

- Traducción in-place de 12 presentaciones `01:11–01:1C`: torneos Guts,
  Healing y Match completos, más Round 1 y Round 2 de Sapling.
- Revisión contra la localización oficial USA, conservando rivales, atributos
  y chips específicos de WonderSwan como `HiCannon` para GutsMan y
  `HeatSprd` para FireMan.
- 67 bloques de texto y 11 bloques binarios totales; los 12 spans nuevos
  suman 2.564 bytes, no alteran ninguna tabla de punteros y respetan 20
  caracteres por línea y tres líneas por página.
- Avance global medido en 39,95 %; diálogo identificado en 66/274 (24,09 %)
  y cobertura por spans en 15.622/52.346 bytes (29,84 %).
- Build directo e IPS aplicado idénticos; ROM final SHA-256
  `232783ad3112dc9d5c8c89dd30d6b91b7c9843837b7e18823455e87cf7a22bd5`
  y checksum WSC `0xB133`.
- Ruta limpia de MesenCE 2.2.1 validada hasta BattleChipGP, briefing y
  `Novice Tournament` Round 1; smoke independiente en Mednafen 1.32.1.
- En el paquete limpio pasan 13 pruebas autocontenidas y se omite una prueba
  opcional que necesita un guardado privado; esa prueba adicional también
  pasó en el entorno de investigación.

## 0.4.0 — 2026-08-21

- Traducción in-place de los 12 tutoriales de torneos `01:02–01:0D`, alineados
  con los grupos oficiales USA 497, 500, 504–510 y 515–517.
- 55 bloques de texto y 11 bloques binarios totales; los nuevos spans suman
  5.212 bytes y conservan 190 words de relleno, sin alterar punteros.
- Observador dinámico de Mesen con catálogo de 289 IDs válidos, capturas PNG,
  TSV/JSON y galería HTML/Markdown reproducible.
- Modo `FORCE` experimental con barreras de hash, firma, tabla, grupo y
  terminador; validado con una redirección desechable `00:10→00:14`.
- Integración externa de BizHawk 2.11: grabación/replay con firmas de RAM y
  sonda ramificada del PET usando estados temporales en memoria.
- Herramienta conservadora para validar, comparar, reparar y convertir SRAM de
  N1 Battle entre formato crudo y SaveRAM de BizHawk/Cygne.
- Ruta manual de 53 capturas repetida sobre v0.4; build directo e IPS aplicado
  idénticos, checksum WSC válido y pruebas automatizadas correctas.

## 0.3.0 — 2026-08-21

- Traducción de 31 bloques nuevos sin relocalización ni cambios de puntero.
- Manual Program Deck completo, adaptado a las reglas reales de WonderSwan:
  1 NaviChip, hasta 9 BattleChips, CS, selección del 50 %, SP y 20 turnos.
- Traducción de ayudas y confirmaciones de compra, recepción, Free Battle,
  torneos, estado, guardado, clase, Zenny, resultados y nombre inválido.
- Diálogo de Yai hasta la sede, explicación del `Novice Tournament` y
  presentaciones oficiales de Round 1, Semi-Finals y Finals.
- Alineación de 116 punteros WSC con grupos de la localización USA; se conserva
  `Cannon` para NumberMan porque el GBA usa un encuentro distinto con `Prism`.
- Ajuste de todas las líneas nuevas a un máximo visual de 20 caracteres y tres
  líneas por página.
- Ruta Lua reproducible desde `NEW GAME` que abre el manual sin SAV ni
  savestate de WonderSwan; 53 capturas en Mesen 2.1.1 sin fallos.
- IPS reproducible, checksum WSC válido y equivalencia byte por byte entre el
  build directo y el IPS aplicado.

## 0.2.0 — 2026-08-21

- Validación de `Mega Man Battle Chip Challenge (USA)`, revisión `A89E`.
- Descubrimiento y extractor reproducible del guion oficial completo: 3.879
  grupos y 17.209 líneas.
- Revisión de los 11 segmentos anteriores contra los grupos oficiales 187–219.
- Traducción adicional del bloque del público, grupo oficial 191.
- Importación limitada a los datos realmente existentes en WSC: 113 chips.
- Traducción de 249 slots de nombres, 249 efectos, 249 filas descriptivas y
  135 nombres de personajes; las reservas permanecen como `NO DATA`.
- Repunteo far con offsets completos y deduplicación dentro de pools
  verificados; ninguna escritura fuera de los rangos conocidos.
- Validador/extractor GBA y scripts de reproducción para Windows.
- Validador reproducible del SAV USA de 32 KiB, incluidos sectores, redundancia,
  checksums y resumen del progreso.
- Parche IPS reproducible y recorrido automático en Mesen 2.1.1.

## 0.1.0 — 2026-08-20

- Verificación exacta de la ROM japonesa Rev 1.
- Extractor de cinco grupos de diálogo conocidos.
- Constructor in-place con validación de fragmentos y checksum WSC.
- Generador/aplicador IPS independiente.
- Traducción inglesa de 11 segmentos del prólogo.
- Sustitución in-place de `NEW GAME / CONTINUE` en los cuatro estados gráficos.
- Scripts Lua y capturas de validación para Mesen 2.1.1.
