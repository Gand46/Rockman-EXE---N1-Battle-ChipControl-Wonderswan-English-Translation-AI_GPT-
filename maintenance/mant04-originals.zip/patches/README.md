# Current player-facing cumulative patches

| Variant | Direct Japanese ROM → English BPS | Release |
| --- | --- | --- |
| **QA09 MANT04** | [QA09 MANT04](qa09/Rockman_N1_English_QA09_MANT04.bps) | Mainline |
| **QA09 MANT04 + Chip Control RC6** | [Experimental RC6](chip-control/Rockman_N1_English_QA09_ChipControl_RC6_MANT04_EXPERIMENTAL.bps) | Optional experimental |

Apply **one** BPS to the original ROM described in [project.json](../project.json). Do not stack patches. Previous QA09 MANT03 patches are retained as provenance under `maintenance/baseline-patches/`, not as the recommended player release.
