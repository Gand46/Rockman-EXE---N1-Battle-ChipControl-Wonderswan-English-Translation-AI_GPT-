# Rockman EXE N1 Battle — Localización inglesa MANT04

Versión principal **QA09 MANT04**, con cinco incidencias gráficas revisadas. Chip Control RC6 se ofrece como variante **opcional y experimental**; ambos parches BPS son acumulativos directamente desde la misma ROM japonesa Rev. 1, no se aplican en cadena.

El ZIP contiene fuentes acumulativas y editables, rutinas y mapas de recursos, generadores de tiles, pruebas, documentación y los dos BPS; **no contiene ROMs originales ni partidas privadas**.

## Compilar

```sh
python scripts/project.py build --source /ruta/ROM_original.wsc --variant all
python scripts/project.py verify --source /ruta/ROM_original.wsc
```

Windows: `scripts\build.bat "C:\ruta\ROM_original.wsc" --variant all`.

La ROM debe tener 4.194.304 bytes y SHA-256 `4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed`. No se modifica el archivo original.

**Cambios:** PET alineado con el cursor; SHOP, HOST TOURNEY y FREE BATTLE emplean máscaras coherentes con el estilo del juego; `NAME / ATK / TYPE` comparten baseline de 6 píxeles con `HP / SP / CS`; el pequeño dibujo naranja de `TOTALCHIPS` se identifica como arte original y se conserva. Estas modificaciones no reescriben código de combate o guardado.

[Informe MANT04](reports/qa13-visual-repairs.html) · [Datos técnicos](qa13-visual-repairs.md) · [Historial](reports/index.html)

**Alcance:** PASS técnico y visual en las pantallas representativas comprobadas, no certificación global del juego ni de hardware. El código original ensamblador RC6 no está presente; el adaptador binario sí es editable. Derechos del payload RC6 pendientes de confirmar antes de publicar.
