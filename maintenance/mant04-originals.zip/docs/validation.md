# Validation scope — QA09 MANT04

The historical QA09 MANT03 has the documented `PASS_SYNTHETIC_SCOPED` status. QA13/MANT04 adds guarded changes to six graphical groups: PET root alignment, carousel SHOP, FREE BATTLE and HOST TOURNEY banners, SHOP purchase labels, and Program Deck sorting captions. Original Japanese `TOTALCHIPS` orange accent is preserved because it is pre-existing native artwork.

**New rebuild:** QA09 + optional RC6 generated from the same verified 4 MiB JP ROM; source-guard checks enforce exactly the changed tile/graphics spans and WonderSwan checksum, with no code or SRAM writes. Optional RC6 has zero overlap with changes to gameplay patch bytes. Current hashes in [project.json](../project.json).

**New scoped runtime:** actual emulator captures after reloading their graphical consumers verify the intended changed regions and a 5-frame-set Chip Control battle path compares 65,536 RAM bytes and 224×144 pixel output with pre-repair RC6. See [full report](reports/qa13-visual-repairs.html) and [visual repair method](qa13-visual-repairs.md). Screenshots loaded directly from savestates can contain stale VRAM before a transition: those are not proof of changed ROM tiles. The report identifies the access method.

**Limitations:** no physical hardware validation; no exhaustive battle, UI, save/load, progression or complete-playthrough certification. Historic SRAM and state fixtures are excluded from GitHub; tests requiring them are marked skipped, not passed. Chip Control remains experimental and its original editable assembly is not present.
