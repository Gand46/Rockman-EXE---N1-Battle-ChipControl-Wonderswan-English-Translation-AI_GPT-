# Build and reproducibility

**Current release:** QA09 MANT04. Python ≥3.11. Normal build is standard-library-only; full tests require `python -m pip install -r requirements/qa.txt`.

Provide the original unmodified 4 MiB JP `.wsc`, SHA-256 `4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed`, outside the repository.

```sh
python scripts/project.py build --source /path/original.wsc                   # QA09 MANT04
python scripts/project.py build --source /path/original.wsc --variant all     # QA09 and RC6 MANT04
python scripts/project.py check
python scripts/project.py verify --source /path/original.wsc
```

Builds produce `build/mant04/<variant>/` files and do not modify original ROMs or editable resources. The MANT04 builder regenerates historical QA09 MANT03 from the editable cumulative resource manifest in a separate temporary build folder, compares the historical RC6 IPS's hashes, and applies only verified graphic cell/tile diffs to each variant. It checks checksum and direct-original BPS roundtrip. See [visual repairs](qa13-visual-repairs.md).

For baseline reconstruction only: `python scripts/project.py build --source /path/original.wsc --baseline --variant all`. To examine intentional manifest modifications, `--allow-modified` builds an isolated **baseline dev** artifact and bypasses release identity verification; do not mistake it for MANT04.

Windows: `scripts\build.bat "C:\Games\original.wsc" --variant all`. macOS/Linux: `bash scripts/build.command "/path/original.wsc" --variant all`.

CI performs source-only checks. Private SRAM/savestates are deliberately absent and corresponding runtime tests are explicitly marked skipped. Local emulator comparison is recorded in the QA13 evidence, not asserted as a complete gameplay test.

Pack after explicit source validation and snapshot refresh:

```sh
python scripts/project.py check --structure-only
python scripts/project.py snapshot
python scripts/project.py package --output ../Rockman_N1_MANT04_sources.zip
```

The packaging process rejects commercial ROMs, game saves and emulator executables. Historic QA09 MANT03 BPS remain under `maintenance/baseline-patches` solely for provenance and regression comparisons.
