# Rockman EXE N1 Battle — English QA09 MANT04

WonderSwan Color localization with an **optional, experimental Chip Control RC6** extension. This repository contains complete cumulative editable sources and two independent BPS patches. **No original commercial ROM, save states or SRAM is distributed.**

[Español](docs/es.md) · [Build](docs/build.md) · [Changes MANT04](docs/qa13-visual-repairs.md) · [QA report](docs/reports/qa13-visual-repairs.html) · [Historical reports](docs/reports/index.html)

## Choose one patch

| Variant | BPS to apply directly to the Japanese ROM | Status |
| --- | --- | --- |
| **QA09 MANT04** | [English MANT04](patches/qa09/Rockman_N1_English_QA09_MANT04.bps) | Default; scoped visual/runtime QA |
| QA09 MANT04 + Chip Control RC6 | [RC6 MANT04 experiment](patches/chip-control/Rockman_N1_English_QA09_ChipControl_RC6_MANT04_EXPERIMENTAL.bps) | Optional experimental integration |

Both patches require the **4,194,304-byte unmodified Japanese ROM** (SHA-256 `4aeaf266e8705772c832652d374e6147c544e37b45f6fd5b1ad9e0aa0d2fd6ed`). Apply **only one patch directly to the Japanese ROM**; do not stack IPS/BPS versions.

## Build the current versions from source

Python 3.11 or later; no external dependencies for normal builds:

```sh
python scripts/project.py build --source "/path/to/original.wsc"
python scripts/project.py build --source "/path/to/original.wsc" --variant all
```

Output: ignored `build/mant04/qa09/` and `build/mant04/chip-control/`. Windows: `scripts\build.bat "C:\path\original.wsc" --variant all`; macOS/Linux: `bash scripts/build.command /path/original.wsc --variant all`.

**Source chain:** verified Japanese ROM → QA09 editable manifest/resources → bounded tile-map visual repair → QA09 MANT04. The optional RC6 engine is applied only through a hash-guarded binary adapter based on the historical RC6 IPS; it has no recovered editable RC6 assembly. The language assets, manifest, visual repair algorithm, masks and checks are editable. Nothing overwrites the base ROM.

## Test and verify

```sh
python -m pip install -r requirements/qa.txt
python scripts/project.py check
python scripts/project.py verify --source "/path/to/original.wsc"
```

A verified `--baseline` build regenerates historical QA09 MANT03, **not** the current release: `python scripts/project.py build --source original.wsc --baseline --variant all`. Its BPS evidence lives under `maintenance/baseline-patches/`. The old A9/RC6 IPS are in the optional component vendor directory; they are not public player instructions.

The release is **not a full natural playthrough/hardware certification**. See [QA scope](docs/validation.md).

## Repository layout

- `components/qa09/`: cumulative editable localization, atlases, maps, assembler support and tests.
- `components/chip-control/`: optional RC6 binary adapter, tests and provenance.
- `scripts/`: guarded normal/legacy builders and MANT04 source renderer.
- `patches/`: **two current** player-facing cumulative BPS patches only.
- `docs/`: current instructions, scoped graphic evidence and consolidated HTML reports.
- `maintenance/`: historic baselines, migration inventory and test receipts.

Game assets and RC6 payload have separate rights. The supplied RC6 materials do not establish distribution permission for its IPS-derived code. Verify rights before publishing RC6 binaries. See [provenance](docs/provenance.md) and [publication](docs/publication.md).
